# V01 round-two disposition

Exact source 8c37322d59eaab20e761ee093e9f8729702b3822, tree 7801aeaf3b6035953fe370ed1222dd53dd7caed9. Comment PASS. Reviewer A completed with REQUEST CHANGES. The user-authorized fourth Cursor attempt completed with APPROVE. Both have no pending runs. The first three Cursor attempts failed without usable verdicts and remain retained.

Accept A's one P2. Ordinary executable branch ranges rejected for nested overlap can disappear from coverage while a positive entry or statement supplies 100 percent fallback. A's in-memory CC10 probe changes CRAP 110 to 10 with unchanged source and observations. Current V8 emission of that synthetic fixture remains unverified. The retained zero range 142:0 and resulting commands.ts increase are directly observed.

B independently confirms the increase is invocation credit, not path coverage, and that no archived row crosses the threshold. Neither point resolves the demonstrated reporter false pass. The parent therefore accepts A's finding. Owner read-only triage agrees and retracts the previous justification of that increase.

A1 exact stage completeness, A2 compiler configuration binding, the erased-only part of A3, and the fixture documentation correction are accepted. No production defect or new policy change is diagnosed by this round.

## Released scope

The sole existing V01 owner may correct tooling, tooling tests and current documentation in its exclusive checkout. If an executable ordinary range is rejected for nested-function overlap, record an explicit ambiguous-branch mapping problem. It must fail that parent's coverage mapping regardless of the rejected count and even if other accepted observations remain. Preserve rejected ranges, counts, reasons and valid entry proofs. Keep nonexecutable/erased-only rejection and existing independently justified root/entry mapping. Do not invent a new attribution algorithm in this correction.

Add focused regressions for A's positive-entry CC10 threshold crossing, positive-statement fallback, mixed accepted/rejected branches, zero and positive rejected counts, and the retained 142:0 case. Preserve the original ten missing observations as failures. Use literal expected mapping/failure outcomes.

Run the targeted tooling suites with one test-file worker and a new retained-data recalculation. Record changed row/failure counts, every source identity and the precise effect on the disputed increase. Preserve all prior source-bound reports and failures as historical artifacts. Correct current documentation without rewriting the old evidence.

Do not change production code, backend tests, fixture data, dependencies, compiler policy, mutation thresholds/denominator, load timeouts or source exclusions. No full backend/load/coverage collection, Stryker dry run or mutation engine, explorer, provider, deployment, device, push, PR, new thread or delegated reviewer action is authorized by this release.

Freeze the new exact head/tree with a complete finding-response and check packet. Then stop source edits for fresh coordinator-owned comment and independent correctness reviews. Official combined-source gates and real-provider acceptance remain open.

## Evidence

- reviews/V01-quality-correctness-a-r2-terminal.json
- reviews/V01-quality-correctness-b-r2-attempt4-terminal.json
- reviews/V01-quality-r2-parent-triage.json
- Owner's read-only triage supplied in this orchestration thread, agreeing with the P2 and proposing conservative ambiguity failure.

