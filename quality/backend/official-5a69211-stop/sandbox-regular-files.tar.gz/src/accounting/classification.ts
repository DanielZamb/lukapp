// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { natureOfCode } from "./chartOfAccounts";
import { AccountingError } from "./errors";
import type { ChartOfAccountsTemplate, FinancialAccountProductKind, FinancialAccountParentKind, ProfileClassificationAnswers } from "./types";
export const profileClassificationPolicy = stryMutAct_9fa48("800") ? "" : (stryCov_9fa48("800"), "financial-account-profile@3");
export function classifyFinancialAccountProfile(template: ChartOfAccountsTemplate, productKind: string, answers?: ProfileClassificationAnswers) {
  if (stryMutAct_9fa48("801")) {
    {}
  } else {
    stryCov_9fa48("801");
    let parent: FinancialAccountParentKind;
    let normalized: ProfileClassificationAnswers | undefined;
    switch (productKind) {
      case stryMutAct_9fa48("803") ? "" : (stryCov_9fa48("803"), "receivable"):
        if (stryMutAct_9fa48("802")) {} else {
          stryCov_9fa48("802");
          if (stryMutAct_9fa48("806") ? answers?.kind !== "receivable" && !answers.counterpartyName.trim() : stryMutAct_9fa48("805") ? false : stryMutAct_9fa48("804") ? true : (stryCov_9fa48("804", "805", "806"), (stryMutAct_9fa48("808") ? answers?.kind === "receivable" : stryMutAct_9fa48("807") ? false : (stryCov_9fa48("807", "808"), (stryMutAct_9fa48("809") ? answers.kind : (stryCov_9fa48("809"), answers?.kind)) !== (stryMutAct_9fa48("810") ? "" : (stryCov_9fa48("810"), "receivable")))) || (stryMutAct_9fa48("811") ? answers.counterpartyName.trim() : (stryCov_9fa48("811"), !(stryMutAct_9fa48("812") ? answers.counterpartyName : (stryCov_9fa48("812"), answers.counterpartyName.trim())))))) throw new AccountingError(stryMutAct_9fa48("814") ? "" : (stryCov_9fa48("814"), "profile_classification_answers_required"));
          parent = (stryMutAct_9fa48("817") ? answers.security !== "secured" : stryMutAct_9fa48("816") ? false : stryMutAct_9fa48("815") ? true : (stryCov_9fa48("815", "816", "817"), answers.security === (stryMutAct_9fa48("818") ? "" : (stryCov_9fa48("818"), "secured")))) ? stryMutAct_9fa48("819") ? "" : (stryCov_9fa48("819"), "securedReceivable") : stryMutAct_9fa48("820") ? "" : (stryCov_9fa48("820"), "unsecuredReceivable");
          normalized = stryMutAct_9fa48("821") ? {} : (stryCov_9fa48("821"), {
            kind: stryMutAct_9fa48("822") ? "" : (stryCov_9fa48("822"), "receivable"),
            security: answers.security,
            counterpartyName: stryMutAct_9fa48("823") ? answers.counterpartyName : (stryCov_9fa48("823"), answers.counterpartyName.trim())
          });
          break;
        }
      case stryMutAct_9fa48("825") ? "" : (stryCov_9fa48("825"), "investment"):
        if (stryMutAct_9fa48("824")) {} else {
          stryCov_9fa48("824");
          if (stryMutAct_9fa48("828") ? answers?.kind === "investment" : stryMutAct_9fa48("827") ? false : stryMutAct_9fa48("826") ? true : (stryCov_9fa48("826", "827", "828"), (stryMutAct_9fa48("829") ? answers.kind : (stryCov_9fa48("829"), answers?.kind)) !== (stryMutAct_9fa48("830") ? "" : (stryCov_9fa48("830"), "investment")))) throw new AccountingError(stryMutAct_9fa48("832") ? "" : (stryCov_9fa48("832"), "profile_classification_answers_required"));
          parent = (stryMutAct_9fa48("835") ? answers.form !== "termDeposit" : stryMutAct_9fa48("834") ? false : stryMutAct_9fa48("833") ? true : (stryCov_9fa48("833", "834", "835"), answers.form === (stryMutAct_9fa48("836") ? "" : (stryCov_9fa48("836"), "termDeposit")))) ? stryMutAct_9fa48("837") ? "" : (stryCov_9fa48("837"), "termDeposit") : stryMutAct_9fa48("838") ? "" : (stryCov_9fa48("838"), "investmentFund");
          normalized = stryMutAct_9fa48("839") ? {} : (stryCov_9fa48("839"), {
            kind: stryMutAct_9fa48("840") ? "" : (stryCov_9fa48("840"), "investment"),
            form: answers.form,
            ...((stryMutAct_9fa48("842") ? answers.counterpartyName.trim() : stryMutAct_9fa48("841") ? answers.counterpartyName : (stryCov_9fa48("841", "842"), answers.counterpartyName?.trim())) ? stryMutAct_9fa48("843") ? {} : (stryCov_9fa48("843"), {
              counterpartyName: stryMutAct_9fa48("844") ? answers.counterpartyName : (stryCov_9fa48("844"), answers.counterpartyName.trim())
            }) : {})
          });
          break;
        }
      case stryMutAct_9fa48("846") ? "" : (stryCov_9fa48("846"), "personalDebt"):
        if (stryMutAct_9fa48("845")) {} else {
          stryCov_9fa48("845");
          if (stryMutAct_9fa48("849") ? answers?.kind !== "personalDebt" && !answers.counterpartyName.trim() : stryMutAct_9fa48("848") ? false : stryMutAct_9fa48("847") ? true : (stryCov_9fa48("847", "848", "849"), (stryMutAct_9fa48("851") ? answers?.kind === "personalDebt" : stryMutAct_9fa48("850") ? false : (stryCov_9fa48("850", "851"), (stryMutAct_9fa48("852") ? answers.kind : (stryCov_9fa48("852"), answers?.kind)) !== (stryMutAct_9fa48("853") ? "" : (stryCov_9fa48("853"), "personalDebt")))) || (stryMutAct_9fa48("854") ? answers.counterpartyName.trim() : (stryCov_9fa48("854"), !(stryMutAct_9fa48("855") ? answers.counterpartyName : (stryCov_9fa48("855"), answers.counterpartyName.trim())))))) throw new AccountingError(stryMutAct_9fa48("857") ? "" : (stryCov_9fa48("857"), "profile_classification_answers_required"));
          parent = stryMutAct_9fa48("858") ? "" : (stryCov_9fa48("858"), "personalDebt");
          normalized = stryMutAct_9fa48("859") ? {} : (stryCov_9fa48("859"), {
            kind: stryMutAct_9fa48("860") ? "" : (stryCov_9fa48("860"), "personalDebt"),
            counterpartyName: stryMutAct_9fa48("861") ? answers.counterpartyName : (stryCov_9fa48("861"), answers.counterpartyName.trim())
          });
          break;
        }
      case stryMutAct_9fa48("862") ? "" : (stryCov_9fa48("862"), "cash"):
      case stryMutAct_9fa48("863") ? "" : (stryCov_9fa48("863"), "bankAccount"):
      case stryMutAct_9fa48("864") ? "" : (stryCov_9fa48("864"), "savingsAccount"):
      case stryMutAct_9fa48("865") ? "" : (stryCov_9fa48("865"), "creditCard"):
      case stryMutAct_9fa48("867") ? "" : (stryCov_9fa48("867"), "loan"):
        if (stryMutAct_9fa48("866")) {} else {
          stryCov_9fa48("866");
          if (stryMutAct_9fa48("869") ? false : stryMutAct_9fa48("868") ? true : (stryCov_9fa48("868", "869"), answers)) throw new AccountingError(stryMutAct_9fa48("871") ? "" : (stryCov_9fa48("871"), "profile_classification_answers_required"));
          parent = productKind;
          break;
        }
      default:
        if (stryMutAct_9fa48("872")) {} else {
          stryCov_9fa48("872");
          {
            if (stryMutAct_9fa48("873")) {
              {}
            } else {
              stryCov_9fa48("873");
              throw new AccountingError(stryMutAct_9fa48("875") ? "" : (stryCov_9fa48("875"), "financial_account_product_kind_unknown"));
            }
          }
        }
    }
    const parentCode = template.financialAccountParents[parent];
    if (stryMutAct_9fa48("878") ? productKind === "receivable" || productKind === "investment" || productKind === "personalDebt" || !template.accounts.some(account => account.code === parentCode && account.use === "general") : stryMutAct_9fa48("877") ? false : stryMutAct_9fa48("876") ? true : (stryCov_9fa48("876", "877", "878"), (stryMutAct_9fa48("880") ? (productKind === "receivable" || productKind === "investment") && productKind === "personalDebt" : stryMutAct_9fa48("879") ? true : (stryCov_9fa48("879", "880"), (stryMutAct_9fa48("882") ? productKind === "receivable" && productKind === "investment" : stryMutAct_9fa48("881") ? false : (stryCov_9fa48("881", "882"), (stryMutAct_9fa48("884") ? productKind !== "receivable" : stryMutAct_9fa48("883") ? false : (stryCov_9fa48("883", "884"), productKind === (stryMutAct_9fa48("885") ? "" : (stryCov_9fa48("885"), "receivable")))) || (stryMutAct_9fa48("887") ? productKind !== "investment" : stryMutAct_9fa48("886") ? false : (stryCov_9fa48("886", "887"), productKind === (stryMutAct_9fa48("888") ? "" : (stryCov_9fa48("888"), "investment")))))) || (stryMutAct_9fa48("890") ? productKind !== "personalDebt" : stryMutAct_9fa48("889") ? false : (stryCov_9fa48("889", "890"), productKind === (stryMutAct_9fa48("891") ? "" : (stryCov_9fa48("891"), "personalDebt")))))) && (stryMutAct_9fa48("892") ? template.accounts.some(account => account.code === parentCode && account.use === "general") : (stryCov_9fa48("892"), !(stryMutAct_9fa48("893") ? template.accounts.every(account => account.code === parentCode && account.use === "general") : (stryCov_9fa48("893"), template.accounts.some(stryMutAct_9fa48("894") ? () => undefined : (stryCov_9fa48("894"), account => stryMutAct_9fa48("897") ? account.code === parentCode || account.use === "general" : stryMutAct_9fa48("896") ? false : stryMutAct_9fa48("895") ? true : (stryCov_9fa48("895", "896", "897"), (stryMutAct_9fa48("899") ? account.code !== parentCode : stryMutAct_9fa48("898") ? true : (stryCov_9fa48("898", "899"), account.code === parentCode)) && (stryMutAct_9fa48("901") ? account.use !== "general" : stryMutAct_9fa48("900") ? true : (stryCov_9fa48("900", "901"), account.use === (stryMutAct_9fa48("902") ? "" : (stryCov_9fa48("902"), "general"))))))))))))) throw new AccountingError(stryMutAct_9fa48("904") ? "" : (stryCov_9fa48("904"), "ledger_account_code_unknown"));
    return stryMutAct_9fa48("905") ? {} : (stryCov_9fa48("905"), {
      productKind,
      parentCode,
      nature: natureOfCode(template, parentCode),
      policy: profileClassificationPolicy,
      ...(normalized ? stryMutAct_9fa48("906") ? {} : (stryCov_9fa48("906"), {
        answers: normalized
      }) : {})
    });
  }
}