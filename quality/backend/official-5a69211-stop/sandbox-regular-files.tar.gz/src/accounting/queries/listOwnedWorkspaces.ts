// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { dateFromTimestamp } from "../period";
import { openWorkspace } from "./openWorkspace";
import type { AccountingClock, AccountingStore, Actor, Workspace } from "../types";
export async function listOwnedWorkspaces(store: AccountingStore, clock: AccountingClock, input: {
  actor: Actor;
  now?: number;
}): Promise<Workspace[]> {
  if (stryMutAct_9fa48("2117")) {
    {}
  } else {
    stryCov_9fa48("2117");
    const now = stryMutAct_9fa48("2118") ? input.now && clock.now().getTime() : (stryCov_9fa48("2118"), input.now ?? clock.now().getTime());
    if (stryMutAct_9fa48("2119")) {
      ;
    } else {
      stryCov_9fa48("2119");
      dateFromTimestamp(now);
    }
    const ids = await store.listOwnedWorkspaceIds(input.actor.userId);
    return Promise.all(ids.map(stryMutAct_9fa48("2120") ? () => undefined : (stryCov_9fa48("2120"), workspaceId => openWorkspace(store, clock, stryMutAct_9fa48("2121") ? {} : (stryCov_9fa48("2121"), {
      ...input,
      now,
      workspaceId
    })))));
  }
}