// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { requireProfile } from "../financialAccountProfiles";
import { requireWorkspace } from "../membership";
import type { AccountingStore, Actor, PostedJournalEntry } from "../types";
import { journalContext, toPostedJournalEntry } from "../views";

/** Every Posted Journal Entry, reversals included, with links between each pair. */
export async function listJournalEntries(store: AccountingStore, input: {
  actor: Actor;
  workspaceId: string;
  financialAccountProfileId?: string;
}): Promise<PostedJournalEntry[]> {
  if (stryMutAct_9fa48("2084")) {
    {}
  } else {
    stryCov_9fa48("2084");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor);
    const profile = (stryMutAct_9fa48("2087") ? input.financialAccountProfileId === undefined : stryMutAct_9fa48("2086") ? false : stryMutAct_9fa48("2085") ? true : (stryCov_9fa48("2085", "2086", "2087"), input.financialAccountProfileId !== undefined)) ? await requireProfile(store, input.workspaceId, input.financialAccountProfileId) : undefined;
    const [entries, context] = await Promise.all(stryMutAct_9fa48("2088") ? [] : (stryCov_9fa48("2088"), [store.listJournalEntries(input.workspaceId), journalContext(store, workspace)]));
    const reversedBy = new Map(entries.flatMap(stryMutAct_9fa48("2089") ? () => undefined : (stryCov_9fa48("2089"), entry => entry.reversesEntryId ? stryMutAct_9fa48("2090") ? [] : (stryCov_9fa48("2090"), [[entry.reversesEntryId, entry.id] as const]) : stryMutAct_9fa48("2091") ? ["Stryker was here"] : (stryCov_9fa48("2091"), []))));
    return Promise.all(stryMutAct_9fa48("2092") ? entries.map(entry => {
      const reversedByEntryId = reversedBy.get(entry.id);
      return toPostedJournalEntry(store, context, entry, {
        replay: false,
        ...(reversedByEntryId ? {
          reversedByEntryId
        } : {})
      });
    }) : (stryCov_9fa48("2092"), entries.filter(stryMutAct_9fa48("2093") ? () => undefined : (stryCov_9fa48("2093"), entry => stryMutAct_9fa48("2096") ? !profile && entry.lines.some(line => line.ledgerAccountId === profile.postingAccountId) : stryMutAct_9fa48("2095") ? false : stryMutAct_9fa48("2094") ? true : (stryCov_9fa48("2094", "2095", "2096"), (stryMutAct_9fa48("2097") ? profile : (stryCov_9fa48("2097"), !profile)) || (stryMutAct_9fa48("2098") ? entry.lines.every(line => line.ledgerAccountId === profile.postingAccountId) : (stryCov_9fa48("2098"), entry.lines.some(stryMutAct_9fa48("2099") ? () => undefined : (stryCov_9fa48("2099"), line => stryMutAct_9fa48("2102") ? line.ledgerAccountId !== profile.postingAccountId : stryMutAct_9fa48("2101") ? false : stryMutAct_9fa48("2100") ? true : (stryCov_9fa48("2100", "2101", "2102"), line.ledgerAccountId === profile.postingAccountId)))))))).map(entry => {
      if (stryMutAct_9fa48("2103")) {
        {}
      } else {
        stryCov_9fa48("2103");
        const reversedByEntryId = reversedBy.get(entry.id);
        return toPostedJournalEntry(store, context, entry, stryMutAct_9fa48("2104") ? {} : (stryCov_9fa48("2104"), {
          replay: stryMutAct_9fa48("2105") ? true : (stryCov_9fa48("2105"), false),
          ...(reversedByEntryId ? stryMutAct_9fa48("2106") ? {} : (stryCov_9fa48("2106"), {
            reversedByEntryId
          }) : {})
        }));
      }
    })));
  }
}