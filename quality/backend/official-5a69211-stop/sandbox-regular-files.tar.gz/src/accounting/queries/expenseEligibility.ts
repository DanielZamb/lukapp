// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "../errors";
import type { AccountingStore } from "../types";
export async function expenseEligibility(store: Pick<AccountingStore, "listJournalSourceEffects" | "getJournalEntry" | "findReversalOf">, input: {
  workspaceId: string;
  sourceEntryId: string;
  originalMinorUnits: number;
  asKnownAt?: number;
}) {
  if (stryMutAct_9fa48("2011")) {
    {}
  } else {
    stryCov_9fa48("2011");
    const facts = await store.listJournalSourceEffects(input.workspaceId, input.sourceEntryId);
    const effects = stryMutAct_9fa48("2012") ? ["Stryker was here"] : (stryCov_9fa48("2012"), []);
    const prefixes = stryMutAct_9fa48("2013") ? ["Stryker was here"] : (stryCov_9fa48("2013"), []);
    let eligible = BigInt(input.originalMinorUnits);
    for (const [index, fact] of stryMutAct_9fa48("2014") ? [...facts].entries() : (stryCov_9fa48("2014"), (stryMutAct_9fa48("2015") ? [] : (stryCov_9fa48("2015"), [...facts])).sort(stryMutAct_9fa48("2016") ? () => undefined : (stryCov_9fa48("2016"), (a, b) => stryMutAct_9fa48("2017") ? a.sourceSequence + b.sourceSequence : (stryCov_9fa48("2017"), a.sourceSequence - b.sourceSequence))).entries())) {
      if (stryMutAct_9fa48("2018")) {
        {}
      } else {
        stryCov_9fa48("2018");
        if (stryMutAct_9fa48("2021") ? !Number.isSafeInteger(fact.sourceSequence) && fact.sourceSequence !== index + 1 : stryMutAct_9fa48("2020") ? false : stryMutAct_9fa48("2019") ? true : (stryCov_9fa48("2019", "2020", "2021"), (stryMutAct_9fa48("2022") ? Number.isSafeInteger(fact.sourceSequence) : (stryCov_9fa48("2022"), !Number.isSafeInteger(fact.sourceSequence))) || (stryMutAct_9fa48("2024") ? fact.sourceSequence === index + 1 : stryMutAct_9fa48("2023") ? false : (stryCov_9fa48("2023", "2024"), fact.sourceSequence !== (stryMutAct_9fa48("2025") ? index - 1 : (stryCov_9fa48("2025"), index + 1)))))) throw new AccountingError(stryMutAct_9fa48("2027") ? "" : (stryCov_9fa48("2027"), "journal_source_effect_invalid"));
        const entry = await store.getJournalEntry(fact.journalEntryId);
        if (stryMutAct_9fa48("2030") ? (!entry || entry.workspaceId !== input.workspaceId) && !Number.isSafeInteger(fact.expenseDeltaMinorUnits) : stryMutAct_9fa48("2029") ? false : stryMutAct_9fa48("2028") ? true : (stryCov_9fa48("2028", "2029", "2030"), (stryMutAct_9fa48("2032") ? !entry && entry.workspaceId !== input.workspaceId : stryMutAct_9fa48("2031") ? false : (stryCov_9fa48("2031", "2032"), (stryMutAct_9fa48("2033") ? entry : (stryCov_9fa48("2033"), !entry)) || (stryMutAct_9fa48("2035") ? entry.workspaceId === input.workspaceId : stryMutAct_9fa48("2034") ? false : (stryCov_9fa48("2034", "2035"), entry.workspaceId !== input.workspaceId)))) || (stryMutAct_9fa48("2036") ? Number.isSafeInteger(fact.expenseDeltaMinorUnits) : (stryCov_9fa48("2036"), !Number.isSafeInteger(fact.expenseDeltaMinorUnits))))) throw new AccountingError(stryMutAct_9fa48("2038") ? "" : (stryCov_9fa48("2038"), "journal_source_effect_invalid"));
        if (stryMutAct_9fa48("2041") ? input.asKnownAt !== undefined || entry.postedAt > input.asKnownAt : stryMutAct_9fa48("2040") ? false : stryMutAct_9fa48("2039") ? true : (stryCov_9fa48("2039", "2040", "2041"), (stryMutAct_9fa48("2043") ? input.asKnownAt === undefined : stryMutAct_9fa48("2042") ? true : (stryCov_9fa48("2042", "2043"), input.asKnownAt !== undefined)) && (stryMutAct_9fa48("2046") ? entry.postedAt <= input.asKnownAt : stryMutAct_9fa48("2045") ? entry.postedAt >= input.asKnownAt : stryMutAct_9fa48("2044") ? true : (stryCov_9fa48("2044", "2045", "2046"), entry.postedAt > input.asKnownAt)))) continue;
        stryMutAct_9fa48("2047") ? eligible -= BigInt(fact.expenseDeltaMinorUnits) : (stryCov_9fa48("2047"), eligible += BigInt(fact.expenseDeltaMinorUnits));
        const prefixMinor = Number((stryMutAct_9fa48("2051") ? eligible <= 0n : stryMutAct_9fa48("2050") ? eligible >= 0n : stryMutAct_9fa48("2049") ? false : stryMutAct_9fa48("2048") ? true : (stryCov_9fa48("2048", "2049", "2050", "2051"), eligible > 0n)) ? eligible : 0n);
        if (stryMutAct_9fa48("2054") ? false : stryMutAct_9fa48("2053") ? true : stryMutAct_9fa48("2052") ? Number.isSafeInteger(prefixMinor) : (stryCov_9fa48("2052", "2053", "2054"), !Number.isSafeInteger(prefixMinor))) throw new AccountingError(stryMutAct_9fa48("2056") ? "" : (stryCov_9fa48("2056"), "journal_source_effect_invalid"));
        prefixes.push(stryMutAct_9fa48("2058") ? {} : (stryCov_9fa48("2058"), {
          sourceSequence: fact.sourceSequence,
          recordedAt: entry.postedAt,
          eligibleMinorUnits: prefixMinor
        }));
        const reversal = await store.findReversalOf(entry.id);
        effects.push(stryMutAct_9fa48("2060") ? {} : (stryCov_9fa48("2060"), {
          ...fact,
          accountingDate: entry.accountingDate,
          recordedAt: entry.postedAt,
          reversedByEntryId: (stryMutAct_9fa48("2063") ? reversal || input.asKnownAt === undefined || reversal.postedAt <= input.asKnownAt : stryMutAct_9fa48("2062") ? false : stryMutAct_9fa48("2061") ? true : (stryCov_9fa48("2061", "2062", "2063"), reversal && (stryMutAct_9fa48("2065") ? input.asKnownAt === undefined && reversal.postedAt <= input.asKnownAt : stryMutAct_9fa48("2064") ? true : (stryCov_9fa48("2064", "2065"), (stryMutAct_9fa48("2067") ? input.asKnownAt !== undefined : stryMutAct_9fa48("2066") ? false : (stryCov_9fa48("2066", "2067"), input.asKnownAt === undefined)) || (stryMutAct_9fa48("2070") ? reversal.postedAt > input.asKnownAt : stryMutAct_9fa48("2069") ? reversal.postedAt < input.asKnownAt : stryMutAct_9fa48("2068") ? false : (stryCov_9fa48("2068", "2069", "2070"), reversal.postedAt <= input.asKnownAt)))))) ? reversal.id : null
        }));
      }
    }
    const minorUnits = Number((stryMutAct_9fa48("2074") ? eligible <= 0n : stryMutAct_9fa48("2073") ? eligible >= 0n : stryMutAct_9fa48("2072") ? false : stryMutAct_9fa48("2071") ? true : (stryCov_9fa48("2071", "2072", "2073", "2074"), eligible > 0n)) ? eligible : 0n);
    if (stryMutAct_9fa48("2077") ? false : stryMutAct_9fa48("2076") ? true : stryMutAct_9fa48("2075") ? Number.isSafeInteger(minorUnits) : (stryCov_9fa48("2075", "2076", "2077"), !Number.isSafeInteger(minorUnits))) throw new AccountingError(stryMutAct_9fa48("2079") ? "" : (stryCov_9fa48("2079"), "journal_source_effect_invalid"));
    return stryMutAct_9fa48("2080") ? {} : (stryCov_9fa48("2080"), {
      minorUnits,
      effects,
      prefixes
    });
  }
}