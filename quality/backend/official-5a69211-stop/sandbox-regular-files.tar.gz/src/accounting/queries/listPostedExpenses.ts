// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { expenseEligibility } from "./expenseEligibility";
import { AccountingError } from "../errors";
import { requireWorkspace } from "../membership";
import { periodFromAccountingDate } from "../period";
import type { AccountingStore, Actor, PostedExpense } from "../types";
export type ExpenseReadStore = Pick<AccountingStore, "getWorkspace" | "membershipRole" | "listExpenseEntriesInRange" | "getLedgerAccount" | "findReversalOf" | "listJournalSourceEffects" | "getJournalEntry">;
export async function listPostedExpenses(store: ExpenseReadStore, input: {
  actor: Actor;
  workspaceId: string;
  from: string;
  through: string;
}): Promise<PostedExpense[]> {
  if (stryMutAct_9fa48("2122")) {
    {}
  } else {
    stryCov_9fa48("2122");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor);
    if (stryMutAct_9fa48("2123")) {
      ;
    } else {
      stryCov_9fa48("2123");
      periodFromAccountingDate(input.from);
    }
    if (stryMutAct_9fa48("2124")) {
      ;
    } else {
      stryCov_9fa48("2124");
      periodFromAccountingDate(input.through);
    }
    if (stryMutAct_9fa48("2128") ? input.from <= input.through : stryMutAct_9fa48("2127") ? input.from >= input.through : stryMutAct_9fa48("2126") ? false : stryMutAct_9fa48("2125") ? true : (stryCov_9fa48("2125", "2126", "2127", "2128"), input.from > input.through)) throw new AccountingError(stryMutAct_9fa48("2130") ? "" : (stryCov_9fa48("2130"), "accounting_date_required"));
    const entries = await store.listExpenseEntriesInRange(input.workspaceId, input.from, input.through);
    return Promise.all(entries.map(async entry => {
      if (stryMutAct_9fa48("2131")) {
        {}
      } else {
        stryCov_9fa48("2131");
        const expenseLines: PostedExpense["expenseLines"] = stryMutAct_9fa48("2132") ? ["Stryker was here"] : (stryCov_9fa48("2132"), []);
        for (const line of entry.lines) {
          if (stryMutAct_9fa48("2133")) {
            {}
          } else {
            stryCov_9fa48("2133");
            const account = await store.getLedgerAccount(line.ledgerAccountId);
            if (stryMutAct_9fa48("2136") ? account?.nature === "Expense" || line.debitMinorUnits > 0 : stryMutAct_9fa48("2135") ? false : stryMutAct_9fa48("2134") ? true : (stryCov_9fa48("2134", "2135", "2136"), (stryMutAct_9fa48("2138") ? account?.nature !== "Expense" : stryMutAct_9fa48("2137") ? true : (stryCov_9fa48("2137", "2138"), (stryMutAct_9fa48("2139") ? account.nature : (stryCov_9fa48("2139"), account?.nature)) === (stryMutAct_9fa48("2140") ? "" : (stryCov_9fa48("2140"), "Expense")))) && (stryMutAct_9fa48("2143") ? line.debitMinorUnits <= 0 : stryMutAct_9fa48("2142") ? line.debitMinorUnits >= 0 : stryMutAct_9fa48("2141") ? true : (stryCov_9fa48("2141", "2142", "2143"), line.debitMinorUnits > 0)))) {
              if (stryMutAct_9fa48("2144")) {
                {}
              } else {
                stryCov_9fa48("2144");
                expenseLines.push(stryMutAct_9fa48("2146") ? {} : (stryCov_9fa48("2146"), {
                  ledgerAccountId: account.id,
                  amount: stryMutAct_9fa48("2147") ? {} : (stryCov_9fa48("2147"), {
                    currency: workspace.functionalCurrency,
                    minorUnits: line.debitMinorUnits
                  })
                }));
              }
            }
          }
        }
        const reversal = await store.findReversalOf(entry.id);
        const eligibility = await expenseEligibility(store, stryMutAct_9fa48("2148") ? {} : (stryCov_9fa48("2148"), {
          workspaceId: input.workspaceId,
          sourceEntryId: entry.id,
          originalMinorUnits: expenseLines.reduce(stryMutAct_9fa48("2149") ? () => undefined : (stryCov_9fa48("2149"), (sum, line) => stryMutAct_9fa48("2150") ? sum - line.amount.minorUnits : (stryCov_9fa48("2150"), sum + line.amount.minorUnits)), 0)
        }));
        return stryMutAct_9fa48("2151") ? {} : (stryCov_9fa48("2151"), {
          entryId: entry.id,
          accountingDate: entry.accountingDate,
          description: entry.description,
          expenseLines,
          currentEligibleAmount: stryMutAct_9fa48("2152") ? {} : (stryCov_9fa48("2152"), {
            currency: workspace.functionalCurrency,
            minorUnits: reversal ? 0 : eligibility.minorUnits
          }),
          sourceEffects: eligibility.effects,
          amount: stryMutAct_9fa48("2153") ? {} : (stryCov_9fa48("2153"), {
            currency: workspace.functionalCurrency,
            minorUnits: expenseLines.reduce(stryMutAct_9fa48("2154") ? () => undefined : (stryCov_9fa48("2154"), (sum, line) => stryMutAct_9fa48("2155") ? sum - line.amount.minorUnits : (stryCov_9fa48("2155"), sum + line.amount.minorUnits)), 0)
          }),
          reversal: reversal ? stryMutAct_9fa48("2156") ? {} : (stryCov_9fa48("2156"), {
            entryId: reversal.id,
            accountingDate: reversal.accountingDate,
            recordedAt: reversal.postedAt
          }) : null
        });
      }
    }));
  }
}