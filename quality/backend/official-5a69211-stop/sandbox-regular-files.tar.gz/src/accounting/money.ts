// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { functionalCurrencyCodes } from "./currencies";
import { AccountingError } from "./errors";
import type { Money, StoredWorkspace } from "./types";
export function requireFunctionalCurrencyCode(currency: string): string {
  if (stryMutAct_9fa48("1530")) {
    {}
  } else {
    stryCov_9fa48("1530");
    if (stryMutAct_9fa48("1533") ? false : stryMutAct_9fa48("1532") ? true : stryMutAct_9fa48("1531") ? functionalCurrencyCodes.has(currency) : (stryCov_9fa48("1531", "1532", "1533"), !functionalCurrencyCodes.has(currency))) {
      if (stryMutAct_9fa48("1534")) {
        {}
      } else {
        stryCov_9fa48("1534");
        throw new AccountingError(stryMutAct_9fa48("1536") ? "" : (stryCov_9fa48("1536"), "functional_currency_invalid"));
      }
    }
    return currency;
  }
}

/** A positive whole number of minor units in the Workspace Functional Currency. */
export function requireFunctionalAmount(workspace: StoredWorkspace, amount: Money): number {
  if (stryMutAct_9fa48("1537")) {
    {}
  } else {
    stryCov_9fa48("1537");
    if (stryMutAct_9fa48("1540") ? !Number.isSafeInteger(amount.minorUnits) && amount.minorUnits <= 0 : stryMutAct_9fa48("1539") ? false : stryMutAct_9fa48("1538") ? true : (stryCov_9fa48("1538", "1539", "1540"), (stryMutAct_9fa48("1541") ? Number.isSafeInteger(amount.minorUnits) : (stryCov_9fa48("1541"), !Number.isSafeInteger(amount.minorUnits))) || (stryMutAct_9fa48("1544") ? amount.minorUnits > 0 : stryMutAct_9fa48("1543") ? amount.minorUnits < 0 : stryMutAct_9fa48("1542") ? false : (stryCov_9fa48("1542", "1543", "1544"), amount.minorUnits <= 0)))) {
      if (stryMutAct_9fa48("1545")) {
        {}
      } else {
        stryCov_9fa48("1545");
        throw new AccountingError(stryMutAct_9fa48("1547") ? "" : (stryCov_9fa48("1547"), "amount_must_be_positive"));
      }
    }
    if (stryMutAct_9fa48("1550") ? amount.currency === workspace.functionalCurrency : stryMutAct_9fa48("1549") ? false : stryMutAct_9fa48("1548") ? true : (stryCov_9fa48("1548", "1549", "1550"), amount.currency !== workspace.functionalCurrency)) {
      if (stryMutAct_9fa48("1551")) {
        {}
      } else {
        stryCov_9fa48("1551");
        throw new AccountingError(stryMutAct_9fa48("1553") ? "" : (stryCov_9fa48("1553"), "currency_mismatch"));
      }
    }
    return amount.minorUnits;
  }
}