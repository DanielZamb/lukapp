// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { commandIdentity } from "./commandIdentity";
import { assertOpeningDates } from "./openingDate";
import { AccountingError } from "./errors";
import { requireWorkspace } from "./membership";
import { periodFromAccountingDate } from "./period";
import { requirePostablePeriod } from "./periodControl";
import type { AccountingClock, AccountingStore, Actor, DraftJournalLine, JournalEntryDraft, StoredJournalEntry } from "./types";
export type PostingResult = {
  entry: StoredJournalEntry;
  replay: boolean;
};
export async function postJournalEntry(store: AccountingStore, clock: AccountingClock, input: {
  actor: Actor;
  workspaceId: string;
  draft: JournalEntryDraft;
}): Promise<PostingResult> {
  if (stryMutAct_9fa48("1768")) {
    {}
  } else {
    stryCov_9fa48("1768");
    const {
      draft
    } = input;
    await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("1769") ? "" : (stryCov_9fa48("1769"), "post"));
    if (stryMutAct_9fa48("1772") ? false : stryMutAct_9fa48("1771") ? true : stryMutAct_9fa48("1770") ? draft.idempotencyKey : (stryCov_9fa48("1770", "1771", "1772"), !draft.idempotencyKey)) {
      if (stryMutAct_9fa48("1773")) {
        {}
      } else {
        stryCov_9fa48("1773");
        throw new AccountingError(stryMutAct_9fa48("1775") ? "" : (stryCov_9fa48("1775"), "idempotency_key_required"));
      }
    }
    const existing = await store.findJournalEntryByIdempotencyKey(input.workspaceId, draft.idempotencyKey);
    if (stryMutAct_9fa48("1777") ? false : stryMutAct_9fa48("1776") ? true : (stryCov_9fa48("1776", "1777"), existing)) {
      if (stryMutAct_9fa48("1778")) {
        {}
      } else {
        stryCov_9fa48("1778");
        if (stryMutAct_9fa48("1781") ? false : stryMutAct_9fa48("1780") ? true : stryMutAct_9fa48("1779") ? sameDraft(existing, draft) : (stryCov_9fa48("1779", "1780", "1781"), !sameDraft(existing, draft))) {
          if (stryMutAct_9fa48("1782")) {
            {}
          } else {
            stryCov_9fa48("1782");
            throw new AccountingError(stryMutAct_9fa48("1784") ? "" : (stryCov_9fa48("1784"), "idempotency_key_conflict"));
          }
        }
        return stryMutAct_9fa48("1785") ? {} : (stryCov_9fa48("1785"), {
          entry: existing,
          replay: stryMutAct_9fa48("1786") ? false : (stryCov_9fa48("1786"), true)
        });
      }
    }
    if (stryMutAct_9fa48("1788") ? false : stryMutAct_9fa48("1787") ? true : (stryCov_9fa48("1787", "1788"), await store.findOpeningPositionByKey(input.workspaceId, draft.idempotencyKey))) {
      if (stryMutAct_9fa48("1789")) {
        {}
      } else {
        stryCov_9fa48("1789");
        throw new AccountingError(stryMutAct_9fa48("1791") ? "" : (stryCov_9fa48("1791"), "idempotency_key_conflict"));
      }
    }
    if (stryMutAct_9fa48("1792")) {
      ;
    } else {
      stryCov_9fa48("1792");
      assertBalancedLines(draft.lines);
    }
    await assertPostingAccounts(store, input.workspaceId, draft.lines);
    await assertLinkedRecords(store, input.workspaceId, draft);
    const period = periodFromAccountingDate(draft.accountingDate);
    await assertOpeningDates(store, input.workspaceId, draft);
    await requirePostablePeriod(store, input.workspaceId, draft.accountingDate);
    const entry = await store.insertJournalEntry(stryMutAct_9fa48("1793") ? {} : (stryCov_9fa48("1793"), {
      ...draft,
      workspaceId: input.workspaceId,
      period,
      postedBy: input.actor.userId,
      postedAt: clock.now().getTime()
    }));
    return stryMutAct_9fa48("1794") ? {} : (stryCov_9fa48("1794"), {
      entry,
      replay: stryMutAct_9fa48("1795") ? true : (stryCov_9fa48("1795"), false)
    });
  }
}

/** Minimum completeness, one positive side per line, and debits equal to credits. */
export function assertBalancedLines(lines: DraftJournalLine[]): void {
  if (stryMutAct_9fa48("1796")) {
    {}
  } else {
    stryCov_9fa48("1796");
    if (stryMutAct_9fa48("1800") ? lines.length >= 2 : stryMutAct_9fa48("1799") ? lines.length <= 2 : stryMutAct_9fa48("1798") ? false : stryMutAct_9fa48("1797") ? true : (stryCov_9fa48("1797", "1798", "1799", "1800"), lines.length < 2)) {
      if (stryMutAct_9fa48("1801")) {
        {}
      } else {
        stryCov_9fa48("1801");
        throw new AccountingError(stryMutAct_9fa48("1803") ? "" : (stryCov_9fa48("1803"), "journal_entry_incomplete"));
      }
    }
    let debit = 0;
    let credit = 0;
    for (const line of lines) {
      if (stryMutAct_9fa48("1804")) {
        {}
      } else {
        stryCov_9fa48("1804");
        const {
          debitMinorUnits: d,
          creditMinorUnits: c
        } = line;
        if (stryMutAct_9fa48("1807") ? (!Number.isSafeInteger(d) || !Number.isSafeInteger(c) || d < 0 || c < 0) && d > 0 === c > 0 : stryMutAct_9fa48("1806") ? false : stryMutAct_9fa48("1805") ? true : (stryCov_9fa48("1805", "1806", "1807"), (stryMutAct_9fa48("1809") ? (!Number.isSafeInteger(d) || !Number.isSafeInteger(c) || d < 0) && c < 0 : stryMutAct_9fa48("1808") ? false : (stryCov_9fa48("1808", "1809"), (stryMutAct_9fa48("1811") ? (!Number.isSafeInteger(d) || !Number.isSafeInteger(c)) && d < 0 : stryMutAct_9fa48("1810") ? false : (stryCov_9fa48("1810", "1811"), (stryMutAct_9fa48("1813") ? !Number.isSafeInteger(d) && !Number.isSafeInteger(c) : stryMutAct_9fa48("1812") ? false : (stryCov_9fa48("1812", "1813"), (stryMutAct_9fa48("1814") ? Number.isSafeInteger(d) : (stryCov_9fa48("1814"), !Number.isSafeInteger(d))) || (stryMutAct_9fa48("1815") ? Number.isSafeInteger(c) : (stryCov_9fa48("1815"), !Number.isSafeInteger(c))))) || (stryMutAct_9fa48("1818") ? d >= 0 : stryMutAct_9fa48("1817") ? d <= 0 : stryMutAct_9fa48("1816") ? false : (stryCov_9fa48("1816", "1817", "1818"), d < 0)))) || (stryMutAct_9fa48("1821") ? c >= 0 : stryMutAct_9fa48("1820") ? c <= 0 : stryMutAct_9fa48("1819") ? false : (stryCov_9fa48("1819", "1820", "1821"), c < 0)))) || (stryMutAct_9fa48("1823") ? d > 0 !== c > 0 : stryMutAct_9fa48("1822") ? false : (stryCov_9fa48("1822", "1823"), (stryMutAct_9fa48("1827") ? d <= 0 : stryMutAct_9fa48("1826") ? d >= 0 : stryMutAct_9fa48("1825") ? false : stryMutAct_9fa48("1824") ? true : (stryCov_9fa48("1824", "1825", "1826", "1827"), d > 0)) === (stryMutAct_9fa48("1831") ? c <= 0 : stryMutAct_9fa48("1830") ? c >= 0 : stryMutAct_9fa48("1829") ? false : stryMutAct_9fa48("1828") ? true : (stryCov_9fa48("1828", "1829", "1830", "1831"), c > 0)))))) {
          if (stryMutAct_9fa48("1832")) {
            {}
          } else {
            stryCov_9fa48("1832");
            throw new AccountingError(stryMutAct_9fa48("1834") ? "" : (stryCov_9fa48("1834"), "journal_line_invalid"));
          }
        }
        stryMutAct_9fa48("1835") ? debit -= d : (stryCov_9fa48("1835"), debit += d);
        stryMutAct_9fa48("1836") ? credit -= c : (stryCov_9fa48("1836"), credit += c);
      }
    }
    if (stryMutAct_9fa48("1839") ? !Number.isSafeInteger(debit) && debit !== credit : stryMutAct_9fa48("1838") ? false : stryMutAct_9fa48("1837") ? true : (stryCov_9fa48("1837", "1838", "1839"), (stryMutAct_9fa48("1840") ? Number.isSafeInteger(debit) : (stryCov_9fa48("1840"), !Number.isSafeInteger(debit))) || (stryMutAct_9fa48("1842") ? debit === credit : stryMutAct_9fa48("1841") ? false : (stryCov_9fa48("1841", "1842"), debit !== credit)))) {
      if (stryMutAct_9fa48("1843")) {
        {}
      } else {
        stryCov_9fa48("1843");
        throw new AccountingError(stryMutAct_9fa48("1845") ? "" : (stryCov_9fa48("1845"), "posted_journal_entry_unbalanced"));
      }
    }
  }
}
async function assertPostingAccounts(store: AccountingStore, workspaceId: string, lines: DraftJournalLine[]): Promise<void> {
  if (stryMutAct_9fa48("1846")) {
    {}
  } else {
    stryCov_9fa48("1846");
    for (const line of lines) {
      if (stryMutAct_9fa48("1847")) {
        {}
      } else {
        stryCov_9fa48("1847");
        const account = await store.getLedgerAccount(line.ledgerAccountId);
        if (stryMutAct_9fa48("1850") ? !account && account.workspaceId !== workspaceId : stryMutAct_9fa48("1849") ? false : stryMutAct_9fa48("1848") ? true : (stryCov_9fa48("1848", "1849", "1850"), (stryMutAct_9fa48("1851") ? account : (stryCov_9fa48("1851"), !account)) || (stryMutAct_9fa48("1853") ? account.workspaceId === workspaceId : stryMutAct_9fa48("1852") ? false : (stryCov_9fa48("1852", "1853"), account.workspaceId !== workspaceId)))) {
          if (stryMutAct_9fa48("1854")) {
            {}
          } else {
            stryCov_9fa48("1854");
            throw new AccountingError(stryMutAct_9fa48("1856") ? "" : (stryCov_9fa48("1856"), "ledger_account_not_found"));
          }
        }
      }
    }
  }
}
async function assertLinkedRecords(store: AccountingStore, workspaceId: string, draft: JournalEntryDraft): Promise<void> {
  if (stryMutAct_9fa48("1857")) {
    {}
  } else {
    stryCov_9fa48("1857");
    for (const effect of stryMutAct_9fa48("1858") ? draft.sourceExpenseEffects && [] : (stryCov_9fa48("1858"), draft.sourceExpenseEffects ?? (stryMutAct_9fa48("1859") ? ["Stryker was here"] : (stryCov_9fa48("1859"), [])))) {
      if (stryMutAct_9fa48("1860")) {
        {}
      } else {
        stryCov_9fa48("1860");
        const source = await store.getJournalEntry(effect.sourceEntryId);
        if (stryMutAct_9fa48("1863") ? (!source || source.workspaceId !== workspaceId) && source.policy !== "cash-expense@1" && source.policy !== "cash-income@1" : stryMutAct_9fa48("1862") ? false : stryMutAct_9fa48("1861") ? true : (stryCov_9fa48("1861", "1862", "1863"), (stryMutAct_9fa48("1865") ? !source && source.workspaceId !== workspaceId : stryMutAct_9fa48("1864") ? false : (stryCov_9fa48("1864", "1865"), (stryMutAct_9fa48("1866") ? source : (stryCov_9fa48("1866"), !source)) || (stryMutAct_9fa48("1868") ? source.workspaceId === workspaceId : stryMutAct_9fa48("1867") ? false : (stryCov_9fa48("1867", "1868"), source.workspaceId !== workspaceId)))) || (stryMutAct_9fa48("1870") ? source.policy !== "cash-expense@1" || source.policy !== "cash-income@1" : stryMutAct_9fa48("1869") ? false : (stryCov_9fa48("1869", "1870"), (stryMutAct_9fa48("1872") ? source.policy === "cash-expense@1" : stryMutAct_9fa48("1871") ? true : (stryCov_9fa48("1871", "1872"), source.policy !== (stryMutAct_9fa48("1873") ? "" : (stryCov_9fa48("1873"), "cash-expense@1")))) && (stryMutAct_9fa48("1875") ? source.policy === "cash-income@1" : stryMutAct_9fa48("1874") ? true : (stryCov_9fa48("1874", "1875"), source.policy !== (stryMutAct_9fa48("1876") ? "" : (stryCov_9fa48("1876"), "cash-income@1")))))))) throw new AccountingError(stryMutAct_9fa48("1878") ? "" : (stryCov_9fa48("1878"), "journal_entry_not_found"));
        if (stryMutAct_9fa48("1881") ? false : stryMutAct_9fa48("1880") ? true : stryMutAct_9fa48("1879") ? Number.isSafeInteger(effect.expenseDeltaMinorUnits) : (stryCov_9fa48("1879", "1880", "1881"), !Number.isSafeInteger(effect.expenseDeltaMinorUnits))) throw new AccountingError(stryMutAct_9fa48("1883") ? "" : (stryCov_9fa48("1883"), "journal_line_invalid"));
      }
    }
    for (const line of draft.lines) {
      if (stryMutAct_9fa48("1884")) {
        {}
      } else {
        stryCov_9fa48("1884");
        if (stryMutAct_9fa48("1886") ? false : stryMutAct_9fa48("1885") ? true : (stryCov_9fa48("1885", "1886"), line.category)) {
          if (stryMutAct_9fa48("1887")) {
            {}
          } else {
            stryCov_9fa48("1887");
            const category = await store.getCategory(line.category.categoryId);
            if (stryMutAct_9fa48("1890") ? !category && category.workspaceId !== workspaceId : stryMutAct_9fa48("1889") ? false : stryMutAct_9fa48("1888") ? true : (stryCov_9fa48("1888", "1889", "1890"), (stryMutAct_9fa48("1891") ? category : (stryCov_9fa48("1891"), !category)) || (stryMutAct_9fa48("1893") ? category.workspaceId === workspaceId : stryMutAct_9fa48("1892") ? false : (stryCov_9fa48("1892", "1893"), category.workspaceId !== workspaceId)))) throw new AccountingError(stryMutAct_9fa48("1895") ? "" : (stryCov_9fa48("1895"), "category_not_found"));
          }
        }
        for (const ref of stryMutAct_9fa48("1896") ? line.categoryCorrection?.sources && [] : (stryCov_9fa48("1896"), (stryMutAct_9fa48("1897") ? line.categoryCorrection.sources : (stryCov_9fa48("1897"), line.categoryCorrection?.sources)) ?? (stryMutAct_9fa48("1898") ? ["Stryker was here"] : (stryCov_9fa48("1898"), [])))) {
          if (stryMutAct_9fa48("1899")) {
            {}
          } else {
            stryCov_9fa48("1899");
            const source = await store.getJournalEntry(ref.entryId);
            if (stryMutAct_9fa48("1902") ? (!source || source.workspaceId !== workspaceId) && !source.lines[ref.lineNumber] : stryMutAct_9fa48("1901") ? false : stryMutAct_9fa48("1900") ? true : (stryCov_9fa48("1900", "1901", "1902"), (stryMutAct_9fa48("1904") ? !source && source.workspaceId !== workspaceId : stryMutAct_9fa48("1903") ? false : (stryCov_9fa48("1903", "1904"), (stryMutAct_9fa48("1905") ? source : (stryCov_9fa48("1905"), !source)) || (stryMutAct_9fa48("1907") ? source.workspaceId === workspaceId : stryMutAct_9fa48("1906") ? false : (stryCov_9fa48("1906", "1907"), source.workspaceId !== workspaceId)))) || (stryMutAct_9fa48("1908") ? source.lines[ref.lineNumber] : (stryCov_9fa48("1908"), !source.lines[ref.lineNumber])))) throw new AccountingError(stryMutAct_9fa48("1910") ? "" : (stryCov_9fa48("1910"), "journal_entry_not_found"));
          }
        }
      }
    }
    if (stryMutAct_9fa48("1913") ? draft.financialAccountProfileId === undefined : stryMutAct_9fa48("1912") ? false : stryMutAct_9fa48("1911") ? true : (stryCov_9fa48("1911", "1912", "1913"), draft.financialAccountProfileId !== undefined)) {
      if (stryMutAct_9fa48("1914")) {
        {}
      } else {
        stryCov_9fa48("1914");
        const profile = await store.getProfile(draft.financialAccountProfileId);
        if (stryMutAct_9fa48("1917") ? !profile && profile.workspaceId !== workspaceId : stryMutAct_9fa48("1916") ? false : stryMutAct_9fa48("1915") ? true : (stryCov_9fa48("1915", "1916", "1917"), (stryMutAct_9fa48("1918") ? profile : (stryCov_9fa48("1918"), !profile)) || (stryMutAct_9fa48("1920") ? profile.workspaceId === workspaceId : stryMutAct_9fa48("1919") ? false : (stryCov_9fa48("1919", "1920"), profile.workspaceId !== workspaceId)))) {
          if (stryMutAct_9fa48("1921")) {
            {}
          } else {
            stryCov_9fa48("1921");
            throw new AccountingError(stryMutAct_9fa48("1923") ? "" : (stryCov_9fa48("1923"), "financial_account_profile_not_found"));
          }
        }
      }
    }
    if (stryMutAct_9fa48("1926") ? draft.reversesEntryId === undefined : stryMutAct_9fa48("1925") ? false : stryMutAct_9fa48("1924") ? true : (stryCov_9fa48("1924", "1925", "1926"), draft.reversesEntryId !== undefined)) {
      if (stryMutAct_9fa48("1927")) {
        {}
      } else {
        stryCov_9fa48("1927");
        const reversed = await store.getJournalEntry(draft.reversesEntryId);
        if (stryMutAct_9fa48("1930") ? !reversed && reversed.workspaceId !== workspaceId : stryMutAct_9fa48("1929") ? false : stryMutAct_9fa48("1928") ? true : (stryCov_9fa48("1928", "1929", "1930"), (stryMutAct_9fa48("1931") ? reversed : (stryCov_9fa48("1931"), !reversed)) || (stryMutAct_9fa48("1933") ? reversed.workspaceId === workspaceId : stryMutAct_9fa48("1932") ? false : (stryCov_9fa48("1932", "1933"), reversed.workspaceId !== workspaceId)))) {
          if (stryMutAct_9fa48("1934")) {
            {}
          } else {
            stryCov_9fa48("1934");
            throw new AccountingError(stryMutAct_9fa48("1936") ? "" : (stryCov_9fa48("1936"), "journal_entry_not_found"));
          }
        }
      }
    }
  }
}
function sameDraft(entry: StoredJournalEntry, draft: JournalEntryDraft): boolean {
  if (stryMutAct_9fa48("1937")) {
    {}
  } else {
    stryCov_9fa48("1937");
    return stryMutAct_9fa48("1940") ? entry.accountingDate === draft.accountingDate && entry.description === draft.description && entry.policy === draft.policy && commandIdentity(entry.cashCategoryInput) === commandIdentity(draft.cashCategoryInput) && commandIdentity(entry.sourceExpenseEffects) === commandIdentity(draft.sourceExpenseEffects) && entry.financialAccountProfileId === draft.financialAccountProfileId && entry.reversesEntryId === draft.reversesEntryId && entry.lines.length === draft.lines.length || entry.lines.every((line, index) => {
      const other = draft.lines[index];
      return other !== undefined && commandIdentity(line.category) === commandIdentity(other.category) && commandIdentity(line.categoryCorrection) === commandIdentity(other.categoryCorrection) && line.ledgerAccountId === other.ledgerAccountId && line.debitMinorUnits === other.debitMinorUnits && line.creditMinorUnits === other.creditMinorUnits;
    }) : stryMutAct_9fa48("1939") ? false : stryMutAct_9fa48("1938") ? true : (stryCov_9fa48("1938", "1939", "1940"), (stryMutAct_9fa48("1942") ? entry.accountingDate === draft.accountingDate && entry.description === draft.description && entry.policy === draft.policy && commandIdentity(entry.cashCategoryInput) === commandIdentity(draft.cashCategoryInput) && commandIdentity(entry.sourceExpenseEffects) === commandIdentity(draft.sourceExpenseEffects) && entry.financialAccountProfileId === draft.financialAccountProfileId && entry.reversesEntryId === draft.reversesEntryId || entry.lines.length === draft.lines.length : stryMutAct_9fa48("1941") ? true : (stryCov_9fa48("1941", "1942"), (stryMutAct_9fa48("1944") ? entry.accountingDate === draft.accountingDate && entry.description === draft.description && entry.policy === draft.policy && commandIdentity(entry.cashCategoryInput) === commandIdentity(draft.cashCategoryInput) && commandIdentity(entry.sourceExpenseEffects) === commandIdentity(draft.sourceExpenseEffects) && entry.financialAccountProfileId === draft.financialAccountProfileId || entry.reversesEntryId === draft.reversesEntryId : stryMutAct_9fa48("1943") ? true : (stryCov_9fa48("1943", "1944"), (stryMutAct_9fa48("1946") ? entry.accountingDate === draft.accountingDate && entry.description === draft.description && entry.policy === draft.policy && commandIdentity(entry.cashCategoryInput) === commandIdentity(draft.cashCategoryInput) && commandIdentity(entry.sourceExpenseEffects) === commandIdentity(draft.sourceExpenseEffects) || entry.financialAccountProfileId === draft.financialAccountProfileId : stryMutAct_9fa48("1945") ? true : (stryCov_9fa48("1945", "1946"), (stryMutAct_9fa48("1948") ? entry.accountingDate === draft.accountingDate && entry.description === draft.description && entry.policy === draft.policy && commandIdentity(entry.cashCategoryInput) === commandIdentity(draft.cashCategoryInput) || commandIdentity(entry.sourceExpenseEffects) === commandIdentity(draft.sourceExpenseEffects) : stryMutAct_9fa48("1947") ? true : (stryCov_9fa48("1947", "1948"), (stryMutAct_9fa48("1950") ? entry.accountingDate === draft.accountingDate && entry.description === draft.description && entry.policy === draft.policy || commandIdentity(entry.cashCategoryInput) === commandIdentity(draft.cashCategoryInput) : stryMutAct_9fa48("1949") ? true : (stryCov_9fa48("1949", "1950"), (stryMutAct_9fa48("1952") ? entry.accountingDate === draft.accountingDate && entry.description === draft.description || entry.policy === draft.policy : stryMutAct_9fa48("1951") ? true : (stryCov_9fa48("1951", "1952"), (stryMutAct_9fa48("1954") ? entry.accountingDate === draft.accountingDate || entry.description === draft.description : stryMutAct_9fa48("1953") ? true : (stryCov_9fa48("1953", "1954"), (stryMutAct_9fa48("1956") ? entry.accountingDate !== draft.accountingDate : stryMutAct_9fa48("1955") ? true : (stryCov_9fa48("1955", "1956"), entry.accountingDate === draft.accountingDate)) && (stryMutAct_9fa48("1958") ? entry.description !== draft.description : stryMutAct_9fa48("1957") ? true : (stryCov_9fa48("1957", "1958"), entry.description === draft.description)))) && (stryMutAct_9fa48("1960") ? entry.policy !== draft.policy : stryMutAct_9fa48("1959") ? true : (stryCov_9fa48("1959", "1960"), entry.policy === draft.policy)))) && (stryMutAct_9fa48("1962") ? commandIdentity(entry.cashCategoryInput) !== commandIdentity(draft.cashCategoryInput) : stryMutAct_9fa48("1961") ? true : (stryCov_9fa48("1961", "1962"), commandIdentity(entry.cashCategoryInput) === commandIdentity(draft.cashCategoryInput))))) && (stryMutAct_9fa48("1964") ? commandIdentity(entry.sourceExpenseEffects) !== commandIdentity(draft.sourceExpenseEffects) : stryMutAct_9fa48("1963") ? true : (stryCov_9fa48("1963", "1964"), commandIdentity(entry.sourceExpenseEffects) === commandIdentity(draft.sourceExpenseEffects))))) && (stryMutAct_9fa48("1966") ? entry.financialAccountProfileId !== draft.financialAccountProfileId : stryMutAct_9fa48("1965") ? true : (stryCov_9fa48("1965", "1966"), entry.financialAccountProfileId === draft.financialAccountProfileId)))) && (stryMutAct_9fa48("1968") ? entry.reversesEntryId !== draft.reversesEntryId : stryMutAct_9fa48("1967") ? true : (stryCov_9fa48("1967", "1968"), entry.reversesEntryId === draft.reversesEntryId)))) && (stryMutAct_9fa48("1970") ? entry.lines.length !== draft.lines.length : stryMutAct_9fa48("1969") ? true : (stryCov_9fa48("1969", "1970"), entry.lines.length === draft.lines.length)))) && (stryMutAct_9fa48("1971") ? entry.lines.some((line, index) => {
      const other = draft.lines[index];
      return other !== undefined && commandIdentity(line.category) === commandIdentity(other.category) && commandIdentity(line.categoryCorrection) === commandIdentity(other.categoryCorrection) && line.ledgerAccountId === other.ledgerAccountId && line.debitMinorUnits === other.debitMinorUnits && line.creditMinorUnits === other.creditMinorUnits;
    }) : (stryCov_9fa48("1971"), entry.lines.every((line, index) => {
      if (stryMutAct_9fa48("1972")) {
        {}
      } else {
        stryCov_9fa48("1972");
        const other = draft.lines[index];
        return stryMutAct_9fa48("1975") ? other !== undefined && commandIdentity(line.category) === commandIdentity(other.category) && commandIdentity(line.categoryCorrection) === commandIdentity(other.categoryCorrection) && line.ledgerAccountId === other.ledgerAccountId && line.debitMinorUnits === other.debitMinorUnits || line.creditMinorUnits === other.creditMinorUnits : stryMutAct_9fa48("1974") ? false : stryMutAct_9fa48("1973") ? true : (stryCov_9fa48("1973", "1974", "1975"), (stryMutAct_9fa48("1977") ? other !== undefined && commandIdentity(line.category) === commandIdentity(other.category) && commandIdentity(line.categoryCorrection) === commandIdentity(other.categoryCorrection) && line.ledgerAccountId === other.ledgerAccountId || line.debitMinorUnits === other.debitMinorUnits : stryMutAct_9fa48("1976") ? true : (stryCov_9fa48("1976", "1977"), (stryMutAct_9fa48("1979") ? other !== undefined && commandIdentity(line.category) === commandIdentity(other.category) && commandIdentity(line.categoryCorrection) === commandIdentity(other.categoryCorrection) || line.ledgerAccountId === other.ledgerAccountId : stryMutAct_9fa48("1978") ? true : (stryCov_9fa48("1978", "1979"), (stryMutAct_9fa48("1981") ? other !== undefined && commandIdentity(line.category) === commandIdentity(other.category) || commandIdentity(line.categoryCorrection) === commandIdentity(other.categoryCorrection) : stryMutAct_9fa48("1980") ? true : (stryCov_9fa48("1980", "1981"), (stryMutAct_9fa48("1983") ? other !== undefined || commandIdentity(line.category) === commandIdentity(other.category) : stryMutAct_9fa48("1982") ? true : (stryCov_9fa48("1982", "1983"), (stryMutAct_9fa48("1985") ? other === undefined : stryMutAct_9fa48("1984") ? true : (stryCov_9fa48("1984", "1985"), other !== undefined)) && (stryMutAct_9fa48("1987") ? commandIdentity(line.category) !== commandIdentity(other.category) : stryMutAct_9fa48("1986") ? true : (stryCov_9fa48("1986", "1987"), commandIdentity(line.category) === commandIdentity(other.category))))) && (stryMutAct_9fa48("1989") ? commandIdentity(line.categoryCorrection) !== commandIdentity(other.categoryCorrection) : stryMutAct_9fa48("1988") ? true : (stryCov_9fa48("1988", "1989"), commandIdentity(line.categoryCorrection) === commandIdentity(other.categoryCorrection))))) && (stryMutAct_9fa48("1991") ? line.ledgerAccountId !== other.ledgerAccountId : stryMutAct_9fa48("1990") ? true : (stryCov_9fa48("1990", "1991"), line.ledgerAccountId === other.ledgerAccountId)))) && (stryMutAct_9fa48("1993") ? line.debitMinorUnits !== other.debitMinorUnits : stryMutAct_9fa48("1992") ? true : (stryCov_9fa48("1992", "1993"), line.debitMinorUnits === other.debitMinorUnits)))) && (stryMutAct_9fa48("1995") ? line.creditMinorUnits !== other.creditMinorUnits : stryMutAct_9fa48("1994") ? true : (stryCov_9fa48("1994", "1995"), line.creditMinorUnits === other.creditMinorUnits)));
      }
    }))));
  }
}