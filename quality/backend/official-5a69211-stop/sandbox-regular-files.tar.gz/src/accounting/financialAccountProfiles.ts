// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "./errors";
import type { AccountingStore, StoredProfile } from "./types";
export async function requireProfile(store: AccountingStore, workspaceId: string, profileId: string): Promise<StoredProfile> {
  if (stryMutAct_9fa48("1470")) {
    {}
  } else {
    stryCov_9fa48("1470");
    const profile = await store.getProfile(profileId);
    if (stryMutAct_9fa48("1473") ? !profile && profile.workspaceId !== workspaceId : stryMutAct_9fa48("1472") ? false : stryMutAct_9fa48("1471") ? true : (stryCov_9fa48("1471", "1472", "1473"), (stryMutAct_9fa48("1474") ? profile : (stryCov_9fa48("1474"), !profile)) || (stryMutAct_9fa48("1476") ? profile.workspaceId === workspaceId : stryMutAct_9fa48("1475") ? false : (stryCov_9fa48("1475", "1476"), profile.workspaceId !== workspaceId)))) throw new AccountingError(stryMutAct_9fa48("1478") ? "" : (stryCov_9fa48("1478"), "financial_account_profile_not_found"));
    return profile;
  }
}