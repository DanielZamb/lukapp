// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "../errors";
import { requireWorkspace } from "../membership";
import { periodFromAccountingDate } from "../period";
import { earliestPermittedDate } from "../periodControl";
import { postJournalEntry } from "../posting";
import type { AccountingClock, AccountingStore, Actor, PostedJournalEntry } from "../types";
import { journalContext, toPostedJournalEntry } from "../views";

/**
 * Append-only correction: a new Posted entry that mirrors every line of the original,
 * so the pair nets to zero and the original stays untouched. Record a Replacement
 * Entry afterwards when the correct treatment is a different amount or account.
 *
 * Without an explicit date the reversal takes the original Accounting Date, or the
 * first day of the next unlocked period when the original's period is Locked.
 */
export async function reversePostedEntry(store: AccountingStore, clock: AccountingClock, input: {
  actor: Actor;
  workspaceId: string;
  journalEntryId: string;
  accountingDate?: string;
  description?: string;
  idempotencyKey: string;
}): Promise<PostedJournalEntry> {
  if (stryMutAct_9fa48("1184")) {
    {}
  } else {
    stryCov_9fa48("1184");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("1185") ? "" : (stryCov_9fa48("1185"), "correct"));
    const original = await store.getJournalEntry(input.journalEntryId);
    if (stryMutAct_9fa48("1188") ? !original && original.workspaceId !== input.workspaceId : stryMutAct_9fa48("1187") ? false : stryMutAct_9fa48("1186") ? true : (stryCov_9fa48("1186", "1187", "1188"), (stryMutAct_9fa48("1189") ? original : (stryCov_9fa48("1189"), !original)) || (stryMutAct_9fa48("1191") ? original.workspaceId === input.workspaceId : stryMutAct_9fa48("1190") ? false : (stryCov_9fa48("1190", "1191"), original.workspaceId !== input.workspaceId)))) {
      if (stryMutAct_9fa48("1192")) {
        {}
      } else {
        stryCov_9fa48("1192");
        throw new AccountingError(stryMutAct_9fa48("1194") ? "" : (stryCov_9fa48("1194"), "journal_entry_not_found"));
      }
    }
    if (stryMutAct_9fa48("1196") ? false : stryMutAct_9fa48("1195") ? true : (stryCov_9fa48("1195", "1196"), original.reversesEntryId)) {
      if (stryMutAct_9fa48("1197")) {
        {}
      } else {
        stryCov_9fa48("1197");
        throw new AccountingError(stryMutAct_9fa48("1199") ? "" : (stryCov_9fa48("1199"), "reversal_cannot_be_reversed"));
      }
    }
    const earlier = await store.findReversalOf(original.id);
    if (stryMutAct_9fa48("1202") ? earlier || earlier.idempotencyKey !== input.idempotencyKey : stryMutAct_9fa48("1201") ? false : stryMutAct_9fa48("1200") ? true : (stryCov_9fa48("1200", "1201", "1202"), earlier && (stryMutAct_9fa48("1204") ? earlier.idempotencyKey === input.idempotencyKey : stryMutAct_9fa48("1203") ? true : (stryCov_9fa48("1203", "1204"), earlier.idempotencyKey !== input.idempotencyKey)))) {
      if (stryMutAct_9fa48("1205")) {
        {}
      } else {
        stryCov_9fa48("1205");
        throw new AccountingError(stryMutAct_9fa48("1207") ? "" : (stryCov_9fa48("1207"), "journal_entry_already_reversed"));
      }
    }
    const accountingDate = stryMutAct_9fa48("1208") ? (input.accountingDate ?? earlier?.accountingDate) && (await earliestPermittedDate(store, input.workspaceId, original.accountingDate)) : (stryCov_9fa48("1208"), (stryMutAct_9fa48("1209") ? input.accountingDate && earlier?.accountingDate : (stryCov_9fa48("1209"), input.accountingDate ?? (stryMutAct_9fa48("1210") ? earlier.accountingDate : (stryCov_9fa48("1210"), earlier?.accountingDate)))) ?? (await earliestPermittedDate(store, input.workspaceId, original.accountingDate)));
    if (stryMutAct_9fa48("1211")) {
      ;
    } else {
      stryCov_9fa48("1211");
      periodFromAccountingDate(accountingDate);
    }
    if (stryMutAct_9fa48("1215") ? accountingDate >= original.accountingDate : stryMutAct_9fa48("1214") ? accountingDate <= original.accountingDate : stryMutAct_9fa48("1213") ? false : stryMutAct_9fa48("1212") ? true : (stryCov_9fa48("1212", "1213", "1214", "1215"), accountingDate < original.accountingDate)) {
      if (stryMutAct_9fa48("1216")) {
        {}
      } else {
        stryCov_9fa48("1216");
        throw new AccountingError(stryMutAct_9fa48("1218") ? "" : (stryCov_9fa48("1218"), "reversal_date_before_original"));
      }
    }
    const draft = stryMutAct_9fa48("1219") ? {} : (stryCov_9fa48("1219"), {
      accountingDate,
      description: stryMutAct_9fa48("1220") ? input.description && `Reversal: ${original.description}` : (stryCov_9fa48("1220"), input.description ?? (stryMutAct_9fa48("1221") ? `` : (stryCov_9fa48("1221"), `Reversal: ${original.description}`))),
      idempotencyKey: input.idempotencyKey,
      policy: "reversal@1" as const,
      ...(original.cashCategoryInput ? stryMutAct_9fa48("1222") ? {} : (stryCov_9fa48("1222"), {
        cashCategoryInput: original.cashCategoryInput
      }) : {}),
      reversesEntryId: original.id,
      ...(original.sourceExpenseEffects ? stryMutAct_9fa48("1223") ? {} : (stryCov_9fa48("1223"), {
        sourceExpenseEffects: original.sourceExpenseEffects.map(stryMutAct_9fa48("1224") ? () => undefined : (stryCov_9fa48("1224"), e => stryMutAct_9fa48("1225") ? {} : (stryCov_9fa48("1225"), {
          sourceEntryId: e.sourceEntryId,
          expenseDeltaMinorUnits: stryMutAct_9fa48("1226") ? +e.expenseDeltaMinorUnits : (stryCov_9fa48("1226"), -e.expenseDeltaMinorUnits)
        })))
      }) : {}),
      lines: original.lines.map(stryMutAct_9fa48("1227") ? () => undefined : (stryCov_9fa48("1227"), line => stryMutAct_9fa48("1228") ? {} : (stryCov_9fa48("1228"), {
        ...(line.category ? stryMutAct_9fa48("1229") ? {} : (stryCov_9fa48("1229"), {
          category: line.category
        }) : {}),
        ...(line.categoryCorrection ? stryMutAct_9fa48("1230") ? {} : (stryCov_9fa48("1230"), {
          categoryCorrection: line.categoryCorrection
        }) : {}),
        ledgerAccountId: line.ledgerAccountId,
        debitMinorUnits: line.creditMinorUnits,
        creditMinorUnits: line.debitMinorUnits
      })))
    });
    const {
      entry,
      replay
    } = await postJournalEntry(store, clock, stryMutAct_9fa48("1231") ? {} : (stryCov_9fa48("1231"), {
      actor: input.actor,
      workspaceId: input.workspaceId,
      draft: original.financialAccountProfileId ? stryMutAct_9fa48("1232") ? {} : (stryCov_9fa48("1232"), {
        ...draft,
        financialAccountProfileId: original.financialAccountProfileId
      }) : draft
    }));
    return toPostedJournalEntry(store, await journalContext(store, workspace), entry, stryMutAct_9fa48("1233") ? {} : (stryCov_9fa48("1233"), {
      replay
    }));
  }
}