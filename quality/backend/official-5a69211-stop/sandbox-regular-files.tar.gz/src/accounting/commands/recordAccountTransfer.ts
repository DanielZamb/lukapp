// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "../errors";
import { requireWorkspace } from "../membership";
import { requireFunctionalAmount } from "../money";
import { requireProfile } from "../financialAccountProfiles";
import { postJournalEntry } from "../posting";
import type { AccountingClock, AccountingStore, AccountTransferInput, PostedJournalEntry } from "../types";
import { journalContext, toPostedJournalEntry } from "../views";
export async function recordAccountTransfer(store: AccountingStore, clock: AccountingClock, input: AccountTransferInput): Promise<PostedJournalEntry> {
  if (stryMutAct_9fa48("1016")) {
    {}
  } else {
    stryCov_9fa48("1016");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("1017") ? "" : (stryCov_9fa48("1017"), "post"));
    const amount = requireFunctionalAmount(workspace, input.amount);
    if (stryMutAct_9fa48("1020") ? input.sourceFinancialAccountProfileId !== input.destinationFinancialAccountProfileId : stryMutAct_9fa48("1019") ? false : stryMutAct_9fa48("1018") ? true : (stryCov_9fa48("1018", "1019", "1020"), input.sourceFinancialAccountProfileId === input.destinationFinancialAccountProfileId)) throw new AccountingError(stryMutAct_9fa48("1022") ? "" : (stryCov_9fa48("1022"), "account_transfer_same_profile"));
    const source = await requireProfile(store, input.workspaceId, input.sourceFinancialAccountProfileId);
    const destination = await requireProfile(store, input.workspaceId, input.destinationFinancialAccountProfileId);
    const {
      entry,
      replay
    } = await postJournalEntry(store, clock, stryMutAct_9fa48("1023") ? {} : (stryCov_9fa48("1023"), {
      actor: input.actor,
      workspaceId: input.workspaceId,
      draft: stryMutAct_9fa48("1024") ? {} : (stryCov_9fa48("1024"), {
        policy: stryMutAct_9fa48("1025") ? "" : (stryCov_9fa48("1025"), "account-transfer@1"),
        financialAccountProfileId: source.id,
        accountingDate: input.accountingDate,
        description: input.description,
        idempotencyKey: input.idempotencyKey,
        lines: stryMutAct_9fa48("1026") ? [] : (stryCov_9fa48("1026"), [stryMutAct_9fa48("1027") ? {} : (stryCov_9fa48("1027"), {
          ledgerAccountId: destination.postingAccountId,
          debitMinorUnits: amount,
          creditMinorUnits: 0
        }), stryMutAct_9fa48("1028") ? {} : (stryCov_9fa48("1028"), {
          ledgerAccountId: source.postingAccountId,
          debitMinorUnits: 0,
          creditMinorUnits: amount
        })])
      })
    }));
    const reversal = await store.findReversalOf(entry.id);
    return toPostedJournalEntry(store, await journalContext(store, workspace), entry, stryMutAct_9fa48("1029") ? {} : (stryCov_9fa48("1029"), {
      replay,
      ...(reversal ? stryMutAct_9fa48("1030") ? {} : (stryCov_9fa48("1030"), {
        reversedByEntryId: reversal.id
      }) : {})
    }));
  }
}