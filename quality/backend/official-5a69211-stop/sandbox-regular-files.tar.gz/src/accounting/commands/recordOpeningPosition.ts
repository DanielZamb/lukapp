// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { requireTemplateAccount } from "../chartOfAccounts";
import { AccountingError } from "../errors";
import { requireWorkspace } from "../membership";
import { requireProfile } from "../financialAccountProfiles";
import { periodFromAccountingDate } from "../period";
import { assertOpeningCutover } from "../openingDate";
import { requirePostablePeriod } from "../periodControl";
import { postJournalEntry } from "../posting";
import type { AccountingClock, AccountingStore, OpeningPositionInput, OpeningPositionResult, StoredOpening, StoredWorkspace } from "../types";
import { journalContext, toPostedJournalEntry, toProfile } from "../views";
export async function recordOpeningPosition(store: AccountingStore, clock: AccountingClock, input: OpeningPositionInput): Promise<OpeningPositionResult> {
  if (stryMutAct_9fa48("1041")) {
    {}
  } else {
    stryCov_9fa48("1041");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("1042") ? "" : (stryCov_9fa48("1042"), "post"));
    if (stryMutAct_9fa48("1045") ? !Number.isSafeInteger(input.amount.minorUnits) && input.amount.minorUnits < 0 : stryMutAct_9fa48("1044") ? false : stryMutAct_9fa48("1043") ? true : (stryCov_9fa48("1043", "1044", "1045"), (stryMutAct_9fa48("1046") ? Number.isSafeInteger(input.amount.minorUnits) : (stryCov_9fa48("1046"), !Number.isSafeInteger(input.amount.minorUnits))) || (stryMutAct_9fa48("1049") ? input.amount.minorUnits >= 0 : stryMutAct_9fa48("1048") ? input.amount.minorUnits <= 0 : stryMutAct_9fa48("1047") ? false : (stryCov_9fa48("1047", "1048", "1049"), input.amount.minorUnits < 0)))) throw new AccountingError(stryMutAct_9fa48("1051") ? "" : (stryCov_9fa48("1051"), "opening_amount_invalid"));
    if (stryMutAct_9fa48("1054") ? input.amount.currency === workspace.functionalCurrency : stryMutAct_9fa48("1053") ? false : stryMutAct_9fa48("1052") ? true : (stryCov_9fa48("1052", "1053", "1054"), input.amount.currency !== workspace.functionalCurrency)) throw new AccountingError(stryMutAct_9fa48("1056") ? "" : (stryCov_9fa48("1056"), "currency_mismatch"));
    if (stryMutAct_9fa48("1057")) {
      ;
    } else {
      stryCov_9fa48("1057");
      periodFromAccountingDate(input.accountingDate);
    }
    if (stryMutAct_9fa48("1060") ? false : stryMutAct_9fa48("1059") ? true : stryMutAct_9fa48("1058") ? input.idempotencyKey : (stryCov_9fa48("1058", "1059", "1060"), !input.idempotencyKey)) throw new AccountingError(stryMutAct_9fa48("1062") ? "" : (stryCov_9fa48("1062"), "idempotency_key_required"));
    const profile = await requireProfile(store, input.workspaceId, input.financialAccountProfileId);
    const previous = await store.findOpeningPositionByKey(input.workspaceId, input.idempotencyKey);
    if (stryMutAct_9fa48("1064") ? false : stryMutAct_9fa48("1063") ? true : (stryCov_9fa48("1063", "1064"), previous)) {
      if (stryMutAct_9fa48("1065")) {
        {}
      } else {
        stryCov_9fa48("1065");
        if (stryMutAct_9fa48("1068") ? (previous.financialAccountProfileId !== profile.id || previous.description !== input.description || previous.replacesOpeningKey !== input.replacesOpeningKey || previous.opening.accountingDate !== input.accountingDate || previous.opening.amount.minorUnits !== input.amount.minorUnits) && previous.opening.amount.currency !== input.amount.currency : stryMutAct_9fa48("1067") ? false : stryMutAct_9fa48("1066") ? true : (stryCov_9fa48("1066", "1067", "1068"), (stryMutAct_9fa48("1070") ? (previous.financialAccountProfileId !== profile.id || previous.description !== input.description || previous.replacesOpeningKey !== input.replacesOpeningKey || previous.opening.accountingDate !== input.accountingDate) && previous.opening.amount.minorUnits !== input.amount.minorUnits : stryMutAct_9fa48("1069") ? false : (stryCov_9fa48("1069", "1070"), (stryMutAct_9fa48("1072") ? (previous.financialAccountProfileId !== profile.id || previous.description !== input.description || previous.replacesOpeningKey !== input.replacesOpeningKey) && previous.opening.accountingDate !== input.accountingDate : stryMutAct_9fa48("1071") ? false : (stryCov_9fa48("1071", "1072"), (stryMutAct_9fa48("1074") ? (previous.financialAccountProfileId !== profile.id || previous.description !== input.description) && previous.replacesOpeningKey !== input.replacesOpeningKey : stryMutAct_9fa48("1073") ? false : (stryCov_9fa48("1073", "1074"), (stryMutAct_9fa48("1076") ? previous.financialAccountProfileId !== profile.id && previous.description !== input.description : stryMutAct_9fa48("1075") ? false : (stryCov_9fa48("1075", "1076"), (stryMutAct_9fa48("1078") ? previous.financialAccountProfileId === profile.id : stryMutAct_9fa48("1077") ? false : (stryCov_9fa48("1077", "1078"), previous.financialAccountProfileId !== profile.id)) || (stryMutAct_9fa48("1080") ? previous.description === input.description : stryMutAct_9fa48("1079") ? false : (stryCov_9fa48("1079", "1080"), previous.description !== input.description)))) || (stryMutAct_9fa48("1082") ? previous.replacesOpeningKey === input.replacesOpeningKey : stryMutAct_9fa48("1081") ? false : (stryCov_9fa48("1081", "1082"), previous.replacesOpeningKey !== input.replacesOpeningKey)))) || (stryMutAct_9fa48("1084") ? previous.opening.accountingDate === input.accountingDate : stryMutAct_9fa48("1083") ? false : (stryCov_9fa48("1083", "1084"), previous.opening.accountingDate !== input.accountingDate)))) || (stryMutAct_9fa48("1086") ? previous.opening.amount.minorUnits === input.amount.minorUnits : stryMutAct_9fa48("1085") ? false : (stryCov_9fa48("1085", "1086"), previous.opening.amount.minorUnits !== input.amount.minorUnits)))) || (stryMutAct_9fa48("1088") ? previous.opening.amount.currency === input.amount.currency : stryMutAct_9fa48("1087") ? false : (stryCov_9fa48("1087", "1088"), previous.opening.amount.currency !== input.amount.currency)))) {
          if (stryMutAct_9fa48("1089")) {
            {}
          } else {
            stryCov_9fa48("1089");
            throw new AccountingError(stryMutAct_9fa48("1091") ? "" : (stryCov_9fa48("1091"), "idempotency_key_conflict"));
          }
        }
        return openingResult(store, workspace, profile.id, previous.opening, stryMutAct_9fa48("1092") ? false : (stryCov_9fa48("1092"), true));
      }
    }
    if (stryMutAct_9fa48("1094") ? false : stryMutAct_9fa48("1093") ? true : (stryCov_9fa48("1093", "1094"), await store.findJournalEntryByIdempotencyKey(input.workspaceId, input.idempotencyKey))) throw new AccountingError(stryMutAct_9fa48("1096") ? "" : (stryCov_9fa48("1096"), "idempotency_key_conflict"));
    if (stryMutAct_9fa48("1098") ? false : stryMutAct_9fa48("1097") ? true : (stryCov_9fa48("1097", "1098"), profile.opening)) {
      if (stryMutAct_9fa48("1099")) {
        {}
      } else {
        stryCov_9fa48("1099");
        await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("1100") ? "" : (stryCov_9fa48("1100"), "correct"));
        if (stryMutAct_9fa48("1103") ? input.replacesOpeningKey !== undefined || input.replacesOpeningKey !== profile.opening.idempotencyKey : stryMutAct_9fa48("1102") ? false : stryMutAct_9fa48("1101") ? true : (stryCov_9fa48("1101", "1102", "1103"), (stryMutAct_9fa48("1105") ? input.replacesOpeningKey === undefined : stryMutAct_9fa48("1104") ? true : (stryCov_9fa48("1104", "1105"), input.replacesOpeningKey !== undefined)) && (stryMutAct_9fa48("1107") ? input.replacesOpeningKey === profile.opening.idempotencyKey : stryMutAct_9fa48("1106") ? true : (stryCov_9fa48("1106", "1107"), input.replacesOpeningKey !== profile.opening.idempotencyKey)))) throw new AccountingError(stryMutAct_9fa48("1109") ? "" : (stryCov_9fa48("1109"), "opening_replacement_conflict"));
        if (stryMutAct_9fa48("1111") ? false : stryMutAct_9fa48("1110") ? true : (stryCov_9fa48("1110", "1111"), (stryMutAct_9fa48("1114") ? profile.opening.kind !== "zero" : stryMutAct_9fa48("1113") ? false : stryMutAct_9fa48("1112") ? true : (stryCov_9fa48("1112", "1113", "1114"), profile.opening.kind === (stryMutAct_9fa48("1115") ? "" : (stryCov_9fa48("1115"), "zero")))) ? stryMutAct_9fa48("1118") ? input.replacesOpeningKey === profile.opening.idempotencyKey : stryMutAct_9fa48("1117") ? false : stryMutAct_9fa48("1116") ? true : (stryCov_9fa48("1116", "1117", "1118"), input.replacesOpeningKey !== profile.opening.idempotencyKey) : stryMutAct_9fa48("1119") ? await store.findReversalOf(profile.opening.journalEntryId) : (stryCov_9fa48("1119"), !(await store.findReversalOf(profile.opening.journalEntryId))))) {
          if (stryMutAct_9fa48("1120")) {
            {}
          } else {
            stryCov_9fa48("1120");
            throw new AccountingError(stryMutAct_9fa48("1122") ? "" : (stryCov_9fa48("1122"), "opening_already_recorded"));
          }
        }
      }
    } else {
      if (stryMutAct_9fa48("1123")) {
        {}
      } else {
        stryCov_9fa48("1123");
        if (stryMutAct_9fa48("1126") ? input.replacesOpeningKey === undefined : stryMutAct_9fa48("1125") ? false : stryMutAct_9fa48("1124") ? true : (stryCov_9fa48("1124", "1125", "1126"), input.replacesOpeningKey !== undefined)) throw new AccountingError(stryMutAct_9fa48("1128") ? "" : (stryCov_9fa48("1128"), "opening_replacement_conflict"));
      }
    }
    await assertOpeningCutover(store, profile, input.accountingDate);
    if (stryMutAct_9fa48("1130") ? false : stryMutAct_9fa48("1129") ? true : (stryCov_9fa48("1129", "1130"), profile.opening)) await store.clearProfileOpening(profile.id);
    let opening: StoredOpening;
    const common = stryMutAct_9fa48("1131") ? {} : (stryCov_9fa48("1131"), {
      accountingDate: input.accountingDate,
      idempotencyKey: input.idempotencyKey,
      amount: input.amount
    });
    if (stryMutAct_9fa48("1134") ? input.amount.minorUnits !== 0 : stryMutAct_9fa48("1133") ? false : stryMutAct_9fa48("1132") ? true : (stryCov_9fa48("1132", "1133", "1134"), input.amount.minorUnits === 0)) {
      if (stryMutAct_9fa48("1135")) {
        {}
      } else {
        stryCov_9fa48("1135");
        await requirePostablePeriod(store, input.workspaceId, input.accountingDate);
        opening = stryMutAct_9fa48("1136") ? {} : (stryCov_9fa48("1136"), {
          ...common,
          kind: stryMutAct_9fa48("1137") ? "" : (stryCov_9fa48("1137"), "zero")
        });
      }
    } else {
      if (stryMutAct_9fa48("1138")) {
        {}
      } else {
        stryCov_9fa48("1138");
        const account = await store.getLedgerAccount(profile.postingAccountId);
        if (stryMutAct_9fa48("1141") ? !account && account.workspaceId !== input.workspaceId : stryMutAct_9fa48("1140") ? false : stryMutAct_9fa48("1139") ? true : (stryCov_9fa48("1139", "1140", "1141"), (stryMutAct_9fa48("1142") ? account : (stryCov_9fa48("1142"), !account)) || (stryMutAct_9fa48("1144") ? account.workspaceId === input.workspaceId : stryMutAct_9fa48("1143") ? false : (stryCov_9fa48("1143", "1144"), account.workspaceId !== input.workspaceId)))) throw new AccountingError(stryMutAct_9fa48("1146") ? "" : (stryCov_9fa48("1146"), "ledger_account_not_found"));
        const equity = await requireTemplateAccount(store, workspace, stryMutAct_9fa48("1147") ? "" : (stryCov_9fa48("1147"), "openingBalance"));
        const debitId = (stryMutAct_9fa48("1150") ? account.normalSide !== "Debit" : stryMutAct_9fa48("1149") ? false : stryMutAct_9fa48("1148") ? true : (stryCov_9fa48("1148", "1149", "1150"), account.normalSide === (stryMutAct_9fa48("1151") ? "" : (stryCov_9fa48("1151"), "Debit")))) ? account.id : equity.id;
        const creditId = (stryMutAct_9fa48("1154") ? account.normalSide !== "Debit" : stryMutAct_9fa48("1153") ? false : stryMutAct_9fa48("1152") ? true : (stryCov_9fa48("1152", "1153", "1154"), account.normalSide === (stryMutAct_9fa48("1155") ? "" : (stryCov_9fa48("1155"), "Debit")))) ? equity.id : account.id;
        const {
          entry
        } = await postJournalEntry(store, clock, stryMutAct_9fa48("1156") ? {} : (stryCov_9fa48("1156"), {
          actor: input.actor,
          workspaceId: input.workspaceId,
          draft: stryMutAct_9fa48("1157") ? {} : (stryCov_9fa48("1157"), {
            policy: stryMutAct_9fa48("1158") ? "" : (stryCov_9fa48("1158"), "opening-position@1"),
            financialAccountProfileId: profile.id,
            accountingDate: input.accountingDate,
            description: input.description,
            idempotencyKey: input.idempotencyKey,
            lines: stryMutAct_9fa48("1159") ? [] : (stryCov_9fa48("1159"), [stryMutAct_9fa48("1160") ? {} : (stryCov_9fa48("1160"), {
              ledgerAccountId: debitId,
              debitMinorUnits: input.amount.minorUnits,
              creditMinorUnits: 0
            }), stryMutAct_9fa48("1161") ? {} : (stryCov_9fa48("1161"), {
              ledgerAccountId: creditId,
              debitMinorUnits: 0,
              creditMinorUnits: input.amount.minorUnits
            })])
          })
        }));
        opening = stryMutAct_9fa48("1162") ? {} : (stryCov_9fa48("1162"), {
          ...common,
          kind: stryMutAct_9fa48("1163") ? "" : (stryCov_9fa48("1163"), "posted"),
          journalEntryId: entry.id
        });
      }
    }
    await store.saveOpeningPosition(stryMutAct_9fa48("1164") ? {} : (stryCov_9fa48("1164"), {
      workspaceId: input.workspaceId,
      financialAccountProfileId: profile.id,
      description: input.description,
      opening,
      ...((stryMutAct_9fa48("1167") ? input.replacesOpeningKey === undefined : stryMutAct_9fa48("1166") ? false : stryMutAct_9fa48("1165") ? true : (stryCov_9fa48("1165", "1166", "1167"), input.replacesOpeningKey !== undefined)) ? stryMutAct_9fa48("1168") ? {} : (stryCov_9fa48("1168"), {
        replacesOpeningKey: input.replacesOpeningKey
      }) : {})
    }));
    return openingResult(store, workspace, profile.id, opening, stryMutAct_9fa48("1169") ? true : (stryCov_9fa48("1169"), false));
  }
}
async function openingResult(store: AccountingStore, workspace: StoredWorkspace, profileId: string, opening: StoredOpening, replay: boolean): Promise<OpeningPositionResult> {
  if (stryMutAct_9fa48("1170")) {
    {}
  } else {
    stryCov_9fa48("1170");
    const profile = await requireProfile(store, workspace.id, profileId);
    let journalEntry = null;
    if (stryMutAct_9fa48("1173") ? opening.kind !== "posted" : stryMutAct_9fa48("1172") ? false : stryMutAct_9fa48("1171") ? true : (stryCov_9fa48("1171", "1172", "1173"), opening.kind === (stryMutAct_9fa48("1174") ? "" : (stryCov_9fa48("1174"), "posted")))) {
      if (stryMutAct_9fa48("1175")) {
        {}
      } else {
        stryCov_9fa48("1175");
        const entry = await store.getJournalEntry(opening.journalEntryId);
        if (stryMutAct_9fa48("1178") ? false : stryMutAct_9fa48("1177") ? true : stryMutAct_9fa48("1176") ? entry : (stryCov_9fa48("1176", "1177", "1178"), !entry)) throw new AccountingError(stryMutAct_9fa48("1180") ? "" : (stryCov_9fa48("1180"), "journal_entry_not_found"));
        const reversal = await store.findReversalOf(entry.id);
        journalEntry = await toPostedJournalEntry(store, await journalContext(store, workspace), entry, stryMutAct_9fa48("1181") ? {} : (stryCov_9fa48("1181"), {
          replay,
          ...(reversal ? stryMutAct_9fa48("1182") ? {} : (stryCov_9fa48("1182"), {
            reversedByEntryId: reversal.id
          }) : {})
        }));
      }
    }
    return stryMutAct_9fa48("1183") ? {} : (stryCov_9fa48("1183"), {
      profile: await toProfile(store, profile),
      journalEntry,
      replay
    });
  }
}