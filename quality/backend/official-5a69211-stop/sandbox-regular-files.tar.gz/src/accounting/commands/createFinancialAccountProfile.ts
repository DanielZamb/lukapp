// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { commandIdentity } from "../commandIdentity";
import { chartTemplate, nextAuxiliaryCode, normalSideOf } from "../chartOfAccounts";
import { classifyFinancialAccountProfile } from "../classification";
import { AccountingError } from "../errors";
import { requireWorkspace } from "../membership";
import type { AccountingStore, Actor, FinancialAccountProfile, FinancialAccountProductKind, ProfileClassificationAnswers } from "../types";
import { toProfile } from "../views";

/** Each profile gets its own auxiliary Posting Account, as a bookkeeper opens one per bank account. */
export async function createFinancialAccountProfile(store: AccountingStore, input: {
  actor: Actor;
  workspaceId: string;
  name: string;
  productKind: FinancialAccountProductKind;
  classificationAnswers?: ProfileClassificationAnswers;
  idempotencyKey?: string;
}): Promise<FinancialAccountProfile> {
  if (stryMutAct_9fa48("922")) {
    {}
  } else {
    stryCov_9fa48("922");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("923") ? "" : (stryCov_9fa48("923"), "prepare"));
    const name = stryMutAct_9fa48("924") ? input.name : (stryCov_9fa48("924"), input.name.trim());
    if (stryMutAct_9fa48("927") ? false : stryMutAct_9fa48("926") ? true : stryMutAct_9fa48("925") ? name : (stryCov_9fa48("925", "926", "927"), !name)) {
      if (stryMutAct_9fa48("928")) {
        {}
      } else {
        stryCov_9fa48("928");
        throw new AccountingError(stryMutAct_9fa48("930") ? "" : (stryCov_9fa48("930"), "name_required"));
      }
    }
    const classified = classifyFinancialAccountProfile(chartTemplate(workspace.chartOfAccountsTemplate), input.productKind, input.classificationAnswers);
    if (stryMutAct_9fa48("933") ? input.idempotencyKey === undefined : stryMutAct_9fa48("932") ? false : stryMutAct_9fa48("931") ? true : (stryCov_9fa48("931", "932", "933"), input.idempotencyKey !== undefined)) {
      if (stryMutAct_9fa48("934")) {
        {}
      } else {
        stryCov_9fa48("934");
        if (stryMutAct_9fa48("937") ? false : stryMutAct_9fa48("936") ? true : stryMutAct_9fa48("935") ? input.idempotencyKey : (stryCov_9fa48("935", "936", "937"), !input.idempotencyKey)) throw new AccountingError(stryMutAct_9fa48("939") ? "" : (stryCov_9fa48("939"), "idempotency_key_required"));
        const existing = await store.findProfileBySetupKey(input.workspaceId, input.idempotencyKey);
        if (stryMutAct_9fa48("941") ? false : stryMutAct_9fa48("940") ? true : (stryCov_9fa48("940", "941"), existing)) {
          if (stryMutAct_9fa48("942")) {
            {}
          } else {
            stryCov_9fa48("942");
            if (stryMutAct_9fa48("945") ? (existing.name !== name || existing.productKind !== input.productKind) && commandIdentity(existing.classificationAnswers) !== commandIdentity(classified.answers) : stryMutAct_9fa48("944") ? false : stryMutAct_9fa48("943") ? true : (stryCov_9fa48("943", "944", "945"), (stryMutAct_9fa48("947") ? existing.name !== name && existing.productKind !== input.productKind : stryMutAct_9fa48("946") ? false : (stryCov_9fa48("946", "947"), (stryMutAct_9fa48("949") ? existing.name === name : stryMutAct_9fa48("948") ? false : (stryCov_9fa48("948", "949"), existing.name !== name)) || (stryMutAct_9fa48("951") ? existing.productKind === input.productKind : stryMutAct_9fa48("950") ? false : (stryCov_9fa48("950", "951"), existing.productKind !== input.productKind)))) || (stryMutAct_9fa48("953") ? commandIdentity(existing.classificationAnswers) === commandIdentity(classified.answers) : stryMutAct_9fa48("952") ? false : (stryCov_9fa48("952", "953"), commandIdentity(existing.classificationAnswers) !== commandIdentity(classified.answers))))) throw new AccountingError(stryMutAct_9fa48("955") ? "" : (stryCov_9fa48("955"), "idempotency_key_conflict"));
            return toProfile(store, existing);
          }
        }
      }
    }
    const postingAccount = await store.insertLedgerAccount(stryMutAct_9fa48("956") ? {} : (stryCov_9fa48("956"), {
      workspaceId: input.workspaceId,
      code: await nextAuxiliaryCode(store, input.workspaceId, classified.parentCode),
      name,
      nature: classified.nature,
      normalSide: normalSideOf(classified.nature),
      role: stryMutAct_9fa48("957") ? "" : (stryCov_9fa48("957"), "Posting")
    }));
    const profile = await store.insertProfile(stryMutAct_9fa48("958") ? {} : (stryCov_9fa48("958"), {
      workspaceId: input.workspaceId,
      name,
      productKind: classified.productKind,
      classificationPolicy: classified.policy,
      ...(classified.answers ? stryMutAct_9fa48("959") ? {} : (stryCov_9fa48("959"), {
        classificationAnswers: classified.answers
      }) : {}),
      postingAccountId: postingAccount.id,
      ...((stryMutAct_9fa48("962") ? input.idempotencyKey === undefined : stryMutAct_9fa48("961") ? false : stryMutAct_9fa48("960") ? true : (stryCov_9fa48("960", "961", "962"), input.idempotencyKey !== undefined)) ? stryMutAct_9fa48("963") ? {} : (stryCov_9fa48("963"), {
        setupIdempotencyKey: input.idempotencyKey
      }) : {})
    }));
    return toProfile(store, profile);
  }
}