// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { createFinancialAccountProfile } from "./createFinancialAccountProfile";
import { recordOpeningPosition } from "./recordOpeningPosition";
import { AccountingError } from "../errors";
import { requireWorkspace } from "../membership";
import type { AccountingClock, AccountingStore, OpeningPositionResult, SetupFinancialAccountInput } from "../types";
export async function setupFinancialAccount(store: AccountingStore, clock: AccountingClock, input: SetupFinancialAccountInput): Promise<OpeningPositionResult> {
  if (stryMutAct_9fa48("1234")) {
    {}
  } else {
    stryCov_9fa48("1234");
    await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("1235") ? "" : (stryCov_9fa48("1235"), "post"));
    if (stryMutAct_9fa48("1238") ? false : stryMutAct_9fa48("1237") ? true : stryMutAct_9fa48("1236") ? input.idempotencyKey : (stryCov_9fa48("1236", "1237", "1238"), !input.idempotencyKey)) throw new AccountingError(stryMutAct_9fa48("1240") ? "" : (stryCov_9fa48("1240"), "idempotency_key_required"));
    const existing = await store.findProfileBySetupKey(input.workspaceId, input.idempotencyKey);
    if (stryMutAct_9fa48("1243") ? !existing || (await store.findOpeningPositionByKey(input.workspaceId, input.idempotencyKey)) || (await store.findJournalEntryByIdempotencyKey(input.workspaceId, input.idempotencyKey)) : stryMutAct_9fa48("1242") ? false : stryMutAct_9fa48("1241") ? true : (stryCov_9fa48("1241", "1242", "1243"), (stryMutAct_9fa48("1244") ? existing : (stryCov_9fa48("1244"), !existing)) && (stryMutAct_9fa48("1246") ? (await store.findOpeningPositionByKey(input.workspaceId, input.idempotencyKey)) && (await store.findJournalEntryByIdempotencyKey(input.workspaceId, input.idempotencyKey)) : stryMutAct_9fa48("1245") ? true : (stryCov_9fa48("1245", "1246"), (await store.findOpeningPositionByKey(input.workspaceId, input.idempotencyKey)) || (await store.findJournalEntryByIdempotencyKey(input.workspaceId, input.idempotencyKey)))))) {
      if (stryMutAct_9fa48("1247")) {
        {}
      } else {
        stryCov_9fa48("1247");
        throw new AccountingError(stryMutAct_9fa48("1249") ? "" : (stryCov_9fa48("1249"), "idempotency_key_conflict"));
      }
    }
    const profile = await createFinancialAccountProfile(store, input);
    return recordOpeningPosition(store, clock, stryMutAct_9fa48("1250") ? {} : (stryCov_9fa48("1250"), {
      ...input,
      financialAccountProfileId: profile.id
    }));
  }
}