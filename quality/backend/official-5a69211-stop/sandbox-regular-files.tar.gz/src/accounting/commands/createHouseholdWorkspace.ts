// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "../errors";
import { requireWorkspace } from "../membership";
import { openWorkspace } from "../queries/openWorkspace";
import type { AccountingClock, AccountingStore, Actor, Workspace } from "../types";
import { provisionWorkspace, workspaceConfiguration } from "../workspaceProvisioning";
export async function createHouseholdWorkspace(store: AccountingStore, clock: AccountingClock, input: {
  actor: Actor;
  functionalCurrency: string;
  chartOfAccountsTemplate?: string;
  idempotencyKey: string;
}): Promise<Workspace> {
  if (stryMutAct_9fa48("964")) {
    {}
  } else {
    stryCov_9fa48("964");
    if (stryMutAct_9fa48("967") ? false : stryMutAct_9fa48("966") ? true : stryMutAct_9fa48("965") ? input.idempotencyKey.trim() : (stryCov_9fa48("965", "966", "967"), !(stryMutAct_9fa48("968") ? input.idempotencyKey : (stryCov_9fa48("968"), input.idempotencyKey.trim())))) {
      if (stryMutAct_9fa48("969")) {
        {}
      } else {
        stryCov_9fa48("969");
        throw new AccountingError(stryMutAct_9fa48("971") ? "" : (stryCov_9fa48("971"), "idempotency_key_required"));
      }
    }
    const existingId = await store.findHouseholdWorkspaceByKey(input.actor.userId, input.idempotencyKey);
    if (stryMutAct_9fa48("973") ? false : stryMutAct_9fa48("972") ? true : (stryCov_9fa48("972", "973"), existingId)) {
      if (stryMutAct_9fa48("974")) {
        {}
      } else {
        stryCov_9fa48("974");
        const workspace = await requireWorkspace(store, existingId, input.actor, stryMutAct_9fa48("975") ? "" : (stryCov_9fa48("975"), "administerMembership"));
        const {
          functionalCurrency,
          template
        } = workspaceConfiguration(stryMutAct_9fa48("976") ? {} : (stryCov_9fa48("976"), {
          ...input,
          kind: stryMutAct_9fa48("977") ? "" : (stryCov_9fa48("977"), "Household")
        }));
        if (stryMutAct_9fa48("980") ? (workspace.kind !== "Household" || workspace.functionalCurrency !== functionalCurrency) && workspace.chartOfAccountsTemplate !== template.version : stryMutAct_9fa48("979") ? false : stryMutAct_9fa48("978") ? true : (stryCov_9fa48("978", "979", "980"), (stryMutAct_9fa48("982") ? workspace.kind !== "Household" && workspace.functionalCurrency !== functionalCurrency : stryMutAct_9fa48("981") ? false : (stryCov_9fa48("981", "982"), (stryMutAct_9fa48("984") ? workspace.kind === "Household" : stryMutAct_9fa48("983") ? false : (stryCov_9fa48("983", "984"), workspace.kind !== (stryMutAct_9fa48("985") ? "" : (stryCov_9fa48("985"), "Household")))) || (stryMutAct_9fa48("987") ? workspace.functionalCurrency === functionalCurrency : stryMutAct_9fa48("986") ? false : (stryCov_9fa48("986", "987"), workspace.functionalCurrency !== functionalCurrency)))) || (stryMutAct_9fa48("989") ? workspace.chartOfAccountsTemplate === template.version : stryMutAct_9fa48("988") ? false : (stryCov_9fa48("988", "989"), workspace.chartOfAccountsTemplate !== template.version)))) {
          if (stryMutAct_9fa48("990")) {
            {}
          } else {
            stryCov_9fa48("990");
            throw new AccountingError(stryMutAct_9fa48("992") ? "" : (stryCov_9fa48("992"), "idempotency_key_conflict"));
          }
        }
        return openWorkspace(store, clock, stryMutAct_9fa48("993") ? {} : (stryCov_9fa48("993"), {
          actor: input.actor,
          workspaceId: existingId
        }));
      }
    }
    const workspace = await provisionWorkspace(store, clock, stryMutAct_9fa48("994") ? {} : (stryCov_9fa48("994"), {
      ...input,
      kind: stryMutAct_9fa48("995") ? "" : (stryCov_9fa48("995"), "Household")
    }));
    await store.saveHouseholdWorkspaceCreation(stryMutAct_9fa48("996") ? {} : (stryCov_9fa48("996"), {
      ownerUserId: input.actor.userId,
      idempotencyKey: input.idempotencyKey,
      workspaceId: workspace.id
    }));
    return workspace;
  }
}