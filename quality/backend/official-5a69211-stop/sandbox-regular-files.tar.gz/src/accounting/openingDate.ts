// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "./errors";
import type { AccountingStore, JournalEntryDraft, StoredProfile } from "./types";
export async function assertOpeningDates(store: AccountingStore, workspaceId: string, draft: JournalEntryDraft): Promise<void> {
  if (stryMutAct_9fa48("1554")) {
    {}
  } else {
    stryCov_9fa48("1554");
    const accountIds = new Set(draft.lines.map(stryMutAct_9fa48("1555") ? () => undefined : (stryCov_9fa48("1555"), line => line.ledgerAccountId)));
    const profiles = await store.listProfiles(workspaceId);
    for (const profile of profiles) {
      if (stryMutAct_9fa48("1556")) {
        {}
      } else {
        stryCov_9fa48("1556");
        if (stryMutAct_9fa48("1559") ? (accountIds.has(profile.postingAccountId) || profile.id === draft.financialAccountProfileId) && profile.opening || draft.accountingDate < profile.opening.accountingDate : stryMutAct_9fa48("1558") ? false : stryMutAct_9fa48("1557") ? true : (stryCov_9fa48("1557", "1558", "1559"), (stryMutAct_9fa48("1561") ? accountIds.has(profile.postingAccountId) || profile.id === draft.financialAccountProfileId || profile.opening : stryMutAct_9fa48("1560") ? true : (stryCov_9fa48("1560", "1561"), (stryMutAct_9fa48("1563") ? accountIds.has(profile.postingAccountId) && profile.id === draft.financialAccountProfileId : stryMutAct_9fa48("1562") ? true : (stryCov_9fa48("1562", "1563"), accountIds.has(profile.postingAccountId) || (stryMutAct_9fa48("1565") ? profile.id !== draft.financialAccountProfileId : stryMutAct_9fa48("1564") ? false : (stryCov_9fa48("1564", "1565"), profile.id === draft.financialAccountProfileId)))) && profile.opening)) && (stryMutAct_9fa48("1568") ? draft.accountingDate >= profile.opening.accountingDate : stryMutAct_9fa48("1567") ? draft.accountingDate <= profile.opening.accountingDate : stryMutAct_9fa48("1566") ? true : (stryCov_9fa48("1566", "1567", "1568"), draft.accountingDate < profile.opening.accountingDate)))) {
          if (stryMutAct_9fa48("1569")) {
            {}
          } else {
            stryCov_9fa48("1569");
            throw new AccountingError(stryMutAct_9fa48("1571") ? "" : (stryCov_9fa48("1571"), "activity_before_opening"));
          }
        }
      }
    }
  }
}
export async function assertOpeningCutover(store: AccountingStore, profile: StoredProfile, accountingDate: string): Promise<void> {
  if (stryMutAct_9fa48("1572")) {
    {}
  } else {
    stryCov_9fa48("1572");
    const entries = await store.listJournalEntries(profile.workspaceId);
    const reversals = new Map(stryMutAct_9fa48("1573") ? entries.map(entry => [entry.reversesEntryId, entry]) : (stryCov_9fa48("1573"), entries.filter(stryMutAct_9fa48("1574") ? () => undefined : (stryCov_9fa48("1574"), entry => stryMutAct_9fa48("1577") ? entry.policy === "reversal@1" || entry.reversesEntryId : stryMutAct_9fa48("1576") ? false : stryMutAct_9fa48("1575") ? true : (stryCov_9fa48("1575", "1576", "1577"), (stryMutAct_9fa48("1579") ? entry.policy !== "reversal@1" : stryMutAct_9fa48("1578") ? true : (stryCov_9fa48("1578", "1579"), entry.policy === (stryMutAct_9fa48("1580") ? "" : (stryCov_9fa48("1580"), "reversal@1")))) && entry.reversesEntryId))).map(stryMutAct_9fa48("1581") ? () => undefined : (stryCov_9fa48("1581"), entry => stryMutAct_9fa48("1582") ? [] : (stryCov_9fa48("1582"), [entry.reversesEntryId, entry])))));
    const retiredEntryIds = new Set<string>();
    for (const entry of entries) {
      if (stryMutAct_9fa48("1583")) {
        {}
      } else {
        stryCov_9fa48("1583");
        if (stryMutAct_9fa48("1586") ? entry.policy === "opening-position@1" || entry.financialAccountProfileId === profile.id : stryMutAct_9fa48("1585") ? false : stryMutAct_9fa48("1584") ? true : (stryCov_9fa48("1584", "1585", "1586"), (stryMutAct_9fa48("1588") ? entry.policy !== "opening-position@1" : stryMutAct_9fa48("1587") ? true : (stryCov_9fa48("1587", "1588"), entry.policy === (stryMutAct_9fa48("1589") ? "" : (stryCov_9fa48("1589"), "opening-position@1")))) && (stryMutAct_9fa48("1591") ? entry.financialAccountProfileId !== profile.id : stryMutAct_9fa48("1590") ? true : (stryCov_9fa48("1590", "1591"), entry.financialAccountProfileId === profile.id)))) {
          if (stryMutAct_9fa48("1592")) {
            {}
          } else {
            stryCov_9fa48("1592");
            const reversal = reversals.get(entry.id);
            if (stryMutAct_9fa48("1594") ? false : stryMutAct_9fa48("1593") ? true : (stryCov_9fa48("1593", "1594"), reversal)) {
              if (stryMutAct_9fa48("1595")) {
                {}
              } else {
                stryCov_9fa48("1595");
                if (stryMutAct_9fa48("1596")) {
                  ;
                } else {
                  stryCov_9fa48("1596");
                  retiredEntryIds.add(entry.id);
                }
                if (stryMutAct_9fa48("1597")) {
                  ;
                } else {
                  stryCov_9fa48("1597");
                  retiredEntryIds.add(reversal.id);
                }
              }
            }
          }
        }
      }
    }
    if (stryMutAct_9fa48("1600") ? entries.every(entry => !retiredEntryIds.has(entry.id) && entry.accountingDate < accountingDate && (entry.financialAccountProfileId === profile.id || entry.lines.some(line => line.ledgerAccountId === profile.postingAccountId))) : stryMutAct_9fa48("1599") ? false : stryMutAct_9fa48("1598") ? true : (stryCov_9fa48("1598", "1599", "1600"), entries.some(stryMutAct_9fa48("1601") ? () => undefined : (stryCov_9fa48("1601"), entry => stryMutAct_9fa48("1604") ? !retiredEntryIds.has(entry.id) && entry.accountingDate < accountingDate || entry.financialAccountProfileId === profile.id || entry.lines.some(line => line.ledgerAccountId === profile.postingAccountId) : stryMutAct_9fa48("1603") ? false : stryMutAct_9fa48("1602") ? true : (stryCov_9fa48("1602", "1603", "1604"), (stryMutAct_9fa48("1606") ? !retiredEntryIds.has(entry.id) || entry.accountingDate < accountingDate : stryMutAct_9fa48("1605") ? true : (stryCov_9fa48("1605", "1606"), (stryMutAct_9fa48("1607") ? retiredEntryIds.has(entry.id) : (stryCov_9fa48("1607"), !retiredEntryIds.has(entry.id))) && (stryMutAct_9fa48("1610") ? entry.accountingDate >= accountingDate : stryMutAct_9fa48("1609") ? entry.accountingDate <= accountingDate : stryMutAct_9fa48("1608") ? true : (stryCov_9fa48("1608", "1609", "1610"), entry.accountingDate < accountingDate)))) && (stryMutAct_9fa48("1612") ? entry.financialAccountProfileId === profile.id && entry.lines.some(line => line.ledgerAccountId === profile.postingAccountId) : stryMutAct_9fa48("1611") ? true : (stryCov_9fa48("1611", "1612"), (stryMutAct_9fa48("1614") ? entry.financialAccountProfileId !== profile.id : stryMutAct_9fa48("1613") ? false : (stryCov_9fa48("1613", "1614"), entry.financialAccountProfileId === profile.id)) || (stryMutAct_9fa48("1615") ? entry.lines.every(line => line.ledgerAccountId === profile.postingAccountId) : (stryCov_9fa48("1615"), entry.lines.some(stryMutAct_9fa48("1616") ? () => undefined : (stryCov_9fa48("1616"), line => stryMutAct_9fa48("1619") ? line.ledgerAccountId !== profile.postingAccountId : stryMutAct_9fa48("1618") ? false : stryMutAct_9fa48("1617") ? true : (stryCov_9fa48("1617", "1618", "1619"), line.ledgerAccountId === profile.postingAccountId)))))))))))) {
      if (stryMutAct_9fa48("1620")) {
        {}
      } else {
        stryCov_9fa48("1620");
        throw new AccountingError(stryMutAct_9fa48("1622") ? "" : (stryCov_9fa48("1622"), "activity_before_opening"));
      }
    }
  }
}