// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { chartTemplate, requireTemplateAccount } from "./chartOfAccounts";
import { classifyFinancialAccountProfile } from "./classification";
import { commandIdentity } from "./commandIdentity";
import { categorySnapshot, requireCategory } from "./categories";
import { assertCategoryAccount } from "./categoryPolicy";
import { setupFinancialAccount } from "./commands/setupFinancialAccount";
import { AccountingError } from "./errors";
import { requireWorkspace } from "./membership";
import { periodFromAccountingDate } from "./period";
import { postJournalEntry } from "./posting";
import type { AccountingClock, AccountingPeriod, AccountingStore, DraftJournalLine, JournalEntryDraft, StoredJournalEntry, StoredWorkspace } from "./types";
import type { CategoryNature, CategorySnapshot, ConfirmReclassificationInput, CorrectionSource, ReclassificationInput, ReclassificationBucket, ReclassificationPreview, UserCategory } from "./categoryTypes";
type ResolvedTarget = {
  kind: "category";
  accountId: string | undefined;
  nature: CategoryNature;
} | {
  kind: "profile";
};
type CorrectionHistory = {
  buckets: Map<string, ReclassificationBucket>;
  periods: Map<string, string>;
  lockedIds: Set<string>;
};
type CorrectionDestination = {
  category: UserCategory;
  ledgerAccountId: string;
} & ({
  kind: "category";
} | {
  kind: "profile";
  financialAccountProfileId: string;
});
export async function previewCategoryReclassification(store: AccountingStore, input: ReclassificationInput): Promise<ReclassificationPreview> {
  if (stryMutAct_9fa48("2171")) {
    {}
  } else {
    stryCov_9fa48("2171");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("2172") ? "" : (stryCov_9fa48("2172"), "correct"));
    const category = await requireCategory(store, input.workspaceId, input.categoryId);
    if (stryMutAct_9fa48("2175") ? category.classification.kind === "resolved" : stryMutAct_9fa48("2174") ? false : stryMutAct_9fa48("2173") ? true : (stryCov_9fa48("2173", "2174", "2175"), category.classification.kind !== (stryMutAct_9fa48("2176") ? "" : (stryCov_9fa48("2176"), "resolved")))) throw new AccountingError(stryMutAct_9fa48("2178") ? "" : (stryCov_9fa48("2178"), "category_unresolved"));
    if (stryMutAct_9fa48("2181") ? category.status === "active" : stryMutAct_9fa48("2180") ? false : stryMutAct_9fa48("2179") ? true : (stryCov_9fa48("2179", "2180", "2181"), category.status !== (stryMutAct_9fa48("2182") ? "" : (stryCov_9fa48("2182"), "active")))) throw new AccountingError(stryMutAct_9fa48("2184") ? "" : (stryCov_9fa48("2184"), "category_inactive"));
    const currentPeriod = periodFromAccountingDate(input.currentDate);
    const target = await resolveReclassificationTarget(store, workspace, input);
    const entries = stryMutAct_9fa48("2185") ? await store.listJournalEntries(input.workspaceId) : (stryCov_9fa48("2185"), (await store.listJournalEntries(input.workspaceId)).sort(stryMutAct_9fa48("2186") ? () => undefined : (stryCov_9fa48("2186"), (a, b) => a.id.localeCompare(b.id))));
    const history = await readCorrectionHistory(store, stryMutAct_9fa48("2187") ? {} : (stryCov_9fa48("2187"), {
      input,
      target,
      entries,
      categoryId: category.id
    }));
    const currentStatus = await store.getAccountingPeriod(input.workspaceId, currentPeriod);
    const outstanding = stryMutAct_9fa48("2189") ? [...history.buckets.values()].sort((a, b) => commandIdentity(a).localeCompare(commandIdentity(b))) : stryMutAct_9fa48("2188") ? [...history.buckets.values()].filter(bucket => bucket.rootSources.some(root => root.signedMinorUnits !== 0)) : (stryCov_9fa48("2188", "2189"), (stryMutAct_9fa48("2190") ? [] : (stryCov_9fa48("2190"), [...history.buckets.values()])).filter(stryMutAct_9fa48("2191") ? () => undefined : (stryCov_9fa48("2191"), bucket => stryMutAct_9fa48("2192") ? bucket.rootSources.every(root => root.signedMinorUnits !== 0) : (stryCov_9fa48("2192"), bucket.rootSources.some(stryMutAct_9fa48("2193") ? () => undefined : (stryCov_9fa48("2193"), root => stryMutAct_9fa48("2196") ? root.signedMinorUnits === 0 : stryMutAct_9fa48("2195") ? false : stryMutAct_9fa48("2194") ? true : (stryCov_9fa48("2194", "2195", "2196"), root.signedMinorUnits !== 0)))))).sort(stryMutAct_9fa48("2197") ? () => undefined : (stryCov_9fa48("2197"), (a, b) => commandIdentity(a).localeCompare(commandIdentity(b)))));
    const selectedSources = outstanding.flatMap(stryMutAct_9fa48("2198") ? () => undefined : (stryCov_9fa48("2198"), bucket => bucket.sources));
    const lockedEntryIds = new Set(stryMutAct_9fa48("2199") ? selectedSources.map(source => source.entryId) : (stryCov_9fa48("2199"), selectedSources.filter(stryMutAct_9fa48("2200") ? () => undefined : (stryCov_9fa48("2200"), source => history.lockedIds.has(source.entryId))).map(stryMutAct_9fa48("2201") ? () => undefined : (stryCov_9fa48("2201"), source => source.entryId))));
    validateCorrectionDates(stryMutAct_9fa48("2203") ? {} : (stryCov_9fa48("2203"), {
      input,
      entries,
      outstanding,
      lockedEntryIds,
      currentStatus
    }));
    const impact = correctionImpact(stryMutAct_9fa48("2204") ? {} : (stryCov_9fa48("2204"), {
      outstanding,
      selectedSources,
      lockedEntryIds
    }));
    const revisionToken = commandIdentity(stryMutAct_9fa48("2205") ? {} : (stryCov_9fa48("2205"), {
      policy: stryMutAct_9fa48("2206") ? "" : (stryCov_9fa48("2206"), "category-reclassification@1"),
      category,
      target: input.target,
      currentDate: input.currentDate,
      template: workspace.chartOfAccountsTemplate,
      periods: stryMutAct_9fa48("2207") ? [...history.periods.entries()] : (stryCov_9fa48("2207"), (stryMutAct_9fa48("2208") ? [] : (stryCov_9fa48("2208"), [...history.periods.entries()])).sort()),
      currentStatus,
      history: stryMutAct_9fa48("2209") ? entries : (stryCov_9fa48("2209"), entries.filter(stryMutAct_9fa48("2210") ? () => undefined : (stryCov_9fa48("2210"), entry => stryMutAct_9fa48("2211") ? entry.lines.every(line => line.category?.categoryId === category.id) : (stryCov_9fa48("2211"), entry.lines.some(stryMutAct_9fa48("2212") ? () => undefined : (stryCov_9fa48("2212"), line => stryMutAct_9fa48("2215") ? line.category?.categoryId !== category.id : stryMutAct_9fa48("2214") ? false : stryMutAct_9fa48("2213") ? true : (stryCov_9fa48("2213", "2214", "2215"), (stryMutAct_9fa48("2216") ? line.category.categoryId : (stryCov_9fa48("2216"), line.category?.categoryId)) === category.id)))))))
    }));
    return stryMutAct_9fa48("2217") ? {} : (stryCov_9fa48("2217"), {
      categoryId: category.id,
      categoryRevision: category.revision,
      revisionToken,
      entryCount: impact.entryCount,
      lineCount: impact.lineCount,
      amount: stryMutAct_9fa48("2218") ? {} : (stryCov_9fa48("2218"), {
        currency: workspace.functionalCurrency,
        minorUnits: impact.total
      }),
      lockedEntryCount: impact.lockedEntryCount,
      lockedAmount: stryMutAct_9fa48("2219") ? {} : (stryCov_9fa48("2219"), {
        currency: workspace.functionalCurrency,
        minorUnits: impact.lockedTotal
      }),
      correctionDates: impact.correctionDates,
      buckets: outstanding
    });
  }
}
async function resolveReclassificationTarget(store: AccountingStore, workspace: StoredWorkspace, input: ReclassificationInput): Promise<ResolvedTarget> {
  if (stryMutAct_9fa48("2220")) {
    {}
  } else {
    stryCov_9fa48("2220");
    const target = input.target;
    if (stryMutAct_9fa48("2223") ? target.kind !== "category" : stryMutAct_9fa48("2222") ? false : stryMutAct_9fa48("2221") ? true : (stryCov_9fa48("2221", "2222", "2223"), target.kind === (stryMutAct_9fa48("2224") ? "" : (stryCov_9fa48("2224"), "category")))) {
      if (stryMutAct_9fa48("2225")) {
        {}
      } else {
        stryCov_9fa48("2225");
        if (stryMutAct_9fa48("2226")) {
          ;
        } else {
          stryCov_9fa48("2226");
          assertCategoryAccount(workspace.chartOfAccountsTemplate, target.nature, target.accountCode);
        }
        const account = await store.findLedgerAccountByCode(input.workspaceId, target.accountCode);
        return stryMutAct_9fa48("2227") ? {} : (stryCov_9fa48("2227"), {
          kind: stryMutAct_9fa48("2228") ? "" : (stryCov_9fa48("2228"), "category"),
          accountId: stryMutAct_9fa48("2229") ? account.id : (stryCov_9fa48("2229"), account?.id),
          nature: target.nature
        });
      }
    }
    if (stryMutAct_9fa48("2230")) {
      ;
    } else {
      stryCov_9fa48("2230");
      classifyFinancialAccountProfile(chartTemplate(workspace.chartOfAccountsTemplate), target.setup.productKind, target.setup.classificationAnswers);
    }
    return stryMutAct_9fa48("2231") ? {} : (stryCov_9fa48("2231"), {
      kind: stryMutAct_9fa48("2232") ? "" : (stryCov_9fa48("2232"), "profile")
    });
  }
}
async function readCorrectionHistory(store: AccountingStore, args: {
  input: ReclassificationInput;
  target: ResolvedTarget;
  entries: StoredJournalEntry[];
  categoryId: string;
}): Promise<CorrectionHistory> {
  if (stryMutAct_9fa48("2233")) {
    {}
  } else {
    stryCov_9fa48("2233");
    const {
      input,
      target,
      entries,
      categoryId
    } = args;
    const history: CorrectionHistory = stryMutAct_9fa48("2234") ? {} : (stryCov_9fa48("2234"), {
      buckets: new Map(),
      periods: new Map(),
      lockedIds: new Set()
    });
    for (const entry of entries) for (const [lineNumber, line] of entry.lines.entries()) {
      if (stryMutAct_9fa48("2235")) {
        {}
      } else {
        stryCov_9fa48("2235");
        if (stryMutAct_9fa48("2238") ? line.category?.categoryId === categoryId : stryMutAct_9fa48("2237") ? false : stryMutAct_9fa48("2236") ? true : (stryCov_9fa48("2236", "2237", "2238"), (stryMutAct_9fa48("2239") ? line.category.categoryId : (stryCov_9fa48("2239"), line.category?.categoryId)) !== categoryId)) continue;
        if (stryMutAct_9fa48("2242") ? target.kind === "category" && line.ledgerAccountId === target.accountId || line.category.nature === target.nature : stryMutAct_9fa48("2241") ? false : stryMutAct_9fa48("2240") ? true : (stryCov_9fa48("2240", "2241", "2242"), (stryMutAct_9fa48("2244") ? target.kind === "category" || line.ledgerAccountId === target.accountId : stryMutAct_9fa48("2243") ? true : (stryCov_9fa48("2243", "2244"), (stryMutAct_9fa48("2246") ? target.kind !== "category" : stryMutAct_9fa48("2245") ? true : (stryCov_9fa48("2245", "2246"), target.kind === (stryMutAct_9fa48("2247") ? "" : (stryCov_9fa48("2247"), "category")))) && (stryMutAct_9fa48("2249") ? line.ledgerAccountId !== target.accountId : stryMutAct_9fa48("2248") ? true : (stryCov_9fa48("2248", "2249"), line.ledgerAccountId === target.accountId)))) && (stryMutAct_9fa48("2251") ? line.category.nature !== target.nature : stryMutAct_9fa48("2250") ? true : (stryCov_9fa48("2250", "2251"), line.category.nature === target.nature)))) continue;
        const periodKey = stryMutAct_9fa48("2252") ? `` : (stryCov_9fa48("2252"), `${entry.period.year}-${String(entry.period.month).padStart(2, stryMutAct_9fa48("2253") ? "" : (stryCov_9fa48("2253"), "0"))}`);
        const status = await readCorrectionPeriod(store, input.workspaceId, entry, periodKey, history.periods);
        const locked = stryMutAct_9fa48("2256") ? status !== "locked" : stryMutAct_9fa48("2255") ? false : stryMutAct_9fa48("2254") ? true : (stryCov_9fa48("2254", "2255", "2256"), status === (stryMutAct_9fa48("2257") ? "" : (stryCov_9fa48("2257"), "locked")));
        accumulateCorrectionBucket(history.buckets, stryMutAct_9fa48("2259") ? {} : (stryCov_9fa48("2259"), {
          entry,
          line,
          category: line.category,
          lineNumber,
          periodKey,
          locked,
          currentDate: input.currentDate
        }));
        if (stryMutAct_9fa48("2261") ? false : stryMutAct_9fa48("2260") ? true : (stryCov_9fa48("2260", "2261"), locked)) if (stryMutAct_9fa48("2262")) {
          ;
        } else {
          stryCov_9fa48("2262");
          history.lockedIds.add(entry.id);
        }
      }
    }
    return history;
  }
}
async function readCorrectionPeriod(store: AccountingStore, workspaceId: string, entry: StoredJournalEntry, periodKey: string, periods: Map<string, string>): Promise<string> {
  if (stryMutAct_9fa48("2263")) {
    {}
  } else {
    stryCov_9fa48("2263");
    let status = periods.get(periodKey);
    if (stryMutAct_9fa48("2266") ? false : stryMutAct_9fa48("2265") ? true : stryMutAct_9fa48("2264") ? status : (stryCov_9fa48("2264", "2265", "2266"), !status)) {
      if (stryMutAct_9fa48("2267")) {
        {}
      } else {
        stryCov_9fa48("2267");
        status = stryMutAct_9fa48("2268") ? (await store.getAccountingPeriod(workspaceId, entry.period)).status : (stryCov_9fa48("2268"), (await store.getAccountingPeriod(workspaceId, entry.period))?.status);
        if (stryMutAct_9fa48("2271") ? false : stryMutAct_9fa48("2270") ? true : stryMutAct_9fa48("2269") ? status : (stryCov_9fa48("2269", "2270", "2271"), !status)) throw new AccountingError(stryMutAct_9fa48("2273") ? "" : (stryCov_9fa48("2273"), "accounting_period_not_found"));
        if (stryMutAct_9fa48("2274")) {
          ;
        } else {
          stryCov_9fa48("2274");
          periods.set(periodKey, status);
        }
      }
    }
    return status;
  }
}
function accumulateCorrectionBucket(buckets: Map<string, ReclassificationBucket>, input: {
  entry: StoredJournalEntry;
  line: DraftJournalLine;
  category: CategorySnapshot;
  lineNumber: number;
  periodKey: string;
  locked: boolean;
  currentDate: string;
}): void {
  if (stryMutAct_9fa48("2275")) {
    {}
  } else {
    stryCov_9fa48("2275");
    const {
      entry,
      line,
      category,
      lineNumber,
      periodKey,
      locked
    } = input;
    const date = locked ? input.currentDate : entry.accountingDate;
    const destinationPeriod = locked ? stryMutAct_9fa48("2276") ? "" : (stryCov_9fa48("2276"), "catch-up") : periodKey;
    const key = stryMutAct_9fa48("2277") ? `` : (stryCov_9fa48("2277"), `${destinationPeriod}:${line.ledgerAccountId}:${commandIdentity(category)}`);
    const bucket = stryMutAct_9fa48("2278") ? buckets.get(key) && {
      accountingDate: date,
      ledgerAccountId: line.ledgerAccountId,
      signedMinorUnits: 0,
      sources: [],
      rootSources: [],
      priorLockedPeriods: [],
      snapshot: category
    } : (stryCov_9fa48("2278"), buckets.get(key) ?? (stryMutAct_9fa48("2279") ? {} : (stryCov_9fa48("2279"), {
      accountingDate: date,
      ledgerAccountId: line.ledgerAccountId,
      signedMinorUnits: 0,
      sources: stryMutAct_9fa48("2280") ? ["Stryker was here"] : (stryCov_9fa48("2280"), []),
      rootSources: stryMutAct_9fa48("2281") ? ["Stryker was here"] : (stryCov_9fa48("2281"), []),
      priorLockedPeriods: stryMutAct_9fa48("2282") ? ["Stryker was here"] : (stryCov_9fa48("2282"), []),
      snapshot: category
    })));
    bucket.accountingDate = (stryMutAct_9fa48("2286") ? date <= bucket.accountingDate : stryMutAct_9fa48("2285") ? date >= bucket.accountingDate : stryMutAct_9fa48("2284") ? false : stryMutAct_9fa48("2283") ? true : (stryCov_9fa48("2283", "2284", "2285", "2286"), date > bucket.accountingDate)) ? date : bucket.accountingDate;
    const signedMinorUnits = stryMutAct_9fa48("2287") ? line.debitMinorUnits + line.creditMinorUnits : (stryCov_9fa48("2287"), line.debitMinorUnits - line.creditMinorUnits);
    stryMutAct_9fa48("2288") ? bucket.signedMinorUnits -= signedMinorUnits : (stryCov_9fa48("2288"), bucket.signedMinorUnits += signedMinorUnits);
    if (stryMutAct_9fa48("2291") ? false : stryMutAct_9fa48("2290") ? true : stryMutAct_9fa48("2289") ? Number.isSafeInteger(bucket.signedMinorUnits) : (stryCov_9fa48("2289", "2290", "2291"), !Number.isSafeInteger(bucket.signedMinorUnits))) throw new AccountingError(stryMutAct_9fa48("2293") ? "" : (stryCov_9fa48("2293"), "journal_line_invalid"));
    bucket.sources.push(stryMutAct_9fa48("2295") ? {} : (stryCov_9fa48("2295"), {
      entryId: entry.id,
      lineNumber,
      signedMinorUnits
    }));
    if (stryMutAct_9fa48("2296")) {
      ;
    } else {
      stryCov_9fa48("2296");
      accumulateOriginalSources(bucket.rootSources, originalSources(entry, line, lineNumber, signedMinorUnits));
    }
    if (stryMutAct_9fa48("2299") ? locked || !bucket.priorLockedPeriods.includes(periodKey) : stryMutAct_9fa48("2298") ? false : stryMutAct_9fa48("2297") ? true : (stryCov_9fa48("2297", "2298", "2299"), locked && (stryMutAct_9fa48("2300") ? bucket.priorLockedPeriods.includes(periodKey) : (stryCov_9fa48("2300"), !bucket.priorLockedPeriods.includes(periodKey))))) if (stryMutAct_9fa48("2301")) {
      ;
    } else {
      stryCov_9fa48("2301");
      bucket.priorLockedPeriods.push(periodKey);
    }
    if (stryMutAct_9fa48("2302")) {
      ;
    } else {
      stryCov_9fa48("2302");
      buckets.set(key, bucket);
    }
  }
}
function originalSources(entry: StoredJournalEntry, line: DraftJournalLine, lineNumber: number, signedMinorUnits: number): CorrectionSource[] {
  if (stryMutAct_9fa48("2303")) {
    {}
  } else {
    stryCov_9fa48("2303");
    const correction = line.categoryCorrection;
    if (stryMutAct_9fa48("2306") ? false : stryMutAct_9fa48("2305") ? true : stryMutAct_9fa48("2304") ? correction : (stryCov_9fa48("2304", "2305", "2306"), !correction)) return stryMutAct_9fa48("2307") ? [] : (stryCov_9fa48("2307"), [stryMutAct_9fa48("2308") ? {} : (stryCov_9fa48("2308"), {
      entryId: stryMutAct_9fa48("2309") ? entry.reversesEntryId && entry.id : (stryCov_9fa48("2309"), entry.reversesEntryId ?? entry.id),
      lineNumber,
      signedMinorUnits
    })]);
    const correctionSign = (stryMutAct_9fa48("2312") ? correction.side !== "reversing" : stryMutAct_9fa48("2311") ? false : stryMutAct_9fa48("2310") ? true : (stryCov_9fa48("2310", "2311", "2312"), correction.side === (stryMutAct_9fa48("2313") ? "" : (stryCov_9fa48("2313"), "reversing")))) ? stryMutAct_9fa48("2314") ? +1 : (stryCov_9fa48("2314"), -1) : 1;
    const reversalSign = entry.reversesEntryId ? stryMutAct_9fa48("2315") ? +1 : (stryCov_9fa48("2315"), -1) : 1;
    return correction.rootSources.map(stryMutAct_9fa48("2316") ? () => undefined : (stryCov_9fa48("2316"), ref => stryMutAct_9fa48("2317") ? {} : (stryCov_9fa48("2317"), {
      ...ref,
      signedMinorUnits: stryMutAct_9fa48("2318") ? ref.signedMinorUnits * correctionSign / reversalSign : (stryCov_9fa48("2318"), (stryMutAct_9fa48("2319") ? ref.signedMinorUnits / correctionSign : (stryCov_9fa48("2319"), ref.signedMinorUnits * correctionSign)) * reversalSign)
    })));
  }
}
function accumulateOriginalSources(savedSources: CorrectionSource[], sources: CorrectionSource[]): void {
  if (stryMutAct_9fa48("2320")) {
    {}
  } else {
    stryCov_9fa48("2320");
    for (const root of sources) {
      if (stryMutAct_9fa48("2321")) {
        {}
      } else {
        stryCov_9fa48("2321");
        const saved = savedSources.find(stryMutAct_9fa48("2322") ? () => undefined : (stryCov_9fa48("2322"), ref => stryMutAct_9fa48("2325") ? ref.entryId === root.entryId || ref.lineNumber === root.lineNumber : stryMutAct_9fa48("2324") ? false : stryMutAct_9fa48("2323") ? true : (stryCov_9fa48("2323", "2324", "2325"), (stryMutAct_9fa48("2327") ? ref.entryId !== root.entryId : stryMutAct_9fa48("2326") ? true : (stryCov_9fa48("2326", "2327"), ref.entryId === root.entryId)) && (stryMutAct_9fa48("2329") ? ref.lineNumber !== root.lineNumber : stryMutAct_9fa48("2328") ? true : (stryCov_9fa48("2328", "2329"), ref.lineNumber === root.lineNumber)))));
        if (stryMutAct_9fa48("2331") ? false : stryMutAct_9fa48("2330") ? true : (stryCov_9fa48("2330", "2331"), saved)) {
          if (stryMutAct_9fa48("2332")) {
            {}
          } else {
            stryCov_9fa48("2332");
            stryMutAct_9fa48("2333") ? saved.signedMinorUnits -= root.signedMinorUnits : (stryCov_9fa48("2333"), saved.signedMinorUnits += root.signedMinorUnits);
            if (stryMutAct_9fa48("2336") ? false : stryMutAct_9fa48("2335") ? true : stryMutAct_9fa48("2334") ? Number.isSafeInteger(saved.signedMinorUnits) : (stryCov_9fa48("2334", "2335", "2336"), !Number.isSafeInteger(saved.signedMinorUnits))) throw new AccountingError(stryMutAct_9fa48("2338") ? "" : (stryCov_9fa48("2338"), "journal_line_invalid"));
          }
        } else savedSources.push(stryMutAct_9fa48("2340") ? {} : (stryCov_9fa48("2340"), {
          ...root
        }));
      }
    }
  }
}
function validateCorrectionDates(input: {
  input: ReclassificationInput;
  entries: StoredJournalEntry[];
  outstanding: ReclassificationBucket[];
  lockedEntryIds: Set<string>;
  currentStatus: AccountingPeriod | undefined;
}): void {
  if (stryMutAct_9fa48("2341")) {
    {}
  } else {
    stryCov_9fa48("2341");
    const {
      input: request,
      entries,
      outstanding,
      lockedEntryIds,
      currentStatus
    } = input;
    if (stryMutAct_9fa48("2344") ? entries.every(entry => lockedEntryIds.has(entry.id) && request.currentDate < entry.accountingDate) : stryMutAct_9fa48("2343") ? false : stryMutAct_9fa48("2342") ? true : (stryCov_9fa48("2342", "2343", "2344"), entries.some(stryMutAct_9fa48("2345") ? () => undefined : (stryCov_9fa48("2345"), entry => stryMutAct_9fa48("2348") ? lockedEntryIds.has(entry.id) || request.currentDate < entry.accountingDate : stryMutAct_9fa48("2347") ? false : stryMutAct_9fa48("2346") ? true : (stryCov_9fa48("2346", "2347", "2348"), lockedEntryIds.has(entry.id) && (stryMutAct_9fa48("2351") ? request.currentDate >= entry.accountingDate : stryMutAct_9fa48("2350") ? request.currentDate <= entry.accountingDate : stryMutAct_9fa48("2349") ? true : (stryCov_9fa48("2349", "2350", "2351"), request.currentDate < entry.accountingDate))))))) throw new AccountingError(stryMutAct_9fa48("2353") ? "" : (stryCov_9fa48("2353"), "reclassification_date_before_source"));
    if (stryMutAct_9fa48("2356") ? outstanding.some(bucket => bucket.priorLockedPeriods.length) || currentStatus?.status !== "open" : stryMutAct_9fa48("2355") ? false : stryMutAct_9fa48("2354") ? true : (stryCov_9fa48("2354", "2355", "2356"), (stryMutAct_9fa48("2357") ? outstanding.every(bucket => bucket.priorLockedPeriods.length) : (stryCov_9fa48("2357"), outstanding.some(stryMutAct_9fa48("2358") ? () => undefined : (stryCov_9fa48("2358"), bucket => bucket.priorLockedPeriods.length)))) && (stryMutAct_9fa48("2360") ? currentStatus?.status === "open" : stryMutAct_9fa48("2359") ? true : (stryCov_9fa48("2359", "2360"), (stryMutAct_9fa48("2361") ? currentStatus.status : (stryCov_9fa48("2361"), currentStatus?.status)) !== (stryMutAct_9fa48("2362") ? "" : (stryCov_9fa48("2362"), "open")))))) throw new AccountingError(stryMutAct_9fa48("2364") ? "" : (stryCov_9fa48("2364"), "reclassification_current_period_required"));
    if (stryMutAct_9fa48("2367") ? request.target.kind !== "profile" : stryMutAct_9fa48("2366") ? false : stryMutAct_9fa48("2365") ? true : (stryCov_9fa48("2365", "2366", "2367"), request.target.kind === (stryMutAct_9fa48("2368") ? "" : (stryCov_9fa48("2368"), "profile")))) {
      if (stryMutAct_9fa48("2369")) {
        {}
      } else {
        stryCov_9fa48("2369");
        const openingDate = request.target.setup.accountingDate;
        if (stryMutAct_9fa48("2372") ? outstanding.every(bucket => bucket.accountingDate < openingDate) : stryMutAct_9fa48("2371") ? false : stryMutAct_9fa48("2370") ? true : (stryCov_9fa48("2370", "2371", "2372"), outstanding.some(stryMutAct_9fa48("2373") ? () => undefined : (stryCov_9fa48("2373"), bucket => stryMutAct_9fa48("2377") ? bucket.accountingDate >= openingDate : stryMutAct_9fa48("2376") ? bucket.accountingDate <= openingDate : stryMutAct_9fa48("2375") ? false : stryMutAct_9fa48("2374") ? true : (stryCov_9fa48("2374", "2375", "2376", "2377"), bucket.accountingDate < openingDate))))) throw new AccountingError(stryMutAct_9fa48("2379") ? "" : (stryCov_9fa48("2379"), "activity_before_opening"));
      }
    }
  }
}
function grossOriginalAmount(bucket: ReclassificationBucket): number {
  if (stryMutAct_9fa48("2380")) {
    {}
  } else {
    stryCov_9fa48("2380");
    return bucket.rootSources.reduce(stryMutAct_9fa48("2381") ? () => undefined : (stryCov_9fa48("2381"), (sum, root) => stryMutAct_9fa48("2382") ? sum - Math.abs(root.signedMinorUnits) : (stryCov_9fa48("2382"), sum + Math.abs(root.signedMinorUnits))), 0);
  }
}
function correctionImpact(input: {
  outstanding: ReclassificationBucket[];
  selectedSources: CorrectionSource[];
  lockedEntryIds: Set<string>;
}) {
  if (stryMutAct_9fa48("2383")) {
    {}
  } else {
    stryCov_9fa48("2383");
    const {
      outstanding,
      selectedSources,
      lockedEntryIds
    } = input;
    const entryIds = new Set(selectedSources.map(stryMutAct_9fa48("2384") ? () => undefined : (stryCov_9fa48("2384"), source => source.entryId)));
    const total = outstanding.reduce(stryMutAct_9fa48("2385") ? () => undefined : (stryCov_9fa48("2385"), (sum, bucket) => stryMutAct_9fa48("2386") ? sum - grossOriginalAmount(bucket) : (stryCov_9fa48("2386"), sum + grossOriginalAmount(bucket))), 0);
    const lockedTotal = stryMutAct_9fa48("2387") ? outstanding.reduce((sum, bucket) => sum + grossOriginalAmount(bucket), 0) : (stryCov_9fa48("2387"), outstanding.filter(stryMutAct_9fa48("2388") ? () => undefined : (stryCov_9fa48("2388"), bucket => bucket.priorLockedPeriods.length)).reduce(stryMutAct_9fa48("2389") ? () => undefined : (stryCov_9fa48("2389"), (sum, bucket) => stryMutAct_9fa48("2390") ? sum - grossOriginalAmount(bucket) : (stryCov_9fa48("2390"), sum + grossOriginalAmount(bucket))), 0));
    if (stryMutAct_9fa48("2393") ? false : stryMutAct_9fa48("2392") ? true : stryMutAct_9fa48("2391") ? Number.isSafeInteger(total) : (stryCov_9fa48("2391", "2392", "2393"), !Number.isSafeInteger(total))) throw new AccountingError(stryMutAct_9fa48("2395") ? "" : (stryCov_9fa48("2395"), "journal_line_invalid"));
    const correctionDates = stryMutAct_9fa48("2396") ? [...new Set(outstanding.map(bucket => bucket.accountingDate.slice(0, 7)))].map(month => outstanding.filter(bucket => bucket.accountingDate.startsWith(month)).reduce((date, bucket) => bucket.accountingDate > date ? bucket.accountingDate : date, "")) : (stryCov_9fa48("2396"), (stryMutAct_9fa48("2397") ? [] : (stryCov_9fa48("2397"), [...new Set(outstanding.map(stryMutAct_9fa48("2398") ? () => undefined : (stryCov_9fa48("2398"), bucket => stryMutAct_9fa48("2399") ? bucket.accountingDate : (stryCov_9fa48("2399"), bucket.accountingDate.slice(0, 7)))))])).sort().map(stryMutAct_9fa48("2400") ? () => undefined : (stryCov_9fa48("2400"), month => stryMutAct_9fa48("2401") ? outstanding.reduce((date, bucket) => bucket.accountingDate > date ? bucket.accountingDate : date, "") : (stryCov_9fa48("2401"), outstanding.filter(stryMutAct_9fa48("2402") ? () => undefined : (stryCov_9fa48("2402"), bucket => stryMutAct_9fa48("2403") ? bucket.accountingDate.endsWith(month) : (stryCov_9fa48("2403"), bucket.accountingDate.startsWith(month)))).reduce(stryMutAct_9fa48("2404") ? () => undefined : (stryCov_9fa48("2404"), (date, bucket) => (stryMutAct_9fa48("2408") ? bucket.accountingDate <= date : stryMutAct_9fa48("2407") ? bucket.accountingDate >= date : stryMutAct_9fa48("2406") ? false : stryMutAct_9fa48("2405") ? true : (stryCov_9fa48("2405", "2406", "2407", "2408"), bucket.accountingDate > date)) ? bucket.accountingDate : date), stryMutAct_9fa48("2409") ? "Stryker was here!" : (stryCov_9fa48("2409"), ""))))));
    return stryMutAct_9fa48("2410") ? {} : (stryCov_9fa48("2410"), {
      entryCount: entryIds.size,
      lineCount: selectedSources.length,
      lockedEntryCount: lockedEntryIds.size,
      total,
      lockedTotal,
      correctionDates
    });
  }
}
export async function confirmCategoryReclassification(store: AccountingStore, clock: AccountingClock, input: ConfirmReclassificationInput) {
  if (stryMutAct_9fa48("2411")) {
    {}
  } else {
    stryCov_9fa48("2411");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("2412") ? "" : (stryCov_9fa48("2412"), "correct"));
    await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("2413") ? "" : (stryCov_9fa48("2413"), "post"));
    if (stryMutAct_9fa48("2416") ? false : stryMutAct_9fa48("2415") ? true : stryMutAct_9fa48("2414") ? input.confirmed : (stryCov_9fa48("2414", "2415", "2416"), !input.confirmed)) throw new AccountingError(stryMutAct_9fa48("2418") ? "" : (stryCov_9fa48("2418"), "category_confirmation_required"));
    if (stryMutAct_9fa48("2421") ? false : stryMutAct_9fa48("2420") ? true : stryMutAct_9fa48("2419") ? input.idempotencyKey : (stryCov_9fa48("2419", "2420", "2421"), !input.idempotencyKey)) throw new AccountingError(stryMutAct_9fa48("2423") ? "" : (stryCov_9fa48("2423"), "idempotency_key_required"));
    const request = commandIdentity(stryMutAct_9fa48("2424") ? {} : (stryCov_9fa48("2424"), {
      command: stryMutAct_9fa48("2425") ? "" : (stryCov_9fa48("2425"), "reclassify"),
      categoryId: input.categoryId,
      target: input.target,
      currentDate: input.currentDate,
      revisionToken: input.revisionToken
    }));
    const receipt = await store.getCategoryReceipt(input.workspaceId, input.idempotencyKey);
    if (stryMutAct_9fa48("2427") ? false : stryMutAct_9fa48("2426") ? true : (stryCov_9fa48("2426", "2427"), receipt)) {
      if (stryMutAct_9fa48("2428")) {
        {}
      } else {
        stryCov_9fa48("2428");
        if (stryMutAct_9fa48("2431") ? receipt.request === request : stryMutAct_9fa48("2430") ? false : stryMutAct_9fa48("2429") ? true : (stryCov_9fa48("2429", "2430", "2431"), receipt.request !== request)) throw new AccountingError(stryMutAct_9fa48("2433") ? "" : (stryCov_9fa48("2433"), "idempotency_key_conflict"));
        return stryMutAct_9fa48("2434") ? {} : (stryCov_9fa48("2434"), {
          category: receipt.category,
          correctionEntryIds: receipt.correctionEntryIds,
          ...(receipt.financialAccountProfileId ? stryMutAct_9fa48("2435") ? {} : (stryCov_9fa48("2435"), {
            financialAccountProfileId: receipt.financialAccountProfileId
          }) : {}),
          replay: stryMutAct_9fa48("2436") ? false : (stryCov_9fa48("2436"), true)
        });
      }
    }
    const preview = await previewCategoryReclassification(store, input);
    if (stryMutAct_9fa48("2439") ? preview.revisionToken === input.revisionToken : stryMutAct_9fa48("2438") ? false : stryMutAct_9fa48("2437") ? true : (stryCov_9fa48("2437", "2438", "2439"), preview.revisionToken !== input.revisionToken)) throw new AccountingError(stryMutAct_9fa48("2441") ? "" : (stryCov_9fa48("2441"), "reclassification_stale"));
    const category = await requireCategory(store, input.workspaceId, input.categoryId);
    const destination = await resolveCorrectionDestination(store, clock, workspace, category, input);
    const profileId = (stryMutAct_9fa48("2444") ? destination.kind !== "profile" : stryMutAct_9fa48("2443") ? false : stryMutAct_9fa48("2442") ? true : (stryCov_9fa48("2442", "2443", "2444"), destination.kind === (stryMutAct_9fa48("2445") ? "" : (stryCov_9fa48("2445"), "profile")))) ? destination.financialAccountProfileId : undefined;
    const correctionEntryIds: string[] = stryMutAct_9fa48("2446") ? ["Stryker was here"] : (stryCov_9fa48("2446"), []);
    for (const date of preview.correctionDates) {
      if (stryMutAct_9fa48("2447")) {
        {}
      } else {
        stryCov_9fa48("2447");
        const draft = draftCategoryCorrection(stryMutAct_9fa48("2448") ? {} : (stryCov_9fa48("2448"), {
          date,
          preview,
          destination,
          input,
          categoryName: category.name
        }));
        if (stryMutAct_9fa48("2451") ? false : stryMutAct_9fa48("2450") ? true : stryMutAct_9fa48("2449") ? draft.lines.length : (stryCov_9fa48("2449", "2450", "2451"), !draft.lines.length)) continue;
        const {
          entry
        } = await postJournalEntry(store, clock, stryMutAct_9fa48("2452") ? {} : (stryCov_9fa48("2452"), {
          actor: input.actor,
          workspaceId: input.workspaceId,
          draft
        }));
        if (stryMutAct_9fa48("2453")) {
          ;
        } else {
          stryCov_9fa48("2453");
          correctionEntryIds.push(entry.id);
        }
      }
    }
    await store.saveCategory(destination.category);
    await store.saveCategoryReceipt(stryMutAct_9fa48("2454") ? {} : (stryCov_9fa48("2454"), {
      workspaceId: input.workspaceId,
      idempotencyKey: input.idempotencyKey,
      request,
      category: destination.category,
      correctionEntryIds,
      ...(profileId ? stryMutAct_9fa48("2455") ? {} : (stryCov_9fa48("2455"), {
        financialAccountProfileId: profileId
      }) : {})
    }));
    return stryMutAct_9fa48("2456") ? {} : (stryCov_9fa48("2456"), {
      category: destination.category,
      correctionEntryIds,
      ...(profileId ? stryMutAct_9fa48("2457") ? {} : (stryCov_9fa48("2457"), {
        financialAccountProfileId: profileId
      }) : {}),
      replay: stryMutAct_9fa48("2458") ? true : (stryCov_9fa48("2458"), false)
    });
  }
}
async function resolveCorrectionDestination(store: AccountingStore, clock: AccountingClock, workspace: StoredWorkspace, category: UserCategory, input: ConfirmReclassificationInput): Promise<CorrectionDestination> {
  if (stryMutAct_9fa48("2459")) {
    {}
  } else {
    stryCov_9fa48("2459");
    const updated = stryMutAct_9fa48("2460") ? {} : (stryCov_9fa48("2460"), {
      ...category,
      revision: stryMutAct_9fa48("2461") ? category.revision - 1 : (stryCov_9fa48("2461"), category.revision + 1)
    });
    const target = input.target;
    if (stryMutAct_9fa48("2464") ? target.kind !== "category" : stryMutAct_9fa48("2463") ? false : stryMutAct_9fa48("2462") ? true : (stryCov_9fa48("2462", "2463", "2464"), target.kind === (stryMutAct_9fa48("2465") ? "" : (stryCov_9fa48("2465"), "category")))) {
      if (stryMutAct_9fa48("2466")) {
        {}
      } else {
        stryCov_9fa48("2466");
        const account = await requireTemplateAccount(store, workspace, (stryMutAct_9fa48("2469") ? target.nature !== "Expense" : stryMutAct_9fa48("2468") ? false : stryMutAct_9fa48("2467") ? true : (stryCov_9fa48("2467", "2468", "2469"), target.nature === (stryMutAct_9fa48("2470") ? "" : (stryCov_9fa48("2470"), "Expense")))) ? stryMutAct_9fa48("2471") ? "" : (stryCov_9fa48("2471"), "expense") : stryMutAct_9fa48("2472") ? "" : (stryCov_9fa48("2472"), "income"), target.accountCode);
        updated.classification = stryMutAct_9fa48("2473") ? {} : (stryCov_9fa48("2473"), {
          kind: stryMutAct_9fa48("2474") ? "" : (stryCov_9fa48("2474"), "resolved"),
          nature: target.nature,
          natureProvenance: stryMutAct_9fa48("2475") ? {} : (stryCov_9fa48("2475"), {
            kind: stryMutAct_9fa48("2476") ? "" : (stryCov_9fa48("2476"), "answered")
          }),
          account: stryMutAct_9fa48("2477") ? {} : (stryCov_9fa48("2477"), {
            kind: stryMutAct_9fa48("2478") ? "" : (stryCov_9fa48("2478"), "advanced"),
            accountCode: target.accountCode
          })
        });
        return stryMutAct_9fa48("2479") ? {} : (stryCov_9fa48("2479"), {
          kind: stryMutAct_9fa48("2480") ? "" : (stryCov_9fa48("2480"), "category"),
          category: updated,
          ledgerAccountId: account.id
        });
      }
    }
    const result = await setupFinancialAccount(store, clock, stryMutAct_9fa48("2481") ? {} : (stryCov_9fa48("2481"), {
      ...target.setup,
      actor: input.actor,
      workspaceId: input.workspaceId,
      idempotencyKey: stryMutAct_9fa48("2482") ? `` : (stryCov_9fa48("2482"), `${input.idempotencyKey}:profile`)
    }));
    updated.classification = stryMutAct_9fa48("2483") ? {} : (stryCov_9fa48("2483"), {
      kind: stryMutAct_9fa48("2484") ? "" : (stryCov_9fa48("2484"), "converted"),
      financialAccountProfileId: result.profile.id
    });
    updated.status = stryMutAct_9fa48("2485") ? "" : (stryCov_9fa48("2485"), "archived");
    return stryMutAct_9fa48("2486") ? {} : (stryCov_9fa48("2486"), {
      kind: stryMutAct_9fa48("2487") ? "" : (stryCov_9fa48("2487"), "profile"),
      category: updated,
      ledgerAccountId: result.profile.ledgerAccountId,
      financialAccountProfileId: result.profile.id
    });
  }
}
function draftCategoryCorrection(args: {
  date: string;
  preview: ReclassificationPreview;
  destination: CorrectionDestination;
  input: ConfirmReclassificationInput;
  categoryName: string;
}): JournalEntryDraft {
  if (stryMutAct_9fa48("2488")) {
    {}
  } else {
    stryCov_9fa48("2488");
    const {
      date,
      preview,
      destination,
      input,
      categoryName
    } = args;
    const lines: DraftJournalLine[] = stryMutAct_9fa48("2489") ? ["Stryker was here"] : (stryCov_9fa48("2489"), []);
    const expenseEffects = new Map<string, number>();
    for (const bucket of stryMutAct_9fa48("2490") ? preview.buckets : (stryCov_9fa48("2490"), preview.buckets.filter(stryMutAct_9fa48("2491") ? () => undefined : (stryCov_9fa48("2491"), bucket => stryMutAct_9fa48("2494") ? bucket.accountingDate.slice(0, 7) !== date.slice(0, 7) : stryMutAct_9fa48("2493") ? false : stryMutAct_9fa48("2492") ? true : (stryCov_9fa48("2492", "2493", "2494"), (stryMutAct_9fa48("2495") ? bucket.accountingDate : (stryCov_9fa48("2495"), bucket.accountingDate.slice(0, 7))) === (stryMutAct_9fa48("2496") ? date : (stryCov_9fa48("2496"), date.slice(0, 7)))))))) {
      if (stryMutAct_9fa48("2497")) {
        {}
      } else {
        stryCov_9fa48("2497");
        const expenseFactor = stryMutAct_9fa48("2498") ? (input.target.kind === "category" && input.target.nature === "Expense" ? 1 : 0) + (bucket.snapshot.nature === "Expense" ? 1 : 0) : (stryCov_9fa48("2498"), ((stryMutAct_9fa48("2501") ? input.target.kind === "category" || input.target.nature === "Expense" : stryMutAct_9fa48("2500") ? false : stryMutAct_9fa48("2499") ? true : (stryCov_9fa48("2499", "2500", "2501"), (stryMutAct_9fa48("2503") ? input.target.kind !== "category" : stryMutAct_9fa48("2502") ? true : (stryCov_9fa48("2502", "2503"), input.target.kind === (stryMutAct_9fa48("2504") ? "" : (stryCov_9fa48("2504"), "category")))) && (stryMutAct_9fa48("2506") ? input.target.nature !== "Expense" : stryMutAct_9fa48("2505") ? true : (stryCov_9fa48("2505", "2506"), input.target.nature === (stryMutAct_9fa48("2507") ? "" : (stryCov_9fa48("2507"), "Expense")))))) ? 1 : 0) - ((stryMutAct_9fa48("2510") ? bucket.snapshot.nature !== "Expense" : stryMutAct_9fa48("2509") ? false : stryMutAct_9fa48("2508") ? true : (stryCov_9fa48("2508", "2509", "2510"), bucket.snapshot.nature === (stryMutAct_9fa48("2511") ? "" : (stryCov_9fa48("2511"), "Expense")))) ? 1 : 0));
        for (const root of stryMutAct_9fa48("2512") ? bucket.rootSources : (stryCov_9fa48("2512"), bucket.rootSources.filter(stryMutAct_9fa48("2513") ? () => undefined : (stryCov_9fa48("2513"), root => stryMutAct_9fa48("2516") ? root.signedMinorUnits === 0 : stryMutAct_9fa48("2515") ? false : stryMutAct_9fa48("2514") ? true : (stryCov_9fa48("2514", "2515", "2516"), root.signedMinorUnits !== 0))))) {
          if (stryMutAct_9fa48("2517")) {
            {}
          } else {
            stryCov_9fa48("2517");
            const amount = Math.abs(root.signedMinorUnits);
            const positive = stryMutAct_9fa48("2521") ? root.signedMinorUnits <= 0 : stryMutAct_9fa48("2520") ? root.signedMinorUnits >= 0 : stryMutAct_9fa48("2519") ? false : stryMutAct_9fa48("2518") ? true : (stryCov_9fa48("2518", "2519", "2520", "2521"), root.signedMinorUnits > 0);
            const correction = stryMutAct_9fa48("2522") ? {} : (stryCov_9fa48("2522"), {
              reclassificationKey: input.idempotencyKey,
              sources: bucket.sources,
              rootSources: stryMutAct_9fa48("2523") ? [] : (stryCov_9fa48("2523"), [root]),
              priorLockedPeriods: stryMutAct_9fa48("2524") ? bucket.priorLockedPeriods : (stryCov_9fa48("2524"), bucket.priorLockedPeriods.sort())
            });
            expenseEffects.set(root.entryId, stryMutAct_9fa48("2526") ? (expenseEffects.get(root.entryId) ?? 0) - expenseFactor * root.signedMinorUnits : (stryCov_9fa48("2526"), (stryMutAct_9fa48("2527") ? expenseEffects.get(root.entryId) && 0 : (stryCov_9fa48("2527"), expenseEffects.get(root.entryId) ?? 0)) + (stryMutAct_9fa48("2528") ? expenseFactor / root.signedMinorUnits : (stryCov_9fa48("2528"), expenseFactor * root.signedMinorUnits))));
            lines.push(stryMutAct_9fa48("2530") ? {} : (stryCov_9fa48("2530"), {
              ledgerAccountId: bucket.ledgerAccountId,
              debitMinorUnits: positive ? 0 : amount,
              creditMinorUnits: positive ? amount : 0,
              category: bucket.snapshot,
              categoryCorrection: stryMutAct_9fa48("2531") ? {} : (stryCov_9fa48("2531"), {
                ...correction,
                side: stryMutAct_9fa48("2532") ? "" : (stryCov_9fa48("2532"), "reversing")
              })
            }));
            lines.push(stryMutAct_9fa48("2534") ? {} : (stryCov_9fa48("2534"), {
              ledgerAccountId: destination.ledgerAccountId,
              debitMinorUnits: positive ? amount : 0,
              creditMinorUnits: positive ? 0 : amount,
              ...((stryMutAct_9fa48("2537") ? input.target.kind !== "category" : stryMutAct_9fa48("2536") ? false : stryMutAct_9fa48("2535") ? true : (stryCov_9fa48("2535", "2536", "2537"), input.target.kind === (stryMutAct_9fa48("2538") ? "" : (stryCov_9fa48("2538"), "category")))) ? stryMutAct_9fa48("2539") ? {} : (stryCov_9fa48("2539"), {
                category: categorySnapshot(destination.category)
              }) : {}),
              categoryCorrection: stryMutAct_9fa48("2540") ? {} : (stryCov_9fa48("2540"), {
                ...correction,
                side: stryMutAct_9fa48("2541") ? "" : (stryCov_9fa48("2541"), "replacement")
              })
            }));
          }
        }
      }
    }
    const catchUp = stryMutAct_9fa48("2542") ? lines.every(line => line.categoryCorrection?.priorLockedPeriods.length) : (stryCov_9fa48("2542"), lines.some(stryMutAct_9fa48("2543") ? () => undefined : (stryCov_9fa48("2543"), line => stryMutAct_9fa48("2544") ? line.categoryCorrection.priorLockedPeriods.length : (stryCov_9fa48("2544"), line.categoryCorrection?.priorLockedPeriods.length))));
    return stryMutAct_9fa48("2545") ? {} : (stryCov_9fa48("2545"), {
      accountingDate: date,
      description: stryMutAct_9fa48("2546") ? `` : (stryCov_9fa48("2546"), `${catchUp ? stryMutAct_9fa48("2547") ? "" : (stryCov_9fa48("2547"), "Prior-period category correction") : stryMutAct_9fa48("2548") ? "" : (stryCov_9fa48("2548"), "Category correction")}: ${categoryName}`),
      idempotencyKey: stryMutAct_9fa48("2549") ? `` : (stryCov_9fa48("2549"), `${input.idempotencyKey}:correction:${stryMutAct_9fa48("2550") ? date : (stryCov_9fa48("2550"), date.slice(0, 7))}`),
      policy: stryMutAct_9fa48("2551") ? "" : (stryCov_9fa48("2551"), "category-reclassification@1"),
      lines,
      sourceExpenseEffects: stryMutAct_9fa48("2553") ? [...expenseEffects.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([sourceEntryId, expenseDeltaMinorUnits]) => ({
        sourceEntryId,
        expenseDeltaMinorUnits
      })) : stryMutAct_9fa48("2552") ? [...expenseEffects.entries()].filter(([, delta]) => delta !== 0).map(([sourceEntryId, expenseDeltaMinorUnits]) => ({
        sourceEntryId,
        expenseDeltaMinorUnits
      })) : (stryCov_9fa48("2552", "2553"), (stryMutAct_9fa48("2554") ? [] : (stryCov_9fa48("2554"), [...expenseEffects.entries()])).filter(stryMutAct_9fa48("2555") ? () => undefined : (stryCov_9fa48("2555"), ([, delta]) => stryMutAct_9fa48("2558") ? delta === 0 : stryMutAct_9fa48("2557") ? false : stryMutAct_9fa48("2556") ? true : (stryCov_9fa48("2556", "2557", "2558"), delta !== 0))).sort(stryMutAct_9fa48("2559") ? () => undefined : (stryCov_9fa48("2559"), ([a], [b]) => a.localeCompare(b))).map(stryMutAct_9fa48("2560") ? () => undefined : (stryCov_9fa48("2560"), ([sourceEntryId, expenseDeltaMinorUnits]) => stryMutAct_9fa48("2561") ? {} : (stryCov_9fa48("2561"), {
        sourceEntryId,
        expenseDeltaMinorUnits
      }))))
    });
  }
}