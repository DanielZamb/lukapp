// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError, type AccountingErrorCode } from "./errors";
import { coPucPersonalTemplate } from "./templates/coPucPersonal";
import { usGaapPersonalTemplate } from "./templates/usGaapPersonal";
import type { AccountNature, AccountingStore, CatalogAccount, CatalogAccountView, CatalogUse, ChartOfAccountsTemplate, LedgerAccount, NormalSide, StoredWorkspace } from "./types";

/** The template a new Personal or Household Workspace starts from unless it asks for another. */
export const personalChartTemplate: ChartOfAccountsTemplate = coPucPersonalTemplate;
const templates = new Map<string, ChartOfAccountsTemplate>((stryMutAct_9fa48("687") ? [] : (stryCov_9fa48("687"), [coPucPersonalTemplate, usGaapPersonalTemplate])).map(stryMutAct_9fa48("688") ? () => undefined : (stryCov_9fa48("688"), template => stryMutAct_9fa48("689") ? [] : (stryCov_9fa48("689"), [template.version, template]))));
type RecordingUse = Extract<CatalogUse, "expense" | "income" | "openingBalance">;
const wrongUse: Record<RecordingUse, AccountingErrorCode> = stryMutAct_9fa48("690") ? {} : (stryCov_9fa48("690"), {
  expense: stryMutAct_9fa48("691") ? "" : (stryCov_9fa48("691"), "cash_expense_account_invalid"),
  income: stryMutAct_9fa48("692") ? "" : (stryCov_9fa48("692"), "cash_income_account_invalid"),
  openingBalance: stryMutAct_9fa48("693") ? "" : (stryCov_9fa48("693"), "opening_balance_account_invalid")
});
export function chartTemplate(version: string): ChartOfAccountsTemplate {
  if (stryMutAct_9fa48("694")) {
    {}
  } else {
    stryCov_9fa48("694");
    const template = templates.get(version);
    if (stryMutAct_9fa48("697") ? false : stryMutAct_9fa48("696") ? true : stryMutAct_9fa48("695") ? template : (stryCov_9fa48("695", "696", "697"), !template)) {
      if (stryMutAct_9fa48("698")) {
        {}
      } else {
        stryCov_9fa48("698");
        throw new AccountingError(stryMutAct_9fa48("700") ? "" : (stryCov_9fa48("700"), "chart_of_accounts_template_unknown"));
      }
    }
    return template;
  }
}

/** The first digit of a code is its class, and the class locks the nature. */
export function natureOfCode(template: ChartOfAccountsTemplate, code: string): AccountNature {
  if (stryMutAct_9fa48("701")) {
    {}
  } else {
    stryCov_9fa48("701");
    const nature = template.natureByClass[stryMutAct_9fa48("702") ? code : (stryCov_9fa48("702"), code.charAt(0))];
    if (stryMutAct_9fa48("705") ? false : stryMutAct_9fa48("704") ? true : stryMutAct_9fa48("703") ? nature : (stryCov_9fa48("703", "704", "705"), !nature)) {
      if (stryMutAct_9fa48("706")) {
        {}
      } else {
        stryCov_9fa48("706");
        throw new AccountingError(stryMutAct_9fa48("708") ? "" : (stryCov_9fa48("708"), "ledger_account_code_unknown"));
      }
    }
    return nature;
  }
}

/** Assets and Expenses grow with debits; Liabilities, Equity, and Revenue grow with credits. */
export function increasesWithDebit(nature: AccountNature): boolean {
  if (stryMutAct_9fa48("709")) {
    {}
  } else {
    stryCov_9fa48("709");
    return stryMutAct_9fa48("712") ? nature === "Asset" && nature === "Expense" : stryMutAct_9fa48("711") ? false : stryMutAct_9fa48("710") ? true : (stryCov_9fa48("710", "711", "712"), (stryMutAct_9fa48("714") ? nature !== "Asset" : stryMutAct_9fa48("713") ? false : (stryCov_9fa48("713", "714"), nature === (stryMutAct_9fa48("715") ? "" : (stryCov_9fa48("715"), "Asset")))) || (stryMutAct_9fa48("717") ? nature !== "Expense" : stryMutAct_9fa48("716") ? false : (stryCov_9fa48("716", "717"), nature === (stryMutAct_9fa48("718") ? "" : (stryCov_9fa48("718"), "Expense")))));
  }
}
export function normalSideOf(nature: AccountNature): NormalSide {
  if (stryMutAct_9fa48("719")) {
    {}
  } else {
    stryCov_9fa48("719");
    return increasesWithDebit(nature) ? stryMutAct_9fa48("720") ? "" : (stryCov_9fa48("720"), "Debit") : stryMutAct_9fa48("721") ? "" : (stryCov_9fa48("721"), "Credit");
  }
}

/** Balance on the account's normal side, so an Asset shows money held and a Liability money owed. */
export function normalBalance(normalSide: NormalSide, totals: {
  debitMinorUnits: number;
  creditMinorUnits: number;
}): number {
  if (stryMutAct_9fa48("722")) {
    {}
  } else {
    stryCov_9fa48("722");
    return (stryMutAct_9fa48("725") ? normalSide !== "Debit" : stryMutAct_9fa48("724") ? false : stryMutAct_9fa48("723") ? true : (stryCov_9fa48("723", "724", "725"), normalSide === (stryMutAct_9fa48("726") ? "" : (stryCov_9fa48("726"), "Debit")))) ? stryMutAct_9fa48("727") ? totals.debitMinorUnits + totals.creditMinorUnits : (stryCov_9fa48("727"), totals.debitMinorUnits - totals.creditMinorUnits) : stryMutAct_9fa48("728") ? totals.creditMinorUnits + totals.debitMinorUnits : (stryCov_9fa48("728"), totals.creditMinorUnits - totals.debitMinorUnits);
  }
}
function classify(template: ChartOfAccountsTemplate, account: CatalogAccount) {
  if (stryMutAct_9fa48("729")) {
    {}
  } else {
    stryCov_9fa48("729");
    const nature = natureOfCode(template, account.code);
    return stryMutAct_9fa48("730") ? {} : (stryCov_9fa48("730"), {
      nature,
      normalSide: stryMutAct_9fa48("731") ? account.normalSide && normalSideOf(nature) : (stryCov_9fa48("731"), account.normalSide ?? normalSideOf(nature))
    });
  }
}
function catalogAccount(template: ChartOfAccountsTemplate, code: string): CatalogAccount {
  if (stryMutAct_9fa48("732")) {
    {}
  } else {
    stryCov_9fa48("732");
    const account = template.accounts.find(stryMutAct_9fa48("733") ? () => undefined : (stryCov_9fa48("733"), candidate => stryMutAct_9fa48("736") ? candidate.code !== code : stryMutAct_9fa48("735") ? false : stryMutAct_9fa48("734") ? true : (stryCov_9fa48("734", "735", "736"), candidate.code === code)));
    if (stryMutAct_9fa48("739") ? false : stryMutAct_9fa48("738") ? true : stryMutAct_9fa48("737") ? account : (stryCov_9fa48("737", "738", "739"), !account)) {
      if (stryMutAct_9fa48("740")) {
        {}
      } else {
        stryCov_9fa48("740");
        throw new AccountingError(stryMutAct_9fa48("742") ? "" : (stryCov_9fa48("742"), "ledger_account_code_unknown"));
      }
    }
    return account;
  }
}
async function activate(store: AccountingStore, workspaceId: string, template: ChartOfAccountsTemplate, account: CatalogAccount): Promise<LedgerAccount> {
  if (stryMutAct_9fa48("743")) {
    {}
  } else {
    stryCov_9fa48("743");
    const existing = await store.findLedgerAccountByCode(workspaceId, account.code);
    if (stryMutAct_9fa48("745") ? false : stryMutAct_9fa48("744") ? true : (stryCov_9fa48("744", "745"), existing)) {
      if (stryMutAct_9fa48("746")) {
        {}
      } else {
        stryCov_9fa48("746");
        return existing;
      }
    }
    return store.insertLedgerAccount(stryMutAct_9fa48("747") ? {} : (stryCov_9fa48("747"), {
      workspaceId,
      code: account.code,
      name: account.name,
      ...classify(template, account),
      role: stryMutAct_9fa48("748") ? "" : (stryCov_9fa48("748"), "Posting")
    }));
  }
}
export async function provisionChartOfAccounts(store: AccountingStore, workspaceId: string, template: ChartOfAccountsTemplate): Promise<void> {
  if (stryMutAct_9fa48("749")) {
    {}
  } else {
    stryCov_9fa48("749");
    const {
      expense,
      income,
      openingBalance
    } = template.defaults;
    for (const code of stryMutAct_9fa48("750") ? [] : (stryCov_9fa48("750"), [openingBalance, income, expense])) {
      if (stryMutAct_9fa48("751")) {
        {}
      } else {
        stryCov_9fa48("751");
        await activate(store, workspaceId, template, catalogAccount(template, code));
      }
    }
  }
}

/**
 * The Workspace's Posting Account for a template code, activated on first use.
 * The template's use for the code must match the recording flow asking for it.
 */
export async function requireTemplateAccount(store: AccountingStore, workspace: StoredWorkspace, use: RecordingUse, code?: string): Promise<LedgerAccount> {
  if (stryMutAct_9fa48("752")) {
    {}
  } else {
    stryCov_9fa48("752");
    const account = resolveTemplateAccount(workspace, use, code);
    return activate(store, workspace.id, chartTemplate(workspace.chartOfAccountsTemplate), account);
  }
}

/** Next auxiliary code under a profile parent: 111005 → 11100501, 11100502, … up to 99. Template accounts never sit under a profile parent. */
export async function nextAuxiliaryCode(store: AccountingStore, workspaceId: string, parentCode: string): Promise<string> {
  if (stryMutAct_9fa48("753")) {
    {}
  } else {
    stryCov_9fa48("753");
    const accounts = await store.listLedgerAccounts(workspaceId);
    const used = stryMutAct_9fa48("754") ? accounts.map(account => Number(account.code.slice(parentCode.length))) : (stryCov_9fa48("754"), accounts.filter(stryMutAct_9fa48("755") ? () => undefined : (stryCov_9fa48("755"), account => stryMutAct_9fa48("756") ? account.code.endsWith(parentCode) : (stryCov_9fa48("756"), account.code.startsWith(parentCode)))).map(stryMutAct_9fa48("757") ? () => undefined : (stryCov_9fa48("757"), account => Number(stryMutAct_9fa48("758") ? account.code : (stryCov_9fa48("758"), account.code.slice(parentCode.length))))));
    const next = stryMutAct_9fa48("759") ? Math.max(0, ...used) - 1 : (stryCov_9fa48("759"), (stryMutAct_9fa48("760") ? Math.min(0, ...used) : (stryCov_9fa48("760"), Math.max(0, ...used))) + 1);
    if (stryMutAct_9fa48("764") ? next <= 99 : stryMutAct_9fa48("763") ? next >= 99 : stryMutAct_9fa48("762") ? false : stryMutAct_9fa48("761") ? true : (stryCov_9fa48("761", "762", "763", "764"), next > 99)) {
      if (stryMutAct_9fa48("765")) {
        {}
      } else {
        stryCov_9fa48("765");
        throw new AccountingError(stryMutAct_9fa48("767") ? "" : (stryCov_9fa48("767"), "auxiliary_accounts_exhausted"));
      }
    }
    return stryMutAct_9fa48("768") ? `` : (stryCov_9fa48("768"), `${parentCode}${String(next).padStart(2, stryMutAct_9fa48("769") ? "" : (stryCov_9fa48("769"), "0"))}`);
  }
}

/** Every Posting Account the template offers, each with its summary levels and activation. */
export function catalogView(template: ChartOfAccountsTemplate, activated: LedgerAccount[]): CatalogAccountView[] {
  if (stryMutAct_9fa48("770")) {
    {}
  } else {
    stryCov_9fa48("770");
    const byCode = new Map(activated.map(stryMutAct_9fa48("771") ? () => undefined : (stryCov_9fa48("771"), account => stryMutAct_9fa48("772") ? [] : (stryCov_9fa48("772"), [account.code, account.id]))));
    return template.accounts.map(account => {
      if (stryMutAct_9fa48("773")) {
        {}
      } else {
        stryCov_9fa48("773");
        const view: CatalogAccountView = stryMutAct_9fa48("774") ? {} : (stryCov_9fa48("774"), {
          code: account.code,
          name: account.name,
          ...classify(template, account),
          use: account.use,
          ...(account.reportingConcept ? stryMutAct_9fa48("775") ? {} : (stryCov_9fa48("775"), {
            reportingConcept: account.reportingConcept
          }) : {}),
          ancestors: ancestorCodes(account.code).map(stryMutAct_9fa48("776") ? () => undefined : (stryCov_9fa48("776"), code => stryMutAct_9fa48("777") ? {} : (stryCov_9fa48("777"), {
            code,
            name: stryMutAct_9fa48("778") ? template.summaryNames[code] && "" : (stryCov_9fa48("778"), template.summaryNames[code] ?? (stryMutAct_9fa48("779") ? "Stryker was here!" : (stryCov_9fa48("779"), "")))
          })))
        });
        const ledgerAccountId = byCode.get(account.code);
        if (stryMutAct_9fa48("781") ? false : stryMutAct_9fa48("780") ? true : (stryCov_9fa48("780", "781"), ledgerAccountId)) {
          if (stryMutAct_9fa48("782")) {
            {}
          } else {
            stryCov_9fa48("782");
            view.ledgerAccountId = ledgerAccountId;
          }
        }
        return view;
      }
    });
  }
}

/** Clase, grupo, cuenta, and subcuenta above a code: 51959595 → 5, 51, 5195, 519595. */
export function ancestorCodes(code: string): string[] {
  if (stryMutAct_9fa48("783")) {
    {}
  } else {
    stryCov_9fa48("783");
    return stryMutAct_9fa48("784") ? [1, 2, 4, 6].map(length => code.slice(0, length)) : (stryCov_9fa48("784"), (stryMutAct_9fa48("785") ? [] : (stryCov_9fa48("785"), [1, 2, 4, 6])).filter(stryMutAct_9fa48("786") ? () => undefined : (stryCov_9fa48("786"), length => stryMutAct_9fa48("790") ? length >= code.length : stryMutAct_9fa48("789") ? length <= code.length : stryMutAct_9fa48("788") ? false : stryMutAct_9fa48("787") ? true : (stryCov_9fa48("787", "788", "789", "790"), length < code.length))).map(stryMutAct_9fa48("791") ? () => undefined : (stryCov_9fa48("791"), length => stryMutAct_9fa48("792") ? code : (stryCov_9fa48("792"), code.slice(0, length)))));
  }
}
export function resolveTemplateAccount(workspace: StoredWorkspace, use: RecordingUse, code?: string) {
  if (stryMutAct_9fa48("793")) {
    {}
  } else {
    stryCov_9fa48("793");
    const template = chartTemplate(workspace.chartOfAccountsTemplate);
    const account = catalogAccount(template, stryMutAct_9fa48("794") ? code && template.defaults[use] : (stryCov_9fa48("794"), code ?? template.defaults[use]));
    if (stryMutAct_9fa48("797") ? account.use === use : stryMutAct_9fa48("796") ? false : stryMutAct_9fa48("795") ? true : (stryCov_9fa48("795", "796", "797"), account.use !== use)) if (stryMutAct_9fa48("798")) {
      ;
    } else {
      stryCov_9fa48("798");
      throw new AccountingError(wrongUse[use]);
    }
    return stryMutAct_9fa48("799") ? {} : (stryCov_9fa48("799"), {
      ...account,
      ...classify(template, account)
    });
  }
}