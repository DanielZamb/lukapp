// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { createUserCategory, changeUserCategory, listUserCategories, categoryTotals, categoryNatureSuggestion } from "./categories";
import { previewCategoryReclassification, confirmCategoryReclassification } from "./reclassification";
import { createHouseholdWorkspace } from "./commands/createHouseholdWorkspace";
import { listOwnedWorkspaces } from "./queries/listOwnedWorkspaces";
import { recordAccountTransfer } from "./commands/recordAccountTransfer";
import { recordOpeningPosition } from "./commands/recordOpeningPosition";
import { setupFinancialAccount } from "./commands/setupFinancialAccount";
import { createFinancialAccountProfile } from "./commands/createFinancialAccountProfile";
import { createPersonalWorkspace } from "./commands/createPersonalWorkspace";
import { lockAccountingPeriod } from "./commands/lockAccountingPeriod";
import { recordCashExpense } from "./commands/recordCashExpense";
import { recordCashIncome } from "./commands/recordCashIncome";
import { reversePostedEntry } from "./commands/reversePostedEntry";
import { listPostedExpenses } from "./queries/listPostedExpenses";
import { balances } from "./queries/balances";
import { listCatalogAccounts } from "./queries/listCatalogAccounts";
import { listFinancialAccountProfiles } from "./queries/listFinancialAccountProfiles";
import { listJournalEntries } from "./queries/listJournalEntries";
import { listLedgerAccounts } from "./queries/listLedgerAccounts";
import { openWorkspace } from "./queries/openWorkspace";
import { trialBalance } from "./queries/trialBalance";
import type { AccountingClock, AccountingCore, AccountingStore } from "./types";
export function createAccountingCore(store: AccountingStore, clock: AccountingClock = stryMutAct_9fa48("1251") ? {} : (stryCov_9fa48("1251"), {
  now: stryMutAct_9fa48("1252") ? () => undefined : (stryCov_9fa48("1252"), () => new Date())
})): AccountingCore {
  if (stryMutAct_9fa48("1253")) {
    {}
  } else {
    stryCov_9fa48("1253");
    return stryMutAct_9fa48("1254") ? {} : (stryCov_9fa48("1254"), {
      createUserCategory: stryMutAct_9fa48("1255") ? () => undefined : (stryCov_9fa48("1255"), input => createUserCategory(store, input)),
      suggestCategoryNature: stryMutAct_9fa48("1256") ? () => undefined : (stryCov_9fa48("1256"), input => categoryNatureSuggestion(store, input)),
      listUserCategories: stryMutAct_9fa48("1257") ? () => undefined : (stryCov_9fa48("1257"), input => listUserCategories(store, input)),
      categoryTotals: stryMutAct_9fa48("1258") ? () => undefined : (stryCov_9fa48("1258"), input => categoryTotals(store, input)),
      changeUserCategory: stryMutAct_9fa48("1259") ? () => undefined : (stryCov_9fa48("1259"), input => changeUserCategory(store, input)),
      previewCategoryReclassification: stryMutAct_9fa48("1260") ? () => undefined : (stryCov_9fa48("1260"), input => previewCategoryReclassification(store, input)),
      confirmCategoryReclassification: stryMutAct_9fa48("1261") ? () => undefined : (stryCov_9fa48("1261"), input => confirmCategoryReclassification(store, clock, input)),
      createPersonalWorkspace: stryMutAct_9fa48("1262") ? () => undefined : (stryCov_9fa48("1262"), input => createPersonalWorkspace(store, clock, input)),
      createHouseholdWorkspace: stryMutAct_9fa48("1263") ? () => undefined : (stryCov_9fa48("1263"), input => createHouseholdWorkspace(store, clock, input)),
      listOwnedWorkspaces: stryMutAct_9fa48("1264") ? () => undefined : (stryCov_9fa48("1264"), input => listOwnedWorkspaces(store, clock, input)),
      openWorkspace: stryMutAct_9fa48("1265") ? () => undefined : (stryCov_9fa48("1265"), input => openWorkspace(store, clock, input)),
      createFinancialAccountProfile: stryMutAct_9fa48("1266") ? () => undefined : (stryCov_9fa48("1266"), input => createFinancialAccountProfile(store, input)),
      listFinancialAccountProfiles: stryMutAct_9fa48("1267") ? () => undefined : (stryCov_9fa48("1267"), input => listFinancialAccountProfiles(store, input)),
      listLedgerAccounts: stryMutAct_9fa48("1268") ? () => undefined : (stryCov_9fa48("1268"), input => listLedgerAccounts(store, input)),
      listCatalogAccounts: stryMutAct_9fa48("1269") ? () => undefined : (stryCov_9fa48("1269"), input => listCatalogAccounts(store, input)),
      recordAccountTransfer: stryMutAct_9fa48("1270") ? () => undefined : (stryCov_9fa48("1270"), input => recordAccountTransfer(store, clock, input)),
      recordOpeningPosition: stryMutAct_9fa48("1271") ? () => undefined : (stryCov_9fa48("1271"), input => recordOpeningPosition(store, clock, input)),
      setupFinancialAccount: stryMutAct_9fa48("1272") ? () => undefined : (stryCov_9fa48("1272"), input => setupFinancialAccount(store, clock, input)),
      recordCashExpense: stryMutAct_9fa48("1273") ? () => undefined : (stryCov_9fa48("1273"), input => recordCashExpense(store, clock, input)),
      recordCashIncome: stryMutAct_9fa48("1274") ? () => undefined : (stryCov_9fa48("1274"), input => recordCashIncome(store, clock, input)),
      reversePostedEntry: stryMutAct_9fa48("1275") ? () => undefined : (stryCov_9fa48("1275"), input => reversePostedEntry(store, clock, input)),
      listJournalEntries: stryMutAct_9fa48("1276") ? () => undefined : (stryCov_9fa48("1276"), input => listJournalEntries(store, input)),
      listPostedExpenses: stryMutAct_9fa48("1277") ? () => undefined : (stryCov_9fa48("1277"), input => listPostedExpenses(store, input)),
      balances: stryMutAct_9fa48("1278") ? () => undefined : (stryCov_9fa48("1278"), input => balances(store, input)),
      trialBalance: stryMutAct_9fa48("1279") ? () => undefined : (stryCov_9fa48("1279"), input => trialBalance(store, input)),
      lockAccountingPeriod: stryMutAct_9fa48("1280") ? () => undefined : (stryCov_9fa48("1280"), input => lockAccountingPeriod(store, clock, input))
    });
  }
}