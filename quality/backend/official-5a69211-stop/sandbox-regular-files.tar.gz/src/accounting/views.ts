// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "./errors";
import type { AccountingPeriod, AccountingStore, FinancialAccountProfile, LedgerAccount, PostedJournalEntry, StoredJournalEntry, StoredProfile, StoredWorkspace, Workspace } from "./types";
export function toWorkspace(workspace: StoredWorkspace, currentAccountingPeriod: AccountingPeriod): Workspace {
  if (stryMutAct_9fa48("3555")) {
    {}
  } else {
    stryCov_9fa48("3555");
    return stryMutAct_9fa48("3556") ? {} : (stryCov_9fa48("3556"), {
      id: workspace.id,
      kind: workspace.kind,
      functionalCurrency: workspace.functionalCurrency,
      chartOfAccountsTemplate: workspace.chartOfAccountsTemplate,
      currentAccountingPeriod
    });
  }
}
export async function toProfile(store: AccountingStore, profile: StoredProfile): Promise<FinancialAccountProfile> {
  if (stryMutAct_9fa48("3557")) {
    {}
  } else {
    stryCov_9fa48("3557");
    return stryMutAct_9fa48("3558") ? {} : (stryCov_9fa48("3558"), {
      id: profile.id,
      workspaceId: profile.workspaceId,
      name: profile.name,
      productKind: profile.productKind,
      ...(profile.classificationAnswers ? stryMutAct_9fa48("3559") ? {} : (stryCov_9fa48("3559"), {
        classificationAnswers: profile.classificationAnswers
      }) : {}),
      ledgerAccountId: profile.postingAccountId,
      opening: (stryMutAct_9fa48("3560") ? profile.opening : (stryCov_9fa48("3560"), !profile.opening)) ? stryMutAct_9fa48("3561") ? {} : (stryCov_9fa48("3561"), {
        status: stryMutAct_9fa48("3562") ? "" : (stryCov_9fa48("3562"), "not_started")
      }) : (stryMutAct_9fa48("3565") ? profile.opening.kind !== "zero" : stryMutAct_9fa48("3564") ? false : stryMutAct_9fa48("3563") ? true : (stryCov_9fa48("3563", "3564", "3565"), profile.opening.kind === (stryMutAct_9fa48("3566") ? "" : (stryCov_9fa48("3566"), "zero")))) ? stryMutAct_9fa48("3567") ? {} : (stryCov_9fa48("3567"), {
        status: stryMutAct_9fa48("3568") ? "" : (stryCov_9fa48("3568"), "zero"),
        accountingDate: profile.opening.accountingDate,
        amount: profile.opening.amount,
        idempotencyKey: profile.opening.idempotencyKey
      }) : stryMutAct_9fa48("3569") ? {} : (stryCov_9fa48("3569"), {
        status: (await store.findReversalOf(profile.opening.journalEntryId)) ? stryMutAct_9fa48("3570") ? "" : (stryCov_9fa48("3570"), "reversed") : stryMutAct_9fa48("3571") ? "" : (stryCov_9fa48("3571"), "posted"),
        accountingDate: profile.opening.accountingDate,
        amount: profile.opening.amount,
        idempotencyKey: profile.opening.idempotencyKey,
        journalEntryId: profile.opening.journalEntryId
      })
    });
  }
}

/** Reads what a view of one Workspace's entries needs, once, for any number of entries. */
export async function journalContext(store: AccountingStore, workspace: StoredWorkspace) {
  if (stryMutAct_9fa48("3572")) {
    {}
  } else {
    stryCov_9fa48("3572");
    const [accounts, profiles] = await Promise.all(stryMutAct_9fa48("3573") ? [] : (stryCov_9fa48("3573"), [store.listLedgerAccounts(workspace.id), store.listProfiles(workspace.id)]));
    return stryMutAct_9fa48("3574") ? {} : (stryCov_9fa48("3574"), {
      workspace,
      accounts: new Map(accounts.map(stryMutAct_9fa48("3575") ? () => undefined : (stryCov_9fa48("3575"), account => stryMutAct_9fa48("3576") ? [] : (stryCov_9fa48("3576"), [account.id, account])))),
      profiles: new Map(profiles.map(stryMutAct_9fa48("3577") ? () => undefined : (stryCov_9fa48("3577"), profile => stryMutAct_9fa48("3578") ? [] : (stryCov_9fa48("3578"), [profile.id, profile])))),
      profileByAccount: new Map(profiles.map(stryMutAct_9fa48("3579") ? () => undefined : (stryCov_9fa48("3579"), profile => stryMutAct_9fa48("3580") ? [] : (stryCov_9fa48("3580"), [profile.postingAccountId, profile.id]))))
    });
  }
}
export type JournalContext = Awaited<ReturnType<typeof journalContext>>;
export async function toPostedJournalEntry(store: AccountingStore, context: JournalContext, entry: StoredJournalEntry, links: {
  replay: boolean;
  reversedByEntryId?: string;
}): Promise<PostedJournalEntry> {
  if (stryMutAct_9fa48("3581")) {
    {}
  } else {
    stryCov_9fa48("3581");
    const period = await store.getAccountingPeriod(context.workspace.id, entry.period);
    if (stryMutAct_9fa48("3584") ? false : stryMutAct_9fa48("3583") ? true : stryMutAct_9fa48("3582") ? period : (stryCov_9fa48("3582", "3583", "3584"), !period)) {
      if (stryMutAct_9fa48("3585")) {
        {}
      } else {
        stryCov_9fa48("3585");
        throw new AccountingError(stryMutAct_9fa48("3587") ? "" : (stryCov_9fa48("3587"), "accounting_period_not_found"));
      }
    }
    const profile = entry.financialAccountProfileId ? context.profiles.get(entry.financialAccountProfileId) : undefined;
    const view: PostedJournalEntry = stryMutAct_9fa48("3588") ? {} : (stryCov_9fa48("3588"), {
      id: entry.id,
      policy: entry.policy,
      ...(entry.cashCategoryInput ? stryMutAct_9fa48("3589") ? {} : (stryCov_9fa48("3589"), {
        cashCategoryInput: entry.cashCategoryInput
      }) : {}),
      ...(entry.sourceExpenseEffects ? stryMutAct_9fa48("3590") ? {} : (stryCov_9fa48("3590"), {
        sourceExpenseEffects: entry.sourceExpenseEffects
      }) : {}),
      description: entry.description,
      accountingDate: entry.accountingDate,
      accountingPeriod: period,
      amount: stryMutAct_9fa48("3591") ? {} : (stryCov_9fa48("3591"), {
        currency: context.workspace.functionalCurrency,
        minorUnits: entry.lines.reduce(stryMutAct_9fa48("3592") ? () => undefined : (stryCov_9fa48("3592"), (sum, line) => stryMutAct_9fa48("3593") ? sum - line.debitMinorUnits : (stryCov_9fa48("3593"), sum + line.debitMinorUnits)), 0)
      }),
      postedBy: entry.postedBy,
      postedAt: entry.postedAt,
      replay: links.replay,
      lines: entry.lines.map(line => {
        if (stryMutAct_9fa48("3594")) {
          {}
        } else {
          stryCov_9fa48("3594");
          const account = requireAccount(context.accounts, line.ledgerAccountId);
          const financialAccountProfileId = context.profileByAccount.get(line.ledgerAccountId);
          return stryMutAct_9fa48("3595") ? {} : (stryCov_9fa48("3595"), {
            ...(line.category ? stryMutAct_9fa48("3596") ? {} : (stryCov_9fa48("3596"), {
              category: line.category
            }) : {}),
            ...(line.categoryCorrection ? stryMutAct_9fa48("3597") ? {} : (stryCov_9fa48("3597"), {
              categoryCorrection: line.categoryCorrection
            }) : {}),
            ledgerAccountId: line.ledgerAccountId,
            ...((stryMutAct_9fa48("3600") ? financialAccountProfileId === undefined : stryMutAct_9fa48("3599") ? false : stryMutAct_9fa48("3598") ? true : (stryCov_9fa48("3598", "3599", "3600"), financialAccountProfileId !== undefined)) ? stryMutAct_9fa48("3601") ? {} : (stryCov_9fa48("3601"), {
              financialAccountProfileId
            }) : {}),
            code: account.code,
            name: account.name,
            nature: account.nature,
            debitMinorUnits: line.debitMinorUnits,
            creditMinorUnits: line.creditMinorUnits
          });
        }
      })
    });
    if (stryMutAct_9fa48("3603") ? false : stryMutAct_9fa48("3602") ? true : (stryCov_9fa48("3602", "3603"), profile)) {
      if (stryMutAct_9fa48("3604")) {
        {}
      } else {
        stryCov_9fa48("3604");
        view.financialAccountProfileId = profile.id;
        view.financialAccountProfileName = profile.name;
      }
    }
    if (stryMutAct_9fa48("3607") ? entry.policy !== "account-transfer@1" : stryMutAct_9fa48("3606") ? false : stryMutAct_9fa48("3605") ? true : (stryCov_9fa48("3605", "3606", "3607"), entry.policy === (stryMutAct_9fa48("3608") ? "" : (stryCov_9fa48("3608"), "account-transfer@1")))) {
      if (stryMutAct_9fa48("3609")) {
        {}
      } else {
        stryCov_9fa48("3609");
        const sourceLine = view.lines.find(stryMutAct_9fa48("3610") ? () => undefined : (stryCov_9fa48("3610"), line => stryMutAct_9fa48("3614") ? line.creditMinorUnits <= 0 : stryMutAct_9fa48("3613") ? line.creditMinorUnits >= 0 : stryMutAct_9fa48("3612") ? false : stryMutAct_9fa48("3611") ? true : (stryCov_9fa48("3611", "3612", "3613", "3614"), line.creditMinorUnits > 0)));
        const destinationLine = view.lines.find(stryMutAct_9fa48("3615") ? () => undefined : (stryCov_9fa48("3615"), line => stryMutAct_9fa48("3619") ? line.debitMinorUnits <= 0 : stryMutAct_9fa48("3618") ? line.debitMinorUnits >= 0 : stryMutAct_9fa48("3617") ? false : stryMutAct_9fa48("3616") ? true : (stryCov_9fa48("3616", "3617", "3618", "3619"), line.debitMinorUnits > 0)));
        if (stryMutAct_9fa48("3622") ? !sourceLine?.financialAccountProfileId && !destinationLine?.financialAccountProfileId : stryMutAct_9fa48("3621") ? false : stryMutAct_9fa48("3620") ? true : (stryCov_9fa48("3620", "3621", "3622"), (stryMutAct_9fa48("3623") ? sourceLine?.financialAccountProfileId : (stryCov_9fa48("3623"), !(stryMutAct_9fa48("3624") ? sourceLine.financialAccountProfileId : (stryCov_9fa48("3624"), sourceLine?.financialAccountProfileId)))) || (stryMutAct_9fa48("3625") ? destinationLine?.financialAccountProfileId : (stryCov_9fa48("3625"), !(stryMutAct_9fa48("3626") ? destinationLine.financialAccountProfileId : (stryCov_9fa48("3626"), destinationLine?.financialAccountProfileId)))))) {
          if (stryMutAct_9fa48("3627")) {
            {}
          } else {
            stryCov_9fa48("3627");
            throw new AccountingError(stryMutAct_9fa48("3629") ? "" : (stryCov_9fa48("3629"), "financial_account_profile_not_found"));
          }
        }
        view.accountTransfer = stryMutAct_9fa48("3630") ? {} : (stryCov_9fa48("3630"), {
          sourceFinancialAccountProfileId: sourceLine.financialAccountProfileId,
          destinationFinancialAccountProfileId: destinationLine.financialAccountProfileId,
          sourceNature: sourceLine.nature,
          destinationNature: destinationLine.nature
        });
      }
    }
    if (stryMutAct_9fa48("3632") ? false : stryMutAct_9fa48("3631") ? true : (stryCov_9fa48("3631", "3632"), entry.reversesEntryId)) {
      if (stryMutAct_9fa48("3633")) {
        {}
      } else {
        stryCov_9fa48("3633");
        view.reversesEntryId = entry.reversesEntryId;
      }
    }
    if (stryMutAct_9fa48("3635") ? false : stryMutAct_9fa48("3634") ? true : (stryCov_9fa48("3634", "3635"), links.reversedByEntryId)) {
      if (stryMutAct_9fa48("3636")) {
        {}
      } else {
        stryCov_9fa48("3636");
        view.reversedByEntryId = links.reversedByEntryId;
      }
    }
    return view;
  }
}

/** Chart of Accounts order: hierarchical codes sort as strings, so 1105 comes before 111005 and 2105. */
export function byCode(a: {
  code: string;
}, b: {
  code: string;
}): number {
  if (stryMutAct_9fa48("3637")) {
    {}
  } else {
    stryCov_9fa48("3637");
    return (stryMutAct_9fa48("3641") ? a.code >= b.code : stryMutAct_9fa48("3640") ? a.code <= b.code : stryMutAct_9fa48("3639") ? false : stryMutAct_9fa48("3638") ? true : (stryCov_9fa48("3638", "3639", "3640", "3641"), a.code < b.code)) ? stryMutAct_9fa48("3642") ? +1 : (stryCov_9fa48("3642"), -1) : (stryMutAct_9fa48("3646") ? a.code <= b.code : stryMutAct_9fa48("3645") ? a.code >= b.code : stryMutAct_9fa48("3644") ? false : stryMutAct_9fa48("3643") ? true : (stryCov_9fa48("3643", "3644", "3645", "3646"), a.code > b.code)) ? 1 : 0;
  }
}
function requireAccount(accounts: Map<string, LedgerAccount>, accountId: string): LedgerAccount {
  if (stryMutAct_9fa48("3647")) {
    {}
  } else {
    stryCov_9fa48("3647");
    const account = accounts.get(accountId);
    if (stryMutAct_9fa48("3650") ? false : stryMutAct_9fa48("3649") ? true : stryMutAct_9fa48("3648") ? account : (stryCov_9fa48("3648", "3649", "3650"), !account)) {
      if (stryMutAct_9fa48("3651")) {
        {}
      } else {
        stryCov_9fa48("3651");
        throw new AccountingError(stryMutAct_9fa48("3653") ? "" : (stryCov_9fa48("3653"), "ledger_account_not_found"));
      }
    }
    return account;
  }
}