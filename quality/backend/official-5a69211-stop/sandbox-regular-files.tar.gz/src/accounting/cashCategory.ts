// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { categorySnapshot, requireCategory } from "./categories";
import { AccountingError } from "./errors";
import type { CategorySnapshot } from "./categoryTypes";
import type { AccountingStore, CashActivityInput } from "./types";
export async function resolveCashCategory(store: Pick<AccountingStore, "getCategory">, input: Pick<CashActivityInput, "workspaceId" | "userCategoryId" | "categoryRevision" | "ledgerAccountCode">, counterpart: "expense" | "income", recorded?: CategorySnapshot): Promise<CategorySnapshot | undefined> {
  if (stryMutAct_9fa48("79")) {
    {}
  } else {
    stryCov_9fa48("79");
    if (stryMutAct_9fa48("82") ? input.userCategoryId !== undefined : stryMutAct_9fa48("81") ? false : stryMutAct_9fa48("80") ? true : (stryCov_9fa48("80", "81", "82"), input.userCategoryId === undefined)) {
      if (stryMutAct_9fa48("83")) {
        {}
      } else {
        stryCov_9fa48("83");
        if (stryMutAct_9fa48("86") ? input.categoryRevision === undefined : stryMutAct_9fa48("85") ? false : stryMutAct_9fa48("84") ? true : (stryCov_9fa48("84", "85", "86"), input.categoryRevision !== undefined)) throw new AccountingError(stryMutAct_9fa48("88") ? "" : (stryCov_9fa48("88"), "category_not_found"));
        return undefined;
      }
    }
    let category = recorded;
    if (stryMutAct_9fa48("91") ? false : stryMutAct_9fa48("90") ? true : stryMutAct_9fa48("89") ? category : (stryCov_9fa48("89", "90", "91"), !category)) {
      if (stryMutAct_9fa48("92")) {
        {}
      } else {
        stryCov_9fa48("92");
        const record = await requireCategory(store, input.workspaceId, input.userCategoryId);
        if (stryMutAct_9fa48("95") ? record.status === "active" : stryMutAct_9fa48("94") ? false : stryMutAct_9fa48("93") ? true : (stryCov_9fa48("93", "94", "95"), record.status !== (stryMutAct_9fa48("96") ? "" : (stryCov_9fa48("96"), "active")))) throw new AccountingError(stryMutAct_9fa48("98") ? "" : (stryCov_9fa48("98"), "category_inactive"));
        category = categorySnapshot(record);
      }
    }
    if (stryMutAct_9fa48("101") ? category.nature === (counterpart === "expense" ? "Expense" : "Income") : stryMutAct_9fa48("100") ? false : stryMutAct_9fa48("99") ? true : (stryCov_9fa48("99", "100", "101"), category.nature !== ((stryMutAct_9fa48("104") ? counterpart !== "expense" : stryMutAct_9fa48("103") ? false : stryMutAct_9fa48("102") ? true : (stryCov_9fa48("102", "103", "104"), counterpart === (stryMutAct_9fa48("105") ? "" : (stryCov_9fa48("105"), "expense")))) ? stryMutAct_9fa48("106") ? "" : (stryCov_9fa48("106"), "Expense") : stryMutAct_9fa48("107") ? "" : (stryCov_9fa48("107"), "Income")))) throw new AccountingError(stryMutAct_9fa48("109") ? "" : (stryCov_9fa48("109"), "category_nature_mismatch"));
    if (stryMutAct_9fa48("112") ? input.categoryRevision !== undefined || category.revision !== input.categoryRevision : stryMutAct_9fa48("111") ? false : stryMutAct_9fa48("110") ? true : (stryCov_9fa48("110", "111", "112"), (stryMutAct_9fa48("114") ? input.categoryRevision === undefined : stryMutAct_9fa48("113") ? true : (stryCov_9fa48("113", "114"), input.categoryRevision !== undefined)) && (stryMutAct_9fa48("116") ? category.revision === input.categoryRevision : stryMutAct_9fa48("115") ? true : (stryCov_9fa48("115", "116"), category.revision !== input.categoryRevision)))) throw new AccountingError(stryMutAct_9fa48("118") ? "" : (stryCov_9fa48("118"), "category_revision_stale"));
    return stryMutAct_9fa48("119") ? {} : (stryCov_9fa48("119"), {
      ...category,
      account: (stryMutAct_9fa48("122") ? input.ledgerAccountCode === undefined : stryMutAct_9fa48("121") ? false : stryMutAct_9fa48("120") ? true : (stryCov_9fa48("120", "121", "122"), input.ledgerAccountCode !== undefined)) ? stryMutAct_9fa48("123") ? {} : (stryCov_9fa48("123"), {
        kind: stryMutAct_9fa48("124") ? "" : (stryCov_9fa48("124"), "advanced"),
        accountCode: input.ledgerAccountCode
      }) : category.account
    });
  }
}