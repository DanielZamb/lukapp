// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "./errors";
export function dateFromTimestamp(now: number): Date {
  if (stryMutAct_9fa48("1623")) {
    {}
  } else {
    stryCov_9fa48("1623");
    if (stryMutAct_9fa48("1626") ? false : stryMutAct_9fa48("1625") ? true : stryMutAct_9fa48("1624") ? Number.isFinite(now) : (stryCov_9fa48("1624", "1625", "1626"), !Number.isFinite(now))) {
      if (stryMutAct_9fa48("1627")) {
        {}
      } else {
        stryCov_9fa48("1627");
        throw new AccountingError(stryMutAct_9fa48("1629") ? "" : (stryCov_9fa48("1629"), "clock_required"));
      }
    }
    const date = new Date(now);
    if (stryMutAct_9fa48("1631") ? false : stryMutAct_9fa48("1630") ? true : (stryCov_9fa48("1630", "1631"), Number.isNaN(date.getTime()))) {
      if (stryMutAct_9fa48("1632")) {
        {}
      } else {
        stryCov_9fa48("1632");
        throw new AccountingError(stryMutAct_9fa48("1634") ? "" : (stryCov_9fa48("1634"), "clock_required"));
      }
    }
    return date;
  }
}
export function clockMonth(now: Date): {
  year: number;
  month: number;
} {
  if (stryMutAct_9fa48("1635")) {
    {}
  } else {
    stryCov_9fa48("1635");
    if (stryMutAct_9fa48("1637") ? false : stryMutAct_9fa48("1636") ? true : (stryCov_9fa48("1636", "1637"), Number.isNaN(now.getTime()))) {
      if (stryMutAct_9fa48("1638")) {
        {}
      } else {
        stryCov_9fa48("1638");
        throw new AccountingError(stryMutAct_9fa48("1640") ? "" : (stryCov_9fa48("1640"), "clock_required"));
      }
    }
    return stryMutAct_9fa48("1641") ? {} : (stryCov_9fa48("1641"), {
      year: now.getUTCFullYear(),
      month: stryMutAct_9fa48("1642") ? now.getUTCMonth() - 1 : (stryCov_9fa48("1642"), now.getUTCMonth() + 1)
    });
  }
}
export function periodFromAccountingDate(accountingDate: string): {
  year: number;
  month: number;
} {
  if (stryMutAct_9fa48("1643")) {
    {}
  } else {
    stryCov_9fa48("1643");
    const match = (stryMutAct_9fa48("1651") ? /^(\d{4})-(\d{2})-(\D{2})$/ : stryMutAct_9fa48("1650") ? /^(\d{4})-(\d{2})-(\d)$/ : stryMutAct_9fa48("1649") ? /^(\d{4})-(\D{2})-(\d{2})$/ : stryMutAct_9fa48("1648") ? /^(\d{4})-(\d)-(\d{2})$/ : stryMutAct_9fa48("1647") ? /^(\D{4})-(\d{2})-(\d{2})$/ : stryMutAct_9fa48("1646") ? /^(\d)-(\d{2})-(\d{2})$/ : stryMutAct_9fa48("1645") ? /^(\d{4})-(\d{2})-(\d{2})/ : stryMutAct_9fa48("1644") ? /(\d{4})-(\d{2})-(\d{2})$/ : (stryCov_9fa48("1644", "1645", "1646", "1647", "1648", "1649", "1650", "1651"), /^(\d{4})-(\d{2})-(\d{2})$/)).exec(accountingDate);
    if (stryMutAct_9fa48("1654") ? false : stryMutAct_9fa48("1653") ? true : stryMutAct_9fa48("1652") ? match : (stryCov_9fa48("1652", "1653", "1654"), !match)) {
      if (stryMutAct_9fa48("1655")) {
        {}
      } else {
        stryCov_9fa48("1655");
        throw new AccountingError(stryMutAct_9fa48("1657") ? "" : (stryCov_9fa48("1657"), "accounting_date_required"));
      }
    }
    const year = Number(match[1]);
    const month = Number(match[2]);
    const day = Number(match[3]);
    const utc = new Date(Date.UTC(year, stryMutAct_9fa48("1658") ? month + 1 : (stryCov_9fa48("1658"), month - 1), day));
    if (stryMutAct_9fa48("1661") ? (utc.getUTCFullYear() !== year || utc.getUTCMonth() + 1 !== month) && utc.getUTCDate() !== day : stryMutAct_9fa48("1660") ? false : stryMutAct_9fa48("1659") ? true : (stryCov_9fa48("1659", "1660", "1661"), (stryMutAct_9fa48("1663") ? utc.getUTCFullYear() !== year && utc.getUTCMonth() + 1 !== month : stryMutAct_9fa48("1662") ? false : (stryCov_9fa48("1662", "1663"), (stryMutAct_9fa48("1665") ? utc.getUTCFullYear() === year : stryMutAct_9fa48("1664") ? false : (stryCov_9fa48("1664", "1665"), utc.getUTCFullYear() !== year)) || (stryMutAct_9fa48("1667") ? utc.getUTCMonth() + 1 === month : stryMutAct_9fa48("1666") ? false : (stryCov_9fa48("1666", "1667"), (stryMutAct_9fa48("1668") ? utc.getUTCMonth() - 1 : (stryCov_9fa48("1668"), utc.getUTCMonth() + 1)) !== month)))) || (stryMutAct_9fa48("1670") ? utc.getUTCDate() === day : stryMutAct_9fa48("1669") ? false : (stryCov_9fa48("1669", "1670"), utc.getUTCDate() !== day)))) {
      if (stryMutAct_9fa48("1671")) {
        {}
      } else {
        stryCov_9fa48("1671");
        throw new AccountingError(stryMutAct_9fa48("1673") ? "" : (stryCov_9fa48("1673"), "accounting_date_required"));
      }
    }
    return stryMutAct_9fa48("1674") ? {} : (stryCov_9fa48("1674"), {
      year,
      month
    });
  }
}
export function requirePeriodKey(period: {
  year: number;
  month: number;
}): {
  year: number;
  month: number;
} {
  if (stryMutAct_9fa48("1675")) {
    {}
  } else {
    stryCov_9fa48("1675");
    if (stryMutAct_9fa48("1678") ? (!Number.isInteger(period.year) || period.year < 1 || period.year > 9999 || !Number.isInteger(period.month) || period.month < 1) && period.month > 12 : stryMutAct_9fa48("1677") ? false : stryMutAct_9fa48("1676") ? true : (stryCov_9fa48("1676", "1677", "1678"), (stryMutAct_9fa48("1680") ? (!Number.isInteger(period.year) || period.year < 1 || period.year > 9999 || !Number.isInteger(period.month)) && period.month < 1 : stryMutAct_9fa48("1679") ? false : (stryCov_9fa48("1679", "1680"), (stryMutAct_9fa48("1682") ? (!Number.isInteger(period.year) || period.year < 1 || period.year > 9999) && !Number.isInteger(period.month) : stryMutAct_9fa48("1681") ? false : (stryCov_9fa48("1681", "1682"), (stryMutAct_9fa48("1684") ? (!Number.isInteger(period.year) || period.year < 1) && period.year > 9999 : stryMutAct_9fa48("1683") ? false : (stryCov_9fa48("1683", "1684"), (stryMutAct_9fa48("1686") ? !Number.isInteger(period.year) && period.year < 1 : stryMutAct_9fa48("1685") ? false : (stryCov_9fa48("1685", "1686"), (stryMutAct_9fa48("1687") ? Number.isInteger(period.year) : (stryCov_9fa48("1687"), !Number.isInteger(period.year))) || (stryMutAct_9fa48("1690") ? period.year >= 1 : stryMutAct_9fa48("1689") ? period.year <= 1 : stryMutAct_9fa48("1688") ? false : (stryCov_9fa48("1688", "1689", "1690"), period.year < 1)))) || (stryMutAct_9fa48("1693") ? period.year <= 9999 : stryMutAct_9fa48("1692") ? period.year >= 9999 : stryMutAct_9fa48("1691") ? false : (stryCov_9fa48("1691", "1692", "1693"), period.year > 9999)))) || (stryMutAct_9fa48("1694") ? Number.isInteger(period.month) : (stryCov_9fa48("1694"), !Number.isInteger(period.month))))) || (stryMutAct_9fa48("1697") ? period.month >= 1 : stryMutAct_9fa48("1696") ? period.month <= 1 : stryMutAct_9fa48("1695") ? false : (stryCov_9fa48("1695", "1696", "1697"), period.month < 1)))) || (stryMutAct_9fa48("1700") ? period.month <= 12 : stryMutAct_9fa48("1699") ? period.month >= 12 : stryMutAct_9fa48("1698") ? false : (stryCov_9fa48("1698", "1699", "1700"), period.month > 12)))) {
      if (stryMutAct_9fa48("1701")) {
        {}
      } else {
        stryCov_9fa48("1701");
        throw new AccountingError(stryMutAct_9fa48("1703") ? "" : (stryCov_9fa48("1703"), "accounting_period_invalid"));
      }
    }
    return stryMutAct_9fa48("1704") ? {} : (stryCov_9fa48("1704"), {
      year: period.year,
      month: period.month
    });
  }
}
export function nextPeriod(period: {
  year: number;
  month: number;
}): {
  year: number;
  month: number;
} {
  if (stryMutAct_9fa48("1705")) {
    {}
  } else {
    stryCov_9fa48("1705");
    return (stryMutAct_9fa48("1708") ? period.month !== 12 : stryMutAct_9fa48("1707") ? false : stryMutAct_9fa48("1706") ? true : (stryCov_9fa48("1706", "1707", "1708"), period.month === 12)) ? stryMutAct_9fa48("1709") ? {} : (stryCov_9fa48("1709"), {
      year: stryMutAct_9fa48("1710") ? period.year - 1 : (stryCov_9fa48("1710"), period.year + 1),
      month: 1
    }) : stryMutAct_9fa48("1711") ? {} : (stryCov_9fa48("1711"), {
      year: period.year,
      month: stryMutAct_9fa48("1712") ? period.month - 1 : (stryCov_9fa48("1712"), period.month + 1)
    });
  }
}
export function firstDayOf(period: {
  year: number;
  month: number;
}): string {
  if (stryMutAct_9fa48("1713")) {
    {}
  } else {
    stryCov_9fa48("1713");
    return stryMutAct_9fa48("1714") ? `` : (stryCov_9fa48("1714"), `${String(period.year).padStart(4, stryMutAct_9fa48("1715") ? "" : (stryCov_9fa48("1715"), "0"))}-${String(period.month).padStart(2, stryMutAct_9fa48("1716") ? "" : (stryCov_9fa48("1716"), "0"))}-01`);
  }
}