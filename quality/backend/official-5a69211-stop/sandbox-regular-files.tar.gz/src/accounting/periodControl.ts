// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "./errors";
import { firstDayOf, nextPeriod, periodFromAccountingDate } from "./period";
import type { AccountingPeriod, AccountingStore, PeriodKey } from "./types";

/** An Accounting Period opens the first time an entry is dated into it. */
export async function ensureOpenPeriod(store: AccountingStore, workspaceId: string, period: PeriodKey): Promise<AccountingPeriod> {
  if (stryMutAct_9fa48("1717")) {
    {}
  } else {
    stryCov_9fa48("1717");
    const stored = await store.getAccountingPeriod(workspaceId, period);
    if (stryMutAct_9fa48("1719") ? false : stryMutAct_9fa48("1718") ? true : (stryCov_9fa48("1718", "1719"), stored)) {
      if (stryMutAct_9fa48("1720")) {
        {}
      } else {
        stryCov_9fa48("1720");
        return stored;
      }
    }
    return store.insertAccountingPeriod(workspaceId, stryMutAct_9fa48("1721") ? {} : (stryCov_9fa48("1721"), {
      ...period,
      status: stryMutAct_9fa48("1722") ? "" : (stryCov_9fa48("1722"), "open")
    }));
  }
}
export async function requirePostablePeriod(store: AccountingStore, workspaceId: string, accountingDate: string): Promise<AccountingPeriod> {
  if (stryMutAct_9fa48("1723")) {
    {}
  } else {
    stryCov_9fa48("1723");
    const period = await ensureOpenPeriod(store, workspaceId, periodFromAccountingDate(accountingDate));
    if (stryMutAct_9fa48("1726") ? period.status !== "locked" : stryMutAct_9fa48("1725") ? false : stryMutAct_9fa48("1724") ? true : (stryCov_9fa48("1724", "1725", "1726"), period.status === (stryMutAct_9fa48("1727") ? "" : (stryCov_9fa48("1727"), "locked")))) {
      if (stryMutAct_9fa48("1728")) {
        {}
      } else {
        stryCov_9fa48("1728");
        throw new AccountingError(stryMutAct_9fa48("1730") ? "" : (stryCov_9fa48("1730"), "locked_period"));
      }
    }
    return period;
  }
}

/**
 * The date itself when its period is open; otherwise the first day of the next
 * period that is not locked (primer invariant 35).
 */
export async function earliestPermittedDate(store: AccountingStore, workspaceId: string, accountingDate: string): Promise<string> {
  if (stryMutAct_9fa48("1731")) {
    {}
  } else {
    stryCov_9fa48("1731");
    let period = periodFromAccountingDate(accountingDate);
    let candidate = accountingDate;
    if (stryMutAct_9fa48("1732")) {
      for (; false;) {
        const stored = await store.getAccountingPeriod(workspaceId, period);
        if (stored?.status !== "locked") {
          return candidate;
        }
        period = nextPeriod(period);
        candidate = firstDayOf(period);
      }
    } else {
      stryCov_9fa48("1732");
      for (;;) {
        if (stryMutAct_9fa48("1733")) {
          {}
        } else {
          stryCov_9fa48("1733");
          const stored = await store.getAccountingPeriod(workspaceId, period);
          if (stryMutAct_9fa48("1736") ? stored?.status === "locked" : stryMutAct_9fa48("1735") ? false : stryMutAct_9fa48("1734") ? true : (stryCov_9fa48("1734", "1735", "1736"), (stryMutAct_9fa48("1737") ? stored.status : (stryCov_9fa48("1737"), stored?.status)) !== (stryMutAct_9fa48("1738") ? "" : (stryCov_9fa48("1738"), "locked")))) {
            if (stryMutAct_9fa48("1739")) {
              {}
            } else {
              stryCov_9fa48("1739");
              return candidate;
            }
          }
          period = nextPeriod(period);
          candidate = firstDayOf(period);
        }
      }
    }
  }
}