// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import type { StoredJournalEntry } from "./types";
export type AccountTotals = {
  debitMinorUnits: number;
  creditMinorUnits: number;
};

/** Debit and credit totals per Ledger Account, from Posted Journal Lines only. */
export function totalsByAccount(entries: StoredJournalEntry[]): Map<string, AccountTotals> {
  if (stryMutAct_9fa48("1479")) {
    {}
  } else {
    stryCov_9fa48("1479");
    const totals = new Map<string, AccountTotals>();
    for (const line of entries.flatMap(stryMutAct_9fa48("1480") ? () => undefined : (stryCov_9fa48("1480"), entry => entry.lines))) {
      if (stryMutAct_9fa48("1481")) {
        {}
      } else {
        stryCov_9fa48("1481");
        const current = stryMutAct_9fa48("1482") ? totals.get(line.ledgerAccountId) && {
          debitMinorUnits: 0,
          creditMinorUnits: 0
        } : (stryCov_9fa48("1482"), totals.get(line.ledgerAccountId) ?? (stryMutAct_9fa48("1483") ? {} : (stryCov_9fa48("1483"), {
          debitMinorUnits: 0,
          creditMinorUnits: 0
        })));
        totals.set(line.ledgerAccountId, stryMutAct_9fa48("1485") ? {} : (stryCov_9fa48("1485"), {
          debitMinorUnits: stryMutAct_9fa48("1486") ? current.debitMinorUnits - line.debitMinorUnits : (stryCov_9fa48("1486"), current.debitMinorUnits + line.debitMinorUnits),
          creditMinorUnits: stryMutAct_9fa48("1487") ? current.creditMinorUnits - line.creditMinorUnits : (stryCov_9fa48("1487"), current.creditMinorUnits + line.creditMinorUnits)
        }));
      }
    }
    return totals;
  }
}