// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
export function commandIdentity(value: unknown): string {
  if (stryMutAct_9fa48("907")) {
    {}
  } else {
    stryCov_9fa48("907");
    return JSON.stringify(value, (_, item: unknown) => {
      if (stryMutAct_9fa48("908")) {
        {}
      } else {
        stryCov_9fa48("908");
        if (stryMutAct_9fa48("911") ? item !== null && typeof item === "object" || !Array.isArray(item) : stryMutAct_9fa48("910") ? false : stryMutAct_9fa48("909") ? true : (stryCov_9fa48("909", "910", "911"), (stryMutAct_9fa48("913") ? item !== null || typeof item === "object" : stryMutAct_9fa48("912") ? true : (stryCov_9fa48("912", "913"), (stryMutAct_9fa48("915") ? item === null : stryMutAct_9fa48("914") ? true : (stryCov_9fa48("914", "915"), item !== null)) && (stryMutAct_9fa48("917") ? typeof item !== "object" : stryMutAct_9fa48("916") ? true : (stryCov_9fa48("916", "917"), typeof item === (stryMutAct_9fa48("918") ? "" : (stryCov_9fa48("918"), "object")))))) && (stryMutAct_9fa48("919") ? Array.isArray(item) : (stryCov_9fa48("919"), !Array.isArray(item))))) return Object.fromEntries(stryMutAct_9fa48("920") ? Object.entries(item) : (stryCov_9fa48("920"), Object.entries(item).sort(stryMutAct_9fa48("921") ? () => undefined : (stryCov_9fa48("921"), ([a], [b]) => a.localeCompare(b)))));
        return item;
      }
    });
  }
}