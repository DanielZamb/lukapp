// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { commandIdentity } from "./commandIdentity";
import { resolveCashCategory } from "./cashCategory";
import { requireTemplateAccount } from "./chartOfAccounts";
import { AccountingError } from "./errors";
import { requireWorkspace } from "./membership";
import { requireFunctionalAmount } from "./money";
import { postJournalEntry } from "./posting";
import type { AccountingClock, AccountingStore, CashActivityInput, PostedJournalEntry, PostingPolicy } from "./types";
import { journalContext, toPostedJournalEntry } from "./views";

/**
 * Cash-style activity between a Financial Account Profile and one Chart of Accounts
 * counterpart. Money out credits the profile; money in debits it. The profile's
 * nature decides what that does to its balance, so a card purchase grows a Liability.
 * The counterpart is the template account for `ledgerAccountCode`, or the template
 * default, and its template use must match the flow: an expense for money out,
 * income for money in.
 */
export async function recordCashActivity(store: AccountingStore, clock: AccountingClock, input: CashActivityInput, treatment: {
  policy: PostingPolicy;
  direction: "out" | "in";
  counterpart: "expense" | "income";
}): Promise<PostedJournalEntry> {
  if (stryMutAct_9fa48("0")) {
    {}
  } else {
    stryCov_9fa48("0");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("1") ? "" : (stryCov_9fa48("1"), "post"));
    const amount = requireFunctionalAmount(workspace, input.amount);
    const profile = await store.getProfile(input.financialAccountProfileId);
    if (stryMutAct_9fa48("4") ? !profile && profile.workspaceId !== input.workspaceId : stryMutAct_9fa48("3") ? false : stryMutAct_9fa48("2") ? true : (stryCov_9fa48("2", "3", "4"), (stryMutAct_9fa48("5") ? profile : (stryCov_9fa48("5"), !profile)) || (stryMutAct_9fa48("7") ? profile.workspaceId === input.workspaceId : stryMutAct_9fa48("6") ? false : (stryCov_9fa48("6", "7"), profile.workspaceId !== input.workspaceId)))) {
      if (stryMutAct_9fa48("8")) {
        {}
      } else {
        stryCov_9fa48("8");
        throw new AccountingError(stryMutAct_9fa48("10") ? "" : (stryCov_9fa48("10"), "financial_account_profile_not_found"));
      }
    }
    const cashCategoryInput = (stryMutAct_9fa48("13") ? input.userCategoryId !== undefined : stryMutAct_9fa48("12") ? false : stryMutAct_9fa48("11") ? true : (stryCov_9fa48("11", "12", "13"), input.userCategoryId === undefined)) ? undefined : stryMutAct_9fa48("14") ? {} : (stryCov_9fa48("14"), {
      userCategoryId: input.userCategoryId,
      ...((stryMutAct_9fa48("17") ? input.categoryRevision === undefined : stryMutAct_9fa48("16") ? false : stryMutAct_9fa48("15") ? true : (stryCov_9fa48("15", "16", "17"), input.categoryRevision !== undefined)) ? stryMutAct_9fa48("18") ? {} : (stryCov_9fa48("18"), {
        categoryRevision: input.categoryRevision
      }) : {}),
      ...((stryMutAct_9fa48("21") ? input.ledgerAccountCode === undefined : stryMutAct_9fa48("20") ? false : stryMutAct_9fa48("19") ? true : (stryCov_9fa48("19", "20", "21"), input.ledgerAccountCode !== undefined)) ? stryMutAct_9fa48("22") ? {} : (stryCov_9fa48("22"), {
        ledgerAccountCode: input.ledgerAccountCode
      }) : {})
    });
    const existing = await store.findJournalEntryByIdempotencyKey(input.workspaceId, input.idempotencyKey);
    if (stryMutAct_9fa48("25") ? existing || commandIdentity(existing.cashCategoryInput) !== commandIdentity(cashCategoryInput) : stryMutAct_9fa48("24") ? false : stryMutAct_9fa48("23") ? true : (stryCov_9fa48("23", "24", "25"), existing && (stryMutAct_9fa48("27") ? commandIdentity(existing.cashCategoryInput) === commandIdentity(cashCategoryInput) : stryMutAct_9fa48("26") ? true : (stryCov_9fa48("26", "27"), commandIdentity(existing.cashCategoryInput) !== commandIdentity(cashCategoryInput))))) throw new AccountingError(stryMutAct_9fa48("29") ? "" : (stryCov_9fa48("29"), "idempotency_key_conflict"));
    const saved = stryMutAct_9fa48("31") ? existing.lines.find(line => line.category)?.category : stryMutAct_9fa48("30") ? existing?.lines.find(line => line.category).category : (stryCov_9fa48("30", "31"), existing?.lines.find(stryMutAct_9fa48("32") ? () => undefined : (stryCov_9fa48("32"), line => line.category))?.category);
    if (stryMutAct_9fa48("35") ? existing && input.userCategoryId !== undefined || !saved || saved.categoryId !== input.userCategoryId : stryMutAct_9fa48("34") ? false : stryMutAct_9fa48("33") ? true : (stryCov_9fa48("33", "34", "35"), (stryMutAct_9fa48("37") ? existing || input.userCategoryId !== undefined : stryMutAct_9fa48("36") ? true : (stryCov_9fa48("36", "37"), existing && (stryMutAct_9fa48("39") ? input.userCategoryId === undefined : stryMutAct_9fa48("38") ? true : (stryCov_9fa48("38", "39"), input.userCategoryId !== undefined)))) && (stryMutAct_9fa48("41") ? !saved && saved.categoryId !== input.userCategoryId : stryMutAct_9fa48("40") ? true : (stryCov_9fa48("40", "41"), (stryMutAct_9fa48("42") ? saved : (stryCov_9fa48("42"), !saved)) || (stryMutAct_9fa48("44") ? saved.categoryId === input.userCategoryId : stryMutAct_9fa48("43") ? false : (stryCov_9fa48("43", "44"), saved.categoryId !== input.userCategoryId)))))) throw new AccountingError(stryMutAct_9fa48("46") ? "" : (stryCov_9fa48("46"), "idempotency_key_conflict"));
    const category = await resolveCashCategory(store, input, treatment.counterpart, saved);
    const counterpart = await requireTemplateAccount(store, workspace, treatment.counterpart, stryMutAct_9fa48("47") ? input.ledgerAccountCode && category?.account.accountCode : (stryCov_9fa48("47"), input.ledgerAccountCode ?? (stryMutAct_9fa48("48") ? category.account.accountCode : (stryCov_9fa48("48"), category?.account.accountCode))));
    const debitAccountId = (stryMutAct_9fa48("51") ? treatment.direction !== "out" : stryMutAct_9fa48("50") ? false : stryMutAct_9fa48("49") ? true : (stryCov_9fa48("49", "50", "51"), treatment.direction === (stryMutAct_9fa48("52") ? "" : (stryCov_9fa48("52"), "out")))) ? counterpart.id : profile.postingAccountId;
    const creditAccountId = (stryMutAct_9fa48("55") ? treatment.direction !== "out" : stryMutAct_9fa48("54") ? false : stryMutAct_9fa48("53") ? true : (stryCov_9fa48("53", "54", "55"), treatment.direction === (stryMutAct_9fa48("56") ? "" : (stryCov_9fa48("56"), "out")))) ? profile.postingAccountId : counterpart.id;
    const {
      entry,
      replay
    } = await postJournalEntry(store, clock, stryMutAct_9fa48("57") ? {} : (stryCov_9fa48("57"), {
      actor: input.actor,
      workspaceId: input.workspaceId,
      draft: stryMutAct_9fa48("58") ? {} : (stryCov_9fa48("58"), {
        accountingDate: input.accountingDate,
        description: input.description,
        idempotencyKey: input.idempotencyKey,
        policy: treatment.policy,
        ...(cashCategoryInput ? stryMutAct_9fa48("59") ? {} : (stryCov_9fa48("59"), {
          cashCategoryInput
        }) : {}),
        financialAccountProfileId: profile.id,
        lines: stryMutAct_9fa48("60") ? [] : (stryCov_9fa48("60"), [stryMutAct_9fa48("61") ? {} : (stryCov_9fa48("61"), {
          ledgerAccountId: debitAccountId,
          debitMinorUnits: amount,
          creditMinorUnits: 0,
          ...((stryMutAct_9fa48("64") ? category || treatment.direction === "out" : stryMutAct_9fa48("63") ? false : stryMutAct_9fa48("62") ? true : (stryCov_9fa48("62", "63", "64"), category && (stryMutAct_9fa48("66") ? treatment.direction !== "out" : stryMutAct_9fa48("65") ? true : (stryCov_9fa48("65", "66"), treatment.direction === (stryMutAct_9fa48("67") ? "" : (stryCov_9fa48("67"), "out")))))) ? stryMutAct_9fa48("68") ? {} : (stryCov_9fa48("68"), {
            category
          }) : {})
        }), stryMutAct_9fa48("69") ? {} : (stryCov_9fa48("69"), {
          ledgerAccountId: creditAccountId,
          debitMinorUnits: 0,
          creditMinorUnits: amount,
          ...((stryMutAct_9fa48("72") ? category || treatment.direction === "in" : stryMutAct_9fa48("71") ? false : stryMutAct_9fa48("70") ? true : (stryCov_9fa48("70", "71", "72"), category && (stryMutAct_9fa48("74") ? treatment.direction !== "in" : stryMutAct_9fa48("73") ? true : (stryCov_9fa48("73", "74"), treatment.direction === (stryMutAct_9fa48("75") ? "" : (stryCov_9fa48("75"), "in")))))) ? stryMutAct_9fa48("76") ? {} : (stryCov_9fa48("76"), {
            category
          }) : {})
        })])
      })
    }));
    const reversal = await store.findReversalOf(entry.id);
    return toPostedJournalEntry(store, await journalContext(store, workspace), entry, stryMutAct_9fa48("77") ? {} : (stryCov_9fa48("77"), {
      replay,
      ...(reversal ? stryMutAct_9fa48("78") ? {} : (stryCov_9fa48("78"), {
        reversedByEntryId: reversal.id
      }) : {})
    }));
  }
}