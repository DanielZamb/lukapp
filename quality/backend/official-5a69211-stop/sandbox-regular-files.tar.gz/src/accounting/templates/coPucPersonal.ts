/*
 * COA Template for a Colombian Personal Workspace, built on the commercial PUC
 * (Decreto 2650 de 1993). Codes up to six digits are the decree's own; eight-digit
 * codes are auxiliaries the decree lets each entity add from the seventh digit
 * (Art. 7), used here for personal concepts the commercial PUC has no subaccount for.
 * Cohesive data file: one template, one version; see ADR-0082.
 */
// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import type { ChartOfAccountsTemplate } from "../types";
export const coPucPersonalTemplate = (stryMutAct_9fa48("2562") ? {} : (stryCov_9fa48("2562"), {
  version: stryMutAct_9fa48("2563") ? "" : (stryCov_9fa48("2563"), "co-puc-personal@1"),
  applicableWorkspaceKinds: stryMutAct_9fa48("2564") ? [] : (stryCov_9fa48("2564"), [stryMutAct_9fa48("2565") ? "" : (stryCov_9fa48("2565"), "Personal"), stryMutAct_9fa48("2566") ? "" : (stryCov_9fa48("2566"), "Household")]),
  natureByClass: stryMutAct_9fa48("2567") ? {} : (stryCov_9fa48("2567"), {
    "1": stryMutAct_9fa48("2568") ? "" : (stryCov_9fa48("2568"), "Asset"),
    "2": stryMutAct_9fa48("2569") ? "" : (stryCov_9fa48("2569"), "Liability"),
    "3": stryMutAct_9fa48("2570") ? "" : (stryCov_9fa48("2570"), "Equity"),
    "4": stryMutAct_9fa48("2571") ? "" : (stryCov_9fa48("2571"), "Revenue"),
    "5": stryMutAct_9fa48("2572") ? "" : (stryCov_9fa48("2572"), "Expense")
  }),
  defaults: stryMutAct_9fa48("2573") ? {} : (stryCov_9fa48("2573"), {
    expense: stryMutAct_9fa48("2574") ? "" : (stryCov_9fa48("2574"), "51959595"),
    income: stryMutAct_9fa48("2575") ? "" : (stryCov_9fa48("2575"), "42959595"),
    openingBalance: stryMutAct_9fa48("2576") ? "" : (stryCov_9fa48("2576"), "313001")
  }),
  financialAccountParents: stryMutAct_9fa48("2577") ? {} : (stryCov_9fa48("2577"), {
    cash: stryMutAct_9fa48("2578") ? "" : (stryCov_9fa48("2578"), "110505"),
    bankAccount: stryMutAct_9fa48("2579") ? "" : (stryCov_9fa48("2579"), "111005"),
    savingsAccount: stryMutAct_9fa48("2580") ? "" : (stryCov_9fa48("2580"), "112005"),
    creditCard: stryMutAct_9fa48("2581") ? "" : (stryCov_9fa48("2581"), "210510"),
    loan: stryMutAct_9fa48("2582") ? "" : (stryCov_9fa48("2582"), "210510"),
    securedReceivable: stryMutAct_9fa48("2583") ? "" : (stryCov_9fa48("2583"), "137005"),
    unsecuredReceivable: stryMutAct_9fa48("2584") ? "" : (stryCov_9fa48("2584"), "137010"),
    termDeposit: stryMutAct_9fa48("2585") ? "" : (stryCov_9fa48("2585"), "122505"),
    investmentFund: stryMutAct_9fa48("2586") ? "" : (stryCov_9fa48("2586"), "124505"),
    personalDebt: stryMutAct_9fa48("2587") ? "" : (stryCov_9fa48("2587"), "219505")
  }),
  accounts: stryMutAct_9fa48("2588") ? [] : (stryCov_9fa48("2588"), [// 1 Activo
  stryMutAct_9fa48("2589") ? {} : (stryCov_9fa48("2589"), {
    code: stryMutAct_9fa48("2590") ? "" : (stryCov_9fa48("2590"), "122505"),
    name: stryMutAct_9fa48("2591") ? "" : (stryCov_9fa48("2591"), "Certificados de depósito a término (CDT)"),
    use: stryMutAct_9fa48("2592") ? "" : (stryCov_9fa48("2592"), "general")
  }), stryMutAct_9fa48("2593") ? {} : (stryCov_9fa48("2593"), {
    code: stryMutAct_9fa48("2594") ? "" : (stryCov_9fa48("2594"), "124505"),
    name: stryMutAct_9fa48("2595") ? "" : (stryCov_9fa48("2595"), "Fideicomisos de inversión moneda nacional"),
    use: stryMutAct_9fa48("2596") ? "" : (stryCov_9fa48("2596"), "general")
  }), stryMutAct_9fa48("2597") ? {} : (stryCov_9fa48("2597"), {
    code: stryMutAct_9fa48("2598") ? "" : (stryCov_9fa48("2598"), "133005"),
    name: stryMutAct_9fa48("2599") ? "" : (stryCov_9fa48("2599"), "Anticipos a proveedores"),
    use: stryMutAct_9fa48("2600") ? "" : (stryCov_9fa48("2600"), "general")
  }), stryMutAct_9fa48("2601") ? {} : (stryCov_9fa48("2601"), {
    code: stryMutAct_9fa48("2602") ? "" : (stryCov_9fa48("2602"), "134505"),
    name: stryMutAct_9fa48("2603") ? "" : (stryCov_9fa48("2603"), "Dividendos y participaciones por cobrar"),
    use: stryMutAct_9fa48("2604") ? "" : (stryCov_9fa48("2604"), "general")
  }), stryMutAct_9fa48("2605") ? {} : (stryCov_9fa48("2605"), {
    code: stryMutAct_9fa48("2606") ? "" : (stryCov_9fa48("2606"), "134510"),
    name: stryMutAct_9fa48("2607") ? "" : (stryCov_9fa48("2607"), "Intereses por cobrar"),
    use: stryMutAct_9fa48("2608") ? "" : (stryCov_9fa48("2608"), "general")
  }), stryMutAct_9fa48("2609") ? {} : (stryCov_9fa48("2609"), {
    code: stryMutAct_9fa48("2610") ? "" : (stryCov_9fa48("2610"), "134530"),
    name: stryMutAct_9fa48("2611") ? "" : (stryCov_9fa48("2611"), "Arrendamientos por cobrar"),
    use: stryMutAct_9fa48("2612") ? "" : (stryCov_9fa48("2612"), "general")
  }), stryMutAct_9fa48("2613") ? {} : (stryCov_9fa48("2613"), {
    code: stryMutAct_9fa48("2614") ? "" : (stryCov_9fa48("2614"), "137005"),
    name: stryMutAct_9fa48("2615") ? "" : (stryCov_9fa48("2615"), "Préstamos a particulares con garantía real"),
    use: stryMutAct_9fa48("2616") ? "" : (stryCov_9fa48("2616"), "general")
  }), stryMutAct_9fa48("2617") ? {} : (stryCov_9fa48("2617"), {
    code: stryMutAct_9fa48("2618") ? "" : (stryCov_9fa48("2618"), "137010"),
    name: stryMutAct_9fa48("2619") ? "" : (stryCov_9fa48("2619"), "Préstamos a particulares con garantía personal"),
    use: stryMutAct_9fa48("2620") ? "" : (stryCov_9fa48("2620"), "general")
  }), stryMutAct_9fa48("2621") ? {} : (stryCov_9fa48("2621"), {
    code: stryMutAct_9fa48("2622") ? "" : (stryCov_9fa48("2622"), "138025"),
    name: stryMutAct_9fa48("2623") ? "" : (stryCov_9fa48("2623"), "Pagos por cuenta de terceros"),
    use: stryMutAct_9fa48("2624") ? "" : (stryCov_9fa48("2624"), "general")
  }), stryMutAct_9fa48("2625") ? {} : (stryCov_9fa48("2625"), {
    code: stryMutAct_9fa48("2626") ? "" : (stryCov_9fa48("2626"), "150405"),
    name: stryMutAct_9fa48("2627") ? "" : (stryCov_9fa48("2627"), "Terrenos urbanos"),
    use: stryMutAct_9fa48("2628") ? "" : (stryCov_9fa48("2628"), "general")
  }), stryMutAct_9fa48("2629") ? {} : (stryCov_9fa48("2629"), {
    code: stryMutAct_9fa48("2630") ? "" : (stryCov_9fa48("2630"), "151605"),
    name: stryMutAct_9fa48("2631") ? "" : (stryCov_9fa48("2631"), "Edificios"),
    use: stryMutAct_9fa48("2632") ? "" : (stryCov_9fa48("2632"), "general")
  }), stryMutAct_9fa48("2633") ? {} : (stryCov_9fa48("2633"), {
    code: stryMutAct_9fa48("2634") ? "" : (stryCov_9fa48("2634"), "152405"),
    name: stryMutAct_9fa48("2635") ? "" : (stryCov_9fa48("2635"), "Muebles y enseres"),
    use: stryMutAct_9fa48("2636") ? "" : (stryCov_9fa48("2636"), "general")
  }), stryMutAct_9fa48("2637") ? {} : (stryCov_9fa48("2637"), {
    code: stryMutAct_9fa48("2638") ? "" : (stryCov_9fa48("2638"), "152805"),
    name: stryMutAct_9fa48("2639") ? "" : (stryCov_9fa48("2639"), "Equipos de procesamiento de datos"),
    use: stryMutAct_9fa48("2640") ? "" : (stryCov_9fa48("2640"), "general")
  }), stryMutAct_9fa48("2641") ? {} : (stryCov_9fa48("2641"), {
    code: stryMutAct_9fa48("2642") ? "" : (stryCov_9fa48("2642"), "154005"),
    name: stryMutAct_9fa48("2643") ? "" : (stryCov_9fa48("2643"), "Autos, camionetas y camperos"),
    use: stryMutAct_9fa48("2644") ? "" : (stryCov_9fa48("2644"), "general")
  }), stryMutAct_9fa48("2645") ? {} : (stryCov_9fa48("2645"), {
    code: stryMutAct_9fa48("2646") ? "" : (stryCov_9fa48("2646"), "154030"),
    name: stryMutAct_9fa48("2647") ? "" : (stryCov_9fa48("2647"), "Motocicletas"),
    use: stryMutAct_9fa48("2648") ? "" : (stryCov_9fa48("2648"), "general")
  }), stryMutAct_9fa48("2649") ? {} : (stryCov_9fa48("2649"), {
    code: stryMutAct_9fa48("2650") ? "" : (stryCov_9fa48("2650"), "159205"),
    name: stryMutAct_9fa48("2651") ? "" : (stryCov_9fa48("2651"), "Depreciación acumulada de construcciones y edificaciones"),
    use: stryMutAct_9fa48("2652") ? "" : (stryCov_9fa48("2652"), "general"),
    normalSide: stryMutAct_9fa48("2653") ? "" : (stryCov_9fa48("2653"), "Credit")
  }), stryMutAct_9fa48("2654") ? {} : (stryCov_9fa48("2654"), {
    code: stryMutAct_9fa48("2655") ? "" : (stryCov_9fa48("2655"), "159215"),
    name: stryMutAct_9fa48("2656") ? "" : (stryCov_9fa48("2656"), "Depreciación acumulada de equipo de oficina"),
    use: stryMutAct_9fa48("2657") ? "" : (stryCov_9fa48("2657"), "general"),
    normalSide: stryMutAct_9fa48("2658") ? "" : (stryCov_9fa48("2658"), "Credit")
  }), stryMutAct_9fa48("2659") ? {} : (stryCov_9fa48("2659"), {
    code: stryMutAct_9fa48("2660") ? "" : (stryCov_9fa48("2660"), "159220"),
    name: stryMutAct_9fa48("2661") ? "" : (stryCov_9fa48("2661"), "Depreciación acumulada de equipo de computación y comunicación"),
    use: stryMutAct_9fa48("2662") ? "" : (stryCov_9fa48("2662"), "general"),
    normalSide: stryMutAct_9fa48("2663") ? "" : (stryCov_9fa48("2663"), "Credit")
  }), stryMutAct_9fa48("2664") ? {} : (stryCov_9fa48("2664"), {
    code: stryMutAct_9fa48("2665") ? "" : (stryCov_9fa48("2665"), "159235"),
    name: stryMutAct_9fa48("2666") ? "" : (stryCov_9fa48("2666"), "Depreciación acumulada de flota y equipo de transporte"),
    use: stryMutAct_9fa48("2667") ? "" : (stryCov_9fa48("2667"), "general"),
    normalSide: stryMutAct_9fa48("2668") ? "" : (stryCov_9fa48("2668"), "Credit")
  }), stryMutAct_9fa48("2669") ? {} : (stryCov_9fa48("2669"), {
    code: stryMutAct_9fa48("2670") ? "" : (stryCov_9fa48("2670"), "170520"),
    name: stryMutAct_9fa48("2671") ? "" : (stryCov_9fa48("2671"), "Seguros y fianzas pagados por anticipado"),
    use: stryMutAct_9fa48("2672") ? "" : (stryCov_9fa48("2672"), "general")
  }), stryMutAct_9fa48("2673") ? {} : (stryCov_9fa48("2673"), {
    code: stryMutAct_9fa48("2674") ? "" : (stryCov_9fa48("2674"), "170545"),
    name: stryMutAct_9fa48("2675") ? "" : (stryCov_9fa48("2675"), "Suscripciones pagadas por anticipado"),
    use: stryMutAct_9fa48("2676") ? "" : (stryCov_9fa48("2676"), "general")
  }), // 2 Pasivo
  stryMutAct_9fa48("2677") ? {} : (stryCov_9fa48("2677"), {
    code: stryMutAct_9fa48("2678") ? "" : (stryCov_9fa48("2678"), "219505"),
    name: stryMutAct_9fa48("2679") ? "" : (stryCov_9fa48("2679"), "Obligaciones con particulares"),
    use: stryMutAct_9fa48("2680") ? "" : (stryCov_9fa48("2680"), "general")
  }), stryMutAct_9fa48("2681") ? {} : (stryCov_9fa48("2681"), {
    code: stryMutAct_9fa48("2682") ? "" : (stryCov_9fa48("2682"), "233595"),
    name: stryMutAct_9fa48("2683") ? "" : (stryCov_9fa48("2683"), "Otros costos y gastos por pagar"),
    use: stryMutAct_9fa48("2684") ? "" : (stryCov_9fa48("2684"), "general")
  }), stryMutAct_9fa48("2685") ? {} : (stryCov_9fa48("2685"), {
    code: stryMutAct_9fa48("2686") ? "" : (stryCov_9fa48("2686"), "238020"),
    name: stryMutAct_9fa48("2687") ? "" : (stryCov_9fa48("2687"), "Reintegros por pagar"),
    use: stryMutAct_9fa48("2688") ? "" : (stryCov_9fa48("2688"), "general")
  }), stryMutAct_9fa48("2689") ? {} : (stryCov_9fa48("2689"), {
    code: stryMutAct_9fa48("2690") ? "" : (stryCov_9fa48("2690"), "240405"),
    name: stryMutAct_9fa48("2691") ? "" : (stryCov_9fa48("2691"), "Impuesto de renta por pagar, vigencia corriente"),
    use: stryMutAct_9fa48("2692") ? "" : (stryCov_9fa48("2692"), "general")
  }), stryMutAct_9fa48("2693") ? {} : (stryCov_9fa48("2693"), {
    code: stryMutAct_9fa48("2694") ? "" : (stryCov_9fa48("2694"), "270515"),
    name: stryMutAct_9fa48("2695") ? "" : (stryCov_9fa48("2695"), "Arrendamientos recibidos por anticipado"),
    use: stryMutAct_9fa48("2696") ? "" : (stryCov_9fa48("2696"), "general")
  }), stryMutAct_9fa48("2697") ? {} : (stryCov_9fa48("2697"), {
    code: stryMutAct_9fa48("2698") ? "" : (stryCov_9fa48("2698"), "280505"),
    name: stryMutAct_9fa48("2699") ? "" : (stryCov_9fa48("2699"), "Anticipos de clientes"),
    use: stryMutAct_9fa48("2700") ? "" : (stryCov_9fa48("2700"), "general")
  }), stryMutAct_9fa48("2701") ? {} : (stryCov_9fa48("2701"), {
    code: stryMutAct_9fa48("2702") ? "" : (stryCov_9fa48("2702"), "281020"),
    name: stryMutAct_9fa48("2703") ? "" : (stryCov_9fa48("2703"), "Depósitos recibidos en garantía de contratos"),
    use: stryMutAct_9fa48("2704") ? "" : (stryCov_9fa48("2704"), "general")
  }), // 3 Patrimonio
  stryMutAct_9fa48("2705") ? {} : (stryCov_9fa48("2705"), {
    code: stryMutAct_9fa48("2706") ? "" : (stryCov_9fa48("2706"), "313001"),
    name: stryMutAct_9fa48("2707") ? "" : (stryCov_9fa48("2707"), "Patrimonio de apertura"),
    use: stryMutAct_9fa48("2708") ? "" : (stryCov_9fa48("2708"), "openingBalance")
  }), // 4 Ingresos
  stryMutAct_9fa48("2709") ? {} : (stryCov_9fa48("2709"), {
    code: stryMutAct_9fa48("2710") ? "" : (stryCov_9fa48("2710"), "421005"),
    name: stryMutAct_9fa48("2711") ? "" : (stryCov_9fa48("2711"), "Intereses"),
    use: stryMutAct_9fa48("2712") ? "" : (stryCov_9fa48("2712"), "income")
  }), stryMutAct_9fa48("2713") ? {} : (stryCov_9fa48("2713"), {
    code: stryMutAct_9fa48("2714") ? "" : (stryCov_9fa48("2714"), "421020"),
    name: stryMutAct_9fa48("2715") ? "" : (stryCov_9fa48("2715"), "Diferencia en cambio (ingreso)"),
    use: stryMutAct_9fa48("2716") ? "" : (stryCov_9fa48("2716"), "general")
  }), stryMutAct_9fa48("2717") ? {} : (stryCov_9fa48("2717"), {
    code: stryMutAct_9fa48("2718") ? "" : (stryCov_9fa48("2718"), "421505"),
    name: stryMutAct_9fa48("2719") ? "" : (stryCov_9fa48("2719"), "Dividendos de sociedades anónimas"),
    use: stryMutAct_9fa48("2720") ? "" : (stryCov_9fa48("2720"), "income")
  }), stryMutAct_9fa48("2721") ? {} : (stryCov_9fa48("2721"), {
    code: stryMutAct_9fa48("2722") ? "" : (stryCov_9fa48("2722"), "42201001"),
    name: stryMutAct_9fa48("2723") ? "" : (stryCov_9fa48("2723"), "Arrendamientos de vivienda"),
    use: stryMutAct_9fa48("2724") ? "" : (stryCov_9fa48("2724"), "income")
  }), stryMutAct_9fa48("2725") ? {} : (stryCov_9fa48("2725"), {
    code: stryMutAct_9fa48("2726") ? "" : (stryCov_9fa48("2726"), "42201002"),
    name: stryMutAct_9fa48("2727") ? "" : (stryCov_9fa48("2727"), "Alojamiento de corta estancia"),
    use: stryMutAct_9fa48("2728") ? "" : (stryCov_9fa48("2728"), "income")
  }), stryMutAct_9fa48("2729") ? {} : (stryCov_9fa48("2729"), {
    code: stryMutAct_9fa48("2730") ? "" : (stryCov_9fa48("2730"), "423005"),
    name: stryMutAct_9fa48("2731") ? "" : (stryCov_9fa48("2731"), "Honorarios por asesorías"),
    use: stryMutAct_9fa48("2732") ? "" : (stryCov_9fa48("2732"), "income")
  }), stryMutAct_9fa48("2733") ? {} : (stryCov_9fa48("2733"), {
    code: stryMutAct_9fa48("2734") ? "" : (stryCov_9fa48("2734"), "424005"),
    name: stryMutAct_9fa48("2735") ? "" : (stryCov_9fa48("2735"), "Utilidad en venta de acciones"),
    use: stryMutAct_9fa48("2736") ? "" : (stryCov_9fa48("2736"), "general")
  }), stryMutAct_9fa48("2737") ? {} : (stryCov_9fa48("2737"), {
    code: stryMutAct_9fa48("2738") ? "" : (stryCov_9fa48("2738"), "429543"),
    name: stryMutAct_9fa48("2739") ? "" : (stryCov_9fa48("2739"), "Premios"),
    use: stryMutAct_9fa48("2740") ? "" : (stryCov_9fa48("2740"), "income")
  }), stryMutAct_9fa48("2741") ? {} : (stryCov_9fa48("2741"), {
    code: stryMutAct_9fa48("2742") ? "" : (stryCov_9fa48("2742"), "429545"),
    name: stryMutAct_9fa48("2743") ? "" : (stryCov_9fa48("2743"), "Bonificaciones"),
    use: stryMutAct_9fa48("2744") ? "" : (stryCov_9fa48("2744"), "income")
  }), stryMutAct_9fa48("2745") ? {} : (stryCov_9fa48("2745"), {
    code: stryMutAct_9fa48("2746") ? "" : (stryCov_9fa48("2746"), "42959501"),
    name: stryMutAct_9fa48("2747") ? "" : (stryCov_9fa48("2747"), "Salario"),
    use: stryMutAct_9fa48("2748") ? "" : (stryCov_9fa48("2748"), "income")
  }), stryMutAct_9fa48("2749") ? {} : (stryCov_9fa48("2749"), {
    code: stryMutAct_9fa48("2750") ? "" : (stryCov_9fa48("2750"), "42959502"),
    name: stryMutAct_9fa48("2751") ? "" : (stryCov_9fa48("2751"), "Regalos y apoyos recibidos"),
    use: stryMutAct_9fa48("2752") ? "" : (stryCov_9fa48("2752"), "income")
  }), stryMutAct_9fa48("2753") ? {} : (stryCov_9fa48("2753"), {
    code: stryMutAct_9fa48("2754") ? "" : (stryCov_9fa48("2754"), "42959595"),
    name: stryMutAct_9fa48("2755") ? "" : (stryCov_9fa48("2755"), "Otros ingresos"),
    use: stryMutAct_9fa48("2756") ? "" : (stryCov_9fa48("2756"), "income")
  }), // 5 Gastos
  stryMutAct_9fa48("2757") ? {} : (stryCov_9fa48("2757"), {
    code: stryMutAct_9fa48("2758") ? "" : (stryCov_9fa48("2758"), "511025"),
    name: stryMutAct_9fa48("2759") ? "" : (stryCov_9fa48("2759"), "Asesoría jurídica"),
    use: stryMutAct_9fa48("2760") ? "" : (stryCov_9fa48("2760"), "expense")
  }), stryMutAct_9fa48("2761") ? {} : (stryCov_9fa48("2761"), {
    code: stryMutAct_9fa48("2762") ? "" : (stryCov_9fa48("2762"), "511030"),
    name: stryMutAct_9fa48("2763") ? "" : (stryCov_9fa48("2763"), "Asesoría financiera"),
    use: stryMutAct_9fa48("2764") ? "" : (stryCov_9fa48("2764"), "expense")
  }), stryMutAct_9fa48("2765") ? {} : (stryCov_9fa48("2765"), {
    code: stryMutAct_9fa48("2766") ? "" : (stryCov_9fa48("2766"), "511515"),
    name: stryMutAct_9fa48("2767") ? "" : (stryCov_9fa48("2767"), "Impuesto predial"),
    use: stryMutAct_9fa48("2768") ? "" : (stryCov_9fa48("2768"), "expense")
  }), stryMutAct_9fa48("2769") ? {} : (stryCov_9fa48("2769"), {
    code: stryMutAct_9fa48("2770") ? "" : (stryCov_9fa48("2770"), "511540"),
    name: stryMutAct_9fa48("2771") ? "" : (stryCov_9fa48("2771"), "Impuesto de vehículos"),
    use: stryMutAct_9fa48("2772") ? "" : (stryCov_9fa48("2772"), "expense")
  }), stryMutAct_9fa48("2773") ? {} : (stryCov_9fa48("2773"), {
    code: stryMutAct_9fa48("2774") ? "" : (stryCov_9fa48("2774"), "51159501"),
    name: stryMutAct_9fa48("2775") ? "" : (stryCov_9fa48("2775"), "Gravamen a los movimientos financieros (4x1000)"),
    use: stryMutAct_9fa48("2776") ? "" : (stryCov_9fa48("2776"), "expense")
  }), stryMutAct_9fa48("2777") ? {} : (stryCov_9fa48("2777"), {
    code: stryMutAct_9fa48("2778") ? "" : (stryCov_9fa48("2778"), "512010"),
    name: stryMutAct_9fa48("2779") ? "" : (stryCov_9fa48("2779"), "Arrendamiento de vivienda"),
    use: stryMutAct_9fa48("2780") ? "" : (stryCov_9fa48("2780"), "expense")
  }), stryMutAct_9fa48("2781") ? {} : (stryCov_9fa48("2781"), {
    code: stryMutAct_9fa48("2782") ? "" : (stryCov_9fa48("2782"), "513020"),
    name: stryMutAct_9fa48("2783") ? "" : (stryCov_9fa48("2783"), "Seguro de vida"),
    use: stryMutAct_9fa48("2784") ? "" : (stryCov_9fa48("2784"), "expense")
  }), stryMutAct_9fa48("2785") ? {} : (stryCov_9fa48("2785"), {
    code: stryMutAct_9fa48("2786") ? "" : (stryCov_9fa48("2786"), "513040"),
    name: stryMutAct_9fa48("2787") ? "" : (stryCov_9fa48("2787"), "Seguro de vehículo"),
    use: stryMutAct_9fa48("2788") ? "" : (stryCov_9fa48("2788"), "expense")
  }), stryMutAct_9fa48("2789") ? {} : (stryCov_9fa48("2789"), {
    code: stryMutAct_9fa48("2790") ? "" : (stryCov_9fa48("2790"), "513075"),
    name: stryMutAct_9fa48("2791") ? "" : (stryCov_9fa48("2791"), "SOAT"),
    use: stryMutAct_9fa48("2792") ? "" : (stryCov_9fa48("2792"), "expense")
  }), stryMutAct_9fa48("2793") ? {} : (stryCov_9fa48("2793"), {
    code: stryMutAct_9fa48("2794") ? "" : (stryCov_9fa48("2794"), "513095"),
    name: stryMutAct_9fa48("2795") ? "" : (stryCov_9fa48("2795"), "Otros seguros"),
    use: stryMutAct_9fa48("2796") ? "" : (stryCov_9fa48("2796"), "expense")
  }), stryMutAct_9fa48("2797") ? {} : (stryCov_9fa48("2797"), {
    code: stryMutAct_9fa48("2798") ? "" : (stryCov_9fa48("2798"), "513505"),
    name: stryMutAct_9fa48("2799") ? "" : (stryCov_9fa48("2799"), "Aseo y vigilancia"),
    use: stryMutAct_9fa48("2800") ? "" : (stryCov_9fa48("2800"), "expense")
  }), stryMutAct_9fa48("2801") ? {} : (stryCov_9fa48("2801"), {
    code: stryMutAct_9fa48("2802") ? "" : (stryCov_9fa48("2802"), "513525"),
    name: stryMutAct_9fa48("2803") ? "" : (stryCov_9fa48("2803"), "Acueducto y alcantarillado"),
    use: stryMutAct_9fa48("2804") ? "" : (stryCov_9fa48("2804"), "expense")
  }), stryMutAct_9fa48("2805") ? {} : (stryCov_9fa48("2805"), {
    code: stryMutAct_9fa48("2806") ? "" : (stryCov_9fa48("2806"), "513530"),
    name: stryMutAct_9fa48("2807") ? "" : (stryCov_9fa48("2807"), "Energía eléctrica"),
    use: stryMutAct_9fa48("2808") ? "" : (stryCov_9fa48("2808"), "expense")
  }), stryMutAct_9fa48("2809") ? {} : (stryCov_9fa48("2809"), {
    code: stryMutAct_9fa48("2810") ? "" : (stryCov_9fa48("2810"), "513535"),
    name: stryMutAct_9fa48("2811") ? "" : (stryCov_9fa48("2811"), "Teléfono e internet"),
    use: stryMutAct_9fa48("2812") ? "" : (stryCov_9fa48("2812"), "expense")
  }), stryMutAct_9fa48("2813") ? {} : (stryCov_9fa48("2813"), {
    code: stryMutAct_9fa48("2814") ? "" : (stryCov_9fa48("2814"), "513550"),
    name: stryMutAct_9fa48("2815") ? "" : (stryCov_9fa48("2815"), "Transporte, fletes y acarreos"),
    use: stryMutAct_9fa48("2816") ? "" : (stryCov_9fa48("2816"), "expense")
  }), stryMutAct_9fa48("2817") ? {} : (stryCov_9fa48("2817"), {
    code: stryMutAct_9fa48("2818") ? "" : (stryCov_9fa48("2818"), "513555"),
    name: stryMutAct_9fa48("2819") ? "" : (stryCov_9fa48("2819"), "Gas"),
    use: stryMutAct_9fa48("2820") ? "" : (stryCov_9fa48("2820"), "expense")
  }), stryMutAct_9fa48("2821") ? {} : (stryCov_9fa48("2821"), {
    code: stryMutAct_9fa48("2822") ? "" : (stryCov_9fa48("2822"), "51359501"),
    name: stryMutAct_9fa48("2823") ? "" : (stryCov_9fa48("2823"), "Software y servicios digitales"),
    use: stryMutAct_9fa48("2824") ? "" : (stryCov_9fa48("2824"), "expense")
  }), stryMutAct_9fa48("2825") ? {} : (stryCov_9fa48("2825"), {
    code: stryMutAct_9fa48("2826") ? "" : (stryCov_9fa48("2826"), "514510"),
    name: stryMutAct_9fa48("2827") ? "" : (stryCov_9fa48("2827"), "Mantenimiento de vivienda"),
    use: stryMutAct_9fa48("2828") ? "" : (stryCov_9fa48("2828"), "expense")
  }), stryMutAct_9fa48("2829") ? {} : (stryCov_9fa48("2829"), {
    code: stryMutAct_9fa48("2830") ? "" : (stryCov_9fa48("2830"), "514525"),
    name: stryMutAct_9fa48("2831") ? "" : (stryCov_9fa48("2831"), "Mantenimiento de equipo de computación y comunicación"),
    use: stryMutAct_9fa48("2832") ? "" : (stryCov_9fa48("2832"), "expense")
  }), stryMutAct_9fa48("2833") ? {} : (stryCov_9fa48("2833"), {
    code: stryMutAct_9fa48("2834") ? "" : (stryCov_9fa48("2834"), "514540"),
    name: stryMutAct_9fa48("2835") ? "" : (stryCov_9fa48("2835"), "Mantenimiento de vehículos"),
    use: stryMutAct_9fa48("2836") ? "" : (stryCov_9fa48("2836"), "expense")
  }), stryMutAct_9fa48("2837") ? {} : (stryCov_9fa48("2837"), {
    code: stryMutAct_9fa48("2838") ? "" : (stryCov_9fa48("2838"), "515505"),
    name: stryMutAct_9fa48("2839") ? "" : (stryCov_9fa48("2839"), "Alojamiento y manutención en viajes"),
    use: stryMutAct_9fa48("2840") ? "" : (stryCov_9fa48("2840"), "expense")
  }), stryMutAct_9fa48("2841") ? {} : (stryCov_9fa48("2841"), {
    code: stryMutAct_9fa48("2842") ? "" : (stryCov_9fa48("2842"), "515515"),
    name: stryMutAct_9fa48("2843") ? "" : (stryCov_9fa48("2843"), "Pasajes aéreos"),
    use: stryMutAct_9fa48("2844") ? "" : (stryCov_9fa48("2844"), "expense")
  }), stryMutAct_9fa48("2845") ? {} : (stryCov_9fa48("2845"), {
    code: stryMutAct_9fa48("2846") ? "" : (stryCov_9fa48("2846"), "515520"),
    name: stryMutAct_9fa48("2847") ? "" : (stryCov_9fa48("2847"), "Pasajes terrestres"),
    use: stryMutAct_9fa48("2848") ? "" : (stryCov_9fa48("2848"), "expense")
  }), stryMutAct_9fa48("2849") ? {} : (stryCov_9fa48("2849"), {
    code: stryMutAct_9fa48("2850") ? "" : (stryCov_9fa48("2850"), "516005"),
    name: stryMutAct_9fa48("2851") ? "" : (stryCov_9fa48("2851"), "Depreciación de construcciones y edificaciones"),
    use: stryMutAct_9fa48("2852") ? "" : (stryCov_9fa48("2852"), "general")
  }), stryMutAct_9fa48("2853") ? {} : (stryCov_9fa48("2853"), {
    code: stryMutAct_9fa48("2854") ? "" : (stryCov_9fa48("2854"), "516015"),
    name: stryMutAct_9fa48("2855") ? "" : (stryCov_9fa48("2855"), "Depreciación de equipo de oficina"),
    use: stryMutAct_9fa48("2856") ? "" : (stryCov_9fa48("2856"), "general")
  }), stryMutAct_9fa48("2857") ? {} : (stryCov_9fa48("2857"), {
    code: stryMutAct_9fa48("2858") ? "" : (stryCov_9fa48("2858"), "516020"),
    name: stryMutAct_9fa48("2859") ? "" : (stryCov_9fa48("2859"), "Depreciación de equipo de computación y comunicación"),
    use: stryMutAct_9fa48("2860") ? "" : (stryCov_9fa48("2860"), "general")
  }), stryMutAct_9fa48("2861") ? {} : (stryCov_9fa48("2861"), {
    code: stryMutAct_9fa48("2862") ? "" : (stryCov_9fa48("2862"), "516035"),
    name: stryMutAct_9fa48("2863") ? "" : (stryCov_9fa48("2863"), "Depreciación de flota y equipo de transporte"),
    use: stryMutAct_9fa48("2864") ? "" : (stryCov_9fa48("2864"), "general")
  }), stryMutAct_9fa48("2865") ? {} : (stryCov_9fa48("2865"), {
    code: stryMutAct_9fa48("2866") ? "" : (stryCov_9fa48("2866"), "519510"),
    name: stryMutAct_9fa48("2867") ? "" : (stryCov_9fa48("2867"), "Libros, suscripciones, periódicos y revistas"),
    use: stryMutAct_9fa48("2868") ? "" : (stryCov_9fa48("2868"), "expense")
  }), stryMutAct_9fa48("2869") ? {} : (stryCov_9fa48("2869"), {
    code: stryMutAct_9fa48("2870") ? "" : (stryCov_9fa48("2870"), "519525"),
    name: stryMutAct_9fa48("2871") ? "" : (stryCov_9fa48("2871"), "Elementos de aseo y cafetería"),
    use: stryMutAct_9fa48("2872") ? "" : (stryCov_9fa48("2872"), "expense")
  }), stryMutAct_9fa48("2873") ? {} : (stryCov_9fa48("2873"), {
    code: stryMutAct_9fa48("2874") ? "" : (stryCov_9fa48("2874"), "519535"),
    name: stryMutAct_9fa48("2875") ? "" : (stryCov_9fa48("2875"), "Combustibles y lubricantes"),
    use: stryMutAct_9fa48("2876") ? "" : (stryCov_9fa48("2876"), "expense")
  }), stryMutAct_9fa48("2877") ? {} : (stryCov_9fa48("2877"), {
    code: stryMutAct_9fa48("2878") ? "" : (stryCov_9fa48("2878"), "519545"),
    name: stryMutAct_9fa48("2879") ? "" : (stryCov_9fa48("2879"), "Taxis y buses"),
    use: stryMutAct_9fa48("2880") ? "" : (stryCov_9fa48("2880"), "expense")
  }), stryMutAct_9fa48("2881") ? {} : (stryCov_9fa48("2881"), {
    code: stryMutAct_9fa48("2882") ? "" : (stryCov_9fa48("2882"), "519560"),
    name: stryMutAct_9fa48("2883") ? "" : (stryCov_9fa48("2883"), "Restaurantes y cafeterías"),
    use: stryMutAct_9fa48("2884") ? "" : (stryCov_9fa48("2884"), "expense")
  }), stryMutAct_9fa48("2885") ? {} : (stryCov_9fa48("2885"), {
    code: stryMutAct_9fa48("2886") ? "" : (stryCov_9fa48("2886"), "519565"),
    name: stryMutAct_9fa48("2887") ? "" : (stryCov_9fa48("2887"), "Parqueaderos"),
    use: stryMutAct_9fa48("2888") ? "" : (stryCov_9fa48("2888"), "expense")
  }), stryMutAct_9fa48("2889") ? {} : (stryCov_9fa48("2889"), {
    code: stryMutAct_9fa48("2890") ? "" : (stryCov_9fa48("2890"), "51959501"),
    name: stryMutAct_9fa48("2891") ? "" : (stryCov_9fa48("2891"), "Mercado y alimentos del hogar"),
    use: stryMutAct_9fa48("2892") ? "" : (stryCov_9fa48("2892"), "expense")
  }), stryMutAct_9fa48("2893") ? {} : (stryCov_9fa48("2893"), {
    code: stryMutAct_9fa48("2894") ? "" : (stryCov_9fa48("2894"), "51959502"),
    name: stryMutAct_9fa48("2895") ? "" : (stryCov_9fa48("2895"), "Salud y medicamentos"),
    use: stryMutAct_9fa48("2896") ? "" : (stryCov_9fa48("2896"), "expense")
  }), stryMutAct_9fa48("2897") ? {} : (stryCov_9fa48("2897"), {
    code: stryMutAct_9fa48("2898") ? "" : (stryCov_9fa48("2898"), "51959503"),
    name: stryMutAct_9fa48("2899") ? "" : (stryCov_9fa48("2899"), "Cuidado personal"),
    use: stryMutAct_9fa48("2900") ? "" : (stryCov_9fa48("2900"), "expense")
  }), stryMutAct_9fa48("2901") ? {} : (stryCov_9fa48("2901"), {
    code: stryMutAct_9fa48("2902") ? "" : (stryCov_9fa48("2902"), "51959504"),
    name: stryMutAct_9fa48("2903") ? "" : (stryCov_9fa48("2903"), "Ropa y calzado"),
    use: stryMutAct_9fa48("2904") ? "" : (stryCov_9fa48("2904"), "expense")
  }), stryMutAct_9fa48("2905") ? {} : (stryCov_9fa48("2905"), {
    code: stryMutAct_9fa48("2906") ? "" : (stryCov_9fa48("2906"), "51959505"),
    name: stryMutAct_9fa48("2907") ? "" : (stryCov_9fa48("2907"), "Educación"),
    use: stryMutAct_9fa48("2908") ? "" : (stryCov_9fa48("2908"), "expense")
  }), stryMutAct_9fa48("2909") ? {} : (stryCov_9fa48("2909"), {
    code: stryMutAct_9fa48("2910") ? "" : (stryCov_9fa48("2910"), "51959506"),
    name: stryMutAct_9fa48("2911") ? "" : (stryCov_9fa48("2911"), "Deporte y bienestar"),
    use: stryMutAct_9fa48("2912") ? "" : (stryCov_9fa48("2912"), "expense")
  }), stryMutAct_9fa48("2913") ? {} : (stryCov_9fa48("2913"), {
    code: stryMutAct_9fa48("2914") ? "" : (stryCov_9fa48("2914"), "51959507"),
    name: stryMutAct_9fa48("2915") ? "" : (stryCov_9fa48("2915"), "Entretenimiento y recreación"),
    use: stryMutAct_9fa48("2916") ? "" : (stryCov_9fa48("2916"), "expense")
  }), stryMutAct_9fa48("2917") ? {} : (stryCov_9fa48("2917"), {
    code: stryMutAct_9fa48("2918") ? "" : (stryCov_9fa48("2918"), "51959508"),
    name: stryMutAct_9fa48("2919") ? "" : (stryCov_9fa48("2919"), "Regalos y apoyo familiar"),
    use: stryMutAct_9fa48("2920") ? "" : (stryCov_9fa48("2920"), "expense")
  }), stryMutAct_9fa48("2921") ? {} : (stryCov_9fa48("2921"), {
    code: stryMutAct_9fa48("2922") ? "" : (stryCov_9fa48("2922"), "51959509"),
    name: stryMutAct_9fa48("2923") ? "" : (stryCov_9fa48("2923"), "Mascotas"),
    use: stryMutAct_9fa48("2924") ? "" : (stryCov_9fa48("2924"), "expense")
  }), stryMutAct_9fa48("2925") ? {} : (stryCov_9fa48("2925"), {
    code: stryMutAct_9fa48("2926") ? "" : (stryCov_9fa48("2926"), "51959510"),
    name: stryMutAct_9fa48("2927") ? "" : (stryCov_9fa48("2927"), "Tecnología y accesorios"),
    use: stryMutAct_9fa48("2928") ? "" : (stryCov_9fa48("2928"), "expense")
  }), stryMutAct_9fa48("2929") ? {} : (stryCov_9fa48("2929"), {
    code: stryMutAct_9fa48("2930") ? "" : (stryCov_9fa48("2930"), "51959595"),
    name: stryMutAct_9fa48("2931") ? "" : (stryCov_9fa48("2931"), "Otros gastos personales"),
    use: stryMutAct_9fa48("2932") ? "" : (stryCov_9fa48("2932"), "expense")
  }), stryMutAct_9fa48("2933") ? {} : (stryCov_9fa48("2933"), {
    code: stryMutAct_9fa48("2934") ? "" : (stryCov_9fa48("2934"), "530505"),
    name: stryMutAct_9fa48("2935") ? "" : (stryCov_9fa48("2935"), "Gastos bancarios"),
    use: stryMutAct_9fa48("2936") ? "" : (stryCov_9fa48("2936"), "expense")
  }), stryMutAct_9fa48("2937") ? {} : (stryCov_9fa48("2937"), {
    code: stryMutAct_9fa48("2938") ? "" : (stryCov_9fa48("2938"), "530515"),
    name: stryMutAct_9fa48("2939") ? "" : (stryCov_9fa48("2939"), "Comisiones financieras"),
    use: stryMutAct_9fa48("2940") ? "" : (stryCov_9fa48("2940"), "expense")
  }), stryMutAct_9fa48("2941") ? {} : (stryCov_9fa48("2941"), {
    code: stryMutAct_9fa48("2942") ? "" : (stryCov_9fa48("2942"), "530520"),
    name: stryMutAct_9fa48("2943") ? "" : (stryCov_9fa48("2943"), "Intereses"),
    use: stryMutAct_9fa48("2944") ? "" : (stryCov_9fa48("2944"), "expense")
  }), stryMutAct_9fa48("2945") ? {} : (stryCov_9fa48("2945"), {
    code: stryMutAct_9fa48("2946") ? "" : (stryCov_9fa48("2946"), "530525"),
    name: stryMutAct_9fa48("2947") ? "" : (stryCov_9fa48("2947"), "Diferencia en cambio (gasto)"),
    use: stryMutAct_9fa48("2948") ? "" : (stryCov_9fa48("2948"), "general")
  }), stryMutAct_9fa48("2949") ? {} : (stryCov_9fa48("2949"), {
    code: stryMutAct_9fa48("2950") ? "" : (stryCov_9fa48("2950"), "531005"),
    name: stryMutAct_9fa48("2951") ? "" : (stryCov_9fa48("2951"), "Pérdida en venta de inversiones"),
    use: stryMutAct_9fa48("2952") ? "" : (stryCov_9fa48("2952"), "general")
  }), stryMutAct_9fa48("2953") ? {} : (stryCov_9fa48("2953"), {
    code: stryMutAct_9fa48("2954") ? "" : (stryCov_9fa48("2954"), "531015"),
    name: stryMutAct_9fa48("2955") ? "" : (stryCov_9fa48("2955"), "Pérdida en venta de propiedades, planta y equipo"),
    use: stryMutAct_9fa48("2956") ? "" : (stryCov_9fa48("2956"), "general")
  }), stryMutAct_9fa48("2957") ? {} : (stryCov_9fa48("2957"), {
    code: stryMutAct_9fa48("2958") ? "" : (stryCov_9fa48("2958"), "539520"),
    name: stryMutAct_9fa48("2959") ? "" : (stryCov_9fa48("2959"), "Multas, sanciones y litigios"),
    use: stryMutAct_9fa48("2960") ? "" : (stryCov_9fa48("2960"), "expense")
  }), stryMutAct_9fa48("2961") ? {} : (stryCov_9fa48("2961"), {
    code: stryMutAct_9fa48("2962") ? "" : (stryCov_9fa48("2962"), "539525"),
    name: stryMutAct_9fa48("2963") ? "" : (stryCov_9fa48("2963"), "Donaciones"),
    use: stryMutAct_9fa48("2964") ? "" : (stryCov_9fa48("2964"), "expense")
  }), stryMutAct_9fa48("2965") ? {} : (stryCov_9fa48("2965"), {
    code: stryMutAct_9fa48("2966") ? "" : (stryCov_9fa48("2966"), "540505"),
    name: stryMutAct_9fa48("2967") ? "" : (stryCov_9fa48("2967"), "Impuesto de renta y complementarios"),
    use: stryMutAct_9fa48("2968") ? "" : (stryCov_9fa48("2968"), "expense")
  })]),
  summaryNames: stryMutAct_9fa48("2969") ? {} : (stryCov_9fa48("2969"), {
    "219505": stryMutAct_9fa48("2970") ? "" : (stryCov_9fa48("2970"), "Obligaciones con particulares"),
    "124505": stryMutAct_9fa48("2971") ? "" : (stryCov_9fa48("2971"), "Fideicomisos de inversión moneda nacional"),
    "122505": stryMutAct_9fa48("2972") ? "" : (stryCov_9fa48("2972"), "Certificados de depósito a término (CDT)"),
    "137010": stryMutAct_9fa48("2973") ? "" : (stryCov_9fa48("2973"), "Préstamos a particulares con garantía personal"),
    "137005": stryMutAct_9fa48("2974") ? "" : (stryCov_9fa48("2974"), "Préstamos a particulares con garantía real"),
    "1": stryMutAct_9fa48("2975") ? "" : (stryCov_9fa48("2975"), "Activo"),
    "11": stryMutAct_9fa48("2976") ? "" : (stryCov_9fa48("2976"), "Disponible"),
    "1105": stryMutAct_9fa48("2977") ? "" : (stryCov_9fa48("2977"), "Caja"),
    "110505": stryMutAct_9fa48("2978") ? "" : (stryCov_9fa48("2978"), "Caja general"),
    "1110": stryMutAct_9fa48("2979") ? "" : (stryCov_9fa48("2979"), "Bancos"),
    "111005": stryMutAct_9fa48("2980") ? "" : (stryCov_9fa48("2980"), "Moneda nacional"),
    "1120": stryMutAct_9fa48("2981") ? "" : (stryCov_9fa48("2981"), "Cuentas de ahorro"),
    "112005": stryMutAct_9fa48("2982") ? "" : (stryCov_9fa48("2982"), "Bancos"),
    "12": stryMutAct_9fa48("2983") ? "" : (stryCov_9fa48("2983"), "Inversiones"),
    "1225": stryMutAct_9fa48("2984") ? "" : (stryCov_9fa48("2984"), "Certificados"),
    "1245": stryMutAct_9fa48("2985") ? "" : (stryCov_9fa48("2985"), "Derechos fiduciarios"),
    "13": stryMutAct_9fa48("2986") ? "" : (stryCov_9fa48("2986"), "Deudores"),
    "1330": stryMutAct_9fa48("2987") ? "" : (stryCov_9fa48("2987"), "Anticipos y avances"),
    "1345": stryMutAct_9fa48("2988") ? "" : (stryCov_9fa48("2988"), "Ingresos por cobrar"),
    "1370": stryMutAct_9fa48("2989") ? "" : (stryCov_9fa48("2989"), "Préstamos a particulares"),
    "1380": stryMutAct_9fa48("2990") ? "" : (stryCov_9fa48("2990"), "Deudores varios"),
    "15": stryMutAct_9fa48("2991") ? "" : (stryCov_9fa48("2991"), "Propiedades, planta y equipo"),
    "1504": stryMutAct_9fa48("2992") ? "" : (stryCov_9fa48("2992"), "Terrenos"),
    "1516": stryMutAct_9fa48("2993") ? "" : (stryCov_9fa48("2993"), "Construcciones y edificaciones"),
    "1524": stryMutAct_9fa48("2994") ? "" : (stryCov_9fa48("2994"), "Equipo de oficina"),
    "1528": stryMutAct_9fa48("2995") ? "" : (stryCov_9fa48("2995"), "Equipo de computación y comunicación"),
    "1540": stryMutAct_9fa48("2996") ? "" : (stryCov_9fa48("2996"), "Flota y equipo de transporte"),
    "1592": stryMutAct_9fa48("2997") ? "" : (stryCov_9fa48("2997"), "Depreciación acumulada"),
    "17": stryMutAct_9fa48("2998") ? "" : (stryCov_9fa48("2998"), "Diferidos"),
    "1705": stryMutAct_9fa48("2999") ? "" : (stryCov_9fa48("2999"), "Gastos pagados por anticipado"),
    "2": stryMutAct_9fa48("3000") ? "" : (stryCov_9fa48("3000"), "Pasivo"),
    "21": stryMutAct_9fa48("3001") ? "" : (stryCov_9fa48("3001"), "Obligaciones financieras"),
    "2105": stryMutAct_9fa48("3002") ? "" : (stryCov_9fa48("3002"), "Bancos nacionales"),
    "210510": stryMutAct_9fa48("3003") ? "" : (stryCov_9fa48("3003"), "Pagarés"),
    "2195": stryMutAct_9fa48("3004") ? "" : (stryCov_9fa48("3004"), "Otras obligaciones"),
    "23": stryMutAct_9fa48("3005") ? "" : (stryCov_9fa48("3005"), "Cuentas por pagar"),
    "2335": stryMutAct_9fa48("3006") ? "" : (stryCov_9fa48("3006"), "Costos y gastos por pagar"),
    "2380": stryMutAct_9fa48("3007") ? "" : (stryCov_9fa48("3007"), "Acreedores varios"),
    "24": stryMutAct_9fa48("3008") ? "" : (stryCov_9fa48("3008"), "Impuestos, gravámenes y tasas"),
    "2404": stryMutAct_9fa48("3009") ? "" : (stryCov_9fa48("3009"), "De renta y complementarios"),
    "27": stryMutAct_9fa48("3010") ? "" : (stryCov_9fa48("3010"), "Diferidos"),
    "2705": stryMutAct_9fa48("3011") ? "" : (stryCov_9fa48("3011"), "Ingresos recibidos por anticipado"),
    "28": stryMutAct_9fa48("3012") ? "" : (stryCov_9fa48("3012"), "Otros pasivos"),
    "2805": stryMutAct_9fa48("3013") ? "" : (stryCov_9fa48("3013"), "Anticipos y avances recibidos"),
    "2810": stryMutAct_9fa48("3014") ? "" : (stryCov_9fa48("3014"), "Depósitos recibidos"),
    "3": stryMutAct_9fa48("3015") ? "" : (stryCov_9fa48("3015"), "Patrimonio"),
    "31": stryMutAct_9fa48("3016") ? "" : (stryCov_9fa48("3016"), "Capital social"),
    "3130": stryMutAct_9fa48("3017") ? "" : (stryCov_9fa48("3017"), "Capital de personas naturales"),
    "4": stryMutAct_9fa48("3018") ? "" : (stryCov_9fa48("3018"), "Ingresos"),
    "42": stryMutAct_9fa48("3019") ? "" : (stryCov_9fa48("3019"), "No operacionales"),
    "4210": stryMutAct_9fa48("3020") ? "" : (stryCov_9fa48("3020"), "Financieros"),
    "4215": stryMutAct_9fa48("3021") ? "" : (stryCov_9fa48("3021"), "Dividendos y participaciones"),
    "4220": stryMutAct_9fa48("3022") ? "" : (stryCov_9fa48("3022"), "Arrendamientos"),
    "422010": stryMutAct_9fa48("3023") ? "" : (stryCov_9fa48("3023"), "Construcciones y edificios"),
    "4230": stryMutAct_9fa48("3024") ? "" : (stryCov_9fa48("3024"), "Honorarios"),
    "4240": stryMutAct_9fa48("3025") ? "" : (stryCov_9fa48("3025"), "Utilidad en venta de inversiones"),
    "4295": stryMutAct_9fa48("3026") ? "" : (stryCov_9fa48("3026"), "Diversos"),
    "429595": stryMutAct_9fa48("3027") ? "" : (stryCov_9fa48("3027"), "Otros"),
    "5": stryMutAct_9fa48("3028") ? "" : (stryCov_9fa48("3028"), "Gastos"),
    "51": stryMutAct_9fa48("3029") ? "" : (stryCov_9fa48("3029"), "Operacionales de administración"),
    "5110": stryMutAct_9fa48("3030") ? "" : (stryCov_9fa48("3030"), "Honorarios"),
    "5115": stryMutAct_9fa48("3031") ? "" : (stryCov_9fa48("3031"), "Impuestos"),
    "511595": stryMutAct_9fa48("3032") ? "" : (stryCov_9fa48("3032"), "Otros"),
    "5120": stryMutAct_9fa48("3033") ? "" : (stryCov_9fa48("3033"), "Arrendamientos"),
    "5130": stryMutAct_9fa48("3034") ? "" : (stryCov_9fa48("3034"), "Seguros"),
    "5135": stryMutAct_9fa48("3035") ? "" : (stryCov_9fa48("3035"), "Servicios"),
    "513595": stryMutAct_9fa48("3036") ? "" : (stryCov_9fa48("3036"), "Otros"),
    "5145": stryMutAct_9fa48("3037") ? "" : (stryCov_9fa48("3037"), "Mantenimiento y reparaciones"),
    "5155": stryMutAct_9fa48("3038") ? "" : (stryCov_9fa48("3038"), "Gastos de viaje"),
    "5160": stryMutAct_9fa48("3039") ? "" : (stryCov_9fa48("3039"), "Depreciaciones"),
    "5195": stryMutAct_9fa48("3040") ? "" : (stryCov_9fa48("3040"), "Diversos"),
    "519595": stryMutAct_9fa48("3041") ? "" : (stryCov_9fa48("3041"), "Otros"),
    "53": stryMutAct_9fa48("3042") ? "" : (stryCov_9fa48("3042"), "No operacionales"),
    "5305": stryMutAct_9fa48("3043") ? "" : (stryCov_9fa48("3043"), "Financieros"),
    "5310": stryMutAct_9fa48("3044") ? "" : (stryCov_9fa48("3044"), "Pérdida en venta y retiro de bienes"),
    "5395": stryMutAct_9fa48("3045") ? "" : (stryCov_9fa48("3045"), "Gastos diversos"),
    "54": stryMutAct_9fa48("3046") ? "" : (stryCov_9fa48("3046"), "Impuesto de renta y complementarios"),
    "5405": stryMutAct_9fa48("3047") ? "" : (stryCov_9fa48("3047"), "Impuesto de renta y complementarios")
  })
})) satisfies ChartOfAccountsTemplate;