/*
 * COA Template for an English-language Personal Workspace, mirroring co-puc-personal@1.
 * US GAAP prescribes no chart of accounts, so codes are application-owned: the first
 * digit is the class, the second the group. Reporting concepts cite the FASB US GAAP
 * Taxonomy 2026 (https://xbrl.fasb.org/us-gaap/2026/elts/us-gaap-2026.xsd) only where an
 * element fits; personal concepts such as salary received or groceries have none,
 * because the taxonomy describes a reporting entity, not a household.
 * Cohesive data file: one template, one version; see ADR-0083.
 */
// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import type { ChartOfAccountsTemplate } from "../types";
export const usGaapPersonalTemplate = (stryMutAct_9fa48("3048") ? {} : (stryCov_9fa48("3048"), {
  version: stryMutAct_9fa48("3049") ? "" : (stryCov_9fa48("3049"), "us-gaap-personal@1"),
  applicableWorkspaceKinds: stryMutAct_9fa48("3050") ? [] : (stryCov_9fa48("3050"), [stryMutAct_9fa48("3051") ? "" : (stryCov_9fa48("3051"), "Personal"), stryMutAct_9fa48("3052") ? "" : (stryCov_9fa48("3052"), "Household")]),
  natureByClass: stryMutAct_9fa48("3053") ? {} : (stryCov_9fa48("3053"), {
    "1": stryMutAct_9fa48("3054") ? "" : (stryCov_9fa48("3054"), "Asset"),
    "2": stryMutAct_9fa48("3055") ? "" : (stryCov_9fa48("3055"), "Liability"),
    "3": stryMutAct_9fa48("3056") ? "" : (stryCov_9fa48("3056"), "Equity"),
    "4": stryMutAct_9fa48("3057") ? "" : (stryCov_9fa48("3057"), "Revenue"),
    "5": stryMutAct_9fa48("3058") ? "" : (stryCov_9fa48("3058"), "Expense"),
    "6": stryMutAct_9fa48("3059") ? "" : (stryCov_9fa48("3059"), "Expense")
  }),
  defaults: stryMutAct_9fa48("3060") ? {} : (stryCov_9fa48("3060"), {
    expense: stryMutAct_9fa48("3061") ? "" : (stryCov_9fa48("3061"), "5599"),
    income: stryMutAct_9fa48("3062") ? "" : (stryCov_9fa48("3062"), "4990"),
    openingBalance: stryMutAct_9fa48("3063") ? "" : (stryCov_9fa48("3063"), "3010")
  }),
  financialAccountParents: stryMutAct_9fa48("3064") ? {} : (stryCov_9fa48("3064"), {
    cash: stryMutAct_9fa48("3065") ? "" : (stryCov_9fa48("3065"), "1010"),
    bankAccount: stryMutAct_9fa48("3066") ? "" : (stryCov_9fa48("3066"), "1020"),
    savingsAccount: stryMutAct_9fa48("3067") ? "" : (stryCov_9fa48("3067"), "1030"),
    creditCard: stryMutAct_9fa48("3068") ? "" : (stryCov_9fa48("3068"), "2010"),
    loan: stryMutAct_9fa48("3069") ? "" : (stryCov_9fa48("3069"), "2110"),
    securedReceivable: stryMutAct_9fa48("3070") ? "" : (stryCov_9fa48("3070"), "1250"),
    unsecuredReceivable: stryMutAct_9fa48("3071") ? "" : (stryCov_9fa48("3071"), "1260"),
    termDeposit: stryMutAct_9fa48("3072") ? "" : (stryCov_9fa48("3072"), "1110"),
    investmentFund: stryMutAct_9fa48("3073") ? "" : (stryCov_9fa48("3073"), "1120"),
    personalDebt: stryMutAct_9fa48("3074") ? "" : (stryCov_9fa48("3074"), "2120")
  }),
  accounts: stryMutAct_9fa48("3075") ? [] : (stryCov_9fa48("3075"), [// 1 Assets
  stryMutAct_9fa48("3076") ? {} : (stryCov_9fa48("3076"), {
    code: stryMutAct_9fa48("3077") ? "" : (stryCov_9fa48("3077"), "1110"),
    name: stryMutAct_9fa48("3078") ? "" : (stryCov_9fa48("3078"), "Certificates of deposit"),
    use: stryMutAct_9fa48("3079") ? "" : (stryCov_9fa48("3079"), "general"),
    reportingConcept: stryMutAct_9fa48("3080") ? "" : (stryCov_9fa48("3080"), "us-gaap:CertificatesOfDepositAtCarryingValue")
  }), stryMutAct_9fa48("3081") ? {} : (stryCov_9fa48("3081"), {
    code: stryMutAct_9fa48("3082") ? "" : (stryCov_9fa48("3082"), "1120"),
    name: stryMutAct_9fa48("3083") ? "" : (stryCov_9fa48("3083"), "Investment fund units"),
    use: stryMutAct_9fa48("3084") ? "" : (stryCov_9fa48("3084"), "general"),
    reportingConcept: stryMutAct_9fa48("3085") ? "" : (stryCov_9fa48("3085"), "us-gaap:EquitySecuritiesFvNi")
  }), stryMutAct_9fa48("3086") ? {} : (stryCov_9fa48("3086"), {
    code: stryMutAct_9fa48("3087") ? "" : (stryCov_9fa48("3087"), "1210"),
    name: stryMutAct_9fa48("3088") ? "" : (stryCov_9fa48("3088"), "Advances to suppliers"),
    use: stryMutAct_9fa48("3089") ? "" : (stryCov_9fa48("3089"), "general")
  }), stryMutAct_9fa48("3090") ? {} : (stryCov_9fa48("3090"), {
    code: stryMutAct_9fa48("3091") ? "" : (stryCov_9fa48("3091"), "1220"),
    name: stryMutAct_9fa48("3092") ? "" : (stryCov_9fa48("3092"), "Dividends receivable"),
    use: stryMutAct_9fa48("3093") ? "" : (stryCov_9fa48("3093"), "general"),
    reportingConcept: stryMutAct_9fa48("3094") ? "" : (stryCov_9fa48("3094"), "us-gaap:DividendsReceivable")
  }), stryMutAct_9fa48("3095") ? {} : (stryCov_9fa48("3095"), {
    code: stryMutAct_9fa48("3096") ? "" : (stryCov_9fa48("3096"), "1230"),
    name: stryMutAct_9fa48("3097") ? "" : (stryCov_9fa48("3097"), "Interest receivable"),
    use: stryMutAct_9fa48("3098") ? "" : (stryCov_9fa48("3098"), "general"),
    reportingConcept: stryMutAct_9fa48("3099") ? "" : (stryCov_9fa48("3099"), "us-gaap:InterestReceivable")
  }), stryMutAct_9fa48("3100") ? {} : (stryCov_9fa48("3100"), {
    code: stryMutAct_9fa48("3101") ? "" : (stryCov_9fa48("3101"), "1240"),
    name: stryMutAct_9fa48("3102") ? "" : (stryCov_9fa48("3102"), "Rent receivable"),
    use: stryMutAct_9fa48("3103") ? "" : (stryCov_9fa48("3103"), "general")
  }), stryMutAct_9fa48("3104") ? {} : (stryCov_9fa48("3104"), {
    code: stryMutAct_9fa48("3105") ? "" : (stryCov_9fa48("3105"), "1250"),
    name: stryMutAct_9fa48("3106") ? "" : (stryCov_9fa48("3106"), "Loans to individuals, secured"),
    use: stryMutAct_9fa48("3107") ? "" : (stryCov_9fa48("3107"), "general"),
    reportingConcept: stryMutAct_9fa48("3108") ? "" : (stryCov_9fa48("3108"), "us-gaap:NotesReceivableGross")
  }), stryMutAct_9fa48("3109") ? {} : (stryCov_9fa48("3109"), {
    code: stryMutAct_9fa48("3110") ? "" : (stryCov_9fa48("3110"), "1260"),
    name: stryMutAct_9fa48("3111") ? "" : (stryCov_9fa48("3111"), "Loans to individuals, unsecured"),
    use: stryMutAct_9fa48("3112") ? "" : (stryCov_9fa48("3112"), "general"),
    reportingConcept: stryMutAct_9fa48("3113") ? "" : (stryCov_9fa48("3113"), "us-gaap:NotesReceivableGross")
  }), stryMutAct_9fa48("3114") ? {} : (stryCov_9fa48("3114"), {
    code: stryMutAct_9fa48("3115") ? "" : (stryCov_9fa48("3115"), "1270"),
    name: stryMutAct_9fa48("3116") ? "" : (stryCov_9fa48("3116"), "Payments made on behalf of others"),
    use: stryMutAct_9fa48("3117") ? "" : (stryCov_9fa48("3117"), "general"),
    reportingConcept: stryMutAct_9fa48("3118") ? "" : (stryCov_9fa48("3118"), "us-gaap:OtherReceivables")
  }), stryMutAct_9fa48("3119") ? {} : (stryCov_9fa48("3119"), {
    code: stryMutAct_9fa48("3120") ? "" : (stryCov_9fa48("3120"), "1310"),
    name: stryMutAct_9fa48("3121") ? "" : (stryCov_9fa48("3121"), "Prepaid insurance"),
    use: stryMutAct_9fa48("3122") ? "" : (stryCov_9fa48("3122"), "general"),
    reportingConcept: stryMutAct_9fa48("3123") ? "" : (stryCov_9fa48("3123"), "us-gaap:PrepaidInsurance")
  }), stryMutAct_9fa48("3124") ? {} : (stryCov_9fa48("3124"), {
    code: stryMutAct_9fa48("3125") ? "" : (stryCov_9fa48("3125"), "1320"),
    name: stryMutAct_9fa48("3126") ? "" : (stryCov_9fa48("3126"), "Prepaid subscriptions"),
    use: stryMutAct_9fa48("3127") ? "" : (stryCov_9fa48("3127"), "general"),
    reportingConcept: stryMutAct_9fa48("3128") ? "" : (stryCov_9fa48("3128"), "us-gaap:OtherPrepaidExpenseCurrent")
  }), stryMutAct_9fa48("3129") ? {} : (stryCov_9fa48("3129"), {
    code: stryMutAct_9fa48("3130") ? "" : (stryCov_9fa48("3130"), "1510"),
    name: stryMutAct_9fa48("3131") ? "" : (stryCov_9fa48("3131"), "Land"),
    use: stryMutAct_9fa48("3132") ? "" : (stryCov_9fa48("3132"), "general"),
    reportingConcept: stryMutAct_9fa48("3133") ? "" : (stryCov_9fa48("3133"), "us-gaap:Land")
  }), stryMutAct_9fa48("3134") ? {} : (stryCov_9fa48("3134"), {
    code: stryMutAct_9fa48("3135") ? "" : (stryCov_9fa48("3135"), "1520"),
    name: stryMutAct_9fa48("3136") ? "" : (stryCov_9fa48("3136"), "Buildings"),
    use: stryMutAct_9fa48("3137") ? "" : (stryCov_9fa48("3137"), "general"),
    reportingConcept: stryMutAct_9fa48("3138") ? "" : (stryCov_9fa48("3138"), "us-gaap:BuildingsAndImprovementsGross")
  }), stryMutAct_9fa48("3139") ? {} : (stryCov_9fa48("3139"), {
    code: stryMutAct_9fa48("3140") ? "" : (stryCov_9fa48("3140"), "1530"),
    name: stryMutAct_9fa48("3141") ? "" : (stryCov_9fa48("3141"), "Furniture and fixtures"),
    use: stryMutAct_9fa48("3142") ? "" : (stryCov_9fa48("3142"), "general"),
    reportingConcept: stryMutAct_9fa48("3143") ? "" : (stryCov_9fa48("3143"), "us-gaap:FurnitureAndFixturesGross")
  }), stryMutAct_9fa48("3144") ? {} : (stryCov_9fa48("3144"), {
    code: stryMutAct_9fa48("3145") ? "" : (stryCov_9fa48("3145"), "1540"),
    name: stryMutAct_9fa48("3146") ? "" : (stryCov_9fa48("3146"), "Computer equipment"),
    use: stryMutAct_9fa48("3147") ? "" : (stryCov_9fa48("3147"), "general"),
    reportingConcept: stryMutAct_9fa48("3148") ? "" : (stryCov_9fa48("3148"), "us-gaap:PropertyPlantAndEquipmentGross")
  }), stryMutAct_9fa48("3149") ? {} : (stryCov_9fa48("3149"), {
    code: stryMutAct_9fa48("3150") ? "" : (stryCov_9fa48("3150"), "1550"),
    name: stryMutAct_9fa48("3151") ? "" : (stryCov_9fa48("3151"), "Vehicles"),
    use: stryMutAct_9fa48("3152") ? "" : (stryCov_9fa48("3152"), "general"),
    reportingConcept: stryMutAct_9fa48("3153") ? "" : (stryCov_9fa48("3153"), "us-gaap:PropertyPlantAndEquipmentGross")
  }), stryMutAct_9fa48("3154") ? {} : (stryCov_9fa48("3154"), {
    code: stryMutAct_9fa48("3155") ? "" : (stryCov_9fa48("3155"), "1560"),
    name: stryMutAct_9fa48("3156") ? "" : (stryCov_9fa48("3156"), "Motorcycles"),
    use: stryMutAct_9fa48("3157") ? "" : (stryCov_9fa48("3157"), "general"),
    reportingConcept: stryMutAct_9fa48("3158") ? "" : (stryCov_9fa48("3158"), "us-gaap:PropertyPlantAndEquipmentGross")
  }), stryMutAct_9fa48("3159") ? {} : (stryCov_9fa48("3159"), {
    code: stryMutAct_9fa48("3160") ? "" : (stryCov_9fa48("3160"), "1591"),
    name: stryMutAct_9fa48("3161") ? "" : (stryCov_9fa48("3161"), "Accumulated depreciation, buildings"),
    use: stryMutAct_9fa48("3162") ? "" : (stryCov_9fa48("3162"), "general"),
    normalSide: stryMutAct_9fa48("3163") ? "" : (stryCov_9fa48("3163"), "Credit"),
    reportingConcept: stryMutAct_9fa48("3164") ? "" : (stryCov_9fa48("3164"), "us-gaap:AccumulatedDepreciationDepletionAndAmortizationPropertyPlantAndEquipment")
  }), stryMutAct_9fa48("3165") ? {} : (stryCov_9fa48("3165"), {
    code: stryMutAct_9fa48("3166") ? "" : (stryCov_9fa48("3166"), "1592"),
    name: stryMutAct_9fa48("3167") ? "" : (stryCov_9fa48("3167"), "Accumulated depreciation, furniture and fixtures"),
    use: stryMutAct_9fa48("3168") ? "" : (stryCov_9fa48("3168"), "general"),
    normalSide: stryMutAct_9fa48("3169") ? "" : (stryCov_9fa48("3169"), "Credit"),
    reportingConcept: stryMutAct_9fa48("3170") ? "" : (stryCov_9fa48("3170"), "us-gaap:AccumulatedDepreciationDepletionAndAmortizationPropertyPlantAndEquipment")
  }), stryMutAct_9fa48("3171") ? {} : (stryCov_9fa48("3171"), {
    code: stryMutAct_9fa48("3172") ? "" : (stryCov_9fa48("3172"), "1593"),
    name: stryMutAct_9fa48("3173") ? "" : (stryCov_9fa48("3173"), "Accumulated depreciation, computer equipment"),
    use: stryMutAct_9fa48("3174") ? "" : (stryCov_9fa48("3174"), "general"),
    normalSide: stryMutAct_9fa48("3175") ? "" : (stryCov_9fa48("3175"), "Credit"),
    reportingConcept: stryMutAct_9fa48("3176") ? "" : (stryCov_9fa48("3176"), "us-gaap:AccumulatedDepreciationDepletionAndAmortizationPropertyPlantAndEquipment")
  }), stryMutAct_9fa48("3177") ? {} : (stryCov_9fa48("3177"), {
    code: stryMutAct_9fa48("3178") ? "" : (stryCov_9fa48("3178"), "1594"),
    name: stryMutAct_9fa48("3179") ? "" : (stryCov_9fa48("3179"), "Accumulated depreciation, vehicles"),
    use: stryMutAct_9fa48("3180") ? "" : (stryCov_9fa48("3180"), "general"),
    normalSide: stryMutAct_9fa48("3181") ? "" : (stryCov_9fa48("3181"), "Credit"),
    reportingConcept: stryMutAct_9fa48("3182") ? "" : (stryCov_9fa48("3182"), "us-gaap:AccumulatedDepreciationDepletionAndAmortizationPropertyPlantAndEquipment")
  }), // 2 Liabilities
  stryMutAct_9fa48("3183") ? {} : (stryCov_9fa48("3183"), {
    code: stryMutAct_9fa48("3184") ? "" : (stryCov_9fa48("3184"), "2120"),
    name: stryMutAct_9fa48("3185") ? "" : (stryCov_9fa48("3185"), "Loans from individuals"),
    use: stryMutAct_9fa48("3186") ? "" : (stryCov_9fa48("3186"), "general"),
    reportingConcept: stryMutAct_9fa48("3187") ? "" : (stryCov_9fa48("3187"), "us-gaap:OtherNotesPayable")
  }), stryMutAct_9fa48("3188") ? {} : (stryCov_9fa48("3188"), {
    code: stryMutAct_9fa48("3189") ? "" : (stryCov_9fa48("3189"), "2210"),
    name: stryMutAct_9fa48("3190") ? "" : (stryCov_9fa48("3190"), "Accrued expenses"),
    use: stryMutAct_9fa48("3191") ? "" : (stryCov_9fa48("3191"), "general"),
    reportingConcept: stryMutAct_9fa48("3192") ? "" : (stryCov_9fa48("3192"), "us-gaap:AccruedLiabilitiesCurrent")
  }), stryMutAct_9fa48("3193") ? {} : (stryCov_9fa48("3193"), {
    code: stryMutAct_9fa48("3194") ? "" : (stryCov_9fa48("3194"), "2220"),
    name: stryMutAct_9fa48("3195") ? "" : (stryCov_9fa48("3195"), "Reimbursements payable"),
    use: stryMutAct_9fa48("3196") ? "" : (stryCov_9fa48("3196"), "general"),
    reportingConcept: stryMutAct_9fa48("3197") ? "" : (stryCov_9fa48("3197"), "us-gaap:AccountsPayableOtherCurrent")
  }), stryMutAct_9fa48("3198") ? {} : (stryCov_9fa48("3198"), {
    code: stryMutAct_9fa48("3199") ? "" : (stryCov_9fa48("3199"), "2230"),
    name: stryMutAct_9fa48("3200") ? "" : (stryCov_9fa48("3200"), "Income taxes payable"),
    use: stryMutAct_9fa48("3201") ? "" : (stryCov_9fa48("3201"), "general"),
    reportingConcept: stryMutAct_9fa48("3202") ? "" : (stryCov_9fa48("3202"), "us-gaap:AccruedIncomeTaxesCurrent")
  }), stryMutAct_9fa48("3203") ? {} : (stryCov_9fa48("3203"), {
    code: stryMutAct_9fa48("3204") ? "" : (stryCov_9fa48("3204"), "2310"),
    name: stryMutAct_9fa48("3205") ? "" : (stryCov_9fa48("3205"), "Rent received in advance"),
    use: stryMutAct_9fa48("3206") ? "" : (stryCov_9fa48("3206"), "general"),
    reportingConcept: stryMutAct_9fa48("3207") ? "" : (stryCov_9fa48("3207"), "us-gaap:DeferredRevenueCurrent")
  }), stryMutAct_9fa48("3208") ? {} : (stryCov_9fa48("3208"), {
    code: stryMutAct_9fa48("3209") ? "" : (stryCov_9fa48("3209"), "2320"),
    name: stryMutAct_9fa48("3210") ? "" : (stryCov_9fa48("3210"), "Customer advances"),
    use: stryMutAct_9fa48("3211") ? "" : (stryCov_9fa48("3211"), "general"),
    reportingConcept: stryMutAct_9fa48("3212") ? "" : (stryCov_9fa48("3212"), "us-gaap:ContractWithCustomerLiabilityCurrent")
  }), stryMutAct_9fa48("3213") ? {} : (stryCov_9fa48("3213"), {
    code: stryMutAct_9fa48("3214") ? "" : (stryCov_9fa48("3214"), "2330"),
    name: stryMutAct_9fa48("3215") ? "" : (stryCov_9fa48("3215"), "Security deposits received"),
    use: stryMutAct_9fa48("3216") ? "" : (stryCov_9fa48("3216"), "general"),
    reportingConcept: stryMutAct_9fa48("3217") ? "" : (stryCov_9fa48("3217"), "us-gaap:SecurityDepositLiability")
  }), // 3 Net worth
  stryMutAct_9fa48("3218") ? {} : (stryCov_9fa48("3218"), {
    code: stryMutAct_9fa48("3219") ? "" : (stryCov_9fa48("3219"), "3010"),
    name: stryMutAct_9fa48("3220") ? "" : (stryCov_9fa48("3220"), "Opening balance equity"),
    use: stryMutAct_9fa48("3221") ? "" : (stryCov_9fa48("3221"), "openingBalance")
  }), // 4 Revenue
  stryMutAct_9fa48("3222") ? {} : (stryCov_9fa48("3222"), {
    code: stryMutAct_9fa48("3223") ? "" : (stryCov_9fa48("3223"), "4010"),
    name: stryMutAct_9fa48("3224") ? "" : (stryCov_9fa48("3224"), "Salary and wages"),
    use: stryMutAct_9fa48("3225") ? "" : (stryCov_9fa48("3225"), "income")
  }), stryMutAct_9fa48("3226") ? {} : (stryCov_9fa48("3226"), {
    code: stryMutAct_9fa48("3227") ? "" : (stryCov_9fa48("3227"), "4020"),
    name: stryMutAct_9fa48("3228") ? "" : (stryCov_9fa48("3228"), "Bonuses"),
    use: stryMutAct_9fa48("3229") ? "" : (stryCov_9fa48("3229"), "income")
  }), stryMutAct_9fa48("3230") ? {} : (stryCov_9fa48("3230"), {
    code: stryMutAct_9fa48("3231") ? "" : (stryCov_9fa48("3231"), "4030"),
    name: stryMutAct_9fa48("3232") ? "" : (stryCov_9fa48("3232"), "Consulting fees"),
    use: stryMutAct_9fa48("3233") ? "" : (stryCov_9fa48("3233"), "income"),
    reportingConcept: stryMutAct_9fa48("3234") ? "" : (stryCov_9fa48("3234"), "us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax")
  }), stryMutAct_9fa48("3235") ? {} : (stryCov_9fa48("3235"), {
    code: stryMutAct_9fa48("3236") ? "" : (stryCov_9fa48("3236"), "4110"),
    name: stryMutAct_9fa48("3237") ? "" : (stryCov_9fa48("3237"), "Interest income"),
    use: stryMutAct_9fa48("3238") ? "" : (stryCov_9fa48("3238"), "income"),
    reportingConcept: stryMutAct_9fa48("3239") ? "" : (stryCov_9fa48("3239"), "us-gaap:InvestmentIncomeInterest")
  }), stryMutAct_9fa48("3240") ? {} : (stryCov_9fa48("3240"), {
    code: stryMutAct_9fa48("3241") ? "" : (stryCov_9fa48("3241"), "4120"),
    name: stryMutAct_9fa48("3242") ? "" : (stryCov_9fa48("3242"), "Dividend income"),
    use: stryMutAct_9fa48("3243") ? "" : (stryCov_9fa48("3243"), "income"),
    reportingConcept: stryMutAct_9fa48("3244") ? "" : (stryCov_9fa48("3244"), "us-gaap:InvestmentIncomeDividend")
  }), stryMutAct_9fa48("3245") ? {} : (stryCov_9fa48("3245"), {
    code: stryMutAct_9fa48("3246") ? "" : (stryCov_9fa48("3246"), "4130"),
    name: stryMutAct_9fa48("3247") ? "" : (stryCov_9fa48("3247"), "Gain on sale of investments"),
    use: stryMutAct_9fa48("3248") ? "" : (stryCov_9fa48("3248"), "general"),
    reportingConcept: stryMutAct_9fa48("3249") ? "" : (stryCov_9fa48("3249"), "us-gaap:GainLossOnInvestments")
  }), stryMutAct_9fa48("3250") ? {} : (stryCov_9fa48("3250"), {
    code: stryMutAct_9fa48("3251") ? "" : (stryCov_9fa48("3251"), "4140"),
    name: stryMutAct_9fa48("3252") ? "" : (stryCov_9fa48("3252"), "Foreign exchange gains"),
    use: stryMutAct_9fa48("3253") ? "" : (stryCov_9fa48("3253"), "general"),
    reportingConcept: stryMutAct_9fa48("3254") ? "" : (stryCov_9fa48("3254"), "us-gaap:ForeignCurrencyTransactionGainBeforeTax")
  }), stryMutAct_9fa48("3255") ? {} : (stryCov_9fa48("3255"), {
    code: stryMutAct_9fa48("3256") ? "" : (stryCov_9fa48("3256"), "4210"),
    name: stryMutAct_9fa48("3257") ? "" : (stryCov_9fa48("3257"), "Long-term rental income"),
    use: stryMutAct_9fa48("3258") ? "" : (stryCov_9fa48("3258"), "income"),
    reportingConcept: stryMutAct_9fa48("3259") ? "" : (stryCov_9fa48("3259"), "us-gaap:RentalIncomeNonoperating")
  }), stryMutAct_9fa48("3260") ? {} : (stryCov_9fa48("3260"), {
    code: stryMutAct_9fa48("3261") ? "" : (stryCov_9fa48("3261"), "4220"),
    name: stryMutAct_9fa48("3262") ? "" : (stryCov_9fa48("3262"), "Short-stay accommodation income"),
    use: stryMutAct_9fa48("3263") ? "" : (stryCov_9fa48("3263"), "income"),
    reportingConcept: stryMutAct_9fa48("3264") ? "" : (stryCov_9fa48("3264"), "us-gaap:OccupancyNet")
  }), stryMutAct_9fa48("3265") ? {} : (stryCov_9fa48("3265"), {
    code: stryMutAct_9fa48("3266") ? "" : (stryCov_9fa48("3266"), "4910"),
    name: stryMutAct_9fa48("3267") ? "" : (stryCov_9fa48("3267"), "Prizes"),
    use: stryMutAct_9fa48("3268") ? "" : (stryCov_9fa48("3268"), "income"),
    reportingConcept: stryMutAct_9fa48("3269") ? "" : (stryCov_9fa48("3269"), "us-gaap:OtherNonoperatingIncome")
  }), stryMutAct_9fa48("3270") ? {} : (stryCov_9fa48("3270"), {
    code: stryMutAct_9fa48("3271") ? "" : (stryCov_9fa48("3271"), "4920"),
    name: stryMutAct_9fa48("3272") ? "" : (stryCov_9fa48("3272"), "Gifts and support received"),
    use: stryMutAct_9fa48("3273") ? "" : (stryCov_9fa48("3273"), "income")
  }), stryMutAct_9fa48("3274") ? {} : (stryCov_9fa48("3274"), {
    code: stryMutAct_9fa48("3275") ? "" : (stryCov_9fa48("3275"), "4990"),
    name: stryMutAct_9fa48("3276") ? "" : (stryCov_9fa48("3276"), "Other income"),
    use: stryMutAct_9fa48("3277") ? "" : (stryCov_9fa48("3277"), "income"),
    reportingConcept: stryMutAct_9fa48("3278") ? "" : (stryCov_9fa48("3278"), "us-gaap:OtherNonoperatingIncome")
  }), // 5 Living expenses
  stryMutAct_9fa48("3279") ? {} : (stryCov_9fa48("3279"), {
    code: stryMutAct_9fa48("3280") ? "" : (stryCov_9fa48("3280"), "5010"),
    name: stryMutAct_9fa48("3281") ? "" : (stryCov_9fa48("3281"), "Rent"),
    use: stryMutAct_9fa48("3282") ? "" : (stryCov_9fa48("3282"), "expense"),
    reportingConcept: stryMutAct_9fa48("3283") ? "" : (stryCov_9fa48("3283"), "us-gaap:OperatingLeaseCost")
  }), stryMutAct_9fa48("3284") ? {} : (stryCov_9fa48("3284"), {
    code: stryMutAct_9fa48("3285") ? "" : (stryCov_9fa48("3285"), "5020"),
    name: stryMutAct_9fa48("3286") ? "" : (stryCov_9fa48("3286"), "Home repairs and maintenance"),
    use: stryMutAct_9fa48("3287") ? "" : (stryCov_9fa48("3287"), "expense"),
    reportingConcept: stryMutAct_9fa48("3288") ? "" : (stryCov_9fa48("3288"), "us-gaap:CostOfPropertyRepairsAndMaintenance")
  }), stryMutAct_9fa48("3289") ? {} : (stryCov_9fa48("3289"), {
    code: stryMutAct_9fa48("3290") ? "" : (stryCov_9fa48("3290"), "5030"),
    name: stryMutAct_9fa48("3291") ? "" : (stryCov_9fa48("3291"), "Property tax"),
    use: stryMutAct_9fa48("3292") ? "" : (stryCov_9fa48("3292"), "expense"),
    reportingConcept: stryMutAct_9fa48("3293") ? "" : (stryCov_9fa48("3293"), "us-gaap:RealEstateTaxExpense")
  }), stryMutAct_9fa48("3294") ? {} : (stryCov_9fa48("3294"), {
    code: stryMutAct_9fa48("3295") ? "" : (stryCov_9fa48("3295"), "5040"),
    name: stryMutAct_9fa48("3296") ? "" : (stryCov_9fa48("3296"), "Cleaning and security services"),
    use: stryMutAct_9fa48("3297") ? "" : (stryCov_9fa48("3297"), "expense")
  }), stryMutAct_9fa48("3298") ? {} : (stryCov_9fa48("3298"), {
    code: stryMutAct_9fa48("3299") ? "" : (stryCov_9fa48("3299"), "5110"),
    name: stryMutAct_9fa48("3300") ? "" : (stryCov_9fa48("3300"), "Water and sewer"),
    use: stryMutAct_9fa48("3301") ? "" : (stryCov_9fa48("3301"), "expense")
  }), stryMutAct_9fa48("3302") ? {} : (stryCov_9fa48("3302"), {
    code: stryMutAct_9fa48("3303") ? "" : (stryCov_9fa48("3303"), "5120"),
    name: stryMutAct_9fa48("3304") ? "" : (stryCov_9fa48("3304"), "Electricity"),
    use: stryMutAct_9fa48("3305") ? "" : (stryCov_9fa48("3305"), "expense")
  }), stryMutAct_9fa48("3306") ? {} : (stryCov_9fa48("3306"), {
    code: stryMutAct_9fa48("3307") ? "" : (stryCov_9fa48("3307"), "5130"),
    name: stryMutAct_9fa48("3308") ? "" : (stryCov_9fa48("3308"), "Gas"),
    use: stryMutAct_9fa48("3309") ? "" : (stryCov_9fa48("3309"), "expense")
  }), stryMutAct_9fa48("3310") ? {} : (stryCov_9fa48("3310"), {
    code: stryMutAct_9fa48("3311") ? "" : (stryCov_9fa48("3311"), "5140"),
    name: stryMutAct_9fa48("3312") ? "" : (stryCov_9fa48("3312"), "Phone and internet"),
    use: stryMutAct_9fa48("3313") ? "" : (stryCov_9fa48("3313"), "expense"),
    reportingConcept: stryMutAct_9fa48("3314") ? "" : (stryCov_9fa48("3314"), "us-gaap:Communication")
  }), stryMutAct_9fa48("3315") ? {} : (stryCov_9fa48("3315"), {
    code: stryMutAct_9fa48("3316") ? "" : (stryCov_9fa48("3316"), "5150"),
    name: stryMutAct_9fa48("3317") ? "" : (stryCov_9fa48("3317"), "Software and digital services"),
    use: stryMutAct_9fa48("3318") ? "" : (stryCov_9fa48("3318"), "expense"),
    reportingConcept: stryMutAct_9fa48("3319") ? "" : (stryCov_9fa48("3319"), "us-gaap:InformationTechnologyAndDataProcessing")
  }), stryMutAct_9fa48("3320") ? {} : (stryCov_9fa48("3320"), {
    code: stryMutAct_9fa48("3321") ? "" : (stryCov_9fa48("3321"), "5160"),
    name: stryMutAct_9fa48("3322") ? "" : (stryCov_9fa48("3322"), "Books and subscriptions"),
    use: stryMutAct_9fa48("3323") ? "" : (stryCov_9fa48("3323"), "expense")
  }), stryMutAct_9fa48("3324") ? {} : (stryCov_9fa48("3324"), {
    code: stryMutAct_9fa48("3325") ? "" : (stryCov_9fa48("3325"), "5210"),
    name: stryMutAct_9fa48("3326") ? "" : (stryCov_9fa48("3326"), "Fuel"),
    use: stryMutAct_9fa48("3327") ? "" : (stryCov_9fa48("3327"), "expense"),
    reportingConcept: stryMutAct_9fa48("3328") ? "" : (stryCov_9fa48("3328"), "us-gaap:FuelCosts")
  }), stryMutAct_9fa48("3329") ? {} : (stryCov_9fa48("3329"), {
    code: stryMutAct_9fa48("3330") ? "" : (stryCov_9fa48("3330"), "5220"),
    name: stryMutAct_9fa48("3331") ? "" : (stryCov_9fa48("3331"), "Taxis and public transit"),
    use: stryMutAct_9fa48("3332") ? "" : (stryCov_9fa48("3332"), "expense")
  }), stryMutAct_9fa48("3333") ? {} : (stryCov_9fa48("3333"), {
    code: stryMutAct_9fa48("3334") ? "" : (stryCov_9fa48("3334"), "5230"),
    name: stryMutAct_9fa48("3335") ? "" : (stryCov_9fa48("3335"), "Parking"),
    use: stryMutAct_9fa48("3336") ? "" : (stryCov_9fa48("3336"), "expense")
  }), stryMutAct_9fa48("3337") ? {} : (stryCov_9fa48("3337"), {
    code: stryMutAct_9fa48("3338") ? "" : (stryCov_9fa48("3338"), "5240"),
    name: stryMutAct_9fa48("3339") ? "" : (stryCov_9fa48("3339"), "Vehicle repairs and maintenance"),
    use: stryMutAct_9fa48("3340") ? "" : (stryCov_9fa48("3340"), "expense")
  }), stryMutAct_9fa48("3341") ? {} : (stryCov_9fa48("3341"), {
    code: stryMutAct_9fa48("3342") ? "" : (stryCov_9fa48("3342"), "5250"),
    name: stryMutAct_9fa48("3343") ? "" : (stryCov_9fa48("3343"), "Vehicle tax"),
    use: stryMutAct_9fa48("3344") ? "" : (stryCov_9fa48("3344"), "expense"),
    reportingConcept: stryMutAct_9fa48("3345") ? "" : (stryCov_9fa48("3345"), "us-gaap:TaxesOther")
  }), stryMutAct_9fa48("3346") ? {} : (stryCov_9fa48("3346"), {
    code: stryMutAct_9fa48("3347") ? "" : (stryCov_9fa48("3347"), "5260"),
    name: stryMutAct_9fa48("3348") ? "" : (stryCov_9fa48("3348"), "Shipping and moving"),
    use: stryMutAct_9fa48("3349") ? "" : (stryCov_9fa48("3349"), "expense")
  }), stryMutAct_9fa48("3350") ? {} : (stryCov_9fa48("3350"), {
    code: stryMutAct_9fa48("3351") ? "" : (stryCov_9fa48("3351"), "5310"),
    name: stryMutAct_9fa48("3352") ? "" : (stryCov_9fa48("3352"), "Groceries"),
    use: stryMutAct_9fa48("3353") ? "" : (stryCov_9fa48("3353"), "expense")
  }), stryMutAct_9fa48("3354") ? {} : (stryCov_9fa48("3354"), {
    code: stryMutAct_9fa48("3355") ? "" : (stryCov_9fa48("3355"), "5320"),
    name: stryMutAct_9fa48("3356") ? "" : (stryCov_9fa48("3356"), "Restaurants and cafés"),
    use: stryMutAct_9fa48("3357") ? "" : (stryCov_9fa48("3357"), "expense")
  }), stryMutAct_9fa48("3358") ? {} : (stryCov_9fa48("3358"), {
    code: stryMutAct_9fa48("3359") ? "" : (stryCov_9fa48("3359"), "5330"),
    name: stryMutAct_9fa48("3360") ? "" : (stryCov_9fa48("3360"), "Household supplies"),
    use: stryMutAct_9fa48("3361") ? "" : (stryCov_9fa48("3361"), "expense"),
    reportingConcept: stryMutAct_9fa48("3362") ? "" : (stryCov_9fa48("3362"), "us-gaap:SuppliesExpense")
  }), stryMutAct_9fa48("3363") ? {} : (stryCov_9fa48("3363"), {
    code: stryMutAct_9fa48("3364") ? "" : (stryCov_9fa48("3364"), "5410"),
    name: stryMutAct_9fa48("3365") ? "" : (stryCov_9fa48("3365"), "Life insurance"),
    use: stryMutAct_9fa48("3366") ? "" : (stryCov_9fa48("3366"), "expense"),
    reportingConcept: stryMutAct_9fa48("3367") ? "" : (stryCov_9fa48("3367"), "us-gaap:GeneralInsuranceExpense")
  }), stryMutAct_9fa48("3368") ? {} : (stryCov_9fa48("3368"), {
    code: stryMutAct_9fa48("3369") ? "" : (stryCov_9fa48("3369"), "5420"),
    name: stryMutAct_9fa48("3370") ? "" : (stryCov_9fa48("3370"), "Vehicle insurance"),
    use: stryMutAct_9fa48("3371") ? "" : (stryCov_9fa48("3371"), "expense"),
    reportingConcept: stryMutAct_9fa48("3372") ? "" : (stryCov_9fa48("3372"), "us-gaap:GeneralInsuranceExpense")
  }), stryMutAct_9fa48("3373") ? {} : (stryCov_9fa48("3373"), {
    code: stryMutAct_9fa48("3374") ? "" : (stryCov_9fa48("3374"), "5430"),
    name: stryMutAct_9fa48("3375") ? "" : (stryCov_9fa48("3375"), "Compulsory traffic accident insurance"),
    use: stryMutAct_9fa48("3376") ? "" : (stryCov_9fa48("3376"), "expense"),
    reportingConcept: stryMutAct_9fa48("3377") ? "" : (stryCov_9fa48("3377"), "us-gaap:GeneralInsuranceExpense")
  }), stryMutAct_9fa48("3378") ? {} : (stryCov_9fa48("3378"), {
    code: stryMutAct_9fa48("3379") ? "" : (stryCov_9fa48("3379"), "5440"),
    name: stryMutAct_9fa48("3380") ? "" : (stryCov_9fa48("3380"), "Other insurance"),
    use: stryMutAct_9fa48("3381") ? "" : (stryCov_9fa48("3381"), "expense"),
    reportingConcept: stryMutAct_9fa48("3382") ? "" : (stryCov_9fa48("3382"), "us-gaap:GeneralInsuranceExpense")
  }), stryMutAct_9fa48("3383") ? {} : (stryCov_9fa48("3383"), {
    code: stryMutAct_9fa48("3384") ? "" : (stryCov_9fa48("3384"), "5510"),
    name: stryMutAct_9fa48("3385") ? "" : (stryCov_9fa48("3385"), "Health and medicine"),
    use: stryMutAct_9fa48("3386") ? "" : (stryCov_9fa48("3386"), "expense")
  }), stryMutAct_9fa48("3387") ? {} : (stryCov_9fa48("3387"), {
    code: stryMutAct_9fa48("3388") ? "" : (stryCov_9fa48("3388"), "5520"),
    name: stryMutAct_9fa48("3389") ? "" : (stryCov_9fa48("3389"), "Personal care"),
    use: stryMutAct_9fa48("3390") ? "" : (stryCov_9fa48("3390"), "expense")
  }), stryMutAct_9fa48("3391") ? {} : (stryCov_9fa48("3391"), {
    code: stryMutAct_9fa48("3392") ? "" : (stryCov_9fa48("3392"), "5530"),
    name: stryMutAct_9fa48("3393") ? "" : (stryCov_9fa48("3393"), "Clothing and footwear"),
    use: stryMutAct_9fa48("3394") ? "" : (stryCov_9fa48("3394"), "expense")
  }), stryMutAct_9fa48("3395") ? {} : (stryCov_9fa48("3395"), {
    code: stryMutAct_9fa48("3396") ? "" : (stryCov_9fa48("3396"), "5540"),
    name: stryMutAct_9fa48("3397") ? "" : (stryCov_9fa48("3397"), "Education"),
    use: stryMutAct_9fa48("3398") ? "" : (stryCov_9fa48("3398"), "expense")
  }), stryMutAct_9fa48("3399") ? {} : (stryCov_9fa48("3399"), {
    code: stryMutAct_9fa48("3400") ? "" : (stryCov_9fa48("3400"), "5550"),
    name: stryMutAct_9fa48("3401") ? "" : (stryCov_9fa48("3401"), "Sports and wellness"),
    use: stryMutAct_9fa48("3402") ? "" : (stryCov_9fa48("3402"), "expense")
  }), stryMutAct_9fa48("3403") ? {} : (stryCov_9fa48("3403"), {
    code: stryMutAct_9fa48("3404") ? "" : (stryCov_9fa48("3404"), "5560"),
    name: stryMutAct_9fa48("3405") ? "" : (stryCov_9fa48("3405"), "Entertainment and recreation"),
    use: stryMutAct_9fa48("3406") ? "" : (stryCov_9fa48("3406"), "expense")
  }), stryMutAct_9fa48("3407") ? {} : (stryCov_9fa48("3407"), {
    code: stryMutAct_9fa48("3408") ? "" : (stryCov_9fa48("3408"), "5570"),
    name: stryMutAct_9fa48("3409") ? "" : (stryCov_9fa48("3409"), "Gifts and family support"),
    use: stryMutAct_9fa48("3410") ? "" : (stryCov_9fa48("3410"), "expense")
  }), stryMutAct_9fa48("3411") ? {} : (stryCov_9fa48("3411"), {
    code: stryMutAct_9fa48("3412") ? "" : (stryCov_9fa48("3412"), "5580"),
    name: stryMutAct_9fa48("3413") ? "" : (stryCov_9fa48("3413"), "Pets"),
    use: stryMutAct_9fa48("3414") ? "" : (stryCov_9fa48("3414"), "expense")
  }), stryMutAct_9fa48("3415") ? {} : (stryCov_9fa48("3415"), {
    code: stryMutAct_9fa48("3416") ? "" : (stryCov_9fa48("3416"), "5590"),
    name: stryMutAct_9fa48("3417") ? "" : (stryCov_9fa48("3417"), "Technology and accessories"),
    use: stryMutAct_9fa48("3418") ? "" : (stryCov_9fa48("3418"), "expense")
  }), stryMutAct_9fa48("3419") ? {} : (stryCov_9fa48("3419"), {
    code: stryMutAct_9fa48("3420") ? "" : (stryCov_9fa48("3420"), "5599"),
    name: stryMutAct_9fa48("3421") ? "" : (stryCov_9fa48("3421"), "Other personal expenses"),
    use: stryMutAct_9fa48("3422") ? "" : (stryCov_9fa48("3422"), "expense")
  }), stryMutAct_9fa48("3423") ? {} : (stryCov_9fa48("3423"), {
    code: stryMutAct_9fa48("3424") ? "" : (stryCov_9fa48("3424"), "5610"),
    name: stryMutAct_9fa48("3425") ? "" : (stryCov_9fa48("3425"), "Legal fees"),
    use: stryMutAct_9fa48("3426") ? "" : (stryCov_9fa48("3426"), "expense"),
    reportingConcept: stryMutAct_9fa48("3427") ? "" : (stryCov_9fa48("3427"), "us-gaap:LegalFees")
  }), stryMutAct_9fa48("3428") ? {} : (stryCov_9fa48("3428"), {
    code: stryMutAct_9fa48("3429") ? "" : (stryCov_9fa48("3429"), "5620"),
    name: stryMutAct_9fa48("3430") ? "" : (stryCov_9fa48("3430"), "Financial advisory fees"),
    use: stryMutAct_9fa48("3431") ? "" : (stryCov_9fa48("3431"), "expense"),
    reportingConcept: stryMutAct_9fa48("3432") ? "" : (stryCov_9fa48("3432"), "us-gaap:ProfessionalFees")
  }), stryMutAct_9fa48("3433") ? {} : (stryCov_9fa48("3433"), {
    code: stryMutAct_9fa48("3434") ? "" : (stryCov_9fa48("3434"), "5630"),
    name: stryMutAct_9fa48("3435") ? "" : (stryCov_9fa48("3435"), "Financial transaction tax"),
    use: stryMutAct_9fa48("3436") ? "" : (stryCov_9fa48("3436"), "expense"),
    reportingConcept: stryMutAct_9fa48("3437") ? "" : (stryCov_9fa48("3437"), "us-gaap:TaxesOther")
  }), stryMutAct_9fa48("3438") ? {} : (stryCov_9fa48("3438"), {
    code: stryMutAct_9fa48("3439") ? "" : (stryCov_9fa48("3439"), "5640"),
    name: stryMutAct_9fa48("3440") ? "" : (stryCov_9fa48("3440"), "Income tax"),
    use: stryMutAct_9fa48("3441") ? "" : (stryCov_9fa48("3441"), "expense"),
    reportingConcept: stryMutAct_9fa48("3442") ? "" : (stryCov_9fa48("3442"), "us-gaap:IncomeTaxExpenseBenefit")
  }), stryMutAct_9fa48("3443") ? {} : (stryCov_9fa48("3443"), {
    code: stryMutAct_9fa48("3444") ? "" : (stryCov_9fa48("3444"), "5650"),
    name: stryMutAct_9fa48("3445") ? "" : (stryCov_9fa48("3445"), "Fines and penalties"),
    use: stryMutAct_9fa48("3446") ? "" : (stryCov_9fa48("3446"), "expense")
  }), stryMutAct_9fa48("3447") ? {} : (stryCov_9fa48("3447"), {
    code: stryMutAct_9fa48("3448") ? "" : (stryCov_9fa48("3448"), "5660"),
    name: stryMutAct_9fa48("3449") ? "" : (stryCov_9fa48("3449"), "Donations"),
    use: stryMutAct_9fa48("3450") ? "" : (stryCov_9fa48("3450"), "expense")
  }), stryMutAct_9fa48("3451") ? {} : (stryCov_9fa48("3451"), {
    code: stryMutAct_9fa48("3452") ? "" : (stryCov_9fa48("3452"), "5710"),
    name: stryMutAct_9fa48("3453") ? "" : (stryCov_9fa48("3453"), "Travel lodging and meals"),
    use: stryMutAct_9fa48("3454") ? "" : (stryCov_9fa48("3454"), "expense"),
    reportingConcept: stryMutAct_9fa48("3455") ? "" : (stryCov_9fa48("3455"), "us-gaap:TravelAndEntertainmentExpense")
  }), stryMutAct_9fa48("3456") ? {} : (stryCov_9fa48("3456"), {
    code: stryMutAct_9fa48("3457") ? "" : (stryCov_9fa48("3457"), "5720"),
    name: stryMutAct_9fa48("3458") ? "" : (stryCov_9fa48("3458"), "Airfare"),
    use: stryMutAct_9fa48("3459") ? "" : (stryCov_9fa48("3459"), "expense"),
    reportingConcept: stryMutAct_9fa48("3460") ? "" : (stryCov_9fa48("3460"), "us-gaap:TravelAndEntertainmentExpense")
  }), stryMutAct_9fa48("3461") ? {} : (stryCov_9fa48("3461"), {
    code: stryMutAct_9fa48("3462") ? "" : (stryCov_9fa48("3462"), "5730"),
    name: stryMutAct_9fa48("3463") ? "" : (stryCov_9fa48("3463"), "Intercity ground fares"),
    use: stryMutAct_9fa48("3464") ? "" : (stryCov_9fa48("3464"), "expense"),
    reportingConcept: stryMutAct_9fa48("3465") ? "" : (stryCov_9fa48("3465"), "us-gaap:TravelAndEntertainmentExpense")
  }), // 6 Financial costs, depreciation, and losses
  stryMutAct_9fa48("3466") ? {} : (stryCov_9fa48("3466"), {
    code: stryMutAct_9fa48("3467") ? "" : (stryCov_9fa48("3467"), "6010"),
    name: stryMutAct_9fa48("3468") ? "" : (stryCov_9fa48("3468"), "Bank fees"),
    use: stryMutAct_9fa48("3469") ? "" : (stryCov_9fa48("3469"), "expense")
  }), stryMutAct_9fa48("3470") ? {} : (stryCov_9fa48("3470"), {
    code: stryMutAct_9fa48("3471") ? "" : (stryCov_9fa48("3471"), "6020"),
    name: stryMutAct_9fa48("3472") ? "" : (stryCov_9fa48("3472"), "Financial commissions"),
    use: stryMutAct_9fa48("3473") ? "" : (stryCov_9fa48("3473"), "expense")
  }), stryMutAct_9fa48("3474") ? {} : (stryCov_9fa48("3474"), {
    code: stryMutAct_9fa48("3475") ? "" : (stryCov_9fa48("3475"), "6030"),
    name: stryMutAct_9fa48("3476") ? "" : (stryCov_9fa48("3476"), "Interest expense"),
    use: stryMutAct_9fa48("3477") ? "" : (stryCov_9fa48("3477"), "expense"),
    reportingConcept: stryMutAct_9fa48("3478") ? "" : (stryCov_9fa48("3478"), "us-gaap:InterestExpense")
  }), stryMutAct_9fa48("3479") ? {} : (stryCov_9fa48("3479"), {
    code: stryMutAct_9fa48("3480") ? "" : (stryCov_9fa48("3480"), "6040"),
    name: stryMutAct_9fa48("3481") ? "" : (stryCov_9fa48("3481"), "Foreign exchange losses"),
    use: stryMutAct_9fa48("3482") ? "" : (stryCov_9fa48("3482"), "general"),
    reportingConcept: stryMutAct_9fa48("3483") ? "" : (stryCov_9fa48("3483"), "us-gaap:ForeignCurrencyTransactionLossBeforeTax")
  }), stryMutAct_9fa48("3484") ? {} : (stryCov_9fa48("3484"), {
    code: stryMutAct_9fa48("3485") ? "" : (stryCov_9fa48("3485"), "6110"),
    name: stryMutAct_9fa48("3486") ? "" : (stryCov_9fa48("3486"), "Depreciation, buildings"),
    use: stryMutAct_9fa48("3487") ? "" : (stryCov_9fa48("3487"), "general"),
    reportingConcept: stryMutAct_9fa48("3488") ? "" : (stryCov_9fa48("3488"), "us-gaap:Depreciation")
  }), stryMutAct_9fa48("3489") ? {} : (stryCov_9fa48("3489"), {
    code: stryMutAct_9fa48("3490") ? "" : (stryCov_9fa48("3490"), "6120"),
    name: stryMutAct_9fa48("3491") ? "" : (stryCov_9fa48("3491"), "Depreciation, furniture and fixtures"),
    use: stryMutAct_9fa48("3492") ? "" : (stryCov_9fa48("3492"), "general"),
    reportingConcept: stryMutAct_9fa48("3493") ? "" : (stryCov_9fa48("3493"), "us-gaap:Depreciation")
  }), stryMutAct_9fa48("3494") ? {} : (stryCov_9fa48("3494"), {
    code: stryMutAct_9fa48("3495") ? "" : (stryCov_9fa48("3495"), "6130"),
    name: stryMutAct_9fa48("3496") ? "" : (stryCov_9fa48("3496"), "Depreciation, computer equipment"),
    use: stryMutAct_9fa48("3497") ? "" : (stryCov_9fa48("3497"), "general"),
    reportingConcept: stryMutAct_9fa48("3498") ? "" : (stryCov_9fa48("3498"), "us-gaap:Depreciation")
  }), stryMutAct_9fa48("3499") ? {} : (stryCov_9fa48("3499"), {
    code: stryMutAct_9fa48("3500") ? "" : (stryCov_9fa48("3500"), "6140"),
    name: stryMutAct_9fa48("3501") ? "" : (stryCov_9fa48("3501"), "Depreciation, vehicles"),
    use: stryMutAct_9fa48("3502") ? "" : (stryCov_9fa48("3502"), "general"),
    reportingConcept: stryMutAct_9fa48("3503") ? "" : (stryCov_9fa48("3503"), "us-gaap:Depreciation")
  }), stryMutAct_9fa48("3504") ? {} : (stryCov_9fa48("3504"), {
    code: stryMutAct_9fa48("3505") ? "" : (stryCov_9fa48("3505"), "6150"),
    name: stryMutAct_9fa48("3506") ? "" : (stryCov_9fa48("3506"), "Loss on sale of investments"),
    use: stryMutAct_9fa48("3507") ? "" : (stryCov_9fa48("3507"), "general"),
    reportingConcept: stryMutAct_9fa48("3508") ? "" : (stryCov_9fa48("3508"), "us-gaap:GainLossOnInvestments")
  }), stryMutAct_9fa48("3509") ? {} : (stryCov_9fa48("3509"), {
    code: stryMutAct_9fa48("3510") ? "" : (stryCov_9fa48("3510"), "6160"),
    name: stryMutAct_9fa48("3511") ? "" : (stryCov_9fa48("3511"), "Loss on disposal of property and equipment"),
    use: stryMutAct_9fa48("3512") ? "" : (stryCov_9fa48("3512"), "general"),
    reportingConcept: stryMutAct_9fa48("3513") ? "" : (stryCov_9fa48("3513"), "us-gaap:GainLossOnDispositionOfAssets")
  })]),
  summaryNames: stryMutAct_9fa48("3514") ? {} : (stryCov_9fa48("3514"), {
    "2120": stryMutAct_9fa48("3515") ? "" : (stryCov_9fa48("3515"), "Loans from individuals"),
    "1120": stryMutAct_9fa48("3516") ? "" : (stryCov_9fa48("3516"), "Investment fund units"),
    "1110": stryMutAct_9fa48("3517") ? "" : (stryCov_9fa48("3517"), "Certificates of deposit"),
    "1260": stryMutAct_9fa48("3518") ? "" : (stryCov_9fa48("3518"), "Loans to individuals, unsecured"),
    "1250": stryMutAct_9fa48("3519") ? "" : (stryCov_9fa48("3519"), "Loans to individuals, secured"),
    "1": stryMutAct_9fa48("3520") ? "" : (stryCov_9fa48("3520"), "Assets"),
    "10": stryMutAct_9fa48("3521") ? "" : (stryCov_9fa48("3521"), "Cash and cash equivalents"),
    "1010": stryMutAct_9fa48("3522") ? "" : (stryCov_9fa48("3522"), "Cash on hand"),
    "1020": stryMutAct_9fa48("3523") ? "" : (stryCov_9fa48("3523"), "Checking accounts"),
    "1030": stryMutAct_9fa48("3524") ? "" : (stryCov_9fa48("3524"), "Savings accounts"),
    "11": stryMutAct_9fa48("3525") ? "" : (stryCov_9fa48("3525"), "Investments"),
    "12": stryMutAct_9fa48("3526") ? "" : (stryCov_9fa48("3526"), "Receivables"),
    "13": stryMutAct_9fa48("3527") ? "" : (stryCov_9fa48("3527"), "Prepaid expenses"),
    "15": stryMutAct_9fa48("3528") ? "" : (stryCov_9fa48("3528"), "Property and equipment"),
    "2": stryMutAct_9fa48("3529") ? "" : (stryCov_9fa48("3529"), "Liabilities"),
    "20": stryMutAct_9fa48("3530") ? "" : (stryCov_9fa48("3530"), "Credit cards"),
    "2010": stryMutAct_9fa48("3531") ? "" : (stryCov_9fa48("3531"), "Credit cards payable"),
    "21": stryMutAct_9fa48("3532") ? "" : (stryCov_9fa48("3532"), "Borrowings"),
    "2110": stryMutAct_9fa48("3533") ? "" : (stryCov_9fa48("3533"), "Loans payable"),
    "22": stryMutAct_9fa48("3534") ? "" : (stryCov_9fa48("3534"), "Payables and accrued liabilities"),
    "23": stryMutAct_9fa48("3535") ? "" : (stryCov_9fa48("3535"), "Deferred revenue and deposits"),
    "3": stryMutAct_9fa48("3536") ? "" : (stryCov_9fa48("3536"), "Net worth"),
    "30": stryMutAct_9fa48("3537") ? "" : (stryCov_9fa48("3537"), "Net worth"),
    "4": stryMutAct_9fa48("3538") ? "" : (stryCov_9fa48("3538"), "Revenue"),
    "40": stryMutAct_9fa48("3539") ? "" : (stryCov_9fa48("3539"), "Earned income"),
    "41": stryMutAct_9fa48("3540") ? "" : (stryCov_9fa48("3540"), "Investment income"),
    "42": stryMutAct_9fa48("3541") ? "" : (stryCov_9fa48("3541"), "Rental income"),
    "49": stryMutAct_9fa48("3542") ? "" : (stryCov_9fa48("3542"), "Other income"),
    "5": stryMutAct_9fa48("3543") ? "" : (stryCov_9fa48("3543"), "Living expenses"),
    "50": stryMutAct_9fa48("3544") ? "" : (stryCov_9fa48("3544"), "Housing"),
    "51": stryMutAct_9fa48("3545") ? "" : (stryCov_9fa48("3545"), "Utilities and communication"),
    "52": stryMutAct_9fa48("3546") ? "" : (stryCov_9fa48("3546"), "Transportation"),
    "53": stryMutAct_9fa48("3547") ? "" : (stryCov_9fa48("3547"), "Food and household"),
    "54": stryMutAct_9fa48("3548") ? "" : (stryCov_9fa48("3548"), "Insurance"),
    "55": stryMutAct_9fa48("3549") ? "" : (stryCov_9fa48("3549"), "Personal and family"),
    "56": stryMutAct_9fa48("3550") ? "" : (stryCov_9fa48("3550"), "Professional services and taxes"),
    "57": stryMutAct_9fa48("3551") ? "" : (stryCov_9fa48("3551"), "Travel"),
    "6": stryMutAct_9fa48("3552") ? "" : (stryCov_9fa48("3552"), "Financial and other expenses"),
    "60": stryMutAct_9fa48("3553") ? "" : (stryCov_9fa48("3553"), "Financial costs"),
    "61": stryMutAct_9fa48("3554") ? "" : (stryCov_9fa48("3554"), "Depreciation and losses")
  })
})) satisfies ChartOfAccountsTemplate;