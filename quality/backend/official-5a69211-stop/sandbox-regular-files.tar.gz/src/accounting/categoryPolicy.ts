// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { chartTemplate } from "./chartOfAccounts";
import { AccountingError } from "./errors";
import type { AccountResolution, CategoryNature, NatureAnswer } from "./categoryTypes";
export const categoryPolicy = stryMutAct_9fa48("367") ? "" : (stryCov_9fa48("367"), "category-es-en@1");
export const categoryPresets = (stryMutAct_9fa48("368") ? [] : (stryCov_9fa48("368"), [stryMutAct_9fa48("369") ? {} : (stryCov_9fa48("369"), {
  concept: stryMutAct_9fa48("370") ? "" : (stryCov_9fa48("370"), "groceries"),
  nature: stryMutAct_9fa48("371") ? "" : (stryCov_9fa48("371"), "Expense"),
  aliases: stryMutAct_9fa48("372") ? [] : (stryCov_9fa48("372"), [stryMutAct_9fa48("373") ? "" : (stryCov_9fa48("373"), "mercado"), stryMutAct_9fa48("374") ? "" : (stryCov_9fa48("374"), "groceries"), stryMutAct_9fa48("375") ? "" : (stryCov_9fa48("375"), "supermercado")]),
  co: stryMutAct_9fa48("376") ? "" : (stryCov_9fa48("376"), "51959501"),
  us: stryMutAct_9fa48("377") ? "" : (stryCov_9fa48("377"), "5310")
}), stryMutAct_9fa48("378") ? {} : (stryCov_9fa48("378"), {
  concept: stryMutAct_9fa48("379") ? "" : (stryCov_9fa48("379"), "restaurants"),
  nature: stryMutAct_9fa48("380") ? "" : (stryCov_9fa48("380"), "Expense"),
  aliases: stryMutAct_9fa48("381") ? [] : (stryCov_9fa48("381"), [stryMutAct_9fa48("382") ? "" : (stryCov_9fa48("382"), "restaurante"), stryMutAct_9fa48("383") ? "" : (stryCov_9fa48("383"), "restaurant"), stryMutAct_9fa48("384") ? "" : (stryCov_9fa48("384"), "cafe"), stryMutAct_9fa48("385") ? "" : (stryCov_9fa48("385"), "coffee")]),
  co: stryMutAct_9fa48("386") ? "" : (stryCov_9fa48("386"), "519560"),
  us: stryMutAct_9fa48("387") ? "" : (stryCov_9fa48("387"), "5320")
}), stryMutAct_9fa48("388") ? {} : (stryCov_9fa48("388"), {
  concept: stryMutAct_9fa48("389") ? "" : (stryCov_9fa48("389"), "fuel"),
  nature: stryMutAct_9fa48("390") ? "" : (stryCov_9fa48("390"), "Expense"),
  aliases: stryMutAct_9fa48("391") ? [] : (stryCov_9fa48("391"), [stryMutAct_9fa48("392") ? "" : (stryCov_9fa48("392"), "gasolina"), stryMutAct_9fa48("393") ? "" : (stryCov_9fa48("393"), "fuel"), stryMutAct_9fa48("394") ? "" : (stryCov_9fa48("394"), "gasoline")]),
  co: stryMutAct_9fa48("395") ? "" : (stryCov_9fa48("395"), "519535"),
  us: stryMutAct_9fa48("396") ? "" : (stryCov_9fa48("396"), "5210")
}), stryMutAct_9fa48("397") ? {} : (stryCov_9fa48("397"), {
  concept: stryMutAct_9fa48("398") ? "" : (stryCov_9fa48("398"), "rentPaid"),
  nature: stryMutAct_9fa48("399") ? "" : (stryCov_9fa48("399"), "Expense"),
  aliases: stryMutAct_9fa48("400") ? [] : (stryCov_9fa48("400"), [stryMutAct_9fa48("401") ? "" : (stryCov_9fa48("401"), "arriendo"), stryMutAct_9fa48("402") ? "" : (stryCov_9fa48("402"), "rent"), stryMutAct_9fa48("403") ? "" : (stryCov_9fa48("403"), "alquiler")]),
  co: stryMutAct_9fa48("404") ? "" : (stryCov_9fa48("404"), "512010"),
  us: stryMutAct_9fa48("405") ? "" : (stryCov_9fa48("405"), "5010")
}), stryMutAct_9fa48("406") ? {} : (stryCov_9fa48("406"), {
  concept: stryMutAct_9fa48("407") ? "" : (stryCov_9fa48("407"), "rentReceived"),
  nature: stryMutAct_9fa48("408") ? "" : (stryCov_9fa48("408"), "Income"),
  aliases: stryMutAct_9fa48("409") ? [] : (stryCov_9fa48("409"), [stryMutAct_9fa48("410") ? "" : (stryCov_9fa48("410"), "arriendo"), stryMutAct_9fa48("411") ? "" : (stryCov_9fa48("411"), "rent"), stryMutAct_9fa48("412") ? "" : (stryCov_9fa48("412"), "alquiler")]),
  co: stryMutAct_9fa48("413") ? "" : (stryCov_9fa48("413"), "42201001"),
  us: stryMutAct_9fa48("414") ? "" : (stryCov_9fa48("414"), "4210")
}), stryMutAct_9fa48("415") ? {} : (stryCov_9fa48("415"), {
  concept: stryMutAct_9fa48("416") ? "" : (stryCov_9fa48("416"), "salary"),
  nature: stryMutAct_9fa48("417") ? "" : (stryCov_9fa48("417"), "Income"),
  aliases: stryMutAct_9fa48("418") ? [] : (stryCov_9fa48("418"), [stryMutAct_9fa48("419") ? "" : (stryCov_9fa48("419"), "salario"), stryMutAct_9fa48("420") ? "" : (stryCov_9fa48("420"), "sueldo"), stryMutAct_9fa48("421") ? "" : (stryCov_9fa48("421"), "salary"), stryMutAct_9fa48("422") ? "" : (stryCov_9fa48("422"), "wages")]),
  co: stryMutAct_9fa48("423") ? "" : (stryCov_9fa48("423"), "42959501"),
  us: stryMutAct_9fa48("424") ? "" : (stryCov_9fa48("424"), "4010")
}), stryMutAct_9fa48("425") ? {} : (stryCov_9fa48("425"), {
  concept: stryMutAct_9fa48("426") ? "" : (stryCov_9fa48("426"), "interestPaid"),
  nature: stryMutAct_9fa48("427") ? "" : (stryCov_9fa48("427"), "Expense"),
  aliases: stryMutAct_9fa48("428") ? [] : (stryCov_9fa48("428"), [stryMutAct_9fa48("429") ? "" : (stryCov_9fa48("429"), "intereses"), stryMutAct_9fa48("430") ? "" : (stryCov_9fa48("430"), "interest")]),
  co: stryMutAct_9fa48("431") ? "" : (stryCov_9fa48("431"), "530520"),
  us: stryMutAct_9fa48("432") ? "" : (stryCov_9fa48("432"), "6030")
}), stryMutAct_9fa48("433") ? {} : (stryCov_9fa48("433"), {
  concept: stryMutAct_9fa48("434") ? "" : (stryCov_9fa48("434"), "interestReceived"),
  nature: stryMutAct_9fa48("435") ? "" : (stryCov_9fa48("435"), "Income"),
  aliases: stryMutAct_9fa48("436") ? [] : (stryCov_9fa48("436"), [stryMutAct_9fa48("437") ? "" : (stryCov_9fa48("437"), "intereses"), stryMutAct_9fa48("438") ? "" : (stryCov_9fa48("438"), "interest")]),
  co: stryMutAct_9fa48("439") ? "" : (stryCov_9fa48("439"), "421005"),
  us: stryMutAct_9fa48("440") ? "" : (stryCov_9fa48("440"), "4110")
}), stryMutAct_9fa48("441") ? {} : (stryCov_9fa48("441"), {
  concept: stryMutAct_9fa48("442") ? "" : (stryCov_9fa48("442"), "lifeInsurance"),
  nature: stryMutAct_9fa48("443") ? "" : (stryCov_9fa48("443"), "Expense"),
  aliases: stryMutAct_9fa48("444") ? [] : (stryCov_9fa48("444"), [stryMutAct_9fa48("445") ? "" : (stryCov_9fa48("445"), "seguro"), stryMutAct_9fa48("446") ? "" : (stryCov_9fa48("446"), "seguro de vida"), stryMutAct_9fa48("447") ? "" : (stryCov_9fa48("447"), "life insurance")]),
  co: stryMutAct_9fa48("448") ? "" : (stryCov_9fa48("448"), "513020"),
  us: stryMutAct_9fa48("449") ? "" : (stryCov_9fa48("449"), "5410")
}), stryMutAct_9fa48("450") ? {} : (stryCov_9fa48("450"), {
  concept: stryMutAct_9fa48("451") ? "" : (stryCov_9fa48("451"), "vehicleInsurance"),
  nature: stryMutAct_9fa48("452") ? "" : (stryCov_9fa48("452"), "Expense"),
  aliases: stryMutAct_9fa48("453") ? [] : (stryCov_9fa48("453"), [stryMutAct_9fa48("454") ? "" : (stryCov_9fa48("454"), "seguro"), stryMutAct_9fa48("455") ? "" : (stryCov_9fa48("455"), "seguro de vehiculo"), stryMutAct_9fa48("456") ? "" : (stryCov_9fa48("456"), "car insurance")]),
  co: stryMutAct_9fa48("457") ? "" : (stryCov_9fa48("457"), "513040"),
  us: stryMutAct_9fa48("458") ? "" : (stryCov_9fa48("458"), "5420")
}), stryMutAct_9fa48("459") ? {} : (stryCov_9fa48("459"), {
  concept: stryMutAct_9fa48("460") ? "" : (stryCov_9fa48("460"), "health"),
  nature: stryMutAct_9fa48("461") ? "" : (stryCov_9fa48("461"), "Expense"),
  aliases: stryMutAct_9fa48("462") ? [] : (stryCov_9fa48("462"), [stryMutAct_9fa48("463") ? "" : (stryCov_9fa48("463"), "salud"), stryMutAct_9fa48("464") ? "" : (stryCov_9fa48("464"), "health"), stryMutAct_9fa48("465") ? "" : (stryCov_9fa48("465"), "medicina")]),
  co: stryMutAct_9fa48("466") ? "" : (stryCov_9fa48("466"), "51959502"),
  us: stryMutAct_9fa48("467") ? "" : (stryCov_9fa48("467"), "5510")
}), stryMutAct_9fa48("468") ? {} : (stryCov_9fa48("468"), {
  concept: stryMutAct_9fa48("469") ? "" : (stryCov_9fa48("469"), "transport"),
  nature: stryMutAct_9fa48("470") ? "" : (stryCov_9fa48("470"), "Expense"),
  aliases: stryMutAct_9fa48("471") ? [] : (stryCov_9fa48("471"), [stryMutAct_9fa48("472") ? "" : (stryCov_9fa48("472"), "taxi"), stryMutAct_9fa48("473") ? "" : (stryCov_9fa48("473"), "bus"), stryMutAct_9fa48("474") ? "" : (stryCov_9fa48("474"), "transporte"), stryMutAct_9fa48("475") ? "" : (stryCov_9fa48("475"), "transit")]),
  co: stryMutAct_9fa48("476") ? "" : (stryCov_9fa48("476"), "519545"),
  us: stryMutAct_9fa48("477") ? "" : (stryCov_9fa48("477"), "5220")
}), stryMutAct_9fa48("478") ? {} : (stryCov_9fa48("478"), {
  concept: stryMutAct_9fa48("479") ? "" : (stryCov_9fa48("479"), "education"),
  nature: stryMutAct_9fa48("480") ? "" : (stryCov_9fa48("480"), "Expense"),
  aliases: stryMutAct_9fa48("481") ? [] : (stryCov_9fa48("481"), [stryMutAct_9fa48("482") ? "" : (stryCov_9fa48("482"), "educacion"), stryMutAct_9fa48("483") ? "" : (stryCov_9fa48("483"), "education")]),
  co: stryMutAct_9fa48("484") ? "" : (stryCov_9fa48("484"), "51959505"),
  us: stryMutAct_9fa48("485") ? "" : (stryCov_9fa48("485"), "5540")
}), stryMutAct_9fa48("486") ? {} : (stryCov_9fa48("486"), {
  concept: stryMutAct_9fa48("487") ? "" : (stryCov_9fa48("487"), "entertainment"),
  nature: stryMutAct_9fa48("488") ? "" : (stryCov_9fa48("488"), "Expense"),
  aliases: stryMutAct_9fa48("489") ? [] : (stryCov_9fa48("489"), [stryMutAct_9fa48("490") ? "" : (stryCov_9fa48("490"), "entretenimiento"), stryMutAct_9fa48("491") ? "" : (stryCov_9fa48("491"), "entertainment"), stryMutAct_9fa48("492") ? "" : (stryCov_9fa48("492"), "ocio")]),
  co: stryMutAct_9fa48("493") ? "" : (stryCov_9fa48("493"), "51959507"),
  us: stryMutAct_9fa48("494") ? "" : (stryCov_9fa48("494"), "5560")
})])) satisfies Array<{
  concept: string;
  nature: CategoryNature;
  aliases: string[];
  co: string;
  us: string;
}>;
export function normalizeCategoryName(name: string): string {
  if (stryMutAct_9fa48("495")) {
    {}
  } else {
    stryCov_9fa48("495");
    return stryMutAct_9fa48("497") ? name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().trim().replace(/\s+/g, " ") : stryMutAct_9fa48("496") ? name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\s+/g, " ") : (stryCov_9fa48("496", "497"), name.normalize(stryMutAct_9fa48("498") ? "" : (stryCov_9fa48("498"), "NFD")).replace(stryMutAct_9fa48("499") ? /[^\u0300-\u036f]/g : (stryCov_9fa48("499"), /[\u0300-\u036f]/g), stryMutAct_9fa48("500") ? "Stryker was here!" : (stryCov_9fa48("500"), "")).toLowerCase().trim().replace(stryMutAct_9fa48("502") ? /\S+/g : stryMutAct_9fa48("501") ? /\s/g : (stryCov_9fa48("501", "502"), /\s+/g), stryMutAct_9fa48("503") ? "" : (stryCov_9fa48("503"), " ")));
  }
}
function distance(a: string, b: string): number {
  if (stryMutAct_9fa48("504")) {
    {}
  } else {
    stryCov_9fa48("504");
    let previous = Array.from(stryMutAct_9fa48("505") ? {} : (stryCov_9fa48("505"), {
      length: stryMutAct_9fa48("506") ? b.length - 1 : (stryCov_9fa48("506"), b.length + 1)
    }), stryMutAct_9fa48("507") ? () => undefined : (stryCov_9fa48("507"), (_, i) => i));
    for (let i = 1; stryMutAct_9fa48("510") ? i > a.length : stryMutAct_9fa48("509") ? i < a.length : stryMutAct_9fa48("508") ? false : (stryCov_9fa48("508", "509", "510"), i <= a.length); stryMutAct_9fa48("511") ? i-- : (stryCov_9fa48("511"), i++)) {
      if (stryMutAct_9fa48("512")) {
        {}
      } else {
        stryCov_9fa48("512");
        const next = stryMutAct_9fa48("513") ? [] : (stryCov_9fa48("513"), [i]);
        for (let j = 1; stryMutAct_9fa48("516") ? j > b.length : stryMutAct_9fa48("515") ? j < b.length : stryMutAct_9fa48("514") ? false : (stryCov_9fa48("514", "515", "516"), j <= b.length); stryMutAct_9fa48("517") ? j-- : (stryCov_9fa48("517"), j++)) next[j] = stryMutAct_9fa48("518") ? Math.max((next[j - 1] ?? 0) + 1, (previous[j] ?? 0) + 1, (previous[j - 1] ?? 0) + (a[i - 1] === b[j - 1] ? 0 : 1)) : (stryCov_9fa48("518"), Math.min(stryMutAct_9fa48("519") ? (next[j - 1] ?? 0) - 1 : (stryCov_9fa48("519"), (stryMutAct_9fa48("520") ? next[j - 1] && 0 : (stryCov_9fa48("520"), next[stryMutAct_9fa48("521") ? j + 1 : (stryCov_9fa48("521"), j - 1)] ?? 0)) + 1), stryMutAct_9fa48("522") ? (previous[j] ?? 0) - 1 : (stryCov_9fa48("522"), (stryMutAct_9fa48("523") ? previous[j] && 0 : (stryCov_9fa48("523"), previous[j] ?? 0)) + 1), stryMutAct_9fa48("524") ? (previous[j - 1] ?? 0) - (a[i - 1] === b[j - 1] ? 0 : 1) : (stryCov_9fa48("524"), (stryMutAct_9fa48("525") ? previous[j - 1] && 0 : (stryCov_9fa48("525"), previous[stryMutAct_9fa48("526") ? j + 1 : (stryCov_9fa48("526"), j - 1)] ?? 0)) + ((stryMutAct_9fa48("529") ? a[i - 1] !== b[j - 1] : stryMutAct_9fa48("528") ? false : stryMutAct_9fa48("527") ? true : (stryCov_9fa48("527", "528", "529"), a[stryMutAct_9fa48("530") ? i + 1 : (stryCov_9fa48("530"), i - 1)] === b[stryMutAct_9fa48("531") ? j + 1 : (stryCov_9fa48("531"), j - 1)])) ? 0 : 1))));
        previous = next;
      }
    }
    return stryMutAct_9fa48("532") ? previous[b.length] && a.length : (stryCov_9fa48("532"), previous[b.length] ?? a.length);
  }
}
function matches(name: string, aliases: string[]): number {
  if (stryMutAct_9fa48("533")) {
    {}
  } else {
    stryCov_9fa48("533");
    const normalized = normalizeCategoryName(name);
    return stryMutAct_9fa48("534") ? Math.max(...aliases.map(alias => {
      const d = distance(normalized, alias);
      return d === 0 || normalized.length >= 4 && alias.length >= 4 && d <= 1 ? d : Infinity;
    })) : (stryCov_9fa48("534"), Math.min(...aliases.map(alias => {
      if (stryMutAct_9fa48("535")) {
        {}
      } else {
        stryCov_9fa48("535");
        const d = distance(normalized, alias);
        return (stryMutAct_9fa48("538") ? d === 0 && normalized.length >= 4 && alias.length >= 4 && d <= 1 : stryMutAct_9fa48("537") ? false : stryMutAct_9fa48("536") ? true : (stryCov_9fa48("536", "537", "538"), (stryMutAct_9fa48("540") ? d !== 0 : stryMutAct_9fa48("539") ? false : (stryCov_9fa48("539", "540"), d === 0)) || (stryMutAct_9fa48("542") ? normalized.length >= 4 && alias.length >= 4 || d <= 1 : stryMutAct_9fa48("541") ? false : (stryCov_9fa48("541", "542"), (stryMutAct_9fa48("544") ? normalized.length >= 4 || alias.length >= 4 : stryMutAct_9fa48("543") ? true : (stryCov_9fa48("543", "544"), (stryMutAct_9fa48("547") ? normalized.length < 4 : stryMutAct_9fa48("546") ? normalized.length > 4 : stryMutAct_9fa48("545") ? true : (stryCov_9fa48("545", "546", "547"), normalized.length >= 4)) && (stryMutAct_9fa48("550") ? alias.length < 4 : stryMutAct_9fa48("549") ? alias.length > 4 : stryMutAct_9fa48("548") ? true : (stryCov_9fa48("548", "549", "550"), alias.length >= 4)))) && (stryMutAct_9fa48("553") ? d > 1 : stryMutAct_9fa48("552") ? d < 1 : stryMutAct_9fa48("551") ? true : (stryCov_9fa48("551", "552", "553"), d <= 1)))))) ? d : Infinity;
      }
    })));
  }
}
export function suggestCategoryNature(name: string) {
  if (stryMutAct_9fa48("554")) {
    {}
  } else {
    stryCov_9fa48("554");
    const candidates: Array<{
      answer: NatureAnswer;
      distance: number;
    }> = categoryPresets.map(stryMutAct_9fa48("555") ? () => undefined : (stryCov_9fa48("555"), p => stryMutAct_9fa48("556") ? {} : (stryCov_9fa48("556"), {
      answer: p.nature,
      distance: matches(name, p.aliases)
    })));
    candidates.push(stryMutAct_9fa48("558") ? {} : (stryCov_9fa48("558"), {
      answer: stryMutAct_9fa48("559") ? "" : (stryCov_9fa48("559"), "stillMine"),
      distance: matches(name, stryMutAct_9fa48("560") ? [] : (stryCov_9fa48("560"), [stryMutAct_9fa48("561") ? "" : (stryCov_9fa48("561"), "ahorro"), stryMutAct_9fa48("562") ? "" : (stryCov_9fa48("562"), "savings"), stryMutAct_9fa48("563") ? "" : (stryCov_9fa48("563"), "inversion"), stryMutAct_9fa48("564") ? "" : (stryCov_9fa48("564"), "investment"), stryMutAct_9fa48("565") ? "" : (stryCov_9fa48("565"), "prestamo a una persona")]))
    }), stryMutAct_9fa48("566") ? {} : (stryCov_9fa48("566"), {
      answer: stryMutAct_9fa48("567") ? "" : (stryCov_9fa48("567"), "payingDebt"),
      distance: matches(name, stryMutAct_9fa48("568") ? [] : (stryCov_9fa48("568"), [stryMutAct_9fa48("569") ? "" : (stryCov_9fa48("569"), "pago tarjeta"), stryMutAct_9fa48("570") ? "" : (stryCov_9fa48("570"), "card payment"), stryMutAct_9fa48("571") ? "" : (stryCov_9fa48("571"), "deuda"), stryMutAct_9fa48("572") ? "" : (stryCov_9fa48("572"), "debt payment")]))
    }));
    const normalized = normalizeCategoryName(name);
    if (stryMutAct_9fa48("574") ? false : stryMutAct_9fa48("573") ? true : (stryCov_9fa48("573", "574"), (stryMutAct_9fa48("575") ? /(prestamo a |loan to )/ : (stryCov_9fa48("575"), /^(prestamo a |loan to )/)).test(normalized))) candidates.push(stryMutAct_9fa48("577") ? {} : (stryCov_9fa48("577"), {
      answer: stryMutAct_9fa48("578") ? "" : (stryCov_9fa48("578"), "stillMine"),
      distance: 0
    }));
    if (stryMutAct_9fa48("580") ? false : stryMutAct_9fa48("579") ? true : (stryCov_9fa48("579", "580"), (stryMutAct_9fa48("581") ? /(deuda con |debt to )/ : (stryCov_9fa48("581"), /^(deuda con |debt to )/)).test(normalized))) candidates.push(stryMutAct_9fa48("583") ? {} : (stryCov_9fa48("583"), {
      answer: stryMutAct_9fa48("584") ? "" : (stryCov_9fa48("584"), "payingDebt"),
      distance: 0
    }));
    const best = stryMutAct_9fa48("585") ? Math.max(...candidates.map(c => c.distance)) : (stryCov_9fa48("585"), Math.min(...candidates.map(stryMutAct_9fa48("586") ? () => undefined : (stryCov_9fa48("586"), c => c.distance))));
    return stryMutAct_9fa48("587") ? {} : (stryCov_9fa48("587"), {
      policy: categoryPolicy,
      suggestions: Number.isFinite(best) ? stryMutAct_9fa48("588") ? [...new Set(candidates.filter(c => c.distance === best).map(c => c.answer))] : (stryCov_9fa48("588"), (stryMutAct_9fa48("589") ? [] : (stryCov_9fa48("589"), [...new Set(stryMutAct_9fa48("590") ? candidates.map(c => c.answer) : (stryCov_9fa48("590"), candidates.filter(stryMutAct_9fa48("591") ? () => undefined : (stryCov_9fa48("591"), c => stryMutAct_9fa48("594") ? c.distance !== best : stryMutAct_9fa48("593") ? false : stryMutAct_9fa48("592") ? true : (stryCov_9fa48("592", "593", "594"), c.distance === best))).map(stryMutAct_9fa48("595") ? () => undefined : (stryCov_9fa48("595"), c => c.answer))))])).sort()) : stryMutAct_9fa48("596") ? ["Stryker was here"] : (stryCov_9fa48("596"), []),
      requiresConfirmation: true as const
    });
  }
}
export function assertCategoryAccount(templateVersion: string, nature: CategoryNature, code: string): void {
  if (stryMutAct_9fa48("597")) {
    {}
  } else {
    stryCov_9fa48("597");
    const account = chartTemplate(templateVersion).accounts.find(stryMutAct_9fa48("598") ? () => undefined : (stryCov_9fa48("598"), a => stryMutAct_9fa48("601") ? a.code !== code : stryMutAct_9fa48("600") ? false : stryMutAct_9fa48("599") ? true : (stryCov_9fa48("599", "600", "601"), a.code === code)));
    if (stryMutAct_9fa48("604") ? false : stryMutAct_9fa48("603") ? true : stryMutAct_9fa48("602") ? account : (stryCov_9fa48("602", "603", "604"), !account)) throw new AccountingError(stryMutAct_9fa48("606") ? "" : (stryCov_9fa48("606"), "ledger_account_code_unknown"));
    if (stryMutAct_9fa48("609") ? account.use === (nature === "Expense" ? "expense" : "income") : stryMutAct_9fa48("608") ? false : stryMutAct_9fa48("607") ? true : (stryCov_9fa48("607", "608", "609"), account.use !== ((stryMutAct_9fa48("612") ? nature !== "Expense" : stryMutAct_9fa48("611") ? false : stryMutAct_9fa48("610") ? true : (stryCov_9fa48("610", "611", "612"), nature === (stryMutAct_9fa48("613") ? "" : (stryCov_9fa48("613"), "Expense")))) ? stryMutAct_9fa48("614") ? "" : (stryCov_9fa48("614"), "expense") : stryMutAct_9fa48("615") ? "" : (stryCov_9fa48("615"), "income")))) throw new AccountingError((stryMutAct_9fa48("619") ? nature !== "Expense" : stryMutAct_9fa48("618") ? false : stryMutAct_9fa48("617") ? true : (stryCov_9fa48("617", "618", "619"), nature === (stryMutAct_9fa48("620") ? "" : (stryCov_9fa48("620"), "Expense")))) ? stryMutAct_9fa48("621") ? "" : (stryCov_9fa48("621"), "cash_expense_account_invalid") : stryMutAct_9fa48("622") ? "" : (stryCov_9fa48("622"), "cash_income_account_invalid"));
  }
}
function presetAccount(templateVersion: string, preset: typeof categoryPresets[number]): string {
  if (stryMutAct_9fa48("623")) {
    {}
  } else {
    stryCov_9fa48("623");
    const code = (stryMutAct_9fa48("626") ? templateVersion !== "co-puc-personal@1" : stryMutAct_9fa48("625") ? false : stryMutAct_9fa48("624") ? true : (stryCov_9fa48("624", "625", "626"), templateVersion === (stryMutAct_9fa48("627") ? "" : (stryCov_9fa48("627"), "co-puc-personal@1")))) ? preset.co : (stryMutAct_9fa48("630") ? templateVersion !== "us-gaap-personal@1" : stryMutAct_9fa48("629") ? false : stryMutAct_9fa48("628") ? true : (stryCov_9fa48("628", "629", "630"), templateVersion === (stryMutAct_9fa48("631") ? "" : (stryCov_9fa48("631"), "us-gaap-personal@1")))) ? preset.us : undefined;
    if (stryMutAct_9fa48("634") ? false : stryMutAct_9fa48("633") ? true : stryMutAct_9fa48("632") ? code : (stryCov_9fa48("632", "633", "634"), !code)) throw new AccountingError(stryMutAct_9fa48("636") ? "" : (stryCov_9fa48("636"), "chart_of_accounts_template_unknown"));
    if (stryMutAct_9fa48("637")) {
      ;
    } else {
      stryCov_9fa48("637");
      assertCategoryAccount(templateVersion, preset.nature, code);
    }
    return code;
  }
}
export function resolveCategoryAccount(templateVersion: string, name: string, nature: CategoryNature): AccountResolution {
  if (stryMutAct_9fa48("638")) {
    {}
  } else {
    stryCov_9fa48("638");
    const candidates = stryMutAct_9fa48("639") ? categoryPresets.map(p => ({
      preset: p,
      distance: matches(name, p.aliases)
    })) : (stryCov_9fa48("639"), categoryPresets.filter(stryMutAct_9fa48("640") ? () => undefined : (stryCov_9fa48("640"), p => stryMutAct_9fa48("643") ? p.nature !== nature : stryMutAct_9fa48("642") ? false : stryMutAct_9fa48("641") ? true : (stryCov_9fa48("641", "642", "643"), p.nature === nature))).map(stryMutAct_9fa48("644") ? () => undefined : (stryCov_9fa48("644"), p => stryMutAct_9fa48("645") ? {} : (stryCov_9fa48("645"), {
      preset: p,
      distance: matches(name, p.aliases)
    }))));
    const best = stryMutAct_9fa48("646") ? Math.max(...candidates.map(c => c.distance)) : (stryCov_9fa48("646"), Math.min(...candidates.map(stryMutAct_9fa48("647") ? () => undefined : (stryCov_9fa48("647"), c => c.distance))));
    const winners = stryMutAct_9fa48("649") ? candidates.map(c => c.preset).sort((a, b) => a.concept.localeCompare(b.concept)) : stryMutAct_9fa48("648") ? candidates.filter(c => Number.isFinite(best) && c.distance === best).map(c => c.preset) : (stryCov_9fa48("648", "649"), candidates.filter(stryMutAct_9fa48("650") ? () => undefined : (stryCov_9fa48("650"), c => stryMutAct_9fa48("653") ? Number.isFinite(best) || c.distance === best : stryMutAct_9fa48("652") ? false : stryMutAct_9fa48("651") ? true : (stryCov_9fa48("651", "652", "653"), Number.isFinite(best) && (stryMutAct_9fa48("655") ? c.distance !== best : stryMutAct_9fa48("654") ? true : (stryCov_9fa48("654", "655"), c.distance === best))))).map(stryMutAct_9fa48("656") ? () => undefined : (stryCov_9fa48("656"), c => c.preset)).sort(stryMutAct_9fa48("657") ? () => undefined : (stryCov_9fa48("657"), (a, b) => a.concept.localeCompare(b.concept))));
    const winner = (stryMutAct_9fa48("660") ? winners.length !== 1 : stryMutAct_9fa48("659") ? false : stryMutAct_9fa48("658") ? true : (stryCov_9fa48("658", "659", "660"), winners.length === 1)) ? winners[0] : undefined;
    if (stryMutAct_9fa48("662") ? false : stryMutAct_9fa48("661") ? true : (stryCov_9fa48("661", "662"), winner)) return stryMutAct_9fa48("663") ? {} : (stryCov_9fa48("663"), {
      kind: stryMutAct_9fa48("664") ? "" : (stryCov_9fa48("664"), "lexicon"),
      concept: winner.concept,
      policy: categoryPolicy,
      accountCode: presetAccount(templateVersion, winner)
    });
    const template = chartTemplate(templateVersion);
    return stryMutAct_9fa48("665") ? {} : (stryCov_9fa48("665"), {
      kind: stryMutAct_9fa48("666") ? "" : (stryCov_9fa48("666"), "fallback"),
      policy: categoryPolicy,
      accountCode: template.defaults[(stryMutAct_9fa48("669") ? nature !== "Expense" : stryMutAct_9fa48("668") ? false : stryMutAct_9fa48("667") ? true : (stryCov_9fa48("667", "668", "669"), nature === (stryMutAct_9fa48("670") ? "" : (stryCov_9fa48("670"), "Expense")))) ? stryMutAct_9fa48("671") ? "" : (stryCov_9fa48("671"), "expense") : stryMutAct_9fa48("672") ? "" : (stryCov_9fa48("672"), "income")],
      candidates: winners.map(stryMutAct_9fa48("673") ? () => undefined : (stryCov_9fa48("673"), p => p.concept))
    });
  }
}
export function resolvePreset(templateVersion: string, concept: string) {
  if (stryMutAct_9fa48("674")) {
    {}
  } else {
    stryCov_9fa48("674");
    const preset = categoryPresets.find(stryMutAct_9fa48("675") ? () => undefined : (stryCov_9fa48("675"), p => stryMutAct_9fa48("678") ? p.concept !== concept : stryMutAct_9fa48("677") ? false : stryMutAct_9fa48("676") ? true : (stryCov_9fa48("676", "677", "678"), p.concept === concept)));
    if (stryMutAct_9fa48("681") ? false : stryMutAct_9fa48("680") ? true : stryMutAct_9fa48("679") ? preset : (stryCov_9fa48("679", "680", "681"), !preset)) throw new AccountingError(stryMutAct_9fa48("683") ? "" : (stryCov_9fa48("683"), "category_preset_unknown"));
    return stryMutAct_9fa48("684") ? {} : (stryCov_9fa48("684"), {
      kind: "resolved" as const,
      nature: preset.nature,
      natureProvenance: stryMutAct_9fa48("685") ? {} : (stryCov_9fa48("685"), {
        kind: "preset" as const,
        concept
      }),
      account: stryMutAct_9fa48("686") ? {} : (stryCov_9fa48("686"), {
        kind: "preset" as const,
        concept,
        policy: categoryPolicy,
        accountCode: presetAccount(templateVersion, preset)
      })
    });
  }
}