// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { commandIdentity } from "./commandIdentity";
import { AccountingError } from "./errors";
import { requireWorkspace } from "./membership";
import { assertCategoryAccount, categoryPolicy, resolveCategoryAccount, resolvePreset, suggestCategoryNature } from "./categoryPolicy";
import type { AccountingStore } from "./types";
import type { CategoryScope, CategorySnapshot, CreateCategoryInput, ChangeCategoryInput, UserCategory, CategoryClassification } from "./categoryTypes";
export async function requireCategory(store: Pick<AccountingStore, "getCategory">, workspaceId: string, id: string): Promise<UserCategory> {
  if (stryMutAct_9fa48("125")) {
    {}
  } else {
    stryCov_9fa48("125");
    const category = await store.getCategory(id);
    if (stryMutAct_9fa48("128") ? !category && category.workspaceId !== workspaceId : stryMutAct_9fa48("127") ? false : stryMutAct_9fa48("126") ? true : (stryCov_9fa48("126", "127", "128"), (stryMutAct_9fa48("129") ? category : (stryCov_9fa48("129"), !category)) || (stryMutAct_9fa48("131") ? category.workspaceId === workspaceId : stryMutAct_9fa48("130") ? false : (stryCov_9fa48("130", "131"), category.workspaceId !== workspaceId)))) throw new AccountingError(stryMutAct_9fa48("133") ? "" : (stryCov_9fa48("133"), "category_not_found"));
    return category;
  }
}
export function categorySnapshot(category: UserCategory): CategorySnapshot {
  if (stryMutAct_9fa48("134")) {
    {}
  } else {
    stryCov_9fa48("134");
    if (stryMutAct_9fa48("137") ? category.classification.kind === "resolved" : stryMutAct_9fa48("136") ? false : stryMutAct_9fa48("135") ? true : (stryCov_9fa48("135", "136", "137"), category.classification.kind !== (stryMutAct_9fa48("138") ? "" : (stryCov_9fa48("138"), "resolved")))) throw new AccountingError(stryMutAct_9fa48("140") ? "" : (stryCov_9fa48("140"), "category_unresolved"));
    return stryMutAct_9fa48("141") ? {} : (stryCov_9fa48("141"), {
      categoryId: category.id,
      revision: category.revision,
      name: category.name,
      nature: category.classification.nature,
      natureProvenance: category.classification.natureProvenance,
      account: category.classification.account
    });
  }
}
export async function createUserCategory(store: AccountingStore, input: CreateCategoryInput) {
  if (stryMutAct_9fa48("142")) {
    {}
  } else {
    stryCov_9fa48("142");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("143") ? "" : (stryCov_9fa48("143"), "prepare"));
    const name = stryMutAct_9fa48("144") ? input.name : (stryCov_9fa48("144"), input.name.trim());
    if (stryMutAct_9fa48("147") ? false : stryMutAct_9fa48("146") ? true : stryMutAct_9fa48("145") ? name : (stryCov_9fa48("145", "146", "147"), !name)) throw new AccountingError(stryMutAct_9fa48("149") ? "" : (stryCov_9fa48("149"), "name_required"));
    if (stryMutAct_9fa48("152") ? false : stryMutAct_9fa48("151") ? true : stryMutAct_9fa48("150") ? input.idempotencyKey : (stryCov_9fa48("150", "151", "152"), !input.idempotencyKey)) throw new AccountingError(stryMutAct_9fa48("154") ? "" : (stryCov_9fa48("154"), "idempotency_key_required"));
    const selection = input.selection;
    const request = commandIdentity(stryMutAct_9fa48("155") ? {} : (stryCov_9fa48("155"), {
      command: stryMutAct_9fa48("156") ? "" : (stryCov_9fa48("156"), "create"),
      name,
      selection
    }));
    const receipt = await store.getCategoryReceipt(input.workspaceId, input.idempotencyKey);
    if (stryMutAct_9fa48("158") ? false : stryMutAct_9fa48("157") ? true : (stryCov_9fa48("157", "158"), receipt)) {
      if (stryMutAct_9fa48("159")) {
        {}
      } else {
        stryCov_9fa48("159");
        if (stryMutAct_9fa48("162") ? receipt.request === request : stryMutAct_9fa48("161") ? false : stryMutAct_9fa48("160") ? true : (stryCov_9fa48("160", "161", "162"), receipt.request !== request)) throw new AccountingError(stryMutAct_9fa48("164") ? "" : (stryCov_9fa48("164"), "idempotency_key_conflict"));
        return stryMutAct_9fa48("165") ? {} : (stryCov_9fa48("165"), {
          kind: "category" as const,
          category: receipt.category,
          replay: stryMutAct_9fa48("166") ? false : (stryCov_9fa48("166"), true)
        });
      }
    }
    if (stryMutAct_9fa48("169") ? selection.kind === "custom" && selection.confirmation === "lexiconConfirmed" || !suggestCategoryNature(name).suggestions.includes(selection.answer) : stryMutAct_9fa48("168") ? false : stryMutAct_9fa48("167") ? true : (stryCov_9fa48("167", "168", "169"), (stryMutAct_9fa48("171") ? selection.kind === "custom" || selection.confirmation === "lexiconConfirmed" : stryMutAct_9fa48("170") ? true : (stryCov_9fa48("170", "171"), (stryMutAct_9fa48("173") ? selection.kind !== "custom" : stryMutAct_9fa48("172") ? true : (stryCov_9fa48("172", "173"), selection.kind === (stryMutAct_9fa48("174") ? "" : (stryCov_9fa48("174"), "custom")))) && (stryMutAct_9fa48("176") ? selection.confirmation !== "lexiconConfirmed" : stryMutAct_9fa48("175") ? true : (stryCov_9fa48("175", "176"), selection.confirmation === (stryMutAct_9fa48("177") ? "" : (stryCov_9fa48("177"), "lexiconConfirmed")))))) && (stryMutAct_9fa48("178") ? suggestCategoryNature(name).suggestions.includes(selection.answer) : (stryCov_9fa48("178"), !suggestCategoryNature(name).suggestions.includes(selection.answer))))) throw new AccountingError(stryMutAct_9fa48("180") ? "" : (stryCov_9fa48("180"), "category_suggestion_invalid"));
    if (stryMutAct_9fa48("183") ? selection.kind === "custom" || selection.answer === "stillMine" || selection.answer === "payingDebt" : stryMutAct_9fa48("182") ? false : stryMutAct_9fa48("181") ? true : (stryCov_9fa48("181", "182", "183"), (stryMutAct_9fa48("185") ? selection.kind !== "custom" : stryMutAct_9fa48("184") ? true : (stryCov_9fa48("184", "185"), selection.kind === (stryMutAct_9fa48("186") ? "" : (stryCov_9fa48("186"), "custom")))) && (stryMutAct_9fa48("188") ? selection.answer === "stillMine" && selection.answer === "payingDebt" : stryMutAct_9fa48("187") ? true : (stryCov_9fa48("187", "188"), (stryMutAct_9fa48("190") ? selection.answer !== "stillMine" : stryMutAct_9fa48("189") ? false : (stryCov_9fa48("189", "190"), selection.answer === (stryMutAct_9fa48("191") ? "" : (stryCov_9fa48("191"), "stillMine")))) || (stryMutAct_9fa48("193") ? selection.answer !== "payingDebt" : stryMutAct_9fa48("192") ? false : (stryCov_9fa48("192", "193"), selection.answer === (stryMutAct_9fa48("194") ? "" : (stryCov_9fa48("194"), "payingDebt")))))))) return stryMutAct_9fa48("195") ? {} : (stryCov_9fa48("195"), {
      kind: "profileRequired" as const,
      answer: selection.answer
    });
    let classification: CategoryClassification;
    if (stryMutAct_9fa48("198") ? selection.kind !== "preset" : stryMutAct_9fa48("197") ? false : stryMutAct_9fa48("196") ? true : (stryCov_9fa48("196", "197", "198"), selection.kind === (stryMutAct_9fa48("199") ? "" : (stryCov_9fa48("199"), "preset")))) classification = resolvePreset(workspace.chartOfAccountsTemplate, selection.concept);else {
      if (stryMutAct_9fa48("200")) {
        {}
      } else {
        stryCov_9fa48("200");
        const answer = selection.answer;
        if (stryMutAct_9fa48("203") ? answer !== "Expense" || answer !== "Income" : stryMutAct_9fa48("202") ? false : stryMutAct_9fa48("201") ? true : (stryCov_9fa48("201", "202", "203"), (stryMutAct_9fa48("205") ? answer === "Expense" : stryMutAct_9fa48("204") ? true : (stryCov_9fa48("204", "205"), answer !== (stryMutAct_9fa48("206") ? "" : (stryCov_9fa48("206"), "Expense")))) && (stryMutAct_9fa48("208") ? answer === "Income" : stryMutAct_9fa48("207") ? true : (stryCov_9fa48("207", "208"), answer !== (stryMutAct_9fa48("209") ? "" : (stryCov_9fa48("209"), "Income")))))) throw new AccountingError(stryMutAct_9fa48("211") ? "" : (stryCov_9fa48("211"), "category_nature_mismatch"));
        classification = stryMutAct_9fa48("212") ? {} : (stryCov_9fa48("212"), {
          kind: stryMutAct_9fa48("213") ? "" : (stryCov_9fa48("213"), "resolved"),
          nature: answer,
          natureProvenance: (stryMutAct_9fa48("216") ? selection.confirmation !== "answered" : stryMutAct_9fa48("215") ? false : stryMutAct_9fa48("214") ? true : (stryCov_9fa48("214", "215", "216"), selection.confirmation === (stryMutAct_9fa48("217") ? "" : (stryCov_9fa48("217"), "answered")))) ? stryMutAct_9fa48("218") ? {} : (stryCov_9fa48("218"), {
            kind: stryMutAct_9fa48("219") ? "" : (stryCov_9fa48("219"), "answered")
          }) : stryMutAct_9fa48("220") ? {} : (stryCov_9fa48("220"), {
            kind: stryMutAct_9fa48("221") ? "" : (stryCov_9fa48("221"), "lexiconConfirmed"),
            policy: categoryPolicy,
            answer
          }),
          account: resolveCategoryAccount(workspace.chartOfAccountsTemplate, name, answer)
        });
      }
    }
    const category = await store.insertCategory(stryMutAct_9fa48("222") ? {} : (stryCov_9fa48("222"), {
      workspaceId: input.workspaceId,
      name,
      revision: 1,
      status: stryMutAct_9fa48("223") ? "" : (stryCov_9fa48("223"), "active"),
      classification
    }));
    await store.saveCategoryReceipt(stryMutAct_9fa48("224") ? {} : (stryCov_9fa48("224"), {
      workspaceId: input.workspaceId,
      idempotencyKey: input.idempotencyKey,
      request,
      category,
      correctionEntryIds: stryMutAct_9fa48("225") ? ["Stryker was here"] : (stryCov_9fa48("225"), [])
    }));
    return stryMutAct_9fa48("226") ? {} : (stryCov_9fa48("226"), {
      kind: "category" as const,
      category,
      replay: stryMutAct_9fa48("227") ? true : (stryCov_9fa48("227"), false)
    });
  }
}
export async function changeUserCategory(store: AccountingStore, input: ChangeCategoryInput) {
  if (stryMutAct_9fa48("228")) {
    {}
  } else {
    stryCov_9fa48("228");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("229") ? "" : (stryCov_9fa48("229"), "prepare"));
    if (stryMutAct_9fa48("232") ? false : stryMutAct_9fa48("231") ? true : stryMutAct_9fa48("230") ? input.confirmed : (stryCov_9fa48("230", "231", "232"), !input.confirmed)) throw new AccountingError(stryMutAct_9fa48("234") ? "" : (stryCov_9fa48("234"), "category_confirmation_required"));
    if (stryMutAct_9fa48("237") ? false : stryMutAct_9fa48("236") ? true : stryMutAct_9fa48("235") ? input.idempotencyKey : (stryCov_9fa48("235", "236", "237"), !input.idempotencyKey)) throw new AccountingError(stryMutAct_9fa48("239") ? "" : (stryCov_9fa48("239"), "idempotency_key_required"));
    const request = commandIdentity(stryMutAct_9fa48("240") ? {} : (stryCov_9fa48("240"), {
      command: stryMutAct_9fa48("241") ? "" : (stryCov_9fa48("241"), "change"),
      categoryId: input.categoryId,
      revision: input.revision,
      change: input.change
    }));
    const receipt = await store.getCategoryReceipt(input.workspaceId, input.idempotencyKey);
    if (stryMutAct_9fa48("243") ? false : stryMutAct_9fa48("242") ? true : (stryCov_9fa48("242", "243"), receipt)) {
      if (stryMutAct_9fa48("244")) {
        {}
      } else {
        stryCov_9fa48("244");
        if (stryMutAct_9fa48("247") ? receipt.request === request : stryMutAct_9fa48("246") ? false : stryMutAct_9fa48("245") ? true : (stryCov_9fa48("245", "246", "247"), receipt.request !== request)) throw new AccountingError(stryMutAct_9fa48("249") ? "" : (stryCov_9fa48("249"), "idempotency_key_conflict"));
        return stryMutAct_9fa48("250") ? {} : (stryCov_9fa48("250"), {
          category: receipt.category,
          replay: stryMutAct_9fa48("251") ? false : (stryCov_9fa48("251"), true)
        });
      }
    }
    const category = await requireCategory(store, input.workspaceId, input.categoryId);
    if (stryMutAct_9fa48("254") ? category.revision === input.revision : stryMutAct_9fa48("253") ? false : stryMutAct_9fa48("252") ? true : (stryCov_9fa48("252", "253", "254"), category.revision !== input.revision)) throw new AccountingError(stryMutAct_9fa48("256") ? "" : (stryCov_9fa48("256"), "category_revision_stale"));
    if (stryMutAct_9fa48("259") ? category.status === "active" : stryMutAct_9fa48("258") ? false : stryMutAct_9fa48("257") ? true : (stryCov_9fa48("257", "258", "259"), category.status !== (stryMutAct_9fa48("260") ? "" : (stryCov_9fa48("260"), "active")))) throw new AccountingError(stryMutAct_9fa48("262") ? "" : (stryCov_9fa48("262"), "category_inactive"));
    const updated = stryMutAct_9fa48("263") ? {} : (stryCov_9fa48("263"), {
      ...category,
      revision: stryMutAct_9fa48("264") ? category.revision - 1 : (stryCov_9fa48("264"), category.revision + 1)
    });
    switch (input.change.kind) {
      case stryMutAct_9fa48("266") ? "" : (stryCov_9fa48("266"), "rename"):
        if (stryMutAct_9fa48("265")) {} else {
          stryCov_9fa48("265");
          updated.name = stryMutAct_9fa48("267") ? input.change.name : (stryCov_9fa48("267"), input.change.name.trim());
          if (stryMutAct_9fa48("270") ? false : stryMutAct_9fa48("269") ? true : stryMutAct_9fa48("268") ? updated.name : (stryCov_9fa48("268", "269", "270"), !updated.name)) throw new AccountingError(stryMutAct_9fa48("272") ? "" : (stryCov_9fa48("272"), "name_required"));
          break;
        }
      case stryMutAct_9fa48("274") ? "" : (stryCov_9fa48("274"), "archive"):
        if (stryMutAct_9fa48("273")) {} else {
          stryCov_9fa48("273");
          updated.status = stryMutAct_9fa48("275") ? "" : (stryCov_9fa48("275"), "archived");
          break;
        }
      case stryMutAct_9fa48("277") ? "" : (stryCov_9fa48("277"), "merge"):
        if (stryMutAct_9fa48("276")) {} else {
          stryCov_9fa48("276");
          {
            if (stryMutAct_9fa48("278")) {
              {}
            } else {
              stryCov_9fa48("278");
              const target = await requireCategory(store, input.workspaceId, input.change.targetCategoryId);
              if (stryMutAct_9fa48("281") ? (target.id === category.id || target.status !== "active" || target.classification.kind !== "resolved" || category.classification.kind !== "resolved") && target.classification.nature !== category.classification.nature : stryMutAct_9fa48("280") ? false : stryMutAct_9fa48("279") ? true : (stryCov_9fa48("279", "280", "281"), (stryMutAct_9fa48("283") ? (target.id === category.id || target.status !== "active" || target.classification.kind !== "resolved") && category.classification.kind !== "resolved" : stryMutAct_9fa48("282") ? false : (stryCov_9fa48("282", "283"), (stryMutAct_9fa48("285") ? (target.id === category.id || target.status !== "active") && target.classification.kind !== "resolved" : stryMutAct_9fa48("284") ? false : (stryCov_9fa48("284", "285"), (stryMutAct_9fa48("287") ? target.id === category.id && target.status !== "active" : stryMutAct_9fa48("286") ? false : (stryCov_9fa48("286", "287"), (stryMutAct_9fa48("289") ? target.id !== category.id : stryMutAct_9fa48("288") ? false : (stryCov_9fa48("288", "289"), target.id === category.id)) || (stryMutAct_9fa48("291") ? target.status === "active" : stryMutAct_9fa48("290") ? false : (stryCov_9fa48("290", "291"), target.status !== (stryMutAct_9fa48("292") ? "" : (stryCov_9fa48("292"), "active")))))) || (stryMutAct_9fa48("294") ? target.classification.kind === "resolved" : stryMutAct_9fa48("293") ? false : (stryCov_9fa48("293", "294"), target.classification.kind !== (stryMutAct_9fa48("295") ? "" : (stryCov_9fa48("295"), "resolved")))))) || (stryMutAct_9fa48("297") ? category.classification.kind === "resolved" : stryMutAct_9fa48("296") ? false : (stryCov_9fa48("296", "297"), category.classification.kind !== (stryMutAct_9fa48("298") ? "" : (stryCov_9fa48("298"), "resolved")))))) || (stryMutAct_9fa48("300") ? target.classification.nature === category.classification.nature : stryMutAct_9fa48("299") ? false : (stryCov_9fa48("299", "300"), target.classification.nature !== category.classification.nature)))) throw new AccountingError(stryMutAct_9fa48("302") ? "" : (stryCov_9fa48("302"), "category_merge_invalid"));
              updated.status = stryMutAct_9fa48("303") ? "" : (stryCov_9fa48("303"), "archived");
              updated.mergedIntoCategoryId = target.id;
              break;
            }
          }
        }
      case stryMutAct_9fa48("305") ? "" : (stryCov_9fa48("305"), "defaultAccount"):
        if (stryMutAct_9fa48("304")) {} else {
          stryCov_9fa48("304");
          if (stryMutAct_9fa48("308") ? category.classification.kind === "resolved" : stryMutAct_9fa48("307") ? false : stryMutAct_9fa48("306") ? true : (stryCov_9fa48("306", "307", "308"), category.classification.kind !== (stryMutAct_9fa48("309") ? "" : (stryCov_9fa48("309"), "resolved")))) throw new AccountingError(stryMutAct_9fa48("311") ? "" : (stryCov_9fa48("311"), "category_unresolved"));
          if (stryMutAct_9fa48("312")) {
            ;
          } else {
            stryCov_9fa48("312");
            assertCategoryAccount(workspace.chartOfAccountsTemplate, category.classification.nature, input.change.accountCode);
          }
          updated.classification = stryMutAct_9fa48("313") ? {} : (stryCov_9fa48("313"), {
            ...category.classification,
            account: stryMutAct_9fa48("314") ? {} : (stryCov_9fa48("314"), {
              kind: stryMutAct_9fa48("315") ? "" : (stryCov_9fa48("315"), "advanced"),
              accountCode: input.change.accountCode
            })
          });
          break;
        }
      default:
        if (stryMutAct_9fa48("316")) {} else {
          stryCov_9fa48("316");
          {
            if (stryMutAct_9fa48("317")) {
              {}
            } else {
              stryCov_9fa48("317");
              const exhaustive: never = input.change;
              return exhaustive;
            }
          }
        }
    }
    await store.saveCategory(updated);
    await store.saveCategoryReceipt(stryMutAct_9fa48("318") ? {} : (stryCov_9fa48("318"), {
      workspaceId: input.workspaceId,
      idempotencyKey: input.idempotencyKey,
      request,
      category: updated,
      correctionEntryIds: stryMutAct_9fa48("319") ? ["Stryker was here"] : (stryCov_9fa48("319"), [])
    }));
    return stryMutAct_9fa48("320") ? {} : (stryCov_9fa48("320"), {
      category: updated,
      replay: stryMutAct_9fa48("321") ? true : (stryCov_9fa48("321"), false)
    });
  }
}
export async function listUserCategories(store: AccountingStore, input: CategoryScope) {
  if (stryMutAct_9fa48("322")) {
    {}
  } else {
    stryCov_9fa48("322");
    await requireWorkspace(store, input.workspaceId, input.actor);
    return stryMutAct_9fa48("323") ? await store.listCategories(input.workspaceId) : (stryCov_9fa48("323"), (await store.listCategories(input.workspaceId)).sort(stryMutAct_9fa48("324") ? () => undefined : (stryCov_9fa48("324"), (a, b) => a.id.localeCompare(b.id))));
  }
}
export async function categoryTotals(store: AccountingStore, input: CategoryScope) {
  if (stryMutAct_9fa48("325")) {
    {}
  } else {
    stryCov_9fa48("325");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor);
    const totals = new Map<string, {
      categoryId: string;
      year: number;
      month: number;
      expense: number;
      income: number;
    }>();
    for (const entry of await store.listJournalEntries(input.workspaceId)) for (const line of entry.lines) {
      if (stryMutAct_9fa48("326")) {
        {}
      } else {
        stryCov_9fa48("326");
        if (stryMutAct_9fa48("329") ? false : stryMutAct_9fa48("328") ? true : stryMutAct_9fa48("327") ? line.category : (stryCov_9fa48("327", "328", "329"), !line.category)) continue;
        const key = stryMutAct_9fa48("330") ? `` : (stryCov_9fa48("330"), `${line.category.categoryId}:${entry.period.year}:${entry.period.month}`);
        const total = stryMutAct_9fa48("331") ? totals.get(key) && {
          categoryId: line.category.categoryId,
          ...entry.period,
          expense: 0,
          income: 0
        } : (stryCov_9fa48("331"), totals.get(key) ?? (stryMutAct_9fa48("332") ? {} : (stryCov_9fa48("332"), {
          categoryId: line.category.categoryId,
          ...entry.period,
          expense: 0,
          income: 0
        })));
        const field = (stryMutAct_9fa48("335") ? line.category.nature !== "Expense" : stryMutAct_9fa48("334") ? false : stryMutAct_9fa48("333") ? true : (stryCov_9fa48("333", "334", "335"), line.category.nature === (stryMutAct_9fa48("336") ? "" : (stryCov_9fa48("336"), "Expense")))) ? stryMutAct_9fa48("337") ? "" : (stryCov_9fa48("337"), "expense") : stryMutAct_9fa48("338") ? "" : (stryCov_9fa48("338"), "income");
        stryMutAct_9fa48("339") ? total[field] -= field === "expense" ? line.debitMinorUnits - line.creditMinorUnits : line.creditMinorUnits - line.debitMinorUnits : (stryCov_9fa48("339"), total[field] += (stryMutAct_9fa48("342") ? field !== "expense" : stryMutAct_9fa48("341") ? false : stryMutAct_9fa48("340") ? true : (stryCov_9fa48("340", "341", "342"), field === (stryMutAct_9fa48("343") ? "" : (stryCov_9fa48("343"), "expense")))) ? stryMutAct_9fa48("344") ? line.debitMinorUnits + line.creditMinorUnits : (stryCov_9fa48("344"), line.debitMinorUnits - line.creditMinorUnits) : stryMutAct_9fa48("345") ? line.creditMinorUnits + line.debitMinorUnits : (stryCov_9fa48("345"), line.creditMinorUnits - line.debitMinorUnits));
        if (stryMutAct_9fa48("348") ? false : stryMutAct_9fa48("347") ? true : stryMutAct_9fa48("346") ? Number.isSafeInteger(total[field]) : (stryCov_9fa48("346", "347", "348"), !Number.isSafeInteger(total[field]))) throw new AccountingError(stryMutAct_9fa48("350") ? "" : (stryCov_9fa48("350"), "journal_line_invalid"));
        if (stryMutAct_9fa48("351")) {
          ;
        } else {
          stryCov_9fa48("351");
          totals.set(key, total);
        }
      }
    }
    return stryMutAct_9fa48("352") ? [...totals.values()].map(row => ({
      ...row,
      expense: {
        currency: workspace.functionalCurrency,
        minorUnits: row.expense
      },
      income: {
        currency: workspace.functionalCurrency,
        minorUnits: row.income
      }
    })) : (stryCov_9fa48("352"), (stryMutAct_9fa48("353") ? [] : (stryCov_9fa48("353"), [...totals.values()])).sort(stryMutAct_9fa48("354") ? () => undefined : (stryCov_9fa48("354"), (a, b) => stryMutAct_9fa48("357") ? (a.categoryId.localeCompare(b.categoryId) || a.year - b.year) && a.month - b.month : stryMutAct_9fa48("356") ? false : stryMutAct_9fa48("355") ? true : (stryCov_9fa48("355", "356", "357"), (stryMutAct_9fa48("359") ? a.categoryId.localeCompare(b.categoryId) && a.year - b.year : stryMutAct_9fa48("358") ? false : (stryCov_9fa48("358", "359"), a.categoryId.localeCompare(b.categoryId) || (stryMutAct_9fa48("360") ? a.year + b.year : (stryCov_9fa48("360"), a.year - b.year)))) || (stryMutAct_9fa48("361") ? a.month + b.month : (stryCov_9fa48("361"), a.month - b.month))))).map(stryMutAct_9fa48("362") ? () => undefined : (stryCov_9fa48("362"), row => stryMutAct_9fa48("363") ? {} : (stryCov_9fa48("363"), {
      ...row,
      expense: stryMutAct_9fa48("364") ? {} : (stryCov_9fa48("364"), {
        currency: workspace.functionalCurrency,
        minorUnits: row.expense
      }),
      income: stryMutAct_9fa48("365") ? {} : (stryCov_9fa48("365"), {
        currency: workspace.functionalCurrency,
        minorUnits: row.income
      })
    }))));
  }
}
export async function categoryNatureSuggestion(store: AccountingStore, input: CategoryScope & {
  name: string;
}) {
  if (stryMutAct_9fa48("366")) {
    {}
  } else {
    stryCov_9fa48("366");
    await requireWorkspace(store, input.workspaceId, input.actor);
    return suggestCategoryNature(input.name);
  }
}