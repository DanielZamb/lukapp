// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "./errors";
import type { AccountingStore, Actor, StoredWorkspace, WorkspaceRole } from "./types";
export type WorkspacePermission = "view" | "prepare" | "post" | "correct" | "manageRecoveryPlans" | "managePeriods" | "administerMembership" | "manageBudgets";
export const workspaceRolePolicyVersion = stryMutAct_9fa48("1488") ? "" : (stryCov_9fa48("1488"), "workspace-roles@3");
export const workspaceRolePolicy = (stryMutAct_9fa48("1489") ? {} : (stryCov_9fa48("1489"), {
  Owner: stryMutAct_9fa48("1490") ? [] : (stryCov_9fa48("1490"), [stryMutAct_9fa48("1491") ? "" : (stryCov_9fa48("1491"), "view"), stryMutAct_9fa48("1492") ? "" : (stryCov_9fa48("1492"), "prepare"), stryMutAct_9fa48("1493") ? "" : (stryCov_9fa48("1493"), "post"), stryMutAct_9fa48("1494") ? "" : (stryCov_9fa48("1494"), "correct"), stryMutAct_9fa48("1495") ? "" : (stryCov_9fa48("1495"), "managePeriods"), stryMutAct_9fa48("1496") ? "" : (stryCov_9fa48("1496"), "administerMembership"), stryMutAct_9fa48("1497") ? "" : (stryCov_9fa48("1497"), "manageBudgets"), stryMutAct_9fa48("1498") ? "" : (stryCov_9fa48("1498"), "manageRecoveryPlans")]),
  Accountant: stryMutAct_9fa48("1499") ? [] : (stryCov_9fa48("1499"), [stryMutAct_9fa48("1500") ? "" : (stryCov_9fa48("1500"), "view"), stryMutAct_9fa48("1501") ? "" : (stryCov_9fa48("1501"), "prepare"), stryMutAct_9fa48("1502") ? "" : (stryCov_9fa48("1502"), "post"), stryMutAct_9fa48("1503") ? "" : (stryCov_9fa48("1503"), "correct"), stryMutAct_9fa48("1504") ? "" : (stryCov_9fa48("1504"), "managePeriods")]),
  Preparer: stryMutAct_9fa48("1505") ? [] : (stryCov_9fa48("1505"), [stryMutAct_9fa48("1506") ? "" : (stryCov_9fa48("1506"), "view"), stryMutAct_9fa48("1507") ? "" : (stryCov_9fa48("1507"), "prepare")]),
  Viewer: stryMutAct_9fa48("1508") ? [] : (stryCov_9fa48("1508"), [stryMutAct_9fa48("1509") ? "" : (stryCov_9fa48("1509"), "view")])
})) satisfies Record<WorkspaceRole, readonly WorkspacePermission[]>;
export function hasWorkspacePermission(role: WorkspaceRole, permission: WorkspacePermission): boolean {
  if (stryMutAct_9fa48("1510")) {
    {}
  } else {
    stryCov_9fa48("1510");
    const permissions: readonly WorkspacePermission[] = workspaceRolePolicy[role];
    return permissions.includes(permission);
  }
}
export async function requireWorkspace(store: Pick<AccountingStore, "membershipRole" | "getWorkspace">, workspaceId: string, actor: Actor, permission: WorkspacePermission = stryMutAct_9fa48("1511") ? "" : (stryCov_9fa48("1511"), "view")): Promise<StoredWorkspace> {
  if (stryMutAct_9fa48("1512")) {
    {}
  } else {
    stryCov_9fa48("1512");
    const role = await store.membershipRole(workspaceId, actor.userId);
    const workspace = stryMutAct_9fa48("1515") ? role || (await store.getWorkspace(workspaceId)) : stryMutAct_9fa48("1514") ? false : stryMutAct_9fa48("1513") ? true : (stryCov_9fa48("1513", "1514", "1515"), role && (await store.getWorkspace(workspaceId)));
    if (stryMutAct_9fa48("1518") ? !role && !workspace : stryMutAct_9fa48("1517") ? false : stryMutAct_9fa48("1516") ? true : (stryCov_9fa48("1516", "1517", "1518"), (stryMutAct_9fa48("1519") ? role : (stryCov_9fa48("1519"), !role)) || (stryMutAct_9fa48("1520") ? workspace : (stryCov_9fa48("1520"), !workspace)))) {
      if (stryMutAct_9fa48("1521")) {
        {}
      } else {
        stryCov_9fa48("1521");
        throw new AccountingError(stryMutAct_9fa48("1523") ? "" : (stryCov_9fa48("1523"), "workspace_membership_required"));
      }
    }
    if (stryMutAct_9fa48("1526") ? false : stryMutAct_9fa48("1525") ? true : stryMutAct_9fa48("1524") ? hasWorkspacePermission(role, permission) : (stryCov_9fa48("1524", "1525", "1526"), !hasWorkspacePermission(role, permission))) {
      if (stryMutAct_9fa48("1527")) {
        {}
      } else {
        stryCov_9fa48("1527");
        throw new AccountingError(stryMutAct_9fa48("1529") ? "" : (stryCov_9fa48("1529"), "workspace_permission_required"));
      }
    }
    return workspace;
  }
}