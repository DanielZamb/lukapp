// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import type { UserIdentity } from "convex/server";
import { ConvexError, v } from "convex/values";
import type { GenericValidator, Infer, ObjectType, PropertyValidators } from "convex/values";
import { customMutation, customQuery } from "convex-helpers/server/customFunctions";
import { mutation, query } from "../_generated/server";
import type { MutationCtx, QueryCtx } from "../_generated/server";
import type { FinancialOperation } from "../../src/access/protocol";
import { deviceProof } from "../deviceValidators";
import { consumeChallenge, verifyChallenge, verifyPayload } from "./deviceAccess";
export function ownerAdmission(identity: UserIdentity | null) {
  if (stryMutAct_9fa48("1826")) {
    {}
  } else {
    stryCov_9fa48("1826");
    if (stryMutAct_9fa48("1829") ? false : stryMutAct_9fa48("1828") ? true : stryMutAct_9fa48("1827") ? identity : (stryCov_9fa48("1827", "1828", "1829"), !identity)) return stryMutAct_9fa48("1830") ? "" : (stryCov_9fa48("1830"), "authentication_required");
    const subject = process.env.LUKAPP_OWNER_CLERK_SUBJECT;
    const issuer = process.env.CLERK_JWT_ISSUER_DOMAIN;
    if (stryMutAct_9fa48("1833") ? !subject && !issuer : stryMutAct_9fa48("1832") ? false : stryMutAct_9fa48("1831") ? true : (stryCov_9fa48("1831", "1832", "1833"), (stryMutAct_9fa48("1834") ? subject : (stryCov_9fa48("1834"), !subject)) || (stryMutAct_9fa48("1835") ? issuer : (stryCov_9fa48("1835"), !issuer)))) return stryMutAct_9fa48("1836") ? "" : (stryCov_9fa48("1836"), "owner_configuration_required");
    if (stryMutAct_9fa48("1839") ? identity.subject !== subject && identity.issuer !== issuer : stryMutAct_9fa48("1838") ? false : stryMutAct_9fa48("1837") ? true : (stryCov_9fa48("1837", "1838", "1839"), (stryMutAct_9fa48("1841") ? identity.subject === subject : stryMutAct_9fa48("1840") ? false : (stryCov_9fa48("1840", "1841"), identity.subject !== subject)) || (stryMutAct_9fa48("1843") ? identity.issuer === issuer : stryMutAct_9fa48("1842") ? false : (stryCov_9fa48("1842", "1843"), identity.issuer !== issuer)))) return stryMutAct_9fa48("1844") ? "" : (stryCov_9fa48("1844"), "owner_not_allowed");
    return null;
  }
}
export async function requireOwner(ctx: {
  auth: {
    getUserIdentity(): Promise<UserIdentity | null>;
  };
}) {
  if (stryMutAct_9fa48("1845")) {
    {}
  } else {
    stryCov_9fa48("1845");
    const identity = await ctx.auth.getUserIdentity();
    if (stryMutAct_9fa48("1848") ? false : stryMutAct_9fa48("1847") ? true : stryMutAct_9fa48("1846") ? identity : (stryCov_9fa48("1846", "1847", "1848"), !identity)) throw new ConvexError(stryMutAct_9fa48("1850") ? {} : (stryCov_9fa48("1850"), {
      code: stryMutAct_9fa48("1851") ? "" : (stryCov_9fa48("1851"), "authentication_required")
    }));
    const error = ownerAdmission(identity);
    if (stryMutAct_9fa48("1853") ? false : stryMutAct_9fa48("1852") ? true : (stryCov_9fa48("1852", "1853"), error)) throw new ConvexError(stryMutAct_9fa48("1855") ? {} : (stryCov_9fa48("1855"), {
      code: error
    }));
    return stryMutAct_9fa48("1856") ? {} : (stryCov_9fa48("1856"), {
      clerkIdentity: identity,
      actor: stryMutAct_9fa48("1857") ? {} : (stryCov_9fa48("1857"), {
        userId: identity.tokenIdentifier
      }),
      identity: stryMutAct_9fa48("1858") ? {} : (stryCov_9fa48("1858"), {
        tokenIdentifier: identity.tokenIdentifier,
        issuer: identity.issuer,
        subject: identity.subject
      })
    });
  }
}
export type OwnerContext = Awaited<ReturnType<typeof requireOwner>>;
const proofArgs = stryMutAct_9fa48("1859") ? {} : (stryCov_9fa48("1859"), {
  access: v.optional(deviceProof)
});
async function financialInput(ctx: QueryCtx, args: {
  access?: Infer<typeof deviceProof>;
}, extra: {
  operation: FinancialOperation;
}) {
  if (stryMutAct_9fa48("1860")) {
    {}
  } else {
    stryCov_9fa48("1860");
    const owner = await requireOwner(ctx);
    const verified = await verifyChallenge(ctx, owner.clerkIdentity, args.access, extra.operation, stryMutAct_9fa48("1861") ? false : (stryCov_9fa48("1861"), true));
    return stryMutAct_9fa48("1862") ? {} : (stryCov_9fa48("1862"), {
      ctx: stryMutAct_9fa48("1863") ? {} : (stryCov_9fa48("1863"), {
        ...owner,
        verifyArguments: stryMutAct_9fa48("1864") ? () => undefined : (stryCov_9fa48("1864"), (request: unknown) => verifyPayload(verified.challenge, request))
      }),
      args: {},
      verified
    });
  }
}
const protectedQuery = customQuery(query, stryMutAct_9fa48("1865") ? {} : (stryCov_9fa48("1865"), {
  args: proofArgs,
  input: financialInput
}));
const protectedMutation = customMutation(mutation, stryMutAct_9fa48("1866") ? {} : (stryCov_9fa48("1866"), {
  args: proofArgs,
  input: async (ctx: MutationCtx, args, extra: {
    operation: FinancialOperation;
  }) => {
    if (stryMutAct_9fa48("1867")) {
      {}
    } else {
      stryCov_9fa48("1867");
      const added = await financialInput(ctx, args, extra);
      await consumeChallenge(ctx, added.verified.challenge, added.verified.device);
      return added;
    }
  }
}));
type FinancialDefinition<Ctx, Args extends PropertyValidators, Returns extends GenericValidator> = {
  operation: FinancialOperation;
  args: Args;
  returns: Returns;
  handler: (ctx: Ctx & OwnerContext, args: ObjectType<Args>) => Promise<Infer<Returns>>;
};
export function ownerQuery<Args extends PropertyValidators, Returns extends GenericValidator>(definition: FinancialDefinition<QueryCtx, Args, Returns>) {
  if (stryMutAct_9fa48("1868")) {
    {}
  } else {
    stryCov_9fa48("1868");
    return protectedQuery(stryMutAct_9fa48("1869") ? {} : (stryCov_9fa48("1869"), {
      ...definition,
      args: v.object(definition.args),
      handler: async (ctx, args): Promise<Infer<Returns>> => {
        if (stryMutAct_9fa48("1870")) {
          {}
        } else {
          stryCov_9fa48("1870");
          await ctx.verifyArguments(args);
          return definition.handler(ctx, args);
        }
      }
    }));
  }
}
export function ownerMutation<Args extends PropertyValidators, Returns extends GenericValidator>(definition: FinancialDefinition<MutationCtx, Args, Returns>) {
  if (stryMutAct_9fa48("1871")) {
    {}
  } else {
    stryCov_9fa48("1871");
    return protectedMutation(stryMutAct_9fa48("1872") ? {} : (stryCov_9fa48("1872"), {
      ...definition,
      args: v.object(definition.args),
      handler: async (ctx, args): Promise<Infer<Returns>> => {
        if (stryMutAct_9fa48("1873")) {
          {}
        } else {
          stryCov_9fa48("1873");
          await ctx.verifyArguments(args);
          return definition.handler(ctx, args);
        }
      }
    }));
  }
}