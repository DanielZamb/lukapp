// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import type { MutationCtx, QueryCtx } from "../_generated/server";
import type { Id } from "../_generated/dataModel";
import type { OwnerContext } from "./owner";
import type { createAccountingCore } from "../../src/accounting/core";
import { convexReadStore } from "../store";
import { requireWorkspace } from "../../src/accounting/membership";
import { AccountingError } from "../../src/accounting/errors";
export function personalWorkspaceLink(ctx: Pick<QueryCtx, "db">, tokenIdentifier: string) {
  if (stryMutAct_9fa48("1874")) {
    {}
  } else {
    stryCov_9fa48("1874");
    return ctx.db.query(stryMutAct_9fa48("1875") ? "" : (stryCov_9fa48("1875"), "personalWorkspaceOwners")).withIndex(stryMutAct_9fa48("1876") ? "" : (stryCov_9fa48("1876"), "by_identity"), stryMutAct_9fa48("1877") ? () => undefined : (stryCov_9fa48("1877"), q => q.eq(stryMutAct_9fa48("1878") ? "" : (stryCov_9fa48("1878"), "tokenIdentifier"), tokenIdentifier))).unique();
  }
}
export async function requirePersonalWorkspaceOwner(ctx: Pick<QueryCtx, "db">, workspaceId: Id<"workspaces">, userId: string) {
  if (stryMutAct_9fa48("1879")) {
    {}
  } else {
    stryCov_9fa48("1879");
    await requireWorkspace(convexReadStore(ctx.db), workspaceId, stryMutAct_9fa48("1880") ? {} : (stryCov_9fa48("1880"), {
      userId
    }), stryMutAct_9fa48("1881") ? "" : (stryCov_9fa48("1881"), "administerMembership"));
  }
}
export async function bootstrapPersonalWorkspace(ctx: MutationCtx & OwnerContext, args: {
  functionalCurrency: string;
  chartOfAccountsTemplate?: string;
  now: number;
}, core: ReturnType<typeof createAccountingCore>) {
  if (stryMutAct_9fa48("1882")) {
    {}
  } else {
    stryCov_9fa48("1882");
    const linked = await personalWorkspaceLink(ctx, ctx.actor.userId);
    if (stryMutAct_9fa48("1884") ? false : stryMutAct_9fa48("1883") ? true : (stryCov_9fa48("1883", "1884"), linked)) {
      if (stryMutAct_9fa48("1885")) {
        {}
      } else {
        stryCov_9fa48("1885");
        await requirePersonalWorkspaceOwner(ctx, linked.workspaceId, ctx.actor.userId);
        const workspace = await core.openWorkspace(stryMutAct_9fa48("1886") ? {} : (stryCov_9fa48("1886"), {
          actor: ctx.actor,
          workspaceId: linked.workspaceId,
          now: args.now
        }));
        if (stryMutAct_9fa48("1889") ? workspace.functionalCurrency !== args.functionalCurrency && args.chartOfAccountsTemplate && workspace.chartOfAccountsTemplate !== args.chartOfAccountsTemplate : stryMutAct_9fa48("1888") ? false : stryMutAct_9fa48("1887") ? true : (stryCov_9fa48("1887", "1888", "1889"), (stryMutAct_9fa48("1891") ? workspace.functionalCurrency === args.functionalCurrency : stryMutAct_9fa48("1890") ? false : (stryCov_9fa48("1890", "1891"), workspace.functionalCurrency !== args.functionalCurrency)) || (stryMutAct_9fa48("1893") ? args.chartOfAccountsTemplate || workspace.chartOfAccountsTemplate !== args.chartOfAccountsTemplate : stryMutAct_9fa48("1892") ? false : (stryCov_9fa48("1892", "1893"), args.chartOfAccountsTemplate && (stryMutAct_9fa48("1895") ? workspace.chartOfAccountsTemplate === args.chartOfAccountsTemplate : stryMutAct_9fa48("1894") ? true : (stryCov_9fa48("1894", "1895"), workspace.chartOfAccountsTemplate !== args.chartOfAccountsTemplate)))))) {
          if (stryMutAct_9fa48("1896")) {
            {}
          } else {
            stryCov_9fa48("1896");
            throw new AccountingError(stryMutAct_9fa48("1898") ? "" : (stryCov_9fa48("1898"), "personal_workspace_configuration_conflict"));
          }
        }
        return workspace;
      }
    }
    const created = await core.createPersonalWorkspace(stryMutAct_9fa48("1899") ? {} : (stryCov_9fa48("1899"), {
      actor: ctx.actor,
      functionalCurrency: args.functionalCurrency,
      ...(args.chartOfAccountsTemplate ? stryMutAct_9fa48("1900") ? {} : (stryCov_9fa48("1900"), {
        chartOfAccountsTemplate: args.chartOfAccountsTemplate
      }) : {})
    }));
    const workspaceId = ctx.db.normalizeId(stryMutAct_9fa48("1901") ? "" : (stryCov_9fa48("1901"), "workspaces"), created.id);
    if (stryMutAct_9fa48("1904") ? false : stryMutAct_9fa48("1903") ? true : stryMutAct_9fa48("1902") ? workspaceId : (stryCov_9fa48("1902", "1903", "1904"), !workspaceId)) throw new Error(stryMutAct_9fa48("1906") ? "" : (stryCov_9fa48("1906"), "Workspace store returned an invalid id"));
    await ctx.db.insert(stryMutAct_9fa48("1907") ? "" : (stryCov_9fa48("1907"), "personalWorkspaceOwners"), stryMutAct_9fa48("1908") ? {} : (stryCov_9fa48("1908"), {
      ...ctx.identity,
      workspaceId
    }));
    return created;
  }
}