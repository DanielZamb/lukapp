// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { createClerkClient } from "@clerk/backend";
import { verifyWebhook } from "@clerk/backend/webhooks";
import { ConvexError } from "convex/values";
import type { Infer } from "convex/values";
import type { providerError } from "../providerValidators";
export type ProviderError = Infer<typeof providerError>;
export function providerFailure(code: ProviderError): never {
  if (stryMutAct_9fa48("1247")) {
    {}
  } else {
    stryCov_9fa48("1247");
    throw new ConvexError(stryMutAct_9fa48("1249") ? {} : (stryCov_9fa48("1249"), {
      code
    }));
  }
}
export function sanitizedProviderError(error: unknown): ProviderError {
  if (stryMutAct_9fa48("1250")) {
    {}
  } else {
    stryCov_9fa48("1250");
    if (stryMutAct_9fa48("1253") ? error instanceof ConvexError && typeof error.data === "object" && error.data !== null || "code" in error.data : stryMutAct_9fa48("1252") ? false : stryMutAct_9fa48("1251") ? true : (stryCov_9fa48("1251", "1252", "1253"), (stryMutAct_9fa48("1255") ? error instanceof ConvexError && typeof error.data === "object" || error.data !== null : stryMutAct_9fa48("1254") ? true : (stryCov_9fa48("1254", "1255"), (stryMutAct_9fa48("1257") ? error instanceof ConvexError || typeof error.data === "object" : stryMutAct_9fa48("1256") ? true : (stryCov_9fa48("1256", "1257"), error instanceof ConvexError && (stryMutAct_9fa48("1259") ? typeof error.data !== "object" : stryMutAct_9fa48("1258") ? true : (stryCov_9fa48("1258", "1259"), typeof error.data === (stryMutAct_9fa48("1260") ? "" : (stryCov_9fa48("1260"), "object")))))) && (stryMutAct_9fa48("1262") ? error.data === null : stryMutAct_9fa48("1261") ? true : (stryCov_9fa48("1261", "1262"), error.data !== null)))) && (stryMutAct_9fa48("1263") ? "" : (stryCov_9fa48("1263"), "code")) in error.data)) {
      if (stryMutAct_9fa48("1264")) {
        {}
      } else {
        stryCov_9fa48("1264");
        const code = error.data.code;
        switch (code) {
          case stryMutAct_9fa48("1265") ? "" : (stryCov_9fa48("1265"), "provider_configuration_required"):
          case stryMutAct_9fa48("1266") ? "" : (stryCov_9fa48("1266"), "provider_instance_mismatch"):
          case stryMutAct_9fa48("1267") ? "" : (stryCov_9fa48("1267"), "provider_provenance_mismatch"):
          case stryMutAct_9fa48("1268") ? "" : (stryCov_9fa48("1268"), "provider_session_invalid"):
          case stryMutAct_9fa48("1269") ? "" : (stryCov_9fa48("1269"), "provider_session_terminal"):
          case stryMutAct_9fa48("1270") ? "" : (stryCov_9fa48("1270"), "recovery_fresh_sign_in_required"):
          case stryMutAct_9fa48("1271") ? "" : (stryCov_9fa48("1271"), "recovery_intent_expired"):
          case stryMutAct_9fa48("1273") ? "" : (stryCov_9fa48("1273"), "recovery_conflict"):
            if (stryMutAct_9fa48("1272")) {} else {
              stryCov_9fa48("1272");
              return code;
            }
        }
      }
    }
    return stryMutAct_9fa48("1274") ? "" : (stryCov_9fa48("1274"), "provider_unavailable");
  }
}
export function providerIdentity() {
  if (stryMutAct_9fa48("1275")) {
    {}
  } else {
    stryCov_9fa48("1275");
    const issuer = process.env.CLERK_JWT_ISSUER_DOMAIN;
    const subject = process.env.LUKAPP_OWNER_CLERK_SUBJECT;
    if (stryMutAct_9fa48("1278") ? !issuer && !subject : stryMutAct_9fa48("1277") ? false : stryMutAct_9fa48("1276") ? true : (stryCov_9fa48("1276", "1277", "1278"), (stryMutAct_9fa48("1279") ? issuer : (stryCov_9fa48("1279"), !issuer)) || (stryMutAct_9fa48("1280") ? subject : (stryCov_9fa48("1280"), !subject)))) providerFailure(stryMutAct_9fa48("1282") ? "" : (stryCov_9fa48("1282"), "provider_configuration_required"));
    return stryMutAct_9fa48("1283") ? {} : (stryCov_9fa48("1283"), {
      issuer,
      subject,
      tokenIdentifier: stryMutAct_9fa48("1284") ? `` : (stryCov_9fa48("1284"), `${issuer}|${subject}`)
    });
  }
}
export function clerkTransport() {
  if (stryMutAct_9fa48("1285")) {
    {}
  } else {
    stryCov_9fa48("1285");
    const secretKey = process.env.CLERK_SECRET_KEY;
    if (stryMutAct_9fa48("1288") ? false : stryMutAct_9fa48("1287") ? true : stryMutAct_9fa48("1286") ? secretKey : (stryCov_9fa48("1286", "1287", "1288"), !secretKey)) providerFailure(stryMutAct_9fa48("1290") ? "" : (stryCov_9fa48("1290"), "provider_configuration_required"));
    return createClerkClient(stryMutAct_9fa48("1291") ? {} : (stryCov_9fa48("1291"), {
      secretKey
    }));
  }
}
export type ClerkTransport = Pick<ReturnType<typeof createClerkClient>, "sessions" | "domains" | "instance">;
export type ClerkSession = Awaited<ReturnType<ClerkTransport["sessions"]["getSession"]>>;
export async function verifyProviderInstance(clerk: ClerkTransport, issuer: string) {
  if (stryMutAct_9fa48("1292")) {
    {}
  } else {
    stryCov_9fa48("1292");
    const domains = await clerk.domains.list();
    if (stryMutAct_9fa48("1295") ? false : stryMutAct_9fa48("1294") ? true : stryMutAct_9fa48("1293") ? domains.data.some(domain => domain.frontendApiUrl === issuer) : (stryCov_9fa48("1293", "1294", "1295"), !(stryMutAct_9fa48("1296") ? domains.data.every(domain => domain.frontendApiUrl === issuer) : (stryCov_9fa48("1296"), domains.data.some(stryMutAct_9fa48("1297") ? () => undefined : (stryCov_9fa48("1297"), domain => stryMutAct_9fa48("1300") ? domain.frontendApiUrl !== issuer : stryMutAct_9fa48("1299") ? false : stryMutAct_9fa48("1298") ? true : (stryCov_9fa48("1298", "1299", "1300"), domain.frontendApiUrl === issuer))))))) providerFailure(stryMutAct_9fa48("1302") ? "" : (stryCov_9fa48("1302"), "provider_instance_mismatch"));
    const instance = await clerk.instance.get();
    if (stryMutAct_9fa48("1305") ? process.env.CLERK_INSTANCE_ID || instance.id !== process.env.CLERK_INSTANCE_ID : stryMutAct_9fa48("1304") ? false : stryMutAct_9fa48("1303") ? true : (stryCov_9fa48("1303", "1304", "1305"), process.env.CLERK_INSTANCE_ID && (stryMutAct_9fa48("1307") ? instance.id === process.env.CLERK_INSTANCE_ID : stryMutAct_9fa48("1306") ? true : (stryCov_9fa48("1306", "1307"), instance.id !== process.env.CLERK_INSTANCE_ID)))) providerFailure(stryMutAct_9fa48("1309") ? "" : (stryCov_9fa48("1309"), "provider_instance_mismatch"));
    return instance;
  }
}
export function ownedSession(session: ClerkSession, subject: string, sid: string) {
  if (stryMutAct_9fa48("1310")) {
    {}
  } else {
    stryCov_9fa48("1310");
    if (stryMutAct_9fa48("1313") ? session.id !== sid && session.userId !== subject : stryMutAct_9fa48("1312") ? false : stryMutAct_9fa48("1311") ? true : (stryCov_9fa48("1311", "1312", "1313"), (stryMutAct_9fa48("1315") ? session.id === sid : stryMutAct_9fa48("1314") ? false : (stryCov_9fa48("1314", "1315"), session.id !== sid)) || (stryMutAct_9fa48("1317") ? session.userId === subject : stryMutAct_9fa48("1316") ? false : (stryCov_9fa48("1316", "1317"), session.userId !== subject)))) providerFailure(stryMutAct_9fa48("1319") ? "" : (stryCov_9fa48("1319"), "provider_provenance_mismatch"));
    if (stryMutAct_9fa48("1322") ? (!/^sess_[a-zA-Z0-9]{1,120}$/.test(session.id) || !Number.isSafeInteger(session.createdAt) || session.createdAt <= 0 || !Number.isSafeInteger(session.expireAt)) && !Number.isSafeInteger(session.abandonAt) : stryMutAct_9fa48("1321") ? false : stryMutAct_9fa48("1320") ? true : (stryCov_9fa48("1320", "1321", "1322"), (stryMutAct_9fa48("1324") ? (!/^sess_[a-zA-Z0-9]{1,120}$/.test(session.id) || !Number.isSafeInteger(session.createdAt) || session.createdAt <= 0) && !Number.isSafeInteger(session.expireAt) : stryMutAct_9fa48("1323") ? false : (stryCov_9fa48("1323", "1324"), (stryMutAct_9fa48("1326") ? (!/^sess_[a-zA-Z0-9]{1,120}$/.test(session.id) || !Number.isSafeInteger(session.createdAt)) && session.createdAt <= 0 : stryMutAct_9fa48("1325") ? false : (stryCov_9fa48("1325", "1326"), (stryMutAct_9fa48("1328") ? !/^sess_[a-zA-Z0-9]{1,120}$/.test(session.id) && !Number.isSafeInteger(session.createdAt) : stryMutAct_9fa48("1327") ? false : (stryCov_9fa48("1327", "1328"), (stryMutAct_9fa48("1329") ? /^sess_[a-zA-Z0-9]{1,120}$/.test(session.id) : (stryCov_9fa48("1329"), !(stryMutAct_9fa48("1333") ? /^sess_[^a-zA-Z0-9]{1,120}$/ : stryMutAct_9fa48("1332") ? /^sess_[a-zA-Z0-9]$/ : stryMutAct_9fa48("1331") ? /^sess_[a-zA-Z0-9]{1,120}/ : stryMutAct_9fa48("1330") ? /sess_[a-zA-Z0-9]{1,120}$/ : (stryCov_9fa48("1330", "1331", "1332", "1333"), /^sess_[a-zA-Z0-9]{1,120}$/)).test(session.id))) || (stryMutAct_9fa48("1334") ? Number.isSafeInteger(session.createdAt) : (stryCov_9fa48("1334"), !Number.isSafeInteger(session.createdAt))))) || (stryMutAct_9fa48("1337") ? session.createdAt > 0 : stryMutAct_9fa48("1336") ? session.createdAt < 0 : stryMutAct_9fa48("1335") ? false : (stryCov_9fa48("1335", "1336", "1337"), session.createdAt <= 0)))) || (stryMutAct_9fa48("1338") ? Number.isSafeInteger(session.expireAt) : (stryCov_9fa48("1338"), !Number.isSafeInteger(session.expireAt))))) || (stryMutAct_9fa48("1339") ? Number.isSafeInteger(session.abandonAt) : (stryCov_9fa48("1339"), !Number.isSafeInteger(session.abandonAt))))) providerFailure(stryMutAct_9fa48("1341") ? "" : (stryCov_9fa48("1341"), "provider_session_invalid"));
    return session;
  }
}
export function sessionIsTerminal(session: ClerkSession) {
  if (stryMutAct_9fa48("1342")) {
    {}
  } else {
    stryCov_9fa48("1342");
    return stryMutAct_9fa48("1345") ? (["ended", "revoked", "removed", "expired", "abandoned"].includes(session.status) || session.expireAt <= Date.now()) && session.abandonAt <= Date.now() : stryMutAct_9fa48("1344") ? false : stryMutAct_9fa48("1343") ? true : (stryCov_9fa48("1343", "1344", "1345"), (stryMutAct_9fa48("1347") ? ["ended", "revoked", "removed", "expired", "abandoned"].includes(session.status) && session.expireAt <= Date.now() : stryMutAct_9fa48("1346") ? false : (stryCov_9fa48("1346", "1347"), (stryMutAct_9fa48("1348") ? [] : (stryCov_9fa48("1348"), [stryMutAct_9fa48("1349") ? "" : (stryCov_9fa48("1349"), "ended"), stryMutAct_9fa48("1350") ? "" : (stryCov_9fa48("1350"), "revoked"), stryMutAct_9fa48("1351") ? "" : (stryCov_9fa48("1351"), "removed"), stryMutAct_9fa48("1352") ? "" : (stryCov_9fa48("1352"), "expired"), stryMutAct_9fa48("1353") ? "" : (stryCov_9fa48("1353"), "abandoned")])).includes(session.status) || (stryMutAct_9fa48("1356") ? session.expireAt > Date.now() : stryMutAct_9fa48("1355") ? session.expireAt < Date.now() : stryMutAct_9fa48("1354") ? false : (stryCov_9fa48("1354", "1355", "1356"), session.expireAt <= Date.now())))) || (stryMutAct_9fa48("1359") ? session.abandonAt > Date.now() : stryMutAct_9fa48("1358") ? session.abandonAt < Date.now() : stryMutAct_9fa48("1357") ? false : (stryCov_9fa48("1357", "1358", "1359"), session.abandonAt <= Date.now())));
  }
}
export function activeSession(session: ClerkSession) {
  if (stryMutAct_9fa48("1360")) {
    {}
  } else {
    stryCov_9fa48("1360");
    if (stryMutAct_9fa48("1363") ? session.actor === null : stryMutAct_9fa48("1362") ? false : stryMutAct_9fa48("1361") ? true : (stryCov_9fa48("1361", "1362", "1363"), session.actor !== null)) providerFailure(stryMutAct_9fa48("1365") ? "" : (stryCov_9fa48("1365"), "provider_provenance_mismatch"));
    if (stryMutAct_9fa48("1367") ? false : stryMutAct_9fa48("1366") ? true : (stryCov_9fa48("1366", "1367"), sessionIsTerminal(session))) providerFailure(stryMutAct_9fa48("1369") ? "" : (stryCov_9fa48("1369"), "provider_session_terminal"));
    if (stryMutAct_9fa48("1372") ? session.status !== "active" && session.createdAt > Date.now() : stryMutAct_9fa48("1371") ? false : stryMutAct_9fa48("1370") ? true : (stryCov_9fa48("1370", "1371", "1372"), (stryMutAct_9fa48("1374") ? session.status === "active" : stryMutAct_9fa48("1373") ? false : (stryCov_9fa48("1373", "1374"), session.status !== (stryMutAct_9fa48("1375") ? "" : (stryCov_9fa48("1375"), "active")))) || (stryMutAct_9fa48("1378") ? session.createdAt <= Date.now() : stryMutAct_9fa48("1377") ? session.createdAt >= Date.now() : stryMutAct_9fa48("1376") ? false : (stryCov_9fa48("1376", "1377", "1378"), session.createdAt > Date.now())))) providerFailure(stryMutAct_9fa48("1380") ? "" : (stryCov_9fa48("1380"), "provider_session_invalid"));
    return session;
  }
}
export async function getOwnedSession(clerk: ClerkTransport, subject: string, sid: string) {
  if (stryMutAct_9fa48("1381")) {
    {}
  } else {
    stryCov_9fa48("1381");
    try {
      if (stryMutAct_9fa48("1382")) {
        {}
      } else {
        stryCov_9fa48("1382");
        return ownedSession(await clerk.sessions.getSession(sid), subject, sid);
      }
    } catch (error) {
      if (stryMutAct_9fa48("1383")) {
        {}
      } else {
        stryCov_9fa48("1383");
        if (stryMutAct_9fa48("1386") ? error instanceof Error && error.name === "ClerkAPIResponseError" && "status" in error || error.status === 404 : stryMutAct_9fa48("1385") ? false : stryMutAct_9fa48("1384") ? true : (stryCov_9fa48("1384", "1385", "1386"), (stryMutAct_9fa48("1388") ? error instanceof Error && error.name === "ClerkAPIResponseError" || "status" in error : stryMutAct_9fa48("1387") ? true : (stryCov_9fa48("1387", "1388"), (stryMutAct_9fa48("1390") ? error instanceof Error || error.name === "ClerkAPIResponseError" : stryMutAct_9fa48("1389") ? true : (stryCov_9fa48("1389", "1390"), error instanceof Error && (stryMutAct_9fa48("1392") ? error.name !== "ClerkAPIResponseError" : stryMutAct_9fa48("1391") ? true : (stryCov_9fa48("1391", "1392"), error.name === (stryMutAct_9fa48("1393") ? "" : (stryCov_9fa48("1393"), "ClerkAPIResponseError")))))) && (stryMutAct_9fa48("1394") ? "" : (stryCov_9fa48("1394"), "status")) in error)) && (stryMutAct_9fa48("1396") ? error.status !== 404 : stryMutAct_9fa48("1395") ? true : (stryCov_9fa48("1395", "1396"), error.status === 404)))) return null;
        throw error;
      }
    }
  }
}
function record(value: unknown): value is Record<string, unknown> {
  if (stryMutAct_9fa48("1397")) {
    {}
  } else {
    stryCov_9fa48("1397");
    return stryMutAct_9fa48("1400") ? typeof value === "object" && value !== null || !Array.isArray(value) : stryMutAct_9fa48("1399") ? false : stryMutAct_9fa48("1398") ? true : (stryCov_9fa48("1398", "1399", "1400"), (stryMutAct_9fa48("1402") ? typeof value === "object" || value !== null : stryMutAct_9fa48("1401") ? true : (stryCov_9fa48("1401", "1402"), (stryMutAct_9fa48("1404") ? typeof value !== "object" : stryMutAct_9fa48("1403") ? true : (stryCov_9fa48("1403", "1404"), typeof value === (stryMutAct_9fa48("1405") ? "" : (stryCov_9fa48("1405"), "object")))) && (stryMutAct_9fa48("1407") ? value === null : stryMutAct_9fa48("1406") ? true : (stryCov_9fa48("1406", "1407"), value !== null)))) && (stryMutAct_9fa48("1408") ? Array.isArray(value) : (stryCov_9fa48("1408"), !Array.isArray(value))));
  }
}
export async function verifiedTerminalWebhook(request: Request) {
  if (stryMutAct_9fa48("1409")) {
    {}
  } else {
    stryCov_9fa48("1409");
    const secret = process.env.CLERK_WEBHOOK_SIGNING_SECRET;
    const instanceId = process.env.CLERK_INSTANCE_ID;
    if (stryMutAct_9fa48("1412") ? !secret && !instanceId : stryMutAct_9fa48("1411") ? false : stryMutAct_9fa48("1410") ? true : (stryCov_9fa48("1410", "1411", "1412"), (stryMutAct_9fa48("1413") ? secret : (stryCov_9fa48("1413"), !secret)) || (stryMutAct_9fa48("1414") ? instanceId : (stryCov_9fa48("1414"), !instanceId)))) providerFailure(stryMutAct_9fa48("1416") ? "" : (stryCov_9fa48("1416"), "provider_configuration_required"));
    let event: unknown;
    try {
      if (stryMutAct_9fa48("1417")) {
        {}
      } else {
        stryCov_9fa48("1417");
        event = await verifyWebhook(request, stryMutAct_9fa48("1418") ? {} : (stryCov_9fa48("1418"), {
          signingSecret: secret
        }));
      }
    } catch {
      if (stryMutAct_9fa48("1419")) {
        {}
      } else {
        stryCov_9fa48("1419");
        providerFailure(stryMutAct_9fa48("1421") ? "" : (stryCov_9fa48("1421"), "provider_session_invalid"));
      }
    }
    if (stryMutAct_9fa48("1424") ? (!record(event) || event.object !== "event") && typeof event.type !== "string" : stryMutAct_9fa48("1423") ? false : stryMutAct_9fa48("1422") ? true : (stryCov_9fa48("1422", "1423", "1424"), (stryMutAct_9fa48("1426") ? !record(event) && event.object !== "event" : stryMutAct_9fa48("1425") ? false : (stryCov_9fa48("1425", "1426"), (stryMutAct_9fa48("1427") ? record(event) : (stryCov_9fa48("1427"), !record(event))) || (stryMutAct_9fa48("1429") ? event.object === "event" : stryMutAct_9fa48("1428") ? false : (stryCov_9fa48("1428", "1429"), event.object !== (stryMutAct_9fa48("1430") ? "" : (stryCov_9fa48("1430"), "event")))))) || (stryMutAct_9fa48("1432") ? typeof event.type === "string" : stryMutAct_9fa48("1431") ? false : (stryCov_9fa48("1431", "1432"), typeof event.type !== (stryMutAct_9fa48("1433") ? "" : (stryCov_9fa48("1433"), "string")))))) providerFailure(stryMutAct_9fa48("1435") ? "" : (stryCov_9fa48("1435"), "provider_session_invalid"));
    if (stryMutAct_9fa48("1438") ? event.instance_id === instanceId : stryMutAct_9fa48("1437") ? false : stryMutAct_9fa48("1436") ? true : (stryCov_9fa48("1436", "1437", "1438"), event.instance_id !== instanceId)) providerFailure(stryMutAct_9fa48("1440") ? "" : (stryCov_9fa48("1440"), "provider_provenance_mismatch"));
    if (stryMutAct_9fa48("1443") ? event.type !== "session.ended" && event.type !== "session.removed" || event.type !== "session.revoked" : stryMutAct_9fa48("1442") ? false : stryMutAct_9fa48("1441") ? true : (stryCov_9fa48("1441", "1442", "1443"), (stryMutAct_9fa48("1445") ? event.type !== "session.ended" || event.type !== "session.removed" : stryMutAct_9fa48("1444") ? true : (stryCov_9fa48("1444", "1445"), (stryMutAct_9fa48("1447") ? event.type === "session.ended" : stryMutAct_9fa48("1446") ? true : (stryCov_9fa48("1446", "1447"), event.type !== (stryMutAct_9fa48("1448") ? "" : (stryCov_9fa48("1448"), "session.ended")))) && (stryMutAct_9fa48("1450") ? event.type === "session.removed" : stryMutAct_9fa48("1449") ? true : (stryCov_9fa48("1449", "1450"), event.type !== (stryMutAct_9fa48("1451") ? "" : (stryCov_9fa48("1451"), "session.removed")))))) && (stryMutAct_9fa48("1453") ? event.type === "session.revoked" : stryMutAct_9fa48("1452") ? true : (stryCov_9fa48("1452", "1453"), event.type !== (stryMutAct_9fa48("1454") ? "" : (stryCov_9fa48("1454"), "session.revoked")))))) return null;
    if (stryMutAct_9fa48("1457") ? false : stryMutAct_9fa48("1456") ? true : stryMutAct_9fa48("1455") ? record(event.data) : (stryCov_9fa48("1455", "1456", "1457"), !record(event.data))) providerFailure(stryMutAct_9fa48("1459") ? "" : (stryCov_9fa48("1459"), "provider_session_invalid"));
    const {
      id: sid,
      user_id: subject,
      status,
      object
    } = event.data;
    const eventId = stryMutAct_9fa48("1461") ? request.headers.get("svix-id").trim() : stryMutAct_9fa48("1460") ? request.headers.get("svix-id") : (stryCov_9fa48("1460", "1461"), request.headers.get(stryMutAct_9fa48("1462") ? "" : (stryCov_9fa48("1462"), "svix-id"))?.trim());
    if (stryMutAct_9fa48("1465") ? (!eventId || eventId.length > 256 || object !== "session" || typeof sid !== "string" || !/^sess_[a-zA-Z0-9]{1,120}$/.test(sid) || typeof status !== "string" || !["ended", "removed", "revoked"].includes(status) || typeof event.timestamp !== "number") && !Number.isSafeInteger(event.timestamp) : stryMutAct_9fa48("1464") ? false : stryMutAct_9fa48("1463") ? true : (stryCov_9fa48("1463", "1464", "1465"), (stryMutAct_9fa48("1467") ? (!eventId || eventId.length > 256 || object !== "session" || typeof sid !== "string" || !/^sess_[a-zA-Z0-9]{1,120}$/.test(sid) || typeof status !== "string" || !["ended", "removed", "revoked"].includes(status)) && typeof event.timestamp !== "number" : stryMutAct_9fa48("1466") ? false : (stryCov_9fa48("1466", "1467"), (stryMutAct_9fa48("1469") ? (!eventId || eventId.length > 256 || object !== "session" || typeof sid !== "string" || !/^sess_[a-zA-Z0-9]{1,120}$/.test(sid) || typeof status !== "string") && !["ended", "removed", "revoked"].includes(status) : stryMutAct_9fa48("1468") ? false : (stryCov_9fa48("1468", "1469"), (stryMutAct_9fa48("1471") ? (!eventId || eventId.length > 256 || object !== "session" || typeof sid !== "string" || !/^sess_[a-zA-Z0-9]{1,120}$/.test(sid)) && typeof status !== "string" : stryMutAct_9fa48("1470") ? false : (stryCov_9fa48("1470", "1471"), (stryMutAct_9fa48("1473") ? (!eventId || eventId.length > 256 || object !== "session" || typeof sid !== "string") && !/^sess_[a-zA-Z0-9]{1,120}$/.test(sid) : stryMutAct_9fa48("1472") ? false : (stryCov_9fa48("1472", "1473"), (stryMutAct_9fa48("1475") ? (!eventId || eventId.length > 256 || object !== "session") && typeof sid !== "string" : stryMutAct_9fa48("1474") ? false : (stryCov_9fa48("1474", "1475"), (stryMutAct_9fa48("1477") ? (!eventId || eventId.length > 256) && object !== "session" : stryMutAct_9fa48("1476") ? false : (stryCov_9fa48("1476", "1477"), (stryMutAct_9fa48("1479") ? !eventId && eventId.length > 256 : stryMutAct_9fa48("1478") ? false : (stryCov_9fa48("1478", "1479"), (stryMutAct_9fa48("1480") ? eventId : (stryCov_9fa48("1480"), !eventId)) || (stryMutAct_9fa48("1483") ? eventId.length <= 256 : stryMutAct_9fa48("1482") ? eventId.length >= 256 : stryMutAct_9fa48("1481") ? false : (stryCov_9fa48("1481", "1482", "1483"), eventId.length > 256)))) || (stryMutAct_9fa48("1485") ? object === "session" : stryMutAct_9fa48("1484") ? false : (stryCov_9fa48("1484", "1485"), object !== (stryMutAct_9fa48("1486") ? "" : (stryCov_9fa48("1486"), "session")))))) || (stryMutAct_9fa48("1488") ? typeof sid === "string" : stryMutAct_9fa48("1487") ? false : (stryCov_9fa48("1487", "1488"), typeof sid !== (stryMutAct_9fa48("1489") ? "" : (stryCov_9fa48("1489"), "string")))))) || (stryMutAct_9fa48("1490") ? /^sess_[a-zA-Z0-9]{1,120}$/.test(sid) : (stryCov_9fa48("1490"), !(stryMutAct_9fa48("1494") ? /^sess_[^a-zA-Z0-9]{1,120}$/ : stryMutAct_9fa48("1493") ? /^sess_[a-zA-Z0-9]$/ : stryMutAct_9fa48("1492") ? /^sess_[a-zA-Z0-9]{1,120}/ : stryMutAct_9fa48("1491") ? /sess_[a-zA-Z0-9]{1,120}$/ : (stryCov_9fa48("1491", "1492", "1493", "1494"), /^sess_[a-zA-Z0-9]{1,120}$/)).test(sid))))) || (stryMutAct_9fa48("1496") ? typeof status === "string" : stryMutAct_9fa48("1495") ? false : (stryCov_9fa48("1495", "1496"), typeof status !== (stryMutAct_9fa48("1497") ? "" : (stryCov_9fa48("1497"), "string")))))) || (stryMutAct_9fa48("1498") ? ["ended", "removed", "revoked"].includes(status) : (stryCov_9fa48("1498"), !(stryMutAct_9fa48("1499") ? [] : (stryCov_9fa48("1499"), [stryMutAct_9fa48("1500") ? "" : (stryCov_9fa48("1500"), "ended"), stryMutAct_9fa48("1501") ? "" : (stryCov_9fa48("1501"), "removed"), stryMutAct_9fa48("1502") ? "" : (stryCov_9fa48("1502"), "revoked")])).includes(status))))) || (stryMutAct_9fa48("1504") ? typeof event.timestamp === "number" : stryMutAct_9fa48("1503") ? false : (stryCov_9fa48("1503", "1504"), typeof event.timestamp !== (stryMutAct_9fa48("1505") ? "" : (stryCov_9fa48("1505"), "number")))))) || (stryMutAct_9fa48("1506") ? Number.isSafeInteger(event.timestamp) : (stryCov_9fa48("1506"), !Number.isSafeInteger(event.timestamp))))) providerFailure(stryMutAct_9fa48("1508") ? "" : (stryCov_9fa48("1508"), "provider_session_invalid"));
    const actor = providerIdentity();
    if (stryMutAct_9fa48("1511") ? subject === actor.subject : stryMutAct_9fa48("1510") ? false : stryMutAct_9fa48("1509") ? true : (stryCov_9fa48("1509", "1510", "1511"), subject !== actor.subject)) providerFailure(stryMutAct_9fa48("1513") ? "" : (stryCov_9fa48("1513"), "provider_provenance_mismatch"));
    return stryMutAct_9fa48("1514") ? {} : (stryCov_9fa48("1514"), {
      ...actor,
      sid,
      eventId,
      eventType: event.type,
      timestamp: event.timestamp
    });
  }
}