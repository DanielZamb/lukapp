// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import type { UserIdentity } from "convex/server";
import { ConvexError } from "convex/values";
import type { MutationCtx, QueryCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { accessPolicy, bindingExpiry, challengeMessage, directiveFor, hexToBytes, requestHash } from "../../src/access/protocol";
import type { AccessDenial, AccessOperation } from "../../src/access/protocol";
export function denyAccess(code: AccessDenial): never {
  if (stryMutAct_9fa48("1515")) {
    {}
  } else {
    stryCov_9fa48("1515");
    throw new ConvexError(stryMutAct_9fa48("1517") ? {} : (stryCov_9fa48("1517"), {
      code,
      directive: directiveFor(code)
    }));
  }
}
export function sessionDenial(identity: UserIdentity): AccessDenial | null {
  if (stryMutAct_9fa48("1518")) {
    {}
  } else {
    stryCov_9fa48("1518");
    if (stryMutAct_9fa48("1521") ? identity.sid !== undefined : stryMutAct_9fa48("1520") ? false : stryMutAct_9fa48("1519") ? true : (stryCov_9fa48("1519", "1520", "1521"), identity.sid === undefined)) return stryMutAct_9fa48("1522") ? "" : (stryCov_9fa48("1522"), "session_id_required");
    if (stryMutAct_9fa48("1525") ? typeof identity.sid !== "string" && !/^sess_[a-zA-Z0-9]{1,120}$/.test(identity.sid) : stryMutAct_9fa48("1524") ? false : stryMutAct_9fa48("1523") ? true : (stryCov_9fa48("1523", "1524", "1525"), (stryMutAct_9fa48("1527") ? typeof identity.sid === "string" : stryMutAct_9fa48("1526") ? false : (stryCov_9fa48("1526", "1527"), typeof identity.sid !== (stryMutAct_9fa48("1528") ? "" : (stryCov_9fa48("1528"), "string")))) || (stryMutAct_9fa48("1529") ? /^sess_[a-zA-Z0-9]{1,120}$/.test(identity.sid) : (stryCov_9fa48("1529"), !(stryMutAct_9fa48("1533") ? /^sess_[^a-zA-Z0-9]{1,120}$/ : stryMutAct_9fa48("1532") ? /^sess_[a-zA-Z0-9]$/ : stryMutAct_9fa48("1531") ? /^sess_[a-zA-Z0-9]{1,120}/ : stryMutAct_9fa48("1530") ? /sess_[a-zA-Z0-9]{1,120}$/ : (stryCov_9fa48("1530", "1531", "1532", "1533"), /^sess_[a-zA-Z0-9]{1,120}$/)).test(identity.sid))))) return stryMutAct_9fa48("1534") ? "" : (stryCov_9fa48("1534"), "session_id_invalid");
    if (stryMutAct_9fa48("1537") ? identity.sts !== undefined : stryMutAct_9fa48("1536") ? false : stryMutAct_9fa48("1535") ? true : (stryCov_9fa48("1535", "1536", "1537"), identity.sts === undefined)) return stryMutAct_9fa48("1538") ? "" : (stryCov_9fa48("1538"), "session_state_unverified");
    if (stryMutAct_9fa48("1541") ? identity.sts === "active" : stryMutAct_9fa48("1540") ? false : stryMutAct_9fa48("1539") ? true : (stryCov_9fa48("1539", "1540", "1541"), identity.sts !== (stryMutAct_9fa48("1542") ? "" : (stryCov_9fa48("1542"), "active")))) return stryMutAct_9fa48("1543") ? "" : (stryCov_9fa48("1543"), "session_not_active");
    return null;
  }
}
export function verifiedSessionId(identity: UserIdentity): string {
  if (stryMutAct_9fa48("1544")) {
    {}
  } else {
    stryCov_9fa48("1544");
    const denial = sessionDenial(identity);
    if (stryMutAct_9fa48("1546") ? false : stryMutAct_9fa48("1545") ? true : (stryCov_9fa48("1545", "1546"), denial)) if (stryMutAct_9fa48("1547")) {
      ;
    } else {
      stryCov_9fa48("1547");
      denyAccess(denial);
    }
    if (stryMutAct_9fa48("1550") ? typeof identity.sid === "string" : stryMutAct_9fa48("1549") ? false : stryMutAct_9fa48("1548") ? true : (stryCov_9fa48("1548", "1549", "1550"), typeof identity.sid !== (stryMutAct_9fa48("1551") ? "" : (stryCov_9fa48("1551"), "string")))) denyAccess(stryMutAct_9fa48("1553") ? "" : (stryCov_9fa48("1553"), "session_id_invalid"));
    return identity.sid;
  }
}
export async function providerSessionDenied(ctx: Pick<QueryCtx, "db">, tokenIdentifier: string, sid: string) {
  if (stryMutAct_9fa48("1554")) {
    {}
  } else {
    stryCov_9fa48("1554");
    return stryMutAct_9fa48("1557") ? (await ctx.db.query("deviceSessionDenials").withIndex("by_identity_sid", q => q.eq("tokenIdentifier", tokenIdentifier).eq("sid", sid)).unique()) === null : stryMutAct_9fa48("1556") ? false : stryMutAct_9fa48("1555") ? true : (stryCov_9fa48("1555", "1556", "1557"), (await ctx.db.query(stryMutAct_9fa48("1558") ? "" : (stryCov_9fa48("1558"), "deviceSessionDenials")).withIndex(stryMutAct_9fa48("1559") ? "" : (stryCov_9fa48("1559"), "by_identity_sid"), stryMutAct_9fa48("1560") ? () => undefined : (stryCov_9fa48("1560"), q => q.eq(stryMutAct_9fa48("1561") ? "" : (stryCov_9fa48("1561"), "tokenIdentifier"), tokenIdentifier).eq(stryMutAct_9fa48("1562") ? "" : (stryCov_9fa48("1562"), "sid"), sid))).unique()) !== null);
  }
}
export async function requireEligibleSession(ctx: Pick<QueryCtx, "db">, identity: UserIdentity) {
  if (stryMutAct_9fa48("1563")) {
    {}
  } else {
    stryCov_9fa48("1563");
    const sid = verifiedSessionId(identity);
    if (stryMutAct_9fa48("1565") ? false : stryMutAct_9fa48("1564") ? true : (stryCov_9fa48("1564", "1565"), await providerSessionDenied(ctx, identity.tokenIdentifier, sid))) denyAccess(stryMutAct_9fa48("1567") ? "" : (stryCov_9fa48("1567"), "session_revoked"));
    return sid;
  }
}
export function sessionBinding(ctx: Pick<QueryCtx, "db">, tokenIdentifier: string, sid: string) {
  if (stryMutAct_9fa48("1568")) {
    {}
  } else {
    stryCov_9fa48("1568");
    return ctx.db.query(stryMutAct_9fa48("1569") ? "" : (stryCov_9fa48("1569"), "mobileDevices")).withIndex(stryMutAct_9fa48("1570") ? "" : (stryCov_9fa48("1570"), "by_identity_sid"), stryMutAct_9fa48("1571") ? () => undefined : (stryCov_9fa48("1571"), q => q.eq(stryMutAct_9fa48("1572") ? "" : (stryCov_9fa48("1572"), "tokenIdentifier"), tokenIdentifier).eq(stryMutAct_9fa48("1573") ? "" : (stryCov_9fa48("1573"), "sid"), sid))).unique();
  }
}
export async function registrationAllowed(ctx: Pick<QueryCtx, "db">, tokenIdentifier: string, sid: string) {
  if (stryMutAct_9fa48("1574")) {
    {}
  } else {
    stryCov_9fa48("1574");
    const barrier = await ctx.db.query(stryMutAct_9fa48("1575") ? "" : (stryCov_9fa48("1575"), "deviceRecoveryBarriers")).withIndex(stryMutAct_9fa48("1576") ? "" : (stryCov_9fa48("1576"), "by_identity"), stryMutAct_9fa48("1577") ? () => undefined : (stryCov_9fa48("1577"), q => q.eq(stryMutAct_9fa48("1578") ? "" : (stryCov_9fa48("1578"), "tokenIdentifier"), tokenIdentifier))).unique();
    if (stryMutAct_9fa48("1581") ? false : stryMutAct_9fa48("1580") ? true : stryMutAct_9fa48("1579") ? barrier : (stryCov_9fa48("1579", "1580", "1581"), !barrier)) return stryMutAct_9fa48("1582") ? false : (stryCov_9fa48("1582"), true);
    const approved = await ctx.db.query(stryMutAct_9fa48("1583") ? "" : (stryCov_9fa48("1583"), "deviceRegistrationApprovals")).withIndex(stryMutAct_9fa48("1584") ? "" : (stryCov_9fa48("1584"), "by_identity_sid"), stryMutAct_9fa48("1585") ? () => undefined : (stryCov_9fa48("1585"), q => q.eq(stryMutAct_9fa48("1586") ? "" : (stryCov_9fa48("1586"), "tokenIdentifier"), tokenIdentifier).eq(stryMutAct_9fa48("1587") ? "" : (stryCov_9fa48("1587"), "sid"), sid))).unique();
    return stryMutAct_9fa48("1590") ? approved === null : stryMutAct_9fa48("1589") ? false : stryMutAct_9fa48("1588") ? true : (stryCov_9fa48("1588", "1589", "1590"), approved !== null);
  }
}
export function bindingDenial(binding: Doc<"mobileDevices"> | null, now: number): AccessDenial | null {
  if (stryMutAct_9fa48("1591")) {
    {}
  } else {
    stryCov_9fa48("1591");
    if (stryMutAct_9fa48("1594") ? false : stryMutAct_9fa48("1593") ? true : stryMutAct_9fa48("1592") ? binding : (stryCov_9fa48("1592", "1593", "1594"), !binding)) return stryMutAct_9fa48("1595") ? "" : (stryCov_9fa48("1595"), "device_unregistered");
    if (stryMutAct_9fa48("1598") ? binding.state.kind !== "revoked" : stryMutAct_9fa48("1597") ? false : stryMutAct_9fa48("1596") ? true : (stryCov_9fa48("1596", "1597", "1598"), binding.state.kind === (stryMutAct_9fa48("1599") ? "" : (stryCov_9fa48("1599"), "revoked")))) return stryMutAct_9fa48("1600") ? "" : (stryCov_9fa48("1600"), "device_revoked");
    return bindingExpiry(binding, now);
  }
}
export async function requireBinding(ctx: Pick<QueryCtx, "db">, tokenIdentifier: string, sid: string, deviceId?: Id<"mobileDevices">) {
  if (stryMutAct_9fa48("1601")) {
    {}
  } else {
    stryCov_9fa48("1601");
    const binding = await sessionBinding(ctx, tokenIdentifier, sid);
    const denial = bindingDenial(binding, Date.now());
    if (stryMutAct_9fa48("1603") ? false : stryMutAct_9fa48("1602") ? true : (stryCov_9fa48("1602", "1603"), denial)) if (stryMutAct_9fa48("1604")) {
      ;
    } else {
      stryCov_9fa48("1604");
      denyAccess(denial);
    }
    if (stryMutAct_9fa48("1607") ? false : stryMutAct_9fa48("1606") ? true : stryMutAct_9fa48("1605") ? binding : (stryCov_9fa48("1605", "1606", "1607"), !binding)) denyAccess(stryMutAct_9fa48("1609") ? "" : (stryCov_9fa48("1609"), "device_unregistered"));
    if (stryMutAct_9fa48("1612") ? deviceId === binding._id : stryMutAct_9fa48("1611") ? false : stryMutAct_9fa48("1610") ? true : (stryCov_9fa48("1610", "1611", "1612"), deviceId !== binding._id)) denyAccess(stryMutAct_9fa48("1614") ? "" : (stryCov_9fa48("1614"), "session_device_mismatch"));
    return binding;
  }
}
export async function importDeviceKey(publicKey: string) {
  if (stryMutAct_9fa48("1615")) {
    {}
  } else {
    stryCov_9fa48("1615");
    try {
      if (stryMutAct_9fa48("1616")) {
        {}
      } else {
        stryCov_9fa48("1616");
        if (stryMutAct_9fa48("1619") ? false : stryMutAct_9fa48("1618") ? true : stryMutAct_9fa48("1617") ? /^04[0-9a-f]{128}$/.test(publicKey) : (stryCov_9fa48("1617", "1618", "1619"), !(stryMutAct_9fa48("1623") ? /^04[^0-9a-f]{128}$/ : stryMutAct_9fa48("1622") ? /^04[0-9a-f]$/ : stryMutAct_9fa48("1621") ? /^04[0-9a-f]{128}/ : stryMutAct_9fa48("1620") ? /04[0-9a-f]{128}$/ : (stryCov_9fa48("1620", "1621", "1622", "1623"), /^04[0-9a-f]{128}$/)).test(publicKey))) denyAccess(stryMutAct_9fa48("1625") ? "" : (stryCov_9fa48("1625"), "device_key_invalid"));
        return await crypto.subtle.importKey(stryMutAct_9fa48("1626") ? "" : (stryCov_9fa48("1626"), "raw"), hexToBytes(publicKey), stryMutAct_9fa48("1627") ? {} : (stryCov_9fa48("1627"), {
          name: stryMutAct_9fa48("1628") ? "" : (stryCov_9fa48("1628"), "ECDSA"),
          namedCurve: stryMutAct_9fa48("1629") ? "" : (stryCov_9fa48("1629"), "P-256")
        }), stryMutAct_9fa48("1630") ? true : (stryCov_9fa48("1630"), false), stryMutAct_9fa48("1631") ? [] : (stryCov_9fa48("1631"), [stryMutAct_9fa48("1632") ? "" : (stryCov_9fa48("1632"), "verify")]));
      }
    } catch {
      if (stryMutAct_9fa48("1633")) {
        {}
      } else {
        stryCov_9fa48("1633");
        denyAccess(stryMutAct_9fa48("1635") ? "" : (stryCov_9fa48("1635"), "device_key_invalid"));
      }
    }
  }
}
export async function verifyChallenge(ctx: Pick<QueryCtx, "db">, identity: UserIdentity, proof: {
  challengeId: Id<"deviceChallenges">;
  signature: string;
} | undefined, operation: AccessOperation, requireRegistered: boolean) {
  if (stryMutAct_9fa48("1636")) {
    {}
  } else {
    stryCov_9fa48("1636");
    const sid = await requireEligibleSession(ctx, identity);
    const current = await sessionBinding(ctx, identity.tokenIdentifier, sid);
    if (stryMutAct_9fa48("1638") ? false : stryMutAct_9fa48("1637") ? true : (stryCov_9fa48("1637", "1638"), current)) {
      if (stryMutAct_9fa48("1639")) {
        {}
      } else {
        stryCov_9fa48("1639");
        const denial = bindingDenial(current, Date.now());
        if (stryMutAct_9fa48("1641") ? false : stryMutAct_9fa48("1640") ? true : (stryCov_9fa48("1640", "1641"), denial)) if (stryMutAct_9fa48("1642")) {
          ;
        } else {
          stryCov_9fa48("1642");
          denyAccess(denial);
        }
      }
    } else if (stryMutAct_9fa48("1645") ? false : stryMutAct_9fa48("1644") ? true : stryMutAct_9fa48("1643") ? await registrationAllowed(ctx, identity.tokenIdentifier, sid) : (stryCov_9fa48("1643", "1644", "1645"), !(await registrationAllowed(ctx, identity.tokenIdentifier, sid)))) {
      if (stryMutAct_9fa48("1646")) {
        {}
      } else {
        stryCov_9fa48("1646");
        denyAccess(stryMutAct_9fa48("1648") ? "" : (stryCov_9fa48("1648"), "recovery_registration_blocked"));
      }
    }
    if (stryMutAct_9fa48("1651") ? false : stryMutAct_9fa48("1650") ? true : stryMutAct_9fa48("1649") ? proof : (stryCov_9fa48("1649", "1650", "1651"), !proof)) denyAccess(stryMutAct_9fa48("1653") ? "" : (stryCov_9fa48("1653"), "device_proof_required"));
    const challenge = await ctx.db.get(proof.challengeId);
    if (stryMutAct_9fa48("1656") ? (!challenge || challenge.tokenIdentifier !== identity.tokenIdentifier || challenge.sid !== sid) && challenge.operation !== operation : stryMutAct_9fa48("1655") ? false : stryMutAct_9fa48("1654") ? true : (stryCov_9fa48("1654", "1655", "1656"), (stryMutAct_9fa48("1658") ? (!challenge || challenge.tokenIdentifier !== identity.tokenIdentifier) && challenge.sid !== sid : stryMutAct_9fa48("1657") ? false : (stryCov_9fa48("1657", "1658"), (stryMutAct_9fa48("1660") ? !challenge && challenge.tokenIdentifier !== identity.tokenIdentifier : stryMutAct_9fa48("1659") ? false : (stryCov_9fa48("1659", "1660"), (stryMutAct_9fa48("1661") ? challenge : (stryCov_9fa48("1661"), !challenge)) || (stryMutAct_9fa48("1663") ? challenge.tokenIdentifier === identity.tokenIdentifier : stryMutAct_9fa48("1662") ? false : (stryCov_9fa48("1662", "1663"), challenge.tokenIdentifier !== identity.tokenIdentifier)))) || (stryMutAct_9fa48("1665") ? challenge.sid === sid : stryMutAct_9fa48("1664") ? false : (stryCov_9fa48("1664", "1665"), challenge.sid !== sid)))) || (stryMutAct_9fa48("1667") ? challenge.operation === operation : stryMutAct_9fa48("1666") ? false : (stryCov_9fa48("1666", "1667"), challenge.operation !== operation)))) denyAccess(stryMutAct_9fa48("1669") ? "" : (stryCov_9fa48("1669"), "device_proof_invalid"));
    if (stryMutAct_9fa48("1672") ? challenge.consumedAt === undefined : stryMutAct_9fa48("1671") ? false : stryMutAct_9fa48("1670") ? true : (stryCov_9fa48("1670", "1671", "1672"), challenge.consumedAt !== undefined)) denyAccess(stryMutAct_9fa48("1674") ? "" : (stryCov_9fa48("1674"), "device_challenge_replayed"));
    if (stryMutAct_9fa48("1678") ? Date.now() < challenge.expiresAt : stryMutAct_9fa48("1677") ? Date.now() > challenge.expiresAt : stryMutAct_9fa48("1676") ? false : stryMutAct_9fa48("1675") ? true : (stryCov_9fa48("1675", "1676", "1677", "1678"), Date.now() >= challenge.expiresAt)) denyAccess(stryMutAct_9fa48("1680") ? "" : (stryCov_9fa48("1680"), "device_challenge_expired"));
    let device: Doc<"mobileDevices"> | null = null;
    if (stryMutAct_9fa48("1682") ? false : stryMutAct_9fa48("1681") ? true : (stryCov_9fa48("1681", "1682"), requireRegistered)) device = await requireBinding(ctx, identity.tokenIdentifier, sid, challenge.deviceId);else if (stryMutAct_9fa48("1684") ? false : stryMutAct_9fa48("1683") ? true : (stryCov_9fa48("1683", "1684"), current)) {
      if (stryMutAct_9fa48("1685")) {
        {}
      } else {
        stryCov_9fa48("1685");
        const enrollmentRetry = stryMutAct_9fa48("1688") ? operation === "devices.register" && challenge.deviceId === undefined || challenge.publicKey === current.publicKey : stryMutAct_9fa48("1687") ? false : stryMutAct_9fa48("1686") ? true : (stryCov_9fa48("1686", "1687", "1688"), (stryMutAct_9fa48("1690") ? operation === "devices.register" || challenge.deviceId === undefined : stryMutAct_9fa48("1689") ? true : (stryCov_9fa48("1689", "1690"), (stryMutAct_9fa48("1692") ? operation !== "devices.register" : stryMutAct_9fa48("1691") ? true : (stryCov_9fa48("1691", "1692"), operation === (stryMutAct_9fa48("1693") ? "" : (stryCov_9fa48("1693"), "devices.register")))) && (stryMutAct_9fa48("1695") ? challenge.deviceId !== undefined : stryMutAct_9fa48("1694") ? true : (stryCov_9fa48("1694", "1695"), challenge.deviceId === undefined)))) && (stryMutAct_9fa48("1697") ? challenge.publicKey !== current.publicKey : stryMutAct_9fa48("1696") ? true : (stryCov_9fa48("1696", "1697"), challenge.publicKey === current.publicKey)));
        if (stryMutAct_9fa48("1700") ? !enrollmentRetry || challenge.deviceId !== current._id || challenge.publicKey !== current.publicKey : stryMutAct_9fa48("1699") ? false : stryMutAct_9fa48("1698") ? true : (stryCov_9fa48("1698", "1699", "1700"), (stryMutAct_9fa48("1701") ? enrollmentRetry : (stryCov_9fa48("1701"), !enrollmentRetry)) && (stryMutAct_9fa48("1703") ? challenge.deviceId !== current._id && challenge.publicKey !== current.publicKey : stryMutAct_9fa48("1702") ? true : (stryCov_9fa48("1702", "1703"), (stryMutAct_9fa48("1705") ? challenge.deviceId === current._id : stryMutAct_9fa48("1704") ? false : (stryCov_9fa48("1704", "1705"), challenge.deviceId !== current._id)) || (stryMutAct_9fa48("1707") ? challenge.publicKey === current.publicKey : stryMutAct_9fa48("1706") ? false : (stryCov_9fa48("1706", "1707"), challenge.publicKey !== current.publicKey)))))) denyAccess(stryMutAct_9fa48("1709") ? "" : (stryCov_9fa48("1709"), "session_device_mismatch"));
      }
    }
    const key = await importDeviceKey(challenge.publicKey);
    let verified = stryMutAct_9fa48("1710") ? true : (stryCov_9fa48("1710"), false);
    try {
      if (stryMutAct_9fa48("1711")) {
        {}
      } else {
        stryCov_9fa48("1711");
        if (stryMutAct_9fa48("1713") ? false : stryMutAct_9fa48("1712") ? true : (stryCov_9fa48("1712", "1713"), (stryMutAct_9fa48("1717") ? /^[^0-9a-f]{128}$/ : stryMutAct_9fa48("1716") ? /^[0-9a-f]$/ : stryMutAct_9fa48("1715") ? /^[0-9a-f]{128}/ : stryMutAct_9fa48("1714") ? /[0-9a-f]{128}$/ : (stryCov_9fa48("1714", "1715", "1716", "1717"), /^[0-9a-f]{128}$/)).test(proof.signature))) {
          if (stryMutAct_9fa48("1718")) {
            {}
          } else {
            stryCov_9fa48("1718");
            verified = await crypto.subtle.verify(stryMutAct_9fa48("1719") ? {} : (stryCov_9fa48("1719"), {
              name: stryMutAct_9fa48("1720") ? "" : (stryCov_9fa48("1720"), "ECDSA"),
              hash: stryMutAct_9fa48("1721") ? "" : (stryCov_9fa48("1721"), "SHA-256")
            }), key, hexToBytes(proof.signature), new TextEncoder().encode(challengeMessage(stryMutAct_9fa48("1722") ? {} : (stryCov_9fa48("1722"), {
              challengeId: challenge._id,
              nonce: challenge.nonce,
              tokenIdentifier: challenge.tokenIdentifier,
              sid,
              operation,
              payloadHash: challenge.payloadHash,
              expiresAt: challenge.expiresAt
            }))));
          }
        }
      }
    } catch {
      if (stryMutAct_9fa48("1723")) {
        {}
      } else {
        stryCov_9fa48("1723");
        verified = stryMutAct_9fa48("1724") ? true : (stryCov_9fa48("1724"), false);
      }
    }
    if (stryMutAct_9fa48("1727") ? false : stryMutAct_9fa48("1726") ? true : stryMutAct_9fa48("1725") ? verified : (stryCov_9fa48("1725", "1726", "1727"), !verified)) denyAccess(stryMutAct_9fa48("1729") ? "" : (stryCov_9fa48("1729"), "device_proof_invalid"));
    return stryMutAct_9fa48("1730") ? {} : (stryCov_9fa48("1730"), {
      challenge,
      device
    });
  }
}
export async function verifyPayload(challenge: Doc<"deviceChallenges">, args: unknown) {
  if (stryMutAct_9fa48("1731")) {
    {}
  } else {
    stryCov_9fa48("1731");
    if (stryMutAct_9fa48("1734") ? (await requestHash(args)) === challenge.payloadHash : stryMutAct_9fa48("1733") ? false : stryMutAct_9fa48("1732") ? true : (stryCov_9fa48("1732", "1733", "1734"), (await requestHash(args)) !== challenge.payloadHash)) denyAccess(stryMutAct_9fa48("1736") ? "" : (stryCov_9fa48("1736"), "device_request_mismatch"));
  }
}
export async function consumeChallenge(ctx: Pick<MutationCtx, "db">, challenge: Doc<"deviceChallenges">, device: Doc<"mobileDevices"> | null) {
  if (stryMutAct_9fa48("1737")) {
    {}
  } else {
    stryCov_9fa48("1737");
    await ctx.db.patch(challenge._id, stryMutAct_9fa48("1738") ? {} : (stryCov_9fa48("1738"), {
      consumedAt: Date.now()
    }));
    if (stryMutAct_9fa48("1740") ? false : stryMutAct_9fa48("1739") ? true : (stryCov_9fa48("1739", "1740"), device)) await ctx.db.patch(device._id, stryMutAct_9fa48("1741") ? {} : (stryCov_9fa48("1741"), {
      lastSeenAt: Date.now()
    }));
  }
}
export function summarizeDevice(device: Doc<"mobileDevices">) {
  if (stryMutAct_9fa48("1742")) {
    {}
  } else {
    stryCov_9fa48("1742");
    return stryMutAct_9fa48("1743") ? {} : (stryCov_9fa48("1743"), {
      id: device._id,
      name: device.name,
      platform: device.platform,
      createdAt: device.createdAt,
      lastSeenAt: device.lastSeenAt,
      state: device.state
    });
  }
}