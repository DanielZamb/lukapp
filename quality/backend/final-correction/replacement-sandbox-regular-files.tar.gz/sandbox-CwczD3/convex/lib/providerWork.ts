// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import type { MutationCtx } from "../_generated/server";
import type { Infer } from "convex/values";
import { internal } from "../_generated/api";
import { providerTarget } from "../providerValidators";
export async function enqueueProviderWork(ctx: MutationCtx, actor: {
  tokenIdentifier: string;
  issuer: string;
  subject: string;
}, target: Infer<typeof providerTarget>) {
  if (stryMutAct_9fa48("1909")) {
    {}
  } else {
    stryCov_9fa48("1909");
    const existing = await ctx.db.query(stryMutAct_9fa48("1910") ? "" : (stryCov_9fa48("1910"), "clerkProviderWork")).withIndex(stryMutAct_9fa48("1911") ? "" : (stryCov_9fa48("1911"), "by_identity"), stryMutAct_9fa48("1912") ? () => undefined : (stryCov_9fa48("1912"), q => q.eq(stryMutAct_9fa48("1913") ? "" : (stryCov_9fa48("1913"), "tokenIdentifier"), actor.tokenIdentifier))).collect();
    const prior = existing.find(stryMutAct_9fa48("1914") ? () => undefined : (stryCov_9fa48("1914"), work => stryMutAct_9fa48("1917") ? work.target.kind === target.kind || work.target.sid === target.sid : stryMutAct_9fa48("1916") ? false : stryMutAct_9fa48("1915") ? true : (stryCov_9fa48("1915", "1916", "1917"), (stryMutAct_9fa48("1919") ? work.target.kind !== target.kind : stryMutAct_9fa48("1918") ? true : (stryCov_9fa48("1918", "1919"), work.target.kind === target.kind)) && (stryMutAct_9fa48("1921") ? work.target.sid !== target.sid : stryMutAct_9fa48("1920") ? true : (stryCov_9fa48("1920", "1921"), work.target.sid === target.sid)))));
    if (stryMutAct_9fa48("1923") ? false : stryMutAct_9fa48("1922") ? true : (stryCov_9fa48("1922", "1923"), prior)) return prior;
    const state = {
      kind: "pending",
      nextAttemptAt: Date.now()
    } as const;
    const workId = await ctx.db.insert(stryMutAct_9fa48("1924") ? "" : (stryCov_9fa48("1924"), "clerkProviderWork"), stryMutAct_9fa48("1925") ? {} : (stryCov_9fa48("1925"), {
      ...actor,
      target,
      state,
      attempts: 0
    }));
    await ctx.scheduler.runAfter(0, internal.providerWork.dispatch, stryMutAct_9fa48("1926") ? {} : (stryCov_9fa48("1926"), {
      workId
    }));
    return stryMutAct_9fa48("1927") ? {} : (stryCov_9fa48("1927"), {
      _id: workId,
      state
    });
  }
}