// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import type { Infer } from "convex/values";
import { ConvexError } from "convex/values";
import type { MutationCtx, QueryCtx } from "../_generated/server";
import type { OwnerContext } from "./owner";
import { firstRunArgs } from "../onboardingValidators";
import { createAccountingCore } from "../../src/accounting/core";
import { convexReadStore, convexStore } from "../store";
import { dateFromTimestamp } from "../../src/accounting/period";
import { bootstrapPersonalWorkspace, personalWorkspaceLink, requirePersonalWorkspaceOwner } from "./personalWorkspace";
import { canonicalJson } from "../../src/access/protocol";
import { normalizeCategoryName } from "../../src/accounting/categoryPolicy";
import { AccountingError } from "../../src/accounting/errors";
import { v } from "convex/values";
const argsValidator = v.object(firstRunArgs);
type FirstRunArgs = Infer<typeof argsValidator>;
export async function finishFirstRun(ctx: MutationCtx & OwnerContext, args: FirstRunArgs) {
  if (stryMutAct_9fa48("1744")) {
    {}
  } else {
    stryCov_9fa48("1744");
    if (stryMutAct_9fa48("1747") ? args.categories.length > 40 && new Set(args.categories.map(c => normalizeCategoryName(c.name))).size !== args.categories.length : stryMutAct_9fa48("1746") ? false : stryMutAct_9fa48("1745") ? true : (stryCov_9fa48("1745", "1746", "1747"), (stryMutAct_9fa48("1750") ? args.categories.length <= 40 : stryMutAct_9fa48("1749") ? args.categories.length >= 40 : stryMutAct_9fa48("1748") ? false : (stryCov_9fa48("1748", "1749", "1750"), args.categories.length > 40)) || (stryMutAct_9fa48("1752") ? new Set(args.categories.map(c => normalizeCategoryName(c.name))).size === args.categories.length : stryMutAct_9fa48("1751") ? false : (stryCov_9fa48("1751", "1752"), new Set(args.categories.map(stryMutAct_9fa48("1753") ? () => undefined : (stryCov_9fa48("1753"), c => normalizeCategoryName(c.name)))).size !== args.categories.length)))) {
      if (stryMutAct_9fa48("1754")) {
        {}
      } else {
        stryCov_9fa48("1754");
        throw new ConvexError(stryMutAct_9fa48("1756") ? {} : (stryCov_9fa48("1756"), {
          code: stryMutAct_9fa48("1757") ? "" : (stryCov_9fa48("1757"), "first_run_categories_invalid")
        }));
      }
    }
    const core = createAccountingCore(convexStore(ctx.db), stryMutAct_9fa48("1758") ? {} : (stryCov_9fa48("1758"), {
      now: stryMutAct_9fa48("1759") ? () => undefined : (stryCov_9fa48("1759"), () => dateFromTimestamp(args.now))
    }));
    const workspace = await bootstrapPersonalWorkspace(ctx, args, core);
    const request = canonicalJson(args);
    const prior = await ctx.db.query(stryMutAct_9fa48("1760") ? "" : (stryCov_9fa48("1760"), "firstRunCompletions")).withIndex(stryMutAct_9fa48("1761") ? "" : (stryCov_9fa48("1761"), "by_identity"), stryMutAct_9fa48("1762") ? () => undefined : (stryCov_9fa48("1762"), q => q.eq(stryMutAct_9fa48("1763") ? "" : (stryCov_9fa48("1763"), "tokenIdentifier"), ctx.actor.userId))).unique();
    if (stryMutAct_9fa48("1765") ? false : stryMutAct_9fa48("1764") ? true : (stryCov_9fa48("1764", "1765"), prior)) {
      if (stryMutAct_9fa48("1766")) {
        {}
      } else {
        stryCov_9fa48("1766");
        if (stryMutAct_9fa48("1769") ? prior.request === request : stryMutAct_9fa48("1768") ? false : stryMutAct_9fa48("1767") ? true : (stryCov_9fa48("1767", "1768", "1769"), prior.request !== request)) throw new AccountingError(stryMutAct_9fa48("1771") ? "" : (stryCov_9fa48("1771"), "idempotency_key_conflict"));
        return stryMutAct_9fa48("1772") ? {} : (stryCov_9fa48("1772"), {
          ...prior.result,
          replay: stryMutAct_9fa48("1773") ? false : (stryCov_9fa48("1773"), true)
        });
      }
    }
    if (stryMutAct_9fa48("1775") ? false : stryMutAct_9fa48("1774") ? true : (stryCov_9fa48("1774", "1775"), (await core.listFinancialAccountProfiles(stryMutAct_9fa48("1776") ? {} : (stryCov_9fa48("1776"), {
      workspaceId: workspace.id,
      actor: ctx.actor
    }))).length)) {
      if (stryMutAct_9fa48("1777")) {
        {}
      } else {
        stryCov_9fa48("1777");
        throw new ConvexError(stryMutAct_9fa48("1779") ? {} : (stryCov_9fa48("1779"), {
          code: stryMutAct_9fa48("1780") ? "" : (stryCov_9fa48("1780"), "first_run_already_completed")
        }));
      }
    }
    const categories = stryMutAct_9fa48("1781") ? ["Stryker was here"] : (stryCov_9fa48("1781"), []);
    for (const [index, selected] of args.categories.entries()) {
      if (stryMutAct_9fa48("1782")) {
        {}
      } else {
        stryCov_9fa48("1782");
        const created = await core.createUserCategory(stryMutAct_9fa48("1783") ? {} : (stryCov_9fa48("1783"), {
          ...selected,
          workspaceId: workspace.id,
          actor: ctx.actor,
          idempotencyKey: (stryMutAct_9fa48("1784") ? "" : (stryCov_9fa48("1784"), "first-run@1:category:")) + index
        }));
        if (stryMutAct_9fa48("1787") ? (created.kind !== "category" || created.category.classification.kind !== "resolved") && created.category.classification.nature !== "Expense" : stryMutAct_9fa48("1786") ? false : stryMutAct_9fa48("1785") ? true : (stryCov_9fa48("1785", "1786", "1787"), (stryMutAct_9fa48("1789") ? created.kind !== "category" && created.category.classification.kind !== "resolved" : stryMutAct_9fa48("1788") ? false : (stryCov_9fa48("1788", "1789"), (stryMutAct_9fa48("1791") ? created.kind === "category" : stryMutAct_9fa48("1790") ? false : (stryCov_9fa48("1790", "1791"), created.kind !== (stryMutAct_9fa48("1792") ? "" : (stryCov_9fa48("1792"), "category")))) || (stryMutAct_9fa48("1794") ? created.category.classification.kind === "resolved" : stryMutAct_9fa48("1793") ? false : (stryCov_9fa48("1793", "1794"), created.category.classification.kind !== (stryMutAct_9fa48("1795") ? "" : (stryCov_9fa48("1795"), "resolved")))))) || (stryMutAct_9fa48("1797") ? created.category.classification.nature === "Expense" : stryMutAct_9fa48("1796") ? false : (stryCov_9fa48("1796", "1797"), created.category.classification.nature !== (stryMutAct_9fa48("1798") ? "" : (stryCov_9fa48("1798"), "Expense")))))) {
          if (stryMutAct_9fa48("1799")) {
            {}
          } else {
            stryCov_9fa48("1799");
            throw new ConvexError(stryMutAct_9fa48("1801") ? {} : (stryCov_9fa48("1801"), {
              code: stryMutAct_9fa48("1802") ? "" : (stryCov_9fa48("1802"), "first_run_spend_category_required")
            }));
          }
        }
        if (stryMutAct_9fa48("1803")) {
          ;
        } else {
          stryCov_9fa48("1803");
          categories.push(created.category);
        }
      }
    }
    const opening = await core.setupFinancialAccount(stryMutAct_9fa48("1804") ? {} : (stryCov_9fa48("1804"), {
      workspaceId: workspace.id,
      actor: ctx.actor,
      name: stryMutAct_9fa48("1805") ? "" : (stryCov_9fa48("1805"), "My money"),
      productKind: stryMutAct_9fa48("1806") ? "" : (stryCov_9fa48("1806"), "cash"),
      amount: stryMutAct_9fa48("1807") ? {} : (stryCov_9fa48("1807"), {
        currency: workspace.functionalCurrency,
        minorUnits: args.startingAmountMinorUnits
      }),
      accountingDate: args.accountingDate,
      description: stryMutAct_9fa48("1808") ? "" : (stryCov_9fa48("1808"), "Start tracking"),
      idempotencyKey: stryMutAct_9fa48("1809") ? "" : (stryCov_9fa48("1809"), "first-run@1:my-money")
    }));
    const result = stryMutAct_9fa48("1810") ? {} : (stryCov_9fa48("1810"), {
      workspace,
      categories,
      opening,
      purchaseNotifications: args.purchaseNotifications,
      replay: stryMutAct_9fa48("1811") ? true : (stryCov_9fa48("1811"), false)
    });
    await ctx.db.insert(stryMutAct_9fa48("1812") ? "" : (stryCov_9fa48("1812"), "firstRunCompletions"), stryMutAct_9fa48("1813") ? {} : (stryCov_9fa48("1813"), {
      tokenIdentifier: ctx.actor.userId,
      request,
      result
    }));
    return result;
  }
}
export async function firstRunState(ctx: QueryCtx & OwnerContext, now: number) {
  if (stryMutAct_9fa48("1814")) {
    {}
  } else {
    stryCov_9fa48("1814");
    const link = await personalWorkspaceLink(ctx, ctx.actor.userId);
    if (stryMutAct_9fa48("1817") ? false : stryMutAct_9fa48("1816") ? true : stryMutAct_9fa48("1815") ? link : (stryCov_9fa48("1815", "1816", "1817"), !link)) return {
      kind: "required"
    } as const;
    await requirePersonalWorkspaceOwner(ctx, link.workspaceId, ctx.actor.userId);
    const core = createAccountingCore(convexReadStore(ctx.db));
    const workspace = await core.openWorkspace(stryMutAct_9fa48("1818") ? {} : (stryCov_9fa48("1818"), {
      workspaceId: link.workspaceId,
      actor: ctx.actor,
      now
    }));
    const receipt = await ctx.db.query(stryMutAct_9fa48("1819") ? "" : (stryCov_9fa48("1819"), "firstRunCompletions")).withIndex(stryMutAct_9fa48("1820") ? "" : (stryCov_9fa48("1820"), "by_identity"), stryMutAct_9fa48("1821") ? () => undefined : (stryCov_9fa48("1821"), q => q.eq(stryMutAct_9fa48("1822") ? "" : (stryCov_9fa48("1822"), "tokenIdentifier"), ctx.actor.userId))).unique();
    if (stryMutAct_9fa48("1824") ? false : stryMutAct_9fa48("1823") ? true : (stryCov_9fa48("1823", "1824"), receipt)) return {
      kind: "complete",
      workspace,
      profile: receipt.result.opening.profile,
      purchaseNotifications: receipt.result.purchaseNotifications
    } as const;
    const profiles = await core.listFinancialAccountProfiles(stryMutAct_9fa48("1825") ? {} : (stryCov_9fa48("1825"), {
      workspaceId: workspace.id,
      actor: ctx.actor
    }));
    return profiles.length ? {
      kind: "existing",
      workspace
    } as const : {
      kind: "required"
    } as const;
  }
}