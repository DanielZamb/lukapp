// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import type { QueryCtx } from "./_generated/server";
import { AccountingError } from "../src/accounting/errors";
export async function requirePlanningReadHeadroom(meta: QueryCtx["meta"]) {
  if (stryMutAct_9fa48("1937")) {
    {}
  } else {
    stryCov_9fa48("1937");
    const metrics = await meta.getTransactionMetrics();
    if (stryMutAct_9fa48("1940") ? (metrics.databaseQueries.used > 3000 || metrics.databaseQueries.remaining < 1096 || metrics.documentsRead.used > 20000 || metrics.documentsRead.remaining < 12000 || metrics.bytesRead.used > 8 * 1024 * 1024) && metrics.bytesRead.remaining < 8 * 1024 * 1024 : stryMutAct_9fa48("1939") ? false : stryMutAct_9fa48("1938") ? true : (stryCov_9fa48("1938", "1939", "1940"), (stryMutAct_9fa48("1942") ? (metrics.databaseQueries.used > 3000 || metrics.databaseQueries.remaining < 1096 || metrics.documentsRead.used > 20000 || metrics.documentsRead.remaining < 12000) && metrics.bytesRead.used > 8 * 1024 * 1024 : stryMutAct_9fa48("1941") ? false : (stryCov_9fa48("1941", "1942"), (stryMutAct_9fa48("1944") ? (metrics.databaseQueries.used > 3000 || metrics.databaseQueries.remaining < 1096 || metrics.documentsRead.used > 20000) && metrics.documentsRead.remaining < 12000 : stryMutAct_9fa48("1943") ? false : (stryCov_9fa48("1943", "1944"), (stryMutAct_9fa48("1946") ? (metrics.databaseQueries.used > 3000 || metrics.databaseQueries.remaining < 1096) && metrics.documentsRead.used > 20000 : stryMutAct_9fa48("1945") ? false : (stryCov_9fa48("1945", "1946"), (stryMutAct_9fa48("1948") ? metrics.databaseQueries.used > 3000 && metrics.databaseQueries.remaining < 1096 : stryMutAct_9fa48("1947") ? false : (stryCov_9fa48("1947", "1948"), (stryMutAct_9fa48("1951") ? metrics.databaseQueries.used <= 3000 : stryMutAct_9fa48("1950") ? metrics.databaseQueries.used >= 3000 : stryMutAct_9fa48("1949") ? false : (stryCov_9fa48("1949", "1950", "1951"), metrics.databaseQueries.used > 3000)) || (stryMutAct_9fa48("1954") ? metrics.databaseQueries.remaining >= 1096 : stryMutAct_9fa48("1953") ? metrics.databaseQueries.remaining <= 1096 : stryMutAct_9fa48("1952") ? false : (stryCov_9fa48("1952", "1953", "1954"), metrics.databaseQueries.remaining < 1096)))) || (stryMutAct_9fa48("1957") ? metrics.documentsRead.used <= 20000 : stryMutAct_9fa48("1956") ? metrics.documentsRead.used >= 20000 : stryMutAct_9fa48("1955") ? false : (stryCov_9fa48("1955", "1956", "1957"), metrics.documentsRead.used > 20000)))) || (stryMutAct_9fa48("1960") ? metrics.documentsRead.remaining >= 12000 : stryMutAct_9fa48("1959") ? metrics.documentsRead.remaining <= 12000 : stryMutAct_9fa48("1958") ? false : (stryCov_9fa48("1958", "1959", "1960"), metrics.documentsRead.remaining < 12000)))) || (stryMutAct_9fa48("1963") ? metrics.bytesRead.used <= 8 * 1024 * 1024 : stryMutAct_9fa48("1962") ? metrics.bytesRead.used >= 8 * 1024 * 1024 : stryMutAct_9fa48("1961") ? false : (stryCov_9fa48("1961", "1962", "1963"), metrics.bytesRead.used > (stryMutAct_9fa48("1964") ? 8 * 1024 / 1024 : (stryCov_9fa48("1964"), (stryMutAct_9fa48("1965") ? 8 / 1024 : (stryCov_9fa48("1965"), 8 * 1024)) * 1024)))))) || (stryMutAct_9fa48("1968") ? metrics.bytesRead.remaining >= 8 * 1024 * 1024 : stryMutAct_9fa48("1967") ? metrics.bytesRead.remaining <= 8 * 1024 * 1024 : stryMutAct_9fa48("1966") ? false : (stryCov_9fa48("1966", "1967", "1968"), metrics.bytesRead.remaining < (stryMutAct_9fa48("1969") ? 8 * 1024 / 1024 : (stryCov_9fa48("1969"), (stryMutAct_9fa48("1970") ? 8 / 1024 : (stryCov_9fa48("1970"), 8 * 1024)) * 1024)))))) throw new AccountingError(stryMutAct_9fa48("1972") ? "" : (stryCov_9fa48("1972"), "planning_read_limit"));
  }
}
export async function planningDocuments<T>(meta: QueryCtx["meta"], query: AsyncIterable<T>, maximum: number): Promise<T[]> {
  if (stryMutAct_9fa48("1973")) {
    {}
  } else {
    stryCov_9fa48("1973");
    await requirePlanningReadHeadroom(meta);
    const iterator = query[Symbol.asyncIterator]();
    const documents: T[] = stryMutAct_9fa48("1974") ? ["Stryker was here"] : (stryCov_9fa48("1974"), []);
    try {
      if (stryMutAct_9fa48("1975")) {
        {}
      } else {
        stryCov_9fa48("1975");
        while (stryMutAct_9fa48("1977") ? false : stryMutAct_9fa48("1976") ? false : (stryCov_9fa48("1976", "1977"), true)) {
          if (stryMutAct_9fa48("1978")) {
            {}
          } else {
            stryCov_9fa48("1978");
            await requirePlanningReadHeadroom(meta);
            const next = await iterator.next();
            await requirePlanningReadHeadroom(meta);
            if (stryMutAct_9fa48("1980") ? false : stryMutAct_9fa48("1979") ? true : (stryCov_9fa48("1979", "1980"), next.done)) return documents;
            if (stryMutAct_9fa48("1983") ? documents.length !== maximum : stryMutAct_9fa48("1982") ? false : stryMutAct_9fa48("1981") ? true : (stryCov_9fa48("1981", "1982", "1983"), documents.length === maximum)) throw new AccountingError(stryMutAct_9fa48("1985") ? "" : (stryCov_9fa48("1985"), "planning_read_limit"));
            if (stryMutAct_9fa48("1986")) {
              ;
            } else {
              stryCov_9fa48("1986");
              documents.push(next.value);
            }
          }
        }
      }
    } finally {
      if (stryMutAct_9fa48("1987")) {
        {}
      } else {
        stryCov_9fa48("1987");
        await (stryMutAct_9fa48("1988") ? iterator.return() : (stryCov_9fa48("1988"), iterator.return?.()));
      }
    }
  }
}