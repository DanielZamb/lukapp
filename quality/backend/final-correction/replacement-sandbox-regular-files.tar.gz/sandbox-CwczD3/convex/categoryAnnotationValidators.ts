// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { v } from "convex/values";
export const categoryNature = v.union(v.literal(stryMutAct_9fa48("527") ? "" : (stryCov_9fa48("527"), "Expense")), v.literal(stryMutAct_9fa48("528") ? "" : (stryCov_9fa48("528"), "Income")));
export const natureAnswer = v.union(categoryNature, v.literal(stryMutAct_9fa48("529") ? "" : (stryCov_9fa48("529"), "stillMine")), v.literal(stryMutAct_9fa48("530") ? "" : (stryCov_9fa48("530"), "payingDebt")));
export const accountResolution = v.union(v.object(stryMutAct_9fa48("531") ? {} : (stryCov_9fa48("531"), {
  kind: v.literal(stryMutAct_9fa48("532") ? "" : (stryCov_9fa48("532"), "preset")),
  concept: v.string(),
  policy: v.string(),
  accountCode: v.string()
})), v.object(stryMutAct_9fa48("533") ? {} : (stryCov_9fa48("533"), {
  kind: v.literal(stryMutAct_9fa48("534") ? "" : (stryCov_9fa48("534"), "lexicon")),
  concept: v.string(),
  policy: v.string(),
  accountCode: v.string()
})), v.object(stryMutAct_9fa48("535") ? {} : (stryCov_9fa48("535"), {
  kind: v.literal(stryMutAct_9fa48("536") ? "" : (stryCov_9fa48("536"), "fallback")),
  policy: v.string(),
  accountCode: v.string(),
  candidates: v.array(v.string())
})), v.object(stryMutAct_9fa48("537") ? {} : (stryCov_9fa48("537"), {
  kind: v.literal(stryMutAct_9fa48("538") ? "" : (stryCov_9fa48("538"), "advanced")),
  accountCode: v.string()
})));
export const natureProvenance = v.union(v.object(stryMutAct_9fa48("539") ? {} : (stryCov_9fa48("539"), {
  kind: v.literal(stryMutAct_9fa48("540") ? "" : (stryCov_9fa48("540"), "preset")),
  concept: v.string()
})), v.object(stryMutAct_9fa48("541") ? {} : (stryCov_9fa48("541"), {
  kind: v.literal(stryMutAct_9fa48("542") ? "" : (stryCov_9fa48("542"), "answered"))
})), v.object(stryMutAct_9fa48("543") ? {} : (stryCov_9fa48("543"), {
  kind: v.literal(stryMutAct_9fa48("544") ? "" : (stryCov_9fa48("544"), "lexiconConfirmed")),
  policy: v.string(),
  answer: natureAnswer
})));
export const categoryClassification = v.union(v.object(stryMutAct_9fa48("545") ? {} : (stryCov_9fa48("545"), {
  kind: v.literal(stryMutAct_9fa48("546") ? "" : (stryCov_9fa48("546"), "unresolved"))
})), v.object(stryMutAct_9fa48("547") ? {} : (stryCov_9fa48("547"), {
  kind: v.literal(stryMutAct_9fa48("548") ? "" : (stryCov_9fa48("548"), "resolved")),
  nature: categoryNature,
  natureProvenance,
  account: accountResolution
})), v.object(stryMutAct_9fa48("549") ? {} : (stryCov_9fa48("549"), {
  kind: v.literal(stryMutAct_9fa48("550") ? "" : (stryCov_9fa48("550"), "converted")),
  financialAccountProfileId: v.string()
})));
export const categoryFields = stryMutAct_9fa48("551") ? {} : (stryCov_9fa48("551"), {
  workspaceId: v.string(),
  name: v.string(),
  revision: v.number(),
  status: v.union(v.literal(stryMutAct_9fa48("552") ? "" : (stryCov_9fa48("552"), "active")), v.literal(stryMutAct_9fa48("553") ? "" : (stryCov_9fa48("553"), "archived"))),
  mergedIntoCategoryId: v.optional(v.string()),
  classification: categoryClassification
});
export const userCategory = v.object(stryMutAct_9fa48("554") ? {} : (stryCov_9fa48("554"), {
  id: v.string(),
  ...categoryFields
}));
export const categorySnapshot = v.object(stryMutAct_9fa48("555") ? {} : (stryCov_9fa48("555"), {
  categoryId: v.string(),
  revision: v.number(),
  name: v.string(),
  nature: categoryNature,
  natureProvenance,
  account: accountResolution
}));
export const correctionSource = v.object(stryMutAct_9fa48("556") ? {} : (stryCov_9fa48("556"), {
  entryId: v.string(),
  lineNumber: v.number(),
  signedMinorUnits: v.number()
}));
export const categoryCorrection = v.object(stryMutAct_9fa48("557") ? {} : (stryCov_9fa48("557"), {
  reclassificationKey: v.string(),
  side: v.union(v.literal(stryMutAct_9fa48("558") ? "" : (stryCov_9fa48("558"), "reversing")), v.literal(stryMutAct_9fa48("559") ? "" : (stryCov_9fa48("559"), "replacement"))),
  sources: v.array(correctionSource),
  rootSources: v.array(correctionSource),
  priorLockedPeriods: v.array(v.string())
}));