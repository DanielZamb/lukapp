// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import type { QueryCtx, MutationCtx } from "./_generated/server";
import type { Doc } from "./_generated/dataModel";
import { convexReadStore } from "./store";
import { listPostedExpenses } from "../src/accounting/queries/listPostedExpenses";
import { balances } from "../src/accounting/queries/balances";
import type { Plan, RecoveryEvent, RecoveryLedger, RecoveryReadStore, RecoveryStore } from "../src/savingsRecovery/types";
function toPlan({
  _id,
  _creationTime,
  ...fields
}: Doc<"recoveryPlans">): Plan {
  if (stryMutAct_9fa48("2314")) {
    {}
  } else {
    stryCov_9fa48("2314");
    return stryMutAct_9fa48("2315") ? {} : (stryCov_9fa48("2315"), {
      id: _id,
      ...fields
    });
  }
}
function toEvent({
  _id,
  _creationTime,
  ...fields
}: Doc<"recoveryEvents">): RecoveryEvent {
  if (stryMutAct_9fa48("2316")) {
    {}
  } else {
    stryCov_9fa48("2316");
    return stryMutAct_9fa48("2317") ? {} : (stryCov_9fa48("2317"), {
      id: _id,
      ...fields
    });
  }
}
export function recoveryLedger(db: QueryCtx["db"]): RecoveryLedger {
  if (stryMutAct_9fa48("2318")) {
    {}
  } else {
    stryCov_9fa48("2318");
    const store = convexReadStore(db);
    return stryMutAct_9fa48("2319") ? {} : (stryCov_9fa48("2319"), {
      getWorkspace: store.getWorkspace,
      membershipRole: store.membershipRole,
      getJournalEntry: store.getJournalEntry,
      findReversalOf: store.findReversalOf,
      listJournalSourceEffects: store.listJournalSourceEffects,
      listAccountTransferEntriesInRange: store.listAccountTransferEntriesInRange,
      getProfile: store.getProfile,
      getLedgerAccount: store.getLedgerAccount,
      getAccountingPeriod: store.getAccountingPeriod,
      expenses: stryMutAct_9fa48("2320") ? () => undefined : (stryCov_9fa48("2320"), input => listPostedExpenses(store, input)),
      balances: stryMutAct_9fa48("2321") ? () => undefined : (stryCov_9fa48("2321"), input => balances(store, input))
    });
  }
}
export function recoveryReadStore(db: QueryCtx["db"]): RecoveryReadStore {
  if (stryMutAct_9fa48("2322")) {
    {}
  } else {
    stryCov_9fa48("2322");
    return stryMutAct_9fa48("2323") ? {} : (stryCov_9fa48("2323"), {
      async snapshot(workspaceId) {
        if (stryMutAct_9fa48("2324")) {
          {}
        } else {
          stryCov_9fa48("2324");
          const [plans, events] = await Promise.all(stryMutAct_9fa48("2325") ? [] : (stryCov_9fa48("2325"), [db.query(stryMutAct_9fa48("2326") ? "" : (stryCov_9fa48("2326"), "recoveryPlans")).withIndex(stryMutAct_9fa48("2327") ? "" : (stryCov_9fa48("2327"), "by_workspace"), stryMutAct_9fa48("2328") ? () => undefined : (stryCov_9fa48("2328"), q => q.eq(stryMutAct_9fa48("2329") ? "" : (stryCov_9fa48("2329"), "workspaceId"), workspaceId))).collect(), db.query(stryMutAct_9fa48("2330") ? "" : (stryCov_9fa48("2330"), "recoveryEvents")).withIndex(stryMutAct_9fa48("2331") ? "" : (stryCov_9fa48("2331"), "by_workspace"), stryMutAct_9fa48("2332") ? () => undefined : (stryCov_9fa48("2332"), q => q.eq(stryMutAct_9fa48("2333") ? "" : (stryCov_9fa48("2333"), "workspaceId"), workspaceId))).collect()]));
          return stryMutAct_9fa48("2334") ? {} : (stryCov_9fa48("2334"), {
            plans: plans.map(toPlan),
            events: events.map(toEvent)
          });
        }
      },
      async receipt(workspaceId, key) {
        if (stryMutAct_9fa48("2335")) {
          {}
        } else {
          stryCov_9fa48("2335");
          const receipt = await db.query(stryMutAct_9fa48("2336") ? "" : (stryCov_9fa48("2336"), "recoveryReceipts")).withIndex(stryMutAct_9fa48("2337") ? "" : (stryCov_9fa48("2337"), "by_workspace_key"), stryMutAct_9fa48("2338") ? () => undefined : (stryCov_9fa48("2338"), q => q.eq(stryMutAct_9fa48("2339") ? "" : (stryCov_9fa48("2339"), "workspaceId"), workspaceId).eq(stryMutAct_9fa48("2340") ? "" : (stryCov_9fa48("2340"), "key"), key))).unique();
          return receipt ? stryMutAct_9fa48("2341") ? {} : (stryCov_9fa48("2341"), {
            fingerprint: receipt.fingerprint,
            resultId: receipt.resultId
          }) : undefined;
        }
      }
    });
  }
}
export function recoveryStore(db: MutationCtx["db"]): RecoveryStore {
  if (stryMutAct_9fa48("2342")) {
    {}
  } else {
    stryCov_9fa48("2342");
    return stryMutAct_9fa48("2343") ? {} : (stryCov_9fa48("2343"), {
      ...recoveryReadStore(db),
      insertPlan: stryMutAct_9fa48("2344") ? () => undefined : (stryCov_9fa48("2344"), plan => db.insert(stryMutAct_9fa48("2345") ? "" : (stryCov_9fa48("2345"), "recoveryPlans"), plan)),
      async updatePlan({
        id,
        ...plan
      }) {
        if (stryMutAct_9fa48("2346")) {
          {}
        } else {
          stryCov_9fa48("2346");
          const normalized = db.normalizeId(stryMutAct_9fa48("2347") ? "" : (stryCov_9fa48("2347"), "recoveryPlans"), id);
          if (stryMutAct_9fa48("2350") ? false : stryMutAct_9fa48("2349") ? true : stryMutAct_9fa48("2348") ? normalized : (stryCov_9fa48("2348", "2349", "2350"), !normalized)) throw new Error(stryMutAct_9fa48("2352") ? "" : (stryCov_9fa48("2352"), "Invalid Recovery plan id"));
          await db.replace(normalized, plan);
        }
      },
      appendEvent: stryMutAct_9fa48("2353") ? () => undefined : (stryCov_9fa48("2353"), event => db.insert(stryMutAct_9fa48("2354") ? "" : (stryCov_9fa48("2354"), "recoveryEvents"), event)),
      async saveReceipt(workspaceId, key, receipt) {
        if (stryMutAct_9fa48("2355")) {
          {}
        } else {
          stryCov_9fa48("2355");
          await db.insert(stryMutAct_9fa48("2356") ? "" : (stryCov_9fa48("2356"), "recoveryReceipts"), stryMutAct_9fa48("2357") ? {} : (stryCov_9fa48("2357"), {
            workspaceId,
            key,
            ...receipt
          }));
        }
      }
    });
  }
}