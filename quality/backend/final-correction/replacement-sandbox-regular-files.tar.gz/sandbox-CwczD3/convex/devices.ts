// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { enqueueProviderWork } from "./lib/providerWork";
import { providerState } from "./providerValidators";
import { ConvexError, v } from "convex/values";
import { mutation, query, internalMutation } from "./_generated/server";
import { ownerAdmission, requireOwner } from "./lib/owner";
import { accessOperation, devicePlatform, deviceProof, deviceSummary, deviceStatus, preparedChallenge } from "./deviceValidators";
import { bindingDenial, consumeChallenge, denyAccess, importDeviceKey, registrationAllowed, providerSessionDenied, requireEligibleSession, sessionBinding, sessionDenial, summarizeDevice, verifiedSessionId, verifyChallenge, verifyPayload } from "./lib/deviceAccess";
import { accessPolicy, bytesToHex, challengeMessage, directiveFor } from "../src/access/protocol";
export const status = query(stryMutAct_9fa48("865") ? {} : (stryCov_9fa48("865"), {
  args: stryMutAct_9fa48("866") ? {} : (stryCov_9fa48("866"), {
    deviceId: v.optional(v.id(stryMutAct_9fa48("867") ? "" : (stryCov_9fa48("867"), "mobileDevices")))
  }),
  returns: deviceStatus,
  handler: async (ctx, args) => {
    if (stryMutAct_9fa48("868")) {
      {}
    } else {
      stryCov_9fa48("868");
      const owner = await requireOwner(ctx);
      const invalid = sessionDenial(owner.clerkIdentity);
      if (stryMutAct_9fa48("870") ? false : stryMutAct_9fa48("869") ? true : (stryCov_9fa48("869", "870"), invalid)) return {
        kind: "denied",
        code: invalid,
        directive: directiveFor(invalid)
      } as const;
      const sid = verifiedSessionId(owner.clerkIdentity);
      if (stryMutAct_9fa48("872") ? false : stryMutAct_9fa48("871") ? true : (stryCov_9fa48("871", "872"), await providerSessionDenied(ctx, owner.identity.tokenIdentifier, sid))) return {
        kind: "denied",
        code: "session_revoked",
        directive: "wipe-local-input-and-sign-out"
      } as const;
      const device = await sessionBinding(ctx, owner.identity.tokenIdentifier, sid);
      if (stryMutAct_9fa48("874") ? false : stryMutAct_9fa48("873") ? true : (stryCov_9fa48("873", "874"), device)) {
        if (stryMutAct_9fa48("875")) {
          {}
        } else {
          stryCov_9fa48("875");
          const denial = bindingDenial(device, Date.now());
          if (stryMutAct_9fa48("877") ? false : stryMutAct_9fa48("876") ? true : (stryCov_9fa48("876", "877"), denial)) return {
            kind: "denied",
            code: denial,
            directive: directiveFor(denial)
          } as const;
        }
      }
      if (stryMutAct_9fa48("880") ? false : stryMutAct_9fa48("879") ? true : stryMutAct_9fa48("878") ? await registrationAllowed(ctx, owner.identity.tokenIdentifier, sid) : (stryCov_9fa48("878", "879", "880"), !(await registrationAllowed(ctx, owner.identity.tokenIdentifier, sid)))) {
        if (stryMutAct_9fa48("881")) {
          {}
        } else {
          stryCov_9fa48("881");
          return {
            kind: "denied",
            code: "recovery_registration_blocked",
            directive: "wipe-local-input-and-sign-out"
          } as const;
        }
      }
      if (stryMutAct_9fa48("884") ? false : stryMutAct_9fa48("883") ? true : stryMutAct_9fa48("882") ? device : (stryCov_9fa48("882", "883", "884"), !device)) {
        if (stryMutAct_9fa48("885")) {
          {}
        } else {
          stryCov_9fa48("885");
          const code = args.deviceId ? stryMutAct_9fa48("886") ? "" : (stryCov_9fa48("886"), "device_unknown") : stryMutAct_9fa48("887") ? "" : (stryCov_9fa48("887"), "device_unregistered");
          return {
            kind: "denied",
            code,
            directive: directiveFor(code)
          } as const;
        }
      }
      if (stryMutAct_9fa48("890") ? args.deviceId || args.deviceId !== device._id : stryMutAct_9fa48("889") ? false : stryMutAct_9fa48("888") ? true : (stryCov_9fa48("888", "889", "890"), args.deviceId && (stryMutAct_9fa48("892") ? args.deviceId === device._id : stryMutAct_9fa48("891") ? true : (stryCov_9fa48("891", "892"), args.deviceId !== device._id)))) {
        if (stryMutAct_9fa48("893")) {
          {}
        } else {
          stryCov_9fa48("893");
          return {
            kind: "denied",
            code: "device_unknown",
            directive: "register-device"
          } as const;
        }
      }
      return {
        kind: "registered",
        device: summarizeDevice(device),
        policy: accessPolicy
      } as const;
    }
  }
}));
export const list = query(stryMutAct_9fa48("894") ? {} : (stryCov_9fa48("894"), {
  args: {},
  returns: v.array(deviceSummary),
  handler: async ctx => {
    if (stryMutAct_9fa48("895")) {
      {}
    } else {
      stryCov_9fa48("895");
      const owner = await requireOwner(ctx);
      const sid = await requireEligibleSession(ctx, owner.clerkIdentity);
      const current = await sessionBinding(ctx, owner.identity.tokenIdentifier, sid);
      if (stryMutAct_9fa48("897") ? false : stryMutAct_9fa48("896") ? true : (stryCov_9fa48("896", "897"), current)) {
        if (stryMutAct_9fa48("898")) {
          {}
        } else {
          stryCov_9fa48("898");
          const denial = bindingDenial(current, Date.now());
          if (stryMutAct_9fa48("900") ? false : stryMutAct_9fa48("899") ? true : (stryCov_9fa48("899", "900"), denial)) if (stryMutAct_9fa48("901")) {
            ;
          } else {
            stryCov_9fa48("901");
            denyAccess(denial);
          }
        }
      }
      if (stryMutAct_9fa48("904") ? false : stryMutAct_9fa48("903") ? true : stryMutAct_9fa48("902") ? await registrationAllowed(ctx, owner.identity.tokenIdentifier, sid) : (stryCov_9fa48("902", "903", "904"), !(await registrationAllowed(ctx, owner.identity.tokenIdentifier, sid)))) denyAccess(stryMutAct_9fa48("906") ? "" : (stryCov_9fa48("906"), "recovery_registration_blocked"));
      return (await ctx.db.query(stryMutAct_9fa48("907") ? "" : (stryCov_9fa48("907"), "mobileDevices")).withIndex(stryMutAct_9fa48("908") ? "" : (stryCov_9fa48("908"), "by_identity"), stryMutAct_9fa48("909") ? () => undefined : (stryCov_9fa48("909"), q => q.eq(stryMutAct_9fa48("910") ? "" : (stryCov_9fa48("910"), "tokenIdentifier"), owner.identity.tokenIdentifier))).collect()).map(summarizeDevice);
    }
  }
}));
export const prepare = mutation(stryMutAct_9fa48("911") ? {} : (stryCov_9fa48("911"), {
  args: stryMutAct_9fa48("912") ? {} : (stryCov_9fa48("912"), {
    operation: accessOperation,
    payloadHash: v.string(),
    deviceId: v.optional(v.id(stryMutAct_9fa48("913") ? "" : (stryCov_9fa48("913"), "mobileDevices"))),
    publicKey: v.optional(v.string())
  }),
  returns: preparedChallenge,
  handler: async (ctx, args) => {
    if (stryMutAct_9fa48("914")) {
      {}
    } else {
      stryCov_9fa48("914");
      const owner = await requireOwner(ctx);
      const sid = await requireEligibleSession(ctx, owner.clerkIdentity);
      if (stryMutAct_9fa48("917") ? false : stryMutAct_9fa48("916") ? true : stryMutAct_9fa48("915") ? /^[0-9a-f]{64}$/.test(args.payloadHash) : (stryCov_9fa48("915", "916", "917"), !(stryMutAct_9fa48("921") ? /^[^0-9a-f]{64}$/ : stryMutAct_9fa48("920") ? /^[0-9a-f]$/ : stryMutAct_9fa48("919") ? /^[0-9a-f]{64}/ : stryMutAct_9fa48("918") ? /[0-9a-f]{64}$/ : (stryCov_9fa48("918", "919", "920", "921"), /^[0-9a-f]{64}$/)).test(args.payloadHash))) denyAccess(stryMutAct_9fa48("923") ? "" : (stryCov_9fa48("923"), "device_request_mismatch"));
      const device = await sessionBinding(ctx, owner.identity.tokenIdentifier, sid);
      if (stryMutAct_9fa48("925") ? false : stryMutAct_9fa48("924") ? true : (stryCov_9fa48("924", "925"), device)) {
        if (stryMutAct_9fa48("926")) {
          {}
        } else {
          stryCov_9fa48("926");
          const denial = bindingDenial(device, Date.now());
          if (stryMutAct_9fa48("928") ? false : stryMutAct_9fa48("927") ? true : (stryCov_9fa48("927", "928"), denial)) if (stryMutAct_9fa48("929")) {
            ;
          } else {
            stryCov_9fa48("929");
            denyAccess(denial);
          }
          const enrollmentRetry = stryMutAct_9fa48("932") ? args.operation === "devices.register" && args.deviceId === undefined || args.publicKey === device.publicKey : stryMutAct_9fa48("931") ? false : stryMutAct_9fa48("930") ? true : (stryCov_9fa48("930", "931", "932"), (stryMutAct_9fa48("934") ? args.operation === "devices.register" || args.deviceId === undefined : stryMutAct_9fa48("933") ? true : (stryCov_9fa48("933", "934"), (stryMutAct_9fa48("936") ? args.operation !== "devices.register" : stryMutAct_9fa48("935") ? true : (stryCov_9fa48("935", "936"), args.operation === (stryMutAct_9fa48("937") ? "" : (stryCov_9fa48("937"), "devices.register")))) && (stryMutAct_9fa48("939") ? args.deviceId !== undefined : stryMutAct_9fa48("938") ? true : (stryCov_9fa48("938", "939"), args.deviceId === undefined)))) && (stryMutAct_9fa48("941") ? args.publicKey !== device.publicKey : stryMutAct_9fa48("940") ? true : (stryCov_9fa48("940", "941"), args.publicKey === device.publicKey)));
          if (stryMutAct_9fa48("944") ? !enrollmentRetry || args.deviceId !== device._id : stryMutAct_9fa48("943") ? false : stryMutAct_9fa48("942") ? true : (stryCov_9fa48("942", "943", "944"), (stryMutAct_9fa48("945") ? enrollmentRetry : (stryCov_9fa48("945"), !enrollmentRetry)) && (stryMutAct_9fa48("947") ? args.deviceId === device._id : stryMutAct_9fa48("946") ? true : (stryCov_9fa48("946", "947"), args.deviceId !== device._id)))) denyAccess(stryMutAct_9fa48("949") ? "" : (stryCov_9fa48("949"), "session_device_mismatch"));
        }
      } else {
        if (stryMutAct_9fa48("950")) {
          {}
        } else {
          stryCov_9fa48("950");
          if (stryMutAct_9fa48("953") ? false : stryMutAct_9fa48("952") ? true : stryMutAct_9fa48("951") ? await registrationAllowed(ctx, owner.identity.tokenIdentifier, sid) : (stryCov_9fa48("951", "952", "953"), !(await registrationAllowed(ctx, owner.identity.tokenIdentifier, sid)))) denyAccess(stryMutAct_9fa48("955") ? "" : (stryCov_9fa48("955"), "recovery_registration_blocked"));
          if (stryMutAct_9fa48("957") ? false : stryMutAct_9fa48("956") ? true : (stryCov_9fa48("956", "957"), args.deviceId)) denyAccess(stryMutAct_9fa48("959") ? "" : (stryCov_9fa48("959"), "device_unknown"));
          if (stryMutAct_9fa48("962") ? args.operation !== "devices.register" || args.operation !== "devices.revoke" : stryMutAct_9fa48("961") ? false : stryMutAct_9fa48("960") ? true : (stryCov_9fa48("960", "961", "962"), (stryMutAct_9fa48("964") ? args.operation === "devices.register" : stryMutAct_9fa48("963") ? true : (stryCov_9fa48("963", "964"), args.operation !== (stryMutAct_9fa48("965") ? "" : (stryCov_9fa48("965"), "devices.register")))) && (stryMutAct_9fa48("967") ? args.operation === "devices.revoke" : stryMutAct_9fa48("966") ? true : (stryCov_9fa48("966", "967"), args.operation !== (stryMutAct_9fa48("968") ? "" : (stryCov_9fa48("968"), "devices.revoke")))))) denyAccess(stryMutAct_9fa48("970") ? "" : (stryCov_9fa48("970"), "device_unregistered"));
        }
      }
      const publicKey = stryMutAct_9fa48("971") ? device?.publicKey && args.publicKey : (stryCov_9fa48("971"), (stryMutAct_9fa48("972") ? device.publicKey : (stryCov_9fa48("972"), device?.publicKey)) ?? args.publicKey);
      if (stryMutAct_9fa48("975") ? false : stryMutAct_9fa48("974") ? true : stryMutAct_9fa48("973") ? publicKey : (stryCov_9fa48("973", "974", "975"), !publicKey)) denyAccess(stryMutAct_9fa48("977") ? "" : (stryCov_9fa48("977"), "device_proof_required"));
      await importDeviceKey(publicKey);
      for (const old of await ctx.db.query(stryMutAct_9fa48("978") ? "" : (stryCov_9fa48("978"), "deviceChallenges")).withIndex(stryMutAct_9fa48("979") ? "" : (stryCov_9fa48("979"), "by_identity_sid"), stryMutAct_9fa48("980") ? () => undefined : (stryCov_9fa48("980"), q => q.eq(stryMutAct_9fa48("981") ? "" : (stryCov_9fa48("981"), "tokenIdentifier"), owner.identity.tokenIdentifier).eq(stryMutAct_9fa48("982") ? "" : (stryCov_9fa48("982"), "sid"), sid))).collect()) {
        if (stryMutAct_9fa48("983")) {
          {}
        } else {
          stryCov_9fa48("983");
          if (stryMutAct_9fa48("987") ? old.expiresAt > Date.now() : stryMutAct_9fa48("986") ? old.expiresAt < Date.now() : stryMutAct_9fa48("985") ? false : stryMutAct_9fa48("984") ? true : (stryCov_9fa48("984", "985", "986", "987"), old.expiresAt <= Date.now())) await ctx.db.delete(old._id);
        }
      }
      const nonce = bytesToHex(crypto.getRandomValues(new Uint8Array(32)));
      const expiresAt = stryMutAct_9fa48("988") ? Date.now() - accessPolicy.challengeLifetimeMs : (stryCov_9fa48("988"), Date.now() + accessPolicy.challengeLifetimeMs);
      const id = await ctx.db.insert(stryMutAct_9fa48("989") ? "" : (stryCov_9fa48("989"), "deviceChallenges"), stryMutAct_9fa48("990") ? {} : (stryCov_9fa48("990"), {
        tokenIdentifier: owner.identity.tokenIdentifier,
        sid,
        operation: args.operation,
        payloadHash: args.payloadHash,
        ...(device ? stryMutAct_9fa48("991") ? {} : (stryCov_9fa48("991"), {
          deviceId: device._id
        }) : {}),
        publicKey,
        nonce,
        expiresAt
      }));
      return stryMutAct_9fa48("992") ? {} : (stryCov_9fa48("992"), {
        challengeId: id,
        expiresAt,
        message: challengeMessage(stryMutAct_9fa48("993") ? {} : (stryCov_9fa48("993"), {
          challengeId: id,
          nonce,
          expiresAt,
          tokenIdentifier: owner.identity.tokenIdentifier,
          sid,
          operation: args.operation,
          payloadHash: args.payloadHash
        }))
      });
    }
  }
}));
export const register = mutation(stryMutAct_9fa48("994") ? {} : (stryCov_9fa48("994"), {
  args: stryMutAct_9fa48("995") ? {} : (stryCov_9fa48("995"), {
    name: v.string(),
    platform: devicePlatform,
    publicKey: v.string(),
    access: v.optional(deviceProof)
  }),
  returns: deviceSummary,
  handler: async (ctx, {
    access,
    ...args
  }) => {
    if (stryMutAct_9fa48("996")) {
      {}
    } else {
      stryCov_9fa48("996");
      const owner = await requireOwner(ctx);
      const sid = await requireEligibleSession(ctx, owner.clerkIdentity);
      const verified = await verifyChallenge(ctx, owner.clerkIdentity, access, stryMutAct_9fa48("997") ? "" : (stryCov_9fa48("997"), "devices.register"), stryMutAct_9fa48("998") ? true : (stryCov_9fa48("998"), false));
      await verifyPayload(verified.challenge, args);
      if (stryMutAct_9fa48("1001") ? args.publicKey === verified.challenge.publicKey : stryMutAct_9fa48("1000") ? false : stryMutAct_9fa48("999") ? true : (stryCov_9fa48("999", "1000", "1001"), args.publicKey !== verified.challenge.publicKey)) denyAccess(stryMutAct_9fa48("1003") ? "" : (stryCov_9fa48("1003"), "device_proof_invalid"));
      if (stryMutAct_9fa48("1006") ? !args.name.trim() && args.name.length > 80 : stryMutAct_9fa48("1005") ? false : stryMutAct_9fa48("1004") ? true : (stryCov_9fa48("1004", "1005", "1006"), (stryMutAct_9fa48("1007") ? args.name.trim() : (stryCov_9fa48("1007"), !(stryMutAct_9fa48("1008") ? args.name : (stryCov_9fa48("1008"), args.name.trim())))) || (stryMutAct_9fa48("1011") ? args.name.length <= 80 : stryMutAct_9fa48("1010") ? args.name.length >= 80 : stryMutAct_9fa48("1009") ? false : (stryCov_9fa48("1009", "1010", "1011"), args.name.length > 80)))) denyAccess(stryMutAct_9fa48("1013") ? "" : (stryCov_9fa48("1013"), "device_registration_conflict"));
      const existing = await sessionBinding(ctx, owner.identity.tokenIdentifier, sid);
      if (stryMutAct_9fa48("1015") ? false : stryMutAct_9fa48("1014") ? true : (stryCov_9fa48("1014", "1015"), existing)) {
        if (stryMutAct_9fa48("1016")) {
          {}
        } else {
          stryCov_9fa48("1016");
          if (stryMutAct_9fa48("1019") ? (existing.publicKey !== args.publicKey || existing.platform !== args.platform) && existing.name !== args.name : stryMutAct_9fa48("1018") ? false : stryMutAct_9fa48("1017") ? true : (stryCov_9fa48("1017", "1018", "1019"), (stryMutAct_9fa48("1021") ? existing.publicKey !== args.publicKey && existing.platform !== args.platform : stryMutAct_9fa48("1020") ? false : (stryCov_9fa48("1020", "1021"), (stryMutAct_9fa48("1023") ? existing.publicKey === args.publicKey : stryMutAct_9fa48("1022") ? false : (stryCov_9fa48("1022", "1023"), existing.publicKey !== args.publicKey)) || (stryMutAct_9fa48("1025") ? existing.platform === args.platform : stryMutAct_9fa48("1024") ? false : (stryCov_9fa48("1024", "1025"), existing.platform !== args.platform)))) || (stryMutAct_9fa48("1027") ? existing.name === args.name : stryMutAct_9fa48("1026") ? false : (stryCov_9fa48("1026", "1027"), existing.name !== args.name)))) denyAccess(stryMutAct_9fa48("1029") ? "" : (stryCov_9fa48("1029"), "device_registration_conflict"));
          await consumeChallenge(ctx, verified.challenge, existing);
          return summarizeDevice(stryMutAct_9fa48("1030") ? {} : (stryCov_9fa48("1030"), {
            ...existing,
            lastSeenAt: Date.now()
          }));
        }
      }
      const keyUsed = await ctx.db.query(stryMutAct_9fa48("1031") ? "" : (stryCov_9fa48("1031"), "mobileDevices")).withIndex(stryMutAct_9fa48("1032") ? "" : (stryCov_9fa48("1032"), "by_identity_key"), stryMutAct_9fa48("1033") ? () => undefined : (stryCov_9fa48("1033"), q => q.eq(stryMutAct_9fa48("1034") ? "" : (stryCov_9fa48("1034"), "tokenIdentifier"), owner.identity.tokenIdentifier).eq(stryMutAct_9fa48("1035") ? "" : (stryCov_9fa48("1035"), "publicKey"), args.publicKey))).first();
      if (stryMutAct_9fa48("1037") ? false : stryMutAct_9fa48("1036") ? true : (stryCov_9fa48("1036", "1037"), keyUsed)) denyAccess(stryMutAct_9fa48("1039") ? "" : (stryCov_9fa48("1039"), "device_registration_conflict"));
      const slot = await ctx.db.query(stryMutAct_9fa48("1040") ? "" : (stryCov_9fa48("1040"), "mobileDevices")).withIndex(stryMutAct_9fa48("1041") ? "" : (stryCov_9fa48("1041"), "by_identity_platform"), stryMutAct_9fa48("1042") ? () => undefined : (stryCov_9fa48("1042"), q => q.eq(stryMutAct_9fa48("1043") ? "" : (stryCov_9fa48("1043"), "tokenIdentifier"), owner.identity.tokenIdentifier).eq(stryMutAct_9fa48("1044") ? "" : (stryCov_9fa48("1044"), "platform"), args.platform))).collect();
      if (stryMutAct_9fa48("1047") ? slot.every(device => device.state.kind === "active") : stryMutAct_9fa48("1046") ? false : stryMutAct_9fa48("1045") ? true : (stryCov_9fa48("1045", "1046", "1047"), slot.some(stryMutAct_9fa48("1048") ? () => undefined : (stryCov_9fa48("1048"), device => stryMutAct_9fa48("1051") ? device.state.kind !== "active" : stryMutAct_9fa48("1050") ? false : stryMutAct_9fa48("1049") ? true : (stryCov_9fa48("1049", "1050", "1051"), device.state.kind === (stryMutAct_9fa48("1052") ? "" : (stryCov_9fa48("1052"), "active"))))))) denyAccess(stryMutAct_9fa48("1054") ? "" : (stryCov_9fa48("1054"), "device_slot_occupied"));
      const facts = stryMutAct_9fa48("1055") ? {} : (stryCov_9fa48("1055"), {
        tokenIdentifier: owner.identity.tokenIdentifier,
        sid,
        ...args,
        createdAt: Date.now(),
        lastSeenAt: Date.now(),
        state: {
          kind: "active"
        } as const
      });
      const id = await ctx.db.insert(stryMutAct_9fa48("1056") ? "" : (stryCov_9fa48("1056"), "mobileDevices"), facts);
      await consumeChallenge(ctx, verified.challenge, null);
      return stryMutAct_9fa48("1057") ? {} : (stryCov_9fa48("1057"), {
        id,
        name: facts.name,
        platform: facts.platform,
        createdAt: facts.createdAt,
        lastSeenAt: facts.lastSeenAt,
        state: facts.state
      });
    }
  }
}));
export const heartbeat = mutation(stryMutAct_9fa48("1058") ? {} : (stryCov_9fa48("1058"), {
  args: stryMutAct_9fa48("1059") ? {} : (stryCov_9fa48("1059"), {
    access: v.optional(deviceProof)
  }),
  returns: deviceSummary,
  handler: async (ctx, {
    access
  }) => {
    if (stryMutAct_9fa48("1060")) {
      {}
    } else {
      stryCov_9fa48("1060");
      const owner = await requireOwner(ctx);
      const verified = await verifyChallenge(ctx, owner.clerkIdentity, access, stryMutAct_9fa48("1061") ? "" : (stryCov_9fa48("1061"), "devices.heartbeat"), stryMutAct_9fa48("1062") ? false : (stryCov_9fa48("1062"), true));
      await verifyPayload(verified.challenge, {});
      if (stryMutAct_9fa48("1065") ? false : stryMutAct_9fa48("1064") ? true : stryMutAct_9fa48("1063") ? verified.device : (stryCov_9fa48("1063", "1064", "1065"), !verified.device)) denyAccess(stryMutAct_9fa48("1067") ? "" : (stryCov_9fa48("1067"), "device_unregistered"));
      await consumeChallenge(ctx, verified.challenge, verified.device);
      return summarizeDevice(stryMutAct_9fa48("1068") ? {} : (stryCov_9fa48("1068"), {
        ...verified.device,
        lastSeenAt: Date.now()
      }));
    }
  }
}));
export const revoke = mutation(stryMutAct_9fa48("1069") ? {} : (stryCov_9fa48("1069"), {
  args: stryMutAct_9fa48("1070") ? {} : (stryCov_9fa48("1070"), {
    deviceId: v.id(stryMutAct_9fa48("1071") ? "" : (stryCov_9fa48("1071"), "mobileDevices")),
    access: v.optional(deviceProof)
  }),
  returns: v.object(stryMutAct_9fa48("1072") ? {} : (stryCov_9fa48("1072"), {
    kind: v.literal(stryMutAct_9fa48("1073") ? "" : (stryCov_9fa48("1073"), "revoked")),
    providerRevocation: providerState,
    workId: v.id(stryMutAct_9fa48("1074") ? "" : (stryCov_9fa48("1074"), "clerkProviderWork"))
  })),
  handler: async (ctx, {
    access,
    ...args
  }) => {
    if (stryMutAct_9fa48("1075")) {
      {}
    } else {
      stryCov_9fa48("1075");
      const owner = await requireOwner(ctx);
      const verified = await verifyChallenge(ctx, owner.clerkIdentity, access, stryMutAct_9fa48("1076") ? "" : (stryCov_9fa48("1076"), "devices.revoke"), stryMutAct_9fa48("1077") ? true : (stryCov_9fa48("1077"), false));
      await verifyPayload(verified.challenge, args);
      const device = await ctx.db.get(args.deviceId);
      if (stryMutAct_9fa48("1080") ? !device && device.tokenIdentifier !== owner.identity.tokenIdentifier : stryMutAct_9fa48("1079") ? false : stryMutAct_9fa48("1078") ? true : (stryCov_9fa48("1078", "1079", "1080"), (stryMutAct_9fa48("1081") ? device : (stryCov_9fa48("1081"), !device)) || (stryMutAct_9fa48("1083") ? device.tokenIdentifier === owner.identity.tokenIdentifier : stryMutAct_9fa48("1082") ? false : (stryCov_9fa48("1082", "1083"), device.tokenIdentifier !== owner.identity.tokenIdentifier)))) denyAccess(stryMutAct_9fa48("1085") ? "" : (stryCov_9fa48("1085"), "device_unknown"));
      if (stryMutAct_9fa48("1088") ? device.state.kind !== "active" : stryMutAct_9fa48("1087") ? false : stryMutAct_9fa48("1086") ? true : (stryCov_9fa48("1086", "1087", "1088"), device.state.kind === (stryMutAct_9fa48("1089") ? "" : (stryCov_9fa48("1089"), "active")))) await ctx.db.patch(device._id, stryMutAct_9fa48("1090") ? {} : (stryCov_9fa48("1090"), {
        state: stryMutAct_9fa48("1091") ? {} : (stryCov_9fa48("1091"), {
          kind: stryMutAct_9fa48("1092") ? "" : (stryCov_9fa48("1092"), "revoked"),
          at: Date.now(),
          reason: stryMutAct_9fa48("1093") ? "" : (stryCov_9fa48("1093"), "owner")
        })
      }));
      await consumeChallenge(ctx, verified.challenge, null);
      const work = await enqueueProviderWork(ctx, owner.identity, stryMutAct_9fa48("1094") ? {} : (stryCov_9fa48("1094"), {
        kind: stryMutAct_9fa48("1095") ? "" : (stryCov_9fa48("1095"), "revoke"),
        sid: device.sid
      }));
      return {
        kind: "revoked",
        providerRevocation: work.state,
        workId: work._id
      } as const;
    }
  }
}));
export const approveRegistration = mutation(stryMutAct_9fa48("1096") ? {} : (stryCov_9fa48("1096"), {
  args: stryMutAct_9fa48("1097") ? {} : (stryCov_9fa48("1097"), {
    sid: v.string(),
    access: v.optional(deviceProof)
  }),
  returns: v.null(),
  handler: async (ctx, {
    access,
    ...args
  }) => {
    if (stryMutAct_9fa48("1098")) {
      {}
    } else {
      stryCov_9fa48("1098");
      const owner = await requireOwner(ctx);
      const verified = await verifyChallenge(ctx, owner.clerkIdentity, access, stryMutAct_9fa48("1099") ? "" : (stryCov_9fa48("1099"), "devices.approveRegistration"), stryMutAct_9fa48("1100") ? false : (stryCov_9fa48("1100"), true));
      await verifyPayload(verified.challenge, args);
      if (stryMutAct_9fa48("1103") ? false : stryMutAct_9fa48("1102") ? true : stryMutAct_9fa48("1101") ? /^sess_[a-zA-Z0-9]{1,120}$/.test(args.sid) : (stryCov_9fa48("1101", "1102", "1103"), !(stryMutAct_9fa48("1107") ? /^sess_[^a-zA-Z0-9]{1,120}$/ : stryMutAct_9fa48("1106") ? /^sess_[a-zA-Z0-9]$/ : stryMutAct_9fa48("1105") ? /^sess_[a-zA-Z0-9]{1,120}/ : stryMutAct_9fa48("1104") ? /sess_[a-zA-Z0-9]{1,120}$/ : (stryCov_9fa48("1104", "1105", "1106", "1107"), /^sess_[a-zA-Z0-9]{1,120}$/)).test(args.sid))) denyAccess(stryMutAct_9fa48("1109") ? "" : (stryCov_9fa48("1109"), "session_id_invalid"));
      if (stryMutAct_9fa48("1111") ? false : stryMutAct_9fa48("1110") ? true : (stryCov_9fa48("1110", "1111"), await providerSessionDenied(ctx, owner.identity.tokenIdentifier, args.sid))) denyAccess(stryMutAct_9fa48("1113") ? "" : (stryCov_9fa48("1113"), "session_revoked"));
      const old = await sessionBinding(ctx, owner.identity.tokenIdentifier, args.sid);
      if (stryMutAct_9fa48("1115") ? false : stryMutAct_9fa48("1114") ? true : (stryCov_9fa48("1114", "1115"), old)) denyAccess(stryMutAct_9fa48("1117") ? "" : (stryCov_9fa48("1117"), "device_registration_conflict"));
      const approval = await ctx.db.query(stryMutAct_9fa48("1118") ? "" : (stryCov_9fa48("1118"), "deviceRegistrationApprovals")).withIndex(stryMutAct_9fa48("1119") ? "" : (stryCov_9fa48("1119"), "by_identity_sid"), stryMutAct_9fa48("1120") ? () => undefined : (stryCov_9fa48("1120"), q => q.eq(stryMutAct_9fa48("1121") ? "" : (stryCov_9fa48("1121"), "tokenIdentifier"), owner.identity.tokenIdentifier).eq(stryMutAct_9fa48("1122") ? "" : (stryCov_9fa48("1122"), "sid"), args.sid))).unique();
      if (stryMutAct_9fa48("1125") ? false : stryMutAct_9fa48("1124") ? true : stryMutAct_9fa48("1123") ? approval : (stryCov_9fa48("1123", "1124", "1125"), !approval)) await ctx.db.insert(stryMutAct_9fa48("1126") ? "" : (stryCov_9fa48("1126"), "deviceRegistrationApprovals"), stryMutAct_9fa48("1127") ? {} : (stryCov_9fa48("1127"), {
        tokenIdentifier: owner.identity.tokenIdentifier,
        sid: args.sid
      }));
      await consumeChallenge(ctx, verified.challenge, verified.device);
      return null;
    }
  }
}));
export const applyClerkRecovery = internalMutation(stryMutAct_9fa48("1128") ? {} : (stryCov_9fa48("1128"), {
  args: stryMutAct_9fa48("1129") ? {} : (stryCov_9fa48("1129"), {
    tokenIdentifier: v.string(),
    issuer: v.string(),
    subject: v.string(),
    recoveredSid: v.string(),
    eventId: v.string()
  }),
  returns: v.null(),
  handler: async (ctx, args) => {
    if (stryMutAct_9fa48("1130")) {
      {}
    } else {
      stryCov_9fa48("1130");
      const error = ownerAdmission(stryMutAct_9fa48("1131") ? {} : (stryCov_9fa48("1131"), {
        tokenIdentifier: args.tokenIdentifier,
        issuer: args.issuer,
        subject: args.subject
      }));
      if (stryMutAct_9fa48("1133") ? false : stryMutAct_9fa48("1132") ? true : (stryCov_9fa48("1132", "1133"), error)) throw new ConvexError(stryMutAct_9fa48("1135") ? {} : (stryCov_9fa48("1135"), {
        code: error
      }));
      if (stryMutAct_9fa48("1138") ? (args.tokenIdentifier !== `${args.issuer}|${args.subject}` || !/^sess_[a-zA-Z0-9]{1,120}$/.test(args.recoveredSid)) && !args.eventId : stryMutAct_9fa48("1137") ? false : stryMutAct_9fa48("1136") ? true : (stryCov_9fa48("1136", "1137", "1138"), (stryMutAct_9fa48("1140") ? args.tokenIdentifier !== `${args.issuer}|${args.subject}` && !/^sess_[a-zA-Z0-9]{1,120}$/.test(args.recoveredSid) : stryMutAct_9fa48("1139") ? false : (stryCov_9fa48("1139", "1140"), (stryMutAct_9fa48("1142") ? args.tokenIdentifier === `${args.issuer}|${args.subject}` : stryMutAct_9fa48("1141") ? false : (stryCov_9fa48("1141", "1142"), args.tokenIdentifier !== (stryMutAct_9fa48("1143") ? `` : (stryCov_9fa48("1143"), `${args.issuer}|${args.subject}`)))) || (stryMutAct_9fa48("1144") ? /^sess_[a-zA-Z0-9]{1,120}$/.test(args.recoveredSid) : (stryCov_9fa48("1144"), !(stryMutAct_9fa48("1148") ? /^sess_[^a-zA-Z0-9]{1,120}$/ : stryMutAct_9fa48("1147") ? /^sess_[a-zA-Z0-9]$/ : stryMutAct_9fa48("1146") ? /^sess_[a-zA-Z0-9]{1,120}/ : stryMutAct_9fa48("1145") ? /sess_[a-zA-Z0-9]{1,120}$/ : (stryCov_9fa48("1145", "1146", "1147", "1148"), /^sess_[a-zA-Z0-9]{1,120}$/)).test(args.recoveredSid))))) || (stryMutAct_9fa48("1149") ? args.eventId : (stryCov_9fa48("1149"), !args.eventId)))) denyAccess(stryMutAct_9fa48("1151") ? "" : (stryCov_9fa48("1151"), "device_registration_conflict"));
      const prior = await ctx.db.query(stryMutAct_9fa48("1152") ? "" : (stryCov_9fa48("1152"), "deviceRecoveryEvents")).withIndex(stryMutAct_9fa48("1153") ? "" : (stryCov_9fa48("1153"), "by_identity_event"), stryMutAct_9fa48("1154") ? () => undefined : (stryCov_9fa48("1154"), q => q.eq(stryMutAct_9fa48("1155") ? "" : (stryCov_9fa48("1155"), "tokenIdentifier"), args.tokenIdentifier).eq(stryMutAct_9fa48("1156") ? "" : (stryCov_9fa48("1156"), "eventId"), args.eventId))).unique();
      if (stryMutAct_9fa48("1158") ? false : stryMutAct_9fa48("1157") ? true : (stryCov_9fa48("1157", "1158"), prior)) {
        if (stryMutAct_9fa48("1159")) {
          {}
        } else {
          stryCov_9fa48("1159");
          if (stryMutAct_9fa48("1162") ? prior.recoveredSid === args.recoveredSid : stryMutAct_9fa48("1161") ? false : stryMutAct_9fa48("1160") ? true : (stryCov_9fa48("1160", "1161", "1162"), prior.recoveredSid !== args.recoveredSid)) denyAccess(stryMutAct_9fa48("1164") ? "" : (stryCov_9fa48("1164"), "device_registration_conflict"));
          return null;
        }
      }
      if (stryMutAct_9fa48("1166") ? false : stryMutAct_9fa48("1165") ? true : (stryCov_9fa48("1165", "1166"), await providerSessionDenied(ctx, args.tokenIdentifier, args.recoveredSid))) denyAccess(stryMutAct_9fa48("1168") ? "" : (stryCov_9fa48("1168"), "session_revoked"));
      const devices = await ctx.db.query(stryMutAct_9fa48("1169") ? "" : (stryCov_9fa48("1169"), "mobileDevices")).withIndex(stryMutAct_9fa48("1170") ? "" : (stryCov_9fa48("1170"), "by_identity"), stryMutAct_9fa48("1171") ? () => undefined : (stryCov_9fa48("1171"), q => q.eq(stryMutAct_9fa48("1172") ? "" : (stryCov_9fa48("1172"), "tokenIdentifier"), args.tokenIdentifier))).collect();
      if (stryMutAct_9fa48("1175") ? devices.every(device => device.sid === args.recoveredSid) : stryMutAct_9fa48("1174") ? false : stryMutAct_9fa48("1173") ? true : (stryCov_9fa48("1173", "1174", "1175"), devices.some(stryMutAct_9fa48("1176") ? () => undefined : (stryCov_9fa48("1176"), device => stryMutAct_9fa48("1179") ? device.sid !== args.recoveredSid : stryMutAct_9fa48("1178") ? false : stryMutAct_9fa48("1177") ? true : (stryCov_9fa48("1177", "1178", "1179"), device.sid === args.recoveredSid))))) denyAccess(stryMutAct_9fa48("1181") ? "" : (stryCov_9fa48("1181"), "device_registration_conflict"));
      for (const device of devices) {
        if (stryMutAct_9fa48("1182")) {
          {}
        } else {
          stryCov_9fa48("1182");
          if (stryMutAct_9fa48("1185") ? device.state.kind !== "active" : stryMutAct_9fa48("1184") ? false : stryMutAct_9fa48("1183") ? true : (stryCov_9fa48("1183", "1184", "1185"), device.state.kind === (stryMutAct_9fa48("1186") ? "" : (stryCov_9fa48("1186"), "active")))) await ctx.db.patch(device._id, stryMutAct_9fa48("1187") ? {} : (stryCov_9fa48("1187"), {
            state: stryMutAct_9fa48("1188") ? {} : (stryCov_9fa48("1188"), {
              kind: stryMutAct_9fa48("1189") ? "" : (stryCov_9fa48("1189"), "revoked"),
              at: Date.now(),
              reason: stryMutAct_9fa48("1190") ? "" : (stryCov_9fa48("1190"), "recovery")
            })
          }));
        }
      }
      const barrier = await ctx.db.query(stryMutAct_9fa48("1191") ? "" : (stryCov_9fa48("1191"), "deviceRecoveryBarriers")).withIndex(stryMutAct_9fa48("1192") ? "" : (stryCov_9fa48("1192"), "by_identity"), stryMutAct_9fa48("1193") ? () => undefined : (stryCov_9fa48("1193"), q => q.eq(stryMutAct_9fa48("1194") ? "" : (stryCov_9fa48("1194"), "tokenIdentifier"), args.tokenIdentifier))).unique();
      if (stryMutAct_9fa48("1197") ? false : stryMutAct_9fa48("1196") ? true : stryMutAct_9fa48("1195") ? barrier : (stryCov_9fa48("1195", "1196", "1197"), !barrier)) await ctx.db.insert(stryMutAct_9fa48("1198") ? "" : (stryCov_9fa48("1198"), "deviceRecoveryBarriers"), stryMutAct_9fa48("1199") ? {} : (stryCov_9fa48("1199"), {
        tokenIdentifier: args.tokenIdentifier
      }));
      for (const approval of await (stryMutAct_9fa48("1200") ? ctx.db.query("deviceRegistrationApprovals").collect() : (stryCov_9fa48("1200"), ctx.db.query(stryMutAct_9fa48("1201") ? "" : (stryCov_9fa48("1201"), "deviceRegistrationApprovals")).filter(stryMutAct_9fa48("1202") ? () => undefined : (stryCov_9fa48("1202"), q => q.eq(q.field(stryMutAct_9fa48("1203") ? "" : (stryCov_9fa48("1203"), "tokenIdentifier")), args.tokenIdentifier))).collect()))) await ctx.db.delete(approval._id);
      await ctx.db.insert(stryMutAct_9fa48("1204") ? "" : (stryCov_9fa48("1204"), "deviceRegistrationApprovals"), stryMutAct_9fa48("1205") ? {} : (stryCov_9fa48("1205"), {
        tokenIdentifier: args.tokenIdentifier,
        sid: args.recoveredSid
      }));
      await ctx.db.insert(stryMutAct_9fa48("1206") ? "" : (stryCov_9fa48("1206"), "deviceRecoveryEvents"), stryMutAct_9fa48("1207") ? {} : (stryCov_9fa48("1207"), {
        tokenIdentifier: args.tokenIdentifier,
        eventId: args.eventId,
        recoveredSid: args.recoveredSid
      }));
      return null;
    }
  }
}));
export const applyClerkSessionRevocation = internalMutation(stryMutAct_9fa48("1208") ? {} : (stryCov_9fa48("1208"), {
  args: stryMutAct_9fa48("1209") ? {} : (stryCov_9fa48("1209"), {
    tokenIdentifier: v.string(),
    issuer: v.string(),
    subject: v.string(),
    sid: v.string()
  }),
  returns: v.null(),
  handler: async (ctx, args) => {
    if (stryMutAct_9fa48("1210")) {
      {}
    } else {
      stryCov_9fa48("1210");
      const error = ownerAdmission(stryMutAct_9fa48("1211") ? {} : (stryCov_9fa48("1211"), {
        tokenIdentifier: args.tokenIdentifier,
        issuer: args.issuer,
        subject: args.subject
      }));
      if (stryMutAct_9fa48("1213") ? false : stryMutAct_9fa48("1212") ? true : (stryCov_9fa48("1212", "1213"), error)) throw new ConvexError(stryMutAct_9fa48("1215") ? {} : (stryCov_9fa48("1215"), {
        code: error
      }));
      if (stryMutAct_9fa48("1218") ? args.tokenIdentifier !== `${args.issuer}|${args.subject}` && !/^sess_[a-zA-Z0-9]{1,120}$/.test(args.sid) : stryMutAct_9fa48("1217") ? false : stryMutAct_9fa48("1216") ? true : (stryCov_9fa48("1216", "1217", "1218"), (stryMutAct_9fa48("1220") ? args.tokenIdentifier === `${args.issuer}|${args.subject}` : stryMutAct_9fa48("1219") ? false : (stryCov_9fa48("1219", "1220"), args.tokenIdentifier !== (stryMutAct_9fa48("1221") ? `` : (stryCov_9fa48("1221"), `${args.issuer}|${args.subject}`)))) || (stryMutAct_9fa48("1222") ? /^sess_[a-zA-Z0-9]{1,120}$/.test(args.sid) : (stryCov_9fa48("1222"), !(stryMutAct_9fa48("1226") ? /^sess_[^a-zA-Z0-9]{1,120}$/ : stryMutAct_9fa48("1225") ? /^sess_[a-zA-Z0-9]$/ : stryMutAct_9fa48("1224") ? /^sess_[a-zA-Z0-9]{1,120}/ : stryMutAct_9fa48("1223") ? /sess_[a-zA-Z0-9]{1,120}$/ : (stryCov_9fa48("1223", "1224", "1225", "1226"), /^sess_[a-zA-Z0-9]{1,120}$/)).test(args.sid))))) denyAccess(stryMutAct_9fa48("1228") ? "" : (stryCov_9fa48("1228"), "session_id_invalid"));
      if (stryMutAct_9fa48("1231") ? false : stryMutAct_9fa48("1230") ? true : stryMutAct_9fa48("1229") ? await providerSessionDenied(ctx, args.tokenIdentifier, args.sid) : (stryCov_9fa48("1229", "1230", "1231"), !(await providerSessionDenied(ctx, args.tokenIdentifier, args.sid)))) await ctx.db.insert(stryMutAct_9fa48("1232") ? "" : (stryCov_9fa48("1232"), "deviceSessionDenials"), stryMutAct_9fa48("1233") ? {} : (stryCov_9fa48("1233"), {
        tokenIdentifier: args.tokenIdentifier,
        sid: args.sid,
        at: Date.now()
      }));
      const device = await sessionBinding(ctx, args.tokenIdentifier, args.sid);
      if (stryMutAct_9fa48("1236") ? device?.state.kind !== "active" : stryMutAct_9fa48("1235") ? false : stryMutAct_9fa48("1234") ? true : (stryCov_9fa48("1234", "1235", "1236"), (stryMutAct_9fa48("1237") ? device.state.kind : (stryCov_9fa48("1237"), device?.state.kind)) === (stryMutAct_9fa48("1238") ? "" : (stryCov_9fa48("1238"), "active")))) await ctx.db.patch(device._id, stryMutAct_9fa48("1239") ? {} : (stryCov_9fa48("1239"), {
        state: stryMutAct_9fa48("1240") ? {} : (stryCov_9fa48("1240"), {
          kind: stryMutAct_9fa48("1241") ? "" : (stryCov_9fa48("1241"), "revoked"),
          at: Date.now(),
          reason: stryMutAct_9fa48("1242") ? "" : (stryCov_9fa48("1242"), "provider")
        })
      }));
      return null;
    }
  }
}));