// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { categorySelection, categoryChange, reclassificationTarget, reclassificationPreview, reclassificationResult, userCategory } from "./categoryValidators";
import { firstRunArgs, firstRunResult, firstRunStatusResult } from "./onboardingValidators";
import { finishFirstRun, firstRunState } from "./lib/onboarding";
import { natureAnswer } from "./categoryAnnotationValidators";
import { ConvexError, v } from "convex/values";
import { ownerMutation, ownerQuery } from "./lib/owner";
import { bootstrapPersonalWorkspace, personalWorkspaceLink, requirePersonalWorkspaceOwner } from "./lib/personalWorkspace";
import { AccountingError, createAccountingCore } from "../src/accounting";
import { requireWorkspace } from "../src/accounting/membership";
import { dateFromTimestamp } from "../src/accounting/period";
import { convexReadStore, convexStore } from "./store";
import { accountBalance, openingPositionResult, accountingPeriod, catalogAccount, financialAccountProfile, ledgerAccount, money, periodKey, postedJournalEntry, postedExpense, productKind, profileClassificationAnswers, trialBalanceRow, workspace } from "./validators";
const inWorkspace = stryMutAct_9fa48("0") ? {} : (stryCov_9fa48("0"), {
  workspaceId: v.string()
});
export const completeFirstRun = ownerMutation(stryMutAct_9fa48("1") ? {} : (stryCov_9fa48("1"), {
  operation: stryMutAct_9fa48("2") ? "" : (stryCov_9fa48("2"), "accounting.completeFirstRun"),
  args: firstRunArgs,
  returns: firstRunResult,
  handler: stryMutAct_9fa48("3") ? () => undefined : (stryCov_9fa48("3"), (ctx, args) => run(stryMutAct_9fa48("4") ? () => undefined : (stryCov_9fa48("4"), () => finishFirstRun(ctx, args))))
}));
export const firstRunStatus = ownerQuery(stryMutAct_9fa48("5") ? {} : (stryCov_9fa48("5"), {
  operation: stryMutAct_9fa48("6") ? "" : (stryCov_9fa48("6"), "accounting.firstRunStatus"),
  args: stryMutAct_9fa48("7") ? {} : (stryCov_9fa48("7"), {
    now: v.number()
  }),
  returns: firstRunStatusResult,
  handler: stryMutAct_9fa48("8") ? () => undefined : (stryCov_9fa48("8"), (ctx, args) => run(stryMutAct_9fa48("9") ? () => undefined : (stryCov_9fa48("9"), () => firstRunState(ctx, args.now))))
}));
export const phoneSummary = ownerQuery(stryMutAct_9fa48("10") ? {} : (stryCov_9fa48("10"), {
  operation: stryMutAct_9fa48("11") ? "" : (stryCov_9fa48("11"), "accounting.phoneSummary"),
  args: stryMutAct_9fa48("12") ? {} : (stryCov_9fa48("12"), {
    ...inWorkspace,
    now: v.number()
  }),
  returns: v.object(stryMutAct_9fa48("13") ? {} : (stryCov_9fa48("13"), {
    workspace,
    profiles: v.array(financialAccountProfile),
    balances: v.array(accountBalance),
    entries: v.array(postedJournalEntry)
  })),
  handler: stryMutAct_9fa48("14") ? () => undefined : (stryCov_9fa48("14"), (ctx, args) => run(async () => {
    if (stryMutAct_9fa48("15")) {
      {}
    } else {
      stryCov_9fa48("15");
      const core = createAccountingCore(convexReadStore(ctx.db));
      const input = stryMutAct_9fa48("16") ? {} : (stryCov_9fa48("16"), {
        ...args,
        actor: ctx.actor
      });
      const [profiles, balances, entries, workspace] = await Promise.all(stryMutAct_9fa48("17") ? [] : (stryCov_9fa48("17"), [core.listFinancialAccountProfiles(input), core.balances(input), core.listJournalEntries(input), core.openWorkspace(input)]));
      return stryMutAct_9fa48("18") ? {} : (stryCov_9fa48("18"), {
        workspace,
        profiles,
        balances,
        entries
      });
    }
  }))
}));
const cashActivity = stryMutAct_9fa48("19") ? {} : (stryCov_9fa48("19"), {
  ...inWorkspace,
  financialAccountProfileId: v.string(),
  amount: money,
  accountingDate: v.string(),
  description: v.string(),
  idempotencyKey: v.string(),
  ledgerAccountCode: v.optional(v.string()),
  userCategoryId: v.optional(v.string()),
  categoryRevision: v.optional(v.number())
});
async function run<T>(work: () => Promise<T>): Promise<T> {
  if (stryMutAct_9fa48("20")) {
    {}
  } else {
    stryCov_9fa48("20");
    try {
      if (stryMutAct_9fa48("21")) {
        {}
      } else {
        stryCov_9fa48("21");
        return await work();
      }
    } catch (error) {
      if (stryMutAct_9fa48("22")) {
        {}
      } else {
        stryCov_9fa48("22");
        if (stryMutAct_9fa48("24") ? false : stryMutAct_9fa48("23") ? true : (stryCov_9fa48("23", "24"), error instanceof AccountingError)) {
          if (stryMutAct_9fa48("25")) {
            {}
          } else {
            stryCov_9fa48("25");
            throw new ConvexError(stryMutAct_9fa48("27") ? {} : (stryCov_9fa48("27"), {
              code: error.code,
              message: error.message
            }));
          }
        }
        throw error;
      }
    }
  }
}
export const createPersonalWorkspace = ownerMutation(stryMutAct_9fa48("28") ? {} : (stryCov_9fa48("28"), {
  operation: stryMutAct_9fa48("29") ? "" : (stryCov_9fa48("29"), "accounting.createPersonalWorkspace"),
  args: stryMutAct_9fa48("30") ? {} : (stryCov_9fa48("30"), {
    functionalCurrency: v.string(),
    chartOfAccountsTemplate: v.optional(v.string()),
    now: v.number()
  }),
  returns: workspace,
  handler: stryMutAct_9fa48("31") ? () => undefined : (stryCov_9fa48("31"), async (ctx, args) => run(() => {
    if (stryMutAct_9fa48("32")) {
      {}
    } else {
      stryCov_9fa48("32");
      const core = createAccountingCore(convexStore(ctx.db), stryMutAct_9fa48("33") ? {} : (stryCov_9fa48("33"), {
        now: stryMutAct_9fa48("34") ? () => undefined : (stryCov_9fa48("34"), () => dateFromTimestamp(args.now))
      }));
      return bootstrapPersonalWorkspace(ctx, args, core);
    }
  }))
}));
export const createHouseholdWorkspace = ownerMutation(stryMutAct_9fa48("35") ? {} : (stryCov_9fa48("35"), {
  operation: stryMutAct_9fa48("36") ? "" : (stryCov_9fa48("36"), "accounting.createHouseholdWorkspace"),
  args: stryMutAct_9fa48("37") ? {} : (stryCov_9fa48("37"), {
    functionalCurrency: v.string(),
    chartOfAccountsTemplate: v.optional(v.string()),
    idempotencyKey: v.string(),
    now: v.number()
  }),
  returns: workspace,
  handler: stryMutAct_9fa48("38") ? () => undefined : (stryCov_9fa48("38"), async (ctx, args) => run(stryMutAct_9fa48("39") ? () => undefined : (stryCov_9fa48("39"), () => createAccountingCore(convexStore(ctx.db), stryMutAct_9fa48("40") ? {} : (stryCov_9fa48("40"), {
    now: stryMutAct_9fa48("41") ? () => undefined : (stryCov_9fa48("41"), () => dateFromTimestamp(args.now))
  })).createHouseholdWorkspace(stryMutAct_9fa48("42") ? {} : (stryCov_9fa48("42"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const listOwnedWorkspaces = ownerQuery(stryMutAct_9fa48("43") ? {} : (stryCov_9fa48("43"), {
  operation: stryMutAct_9fa48("44") ? "" : (stryCov_9fa48("44"), "accounting.listOwnedWorkspaces"),
  args: stryMutAct_9fa48("45") ? {} : (stryCov_9fa48("45"), {
    now: v.number()
  }),
  returns: v.array(workspace),
  handler: stryMutAct_9fa48("46") ? () => undefined : (stryCov_9fa48("46"), async (ctx, args) => run(stryMutAct_9fa48("47") ? () => undefined : (stryCov_9fa48("47"), () => createAccountingCore(convexReadStore(ctx.db)).listOwnedWorkspaces(stryMutAct_9fa48("48") ? {} : (stryCov_9fa48("48"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const personalWorkspace = ownerQuery(stryMutAct_9fa48("49") ? {} : (stryCov_9fa48("49"), {
  operation: stryMutAct_9fa48("50") ? "" : (stryCov_9fa48("50"), "accounting.personalWorkspace"),
  args: stryMutAct_9fa48("51") ? {} : (stryCov_9fa48("51"), {
    now: v.number()
  }),
  returns: v.union(v.object(stryMutAct_9fa48("52") ? {} : (stryCov_9fa48("52"), {
    status: v.literal(stryMutAct_9fa48("53") ? "" : (stryCov_9fa48("53"), "provisioning-required"))
  })), v.object(stryMutAct_9fa48("54") ? {} : (stryCov_9fa48("54"), {
    status: v.literal(stryMutAct_9fa48("55") ? "" : (stryCov_9fa48("55"), "ready")),
    workspace
  }))),
  handler: stryMutAct_9fa48("56") ? () => undefined : (stryCov_9fa48("56"), async (ctx, args) => run(async () => {
    if (stryMutAct_9fa48("57")) {
      {}
    } else {
      stryCov_9fa48("57");
      const linked = await personalWorkspaceLink(ctx, ctx.actor.userId);
      if (stryMutAct_9fa48("60") ? false : stryMutAct_9fa48("59") ? true : stryMutAct_9fa48("58") ? linked : (stryCov_9fa48("58", "59", "60"), !linked)) return {
        status: "provisioning-required"
      } as const;
      await requirePersonalWorkspaceOwner(ctx, linked.workspaceId, ctx.actor.userId);
      const workspace = await createAccountingCore(convexReadStore(ctx.db)).openWorkspace(stryMutAct_9fa48("61") ? {} : (stryCov_9fa48("61"), {
        actor: ctx.actor,
        workspaceId: linked.workspaceId,
        now: args.now
      }));
      return {
        status: "ready",
        workspace
      } as const;
    }
  }))
}));
export const localInputAuthority = ownerQuery(stryMutAct_9fa48("62") ? {} : (stryCov_9fa48("62"), {
  operation: stryMutAct_9fa48("63") ? "" : (stryCov_9fa48("63"), "accounting.localInputAuthority"),
  args: stryMutAct_9fa48("64") ? {} : (stryCov_9fa48("64"), {
    workspaceId: v.optional(v.string())
  }),
  returns: v.union(v.object(stryMutAct_9fa48("65") ? {} : (stryCov_9fa48("65"), {
    kind: v.literal(stryMutAct_9fa48("66") ? "" : (stryCov_9fa48("66"), "provisioning-required"))
  })), v.object(stryMutAct_9fa48("67") ? {} : (stryCov_9fa48("67"), {
    kind: v.literal(stryMutAct_9fa48("68") ? "" : (stryCov_9fa48("68"), "ready")),
    workspaceId: v.string()
  }))),
  handler: stryMutAct_9fa48("69") ? () => undefined : (stryCov_9fa48("69"), async (ctx, args) => run(async () => {
    if (stryMutAct_9fa48("70")) {
      {}
    } else {
      stryCov_9fa48("70");
      const workspaceId = stryMutAct_9fa48("71") ? args.workspaceId && (await personalWorkspaceLink(ctx, ctx.actor.userId))?.workspaceId : (stryCov_9fa48("71"), args.workspaceId ?? (stryMutAct_9fa48("72") ? (await personalWorkspaceLink(ctx, ctx.actor.userId)).workspaceId : (stryCov_9fa48("72"), (await personalWorkspaceLink(ctx, ctx.actor.userId))?.workspaceId)));
      if (stryMutAct_9fa48("75") ? workspaceId !== undefined : stryMutAct_9fa48("74") ? false : stryMutAct_9fa48("73") ? true : (stryCov_9fa48("73", "74", "75"), workspaceId === undefined)) return {
        kind: "provisioning-required"
      } as const;
      await requireWorkspace(convexReadStore(ctx.db), workspaceId, ctx.actor, stryMutAct_9fa48("76") ? "" : (stryCov_9fa48("76"), "prepare"));
      return {
        kind: "ready",
        workspaceId
      } as const;
    }
  }))
}));
export const openWorkspace = ownerQuery(stryMutAct_9fa48("77") ? {} : (stryCov_9fa48("77"), {
  operation: stryMutAct_9fa48("78") ? "" : (stryCov_9fa48("78"), "accounting.openWorkspace"),
  args: stryMutAct_9fa48("79") ? {} : (stryCov_9fa48("79"), {
    ...inWorkspace,
    now: v.number()
  }),
  returns: workspace,
  handler: stryMutAct_9fa48("80") ? () => undefined : (stryCov_9fa48("80"), async (ctx, args) => run(stryMutAct_9fa48("81") ? () => undefined : (stryCov_9fa48("81"), () => createAccountingCore(convexReadStore(ctx.db)).openWorkspace(stryMutAct_9fa48("82") ? {} : (stryCov_9fa48("82"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const createFinancialAccountProfile = ownerMutation(stryMutAct_9fa48("83") ? {} : (stryCov_9fa48("83"), {
  operation: stryMutAct_9fa48("84") ? "" : (stryCov_9fa48("84"), "accounting.createFinancialAccountProfile"),
  args: stryMutAct_9fa48("85") ? {} : (stryCov_9fa48("85"), {
    ...inWorkspace,
    name: v.string(),
    productKind,
    classificationAnswers: v.optional(profileClassificationAnswers),
    idempotencyKey: v.optional(v.string())
  }),
  returns: financialAccountProfile,
  handler: stryMutAct_9fa48("86") ? () => undefined : (stryCov_9fa48("86"), async (ctx, args) => run(stryMutAct_9fa48("87") ? () => undefined : (stryCov_9fa48("87"), () => createAccountingCore(convexStore(ctx.db)).createFinancialAccountProfile(stryMutAct_9fa48("88") ? {} : (stryCov_9fa48("88"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const listFinancialAccountProfiles = ownerQuery(stryMutAct_9fa48("89") ? {} : (stryCov_9fa48("89"), {
  operation: stryMutAct_9fa48("90") ? "" : (stryCov_9fa48("90"), "accounting.listFinancialAccountProfiles"),
  args: inWorkspace,
  returns: v.array(financialAccountProfile),
  handler: stryMutAct_9fa48("91") ? () => undefined : (stryCov_9fa48("91"), async (ctx, args) => run(stryMutAct_9fa48("92") ? () => undefined : (stryCov_9fa48("92"), () => createAccountingCore(convexReadStore(ctx.db)).listFinancialAccountProfiles(stryMutAct_9fa48("93") ? {} : (stryCov_9fa48("93"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const listLedgerAccounts = ownerQuery(stryMutAct_9fa48("94") ? {} : (stryCov_9fa48("94"), {
  operation: stryMutAct_9fa48("95") ? "" : (stryCov_9fa48("95"), "accounting.listLedgerAccounts"),
  args: inWorkspace,
  returns: v.array(ledgerAccount),
  handler: stryMutAct_9fa48("96") ? () => undefined : (stryCov_9fa48("96"), async (ctx, args) => run(stryMutAct_9fa48("97") ? () => undefined : (stryCov_9fa48("97"), () => createAccountingCore(convexReadStore(ctx.db)).listLedgerAccounts(stryMutAct_9fa48("98") ? {} : (stryCov_9fa48("98"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const listCatalogAccounts = ownerQuery(stryMutAct_9fa48("99") ? {} : (stryCov_9fa48("99"), {
  operation: stryMutAct_9fa48("100") ? "" : (stryCov_9fa48("100"), "accounting.listCatalogAccounts"),
  args: inWorkspace,
  returns: v.array(catalogAccount),
  handler: stryMutAct_9fa48("101") ? () => undefined : (stryCov_9fa48("101"), async (ctx, args) => run(stryMutAct_9fa48("102") ? () => undefined : (stryCov_9fa48("102"), () => createAccountingCore(convexReadStore(ctx.db)).listCatalogAccounts(stryMutAct_9fa48("103") ? {} : (stryCov_9fa48("103"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const lockAccountingPeriod = ownerMutation(stryMutAct_9fa48("104") ? {} : (stryCov_9fa48("104"), {
  operation: stryMutAct_9fa48("105") ? "" : (stryCov_9fa48("105"), "accounting.lockAccountingPeriod"),
  args: stryMutAct_9fa48("106") ? {} : (stryCov_9fa48("106"), {
    ...inWorkspace,
    period: periodKey,
    reason: v.optional(v.string())
  }),
  returns: accountingPeriod,
  handler: stryMutAct_9fa48("107") ? () => undefined : (stryCov_9fa48("107"), async (ctx, args) => run(stryMutAct_9fa48("108") ? () => undefined : (stryCov_9fa48("108"), () => createAccountingCore(convexStore(ctx.db)).lockAccountingPeriod(stryMutAct_9fa48("109") ? {} : (stryCov_9fa48("109"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const recordCashExpense = ownerMutation(stryMutAct_9fa48("110") ? {} : (stryCov_9fa48("110"), {
  operation: stryMutAct_9fa48("111") ? "" : (stryCov_9fa48("111"), "accounting.recordCashExpense"),
  args: cashActivity,
  returns: postedJournalEntry,
  handler: stryMutAct_9fa48("112") ? () => undefined : (stryCov_9fa48("112"), async (ctx, args) => run(stryMutAct_9fa48("113") ? () => undefined : (stryCov_9fa48("113"), () => createAccountingCore(convexStore(ctx.db)).recordCashExpense(stryMutAct_9fa48("114") ? {} : (stryCov_9fa48("114"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const recordCashIncome = ownerMutation(stryMutAct_9fa48("115") ? {} : (stryCov_9fa48("115"), {
  operation: stryMutAct_9fa48("116") ? "" : (stryCov_9fa48("116"), "accounting.recordCashIncome"),
  args: cashActivity,
  returns: postedJournalEntry,
  handler: stryMutAct_9fa48("117") ? () => undefined : (stryCov_9fa48("117"), async (ctx, args) => run(stryMutAct_9fa48("118") ? () => undefined : (stryCov_9fa48("118"), () => createAccountingCore(convexStore(ctx.db)).recordCashIncome(stryMutAct_9fa48("119") ? {} : (stryCov_9fa48("119"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const reversePostedEntry = ownerMutation(stryMutAct_9fa48("120") ? {} : (stryCov_9fa48("120"), {
  operation: stryMutAct_9fa48("121") ? "" : (stryCov_9fa48("121"), "accounting.reversePostedEntry"),
  args: stryMutAct_9fa48("122") ? {} : (stryCov_9fa48("122"), {
    ...inWorkspace,
    journalEntryId: v.string(),
    accountingDate: v.optional(v.string()),
    description: v.optional(v.string()),
    idempotencyKey: v.string()
  }),
  returns: postedJournalEntry,
  handler: stryMutAct_9fa48("123") ? () => undefined : (stryCov_9fa48("123"), async (ctx, args) => run(stryMutAct_9fa48("124") ? () => undefined : (stryCov_9fa48("124"), () => createAccountingCore(convexStore(ctx.db)).reversePostedEntry(stryMutAct_9fa48("125") ? {} : (stryCov_9fa48("125"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const listJournalEntries = ownerQuery(stryMutAct_9fa48("126") ? {} : (stryCov_9fa48("126"), {
  operation: stryMutAct_9fa48("127") ? "" : (stryCov_9fa48("127"), "accounting.listJournalEntries"),
  args: stryMutAct_9fa48("128") ? {} : (stryCov_9fa48("128"), {
    ...inWorkspace,
    financialAccountProfileId: v.optional(v.string())
  }),
  returns: v.array(postedJournalEntry),
  handler: stryMutAct_9fa48("129") ? () => undefined : (stryCov_9fa48("129"), async (ctx, args) => run(stryMutAct_9fa48("130") ? () => undefined : (stryCov_9fa48("130"), () => createAccountingCore(convexReadStore(ctx.db)).listJournalEntries(stryMutAct_9fa48("131") ? {} : (stryCov_9fa48("131"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const balances = ownerQuery(stryMutAct_9fa48("132") ? {} : (stryCov_9fa48("132"), {
  operation: stryMutAct_9fa48("133") ? "" : (stryCov_9fa48("133"), "accounting.balances"),
  args: inWorkspace,
  returns: v.array(accountBalance),
  handler: stryMutAct_9fa48("134") ? () => undefined : (stryCov_9fa48("134"), async (ctx, args) => run(stryMutAct_9fa48("135") ? () => undefined : (stryCov_9fa48("135"), () => createAccountingCore(convexReadStore(ctx.db)).balances(stryMutAct_9fa48("136") ? {} : (stryCov_9fa48("136"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const trialBalance = ownerQuery(stryMutAct_9fa48("137") ? {} : (stryCov_9fa48("137"), {
  operation: stryMutAct_9fa48("138") ? "" : (stryCov_9fa48("138"), "accounting.trialBalance"),
  args: inWorkspace,
  returns: v.array(trialBalanceRow),
  handler: stryMutAct_9fa48("139") ? () => undefined : (stryCov_9fa48("139"), async (ctx, args) => run(stryMutAct_9fa48("140") ? () => undefined : (stryCov_9fa48("140"), () => createAccountingCore(convexReadStore(ctx.db)).trialBalance(stryMutAct_9fa48("141") ? {} : (stryCov_9fa48("141"), {
    ...args,
    actor: ctx.actor
  })))))
}));
const openingPositionArgs = stryMutAct_9fa48("142") ? {} : (stryCov_9fa48("142"), {
  ...inWorkspace,
  amount: money,
  accountingDate: v.string(),
  description: v.string(),
  idempotencyKey: v.string()
});
export const recordOpeningPosition = ownerMutation(stryMutAct_9fa48("143") ? {} : (stryCov_9fa48("143"), {
  operation: stryMutAct_9fa48("144") ? "" : (stryCov_9fa48("144"), "accounting.recordOpeningPosition"),
  args: stryMutAct_9fa48("145") ? {} : (stryCov_9fa48("145"), {
    ...openingPositionArgs,
    financialAccountProfileId: v.string(),
    replacesOpeningKey: v.optional(v.string())
  }),
  returns: openingPositionResult,
  handler: stryMutAct_9fa48("146") ? () => undefined : (stryCov_9fa48("146"), async (ctx, args) => run(stryMutAct_9fa48("147") ? () => undefined : (stryCov_9fa48("147"), () => createAccountingCore(convexStore(ctx.db)).recordOpeningPosition(stryMutAct_9fa48("148") ? {} : (stryCov_9fa48("148"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const setupFinancialAccount = ownerMutation(stryMutAct_9fa48("149") ? {} : (stryCov_9fa48("149"), {
  operation: stryMutAct_9fa48("150") ? "" : (stryCov_9fa48("150"), "accounting.setupFinancialAccount"),
  args: stryMutAct_9fa48("151") ? {} : (stryCov_9fa48("151"), {
    ...openingPositionArgs,
    name: v.string(),
    productKind,
    classificationAnswers: v.optional(profileClassificationAnswers)
  }),
  returns: openingPositionResult,
  handler: stryMutAct_9fa48("152") ? () => undefined : (stryCov_9fa48("152"), async (ctx, args) => run(stryMutAct_9fa48("153") ? () => undefined : (stryCov_9fa48("153"), () => createAccountingCore(convexStore(ctx.db)).setupFinancialAccount(stryMutAct_9fa48("154") ? {} : (stryCov_9fa48("154"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const recordAccountTransfer = ownerMutation(stryMutAct_9fa48("155") ? {} : (stryCov_9fa48("155"), {
  operation: stryMutAct_9fa48("156") ? "" : (stryCov_9fa48("156"), "accounting.recordAccountTransfer"),
  args: stryMutAct_9fa48("157") ? {} : (stryCov_9fa48("157"), {
    ...openingPositionArgs,
    sourceFinancialAccountProfileId: v.string(),
    destinationFinancialAccountProfileId: v.string()
  }),
  returns: postedJournalEntry,
  handler: stryMutAct_9fa48("158") ? () => undefined : (stryCov_9fa48("158"), async (ctx, args) => run(stryMutAct_9fa48("159") ? () => undefined : (stryCov_9fa48("159"), () => createAccountingCore(convexStore(ctx.db)).recordAccountTransfer(stryMutAct_9fa48("160") ? {} : (stryCov_9fa48("160"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const listPostedExpenses = ownerQuery(stryMutAct_9fa48("161") ? {} : (stryCov_9fa48("161"), {
  operation: stryMutAct_9fa48("162") ? "" : (stryCov_9fa48("162"), "accounting.listPostedExpenses"),
  args: stryMutAct_9fa48("163") ? {} : (stryCov_9fa48("163"), {
    ...inWorkspace,
    from: v.string(),
    through: v.string()
  }),
  returns: v.array(postedExpense),
  handler: stryMutAct_9fa48("164") ? () => undefined : (stryCov_9fa48("164"), async (ctx, args) => run(stryMutAct_9fa48("165") ? () => undefined : (stryCov_9fa48("165"), () => createAccountingCore(convexReadStore(ctx.db)).listPostedExpenses(stryMutAct_9fa48("166") ? {} : (stryCov_9fa48("166"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const createUserCategory = ownerMutation(stryMutAct_9fa48("167") ? {} : (stryCov_9fa48("167"), {
  operation: stryMutAct_9fa48("168") ? "" : (stryCov_9fa48("168"), "accounting.createUserCategory"),
  args: stryMutAct_9fa48("169") ? {} : (stryCov_9fa48("169"), {
    ...inWorkspace,
    name: v.string(),
    selection: categorySelection,
    idempotencyKey: v.string()
  }),
  returns: v.union(v.object(stryMutAct_9fa48("170") ? {} : (stryCov_9fa48("170"), {
    kind: v.literal(stryMutAct_9fa48("171") ? "" : (stryCov_9fa48("171"), "category")),
    category: userCategory,
    replay: v.boolean()
  })), v.object(stryMutAct_9fa48("172") ? {} : (stryCov_9fa48("172"), {
    kind: v.literal(stryMutAct_9fa48("173") ? "" : (stryCov_9fa48("173"), "profileRequired")),
    answer: v.union(v.literal(stryMutAct_9fa48("174") ? "" : (stryCov_9fa48("174"), "stillMine")), v.literal(stryMutAct_9fa48("175") ? "" : (stryCov_9fa48("175"), "payingDebt")))
  }))),
  handler: stryMutAct_9fa48("176") ? () => undefined : (stryCov_9fa48("176"), (ctx, args) => run(stryMutAct_9fa48("177") ? () => undefined : (stryCov_9fa48("177"), () => createAccountingCore(convexStore(ctx.db)).createUserCategory(stryMutAct_9fa48("178") ? {} : (stryCov_9fa48("178"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const suggestCategoryNature = ownerQuery(stryMutAct_9fa48("179") ? {} : (stryCov_9fa48("179"), {
  operation: stryMutAct_9fa48("180") ? "" : (stryCov_9fa48("180"), "accounting.suggestCategoryNature"),
  args: stryMutAct_9fa48("181") ? {} : (stryCov_9fa48("181"), {
    ...inWorkspace,
    name: v.string()
  }),
  returns: v.object(stryMutAct_9fa48("182") ? {} : (stryCov_9fa48("182"), {
    policy: v.string(),
    suggestions: v.array(natureAnswer),
    requiresConfirmation: v.literal(stryMutAct_9fa48("183") ? false : (stryCov_9fa48("183"), true))
  })),
  handler: stryMutAct_9fa48("184") ? () => undefined : (stryCov_9fa48("184"), (ctx, args) => run(stryMutAct_9fa48("185") ? () => undefined : (stryCov_9fa48("185"), () => createAccountingCore(convexReadStore(ctx.db)).suggestCategoryNature(stryMutAct_9fa48("186") ? {} : (stryCov_9fa48("186"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const listUserCategories = ownerQuery(stryMutAct_9fa48("187") ? {} : (stryCov_9fa48("187"), {
  operation: stryMutAct_9fa48("188") ? "" : (stryCov_9fa48("188"), "accounting.listUserCategories"),
  args: inWorkspace,
  returns: v.array(userCategory),
  handler: stryMutAct_9fa48("189") ? () => undefined : (stryCov_9fa48("189"), (ctx, args) => run(stryMutAct_9fa48("190") ? () => undefined : (stryCov_9fa48("190"), () => createAccountingCore(convexReadStore(ctx.db)).listUserCategories(stryMutAct_9fa48("191") ? {} : (stryCov_9fa48("191"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const categoryTotals = ownerQuery(stryMutAct_9fa48("192") ? {} : (stryCov_9fa48("192"), {
  operation: stryMutAct_9fa48("193") ? "" : (stryCov_9fa48("193"), "accounting.categoryTotals"),
  args: inWorkspace,
  returns: v.array(v.object(stryMutAct_9fa48("194") ? {} : (stryCov_9fa48("194"), {
    categoryId: v.string(),
    year: v.number(),
    month: v.number(),
    expense: money,
    income: money
  }))),
  handler: stryMutAct_9fa48("195") ? () => undefined : (stryCov_9fa48("195"), (ctx, args) => run(stryMutAct_9fa48("196") ? () => undefined : (stryCov_9fa48("196"), () => createAccountingCore(convexReadStore(ctx.db)).categoryTotals(stryMutAct_9fa48("197") ? {} : (stryCov_9fa48("197"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const changeUserCategory = ownerMutation(stryMutAct_9fa48("198") ? {} : (stryCov_9fa48("198"), {
  operation: stryMutAct_9fa48("199") ? "" : (stryCov_9fa48("199"), "accounting.changeUserCategory"),
  args: stryMutAct_9fa48("200") ? {} : (stryCov_9fa48("200"), {
    ...inWorkspace,
    categoryId: v.string(),
    revision: v.number(),
    change: categoryChange,
    confirmed: v.literal(stryMutAct_9fa48("201") ? false : (stryCov_9fa48("201"), true)),
    idempotencyKey: v.string()
  }),
  returns: v.object(stryMutAct_9fa48("202") ? {} : (stryCov_9fa48("202"), {
    category: userCategory,
    replay: v.boolean()
  })),
  handler: stryMutAct_9fa48("203") ? () => undefined : (stryCov_9fa48("203"), (ctx, args) => run(stryMutAct_9fa48("204") ? () => undefined : (stryCov_9fa48("204"), () => createAccountingCore(convexStore(ctx.db)).changeUserCategory(stryMutAct_9fa48("205") ? {} : (stryCov_9fa48("205"), {
    ...args,
    actor: ctx.actor
  })))))
}));
const reclassificationArgs = stryMutAct_9fa48("206") ? {} : (stryCov_9fa48("206"), {
  ...inWorkspace,
  categoryId: v.string(),
  target: reclassificationTarget,
  currentDate: v.string()
});
export const previewCategoryReclassification = ownerQuery(stryMutAct_9fa48("207") ? {} : (stryCov_9fa48("207"), {
  operation: stryMutAct_9fa48("208") ? "" : (stryCov_9fa48("208"), "accounting.previewCategoryReclassification"),
  args: reclassificationArgs,
  returns: reclassificationPreview,
  handler: stryMutAct_9fa48("209") ? () => undefined : (stryCov_9fa48("209"), (ctx, args) => run(stryMutAct_9fa48("210") ? () => undefined : (stryCov_9fa48("210"), () => createAccountingCore(convexReadStore(ctx.db)).previewCategoryReclassification(stryMutAct_9fa48("211") ? {} : (stryCov_9fa48("211"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const confirmCategoryReclassification = ownerMutation(stryMutAct_9fa48("212") ? {} : (stryCov_9fa48("212"), {
  operation: stryMutAct_9fa48("213") ? "" : (stryCov_9fa48("213"), "accounting.confirmCategoryReclassification"),
  args: stryMutAct_9fa48("214") ? {} : (stryCov_9fa48("214"), {
    ...reclassificationArgs,
    revisionToken: v.string(),
    confirmed: v.literal(stryMutAct_9fa48("215") ? false : (stryCov_9fa48("215"), true)),
    idempotencyKey: v.string()
  }),
  returns: reclassificationResult,
  handler: stryMutAct_9fa48("216") ? () => undefined : (stryCov_9fa48("216"), (ctx, args) => run(stryMutAct_9fa48("217") ? () => undefined : (stryCov_9fa48("217"), () => createAccountingCore(convexStore(ctx.db)).confirmCategoryReclassification(stryMutAct_9fa48("218") ? {} : (stryCov_9fa48("218"), {
    ...args,
    actor: ctx.actor
  })))))
}));