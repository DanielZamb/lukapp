// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { defineTable } from "convex/server";
import { v } from "convex/values";
import { ledgerAccount, money, periodKey, postingPolicy, workspace } from "./validators";
import { categoryCorrection, categorySnapshot, userCategory } from "./categoryAnnotationValidators";
export const targetSelection = v.union(v.object(stryMutAct_9fa48("434") ? {} : (stryCov_9fa48("434"), {
  kind: v.literal(stryMutAct_9fa48("435") ? "" : (stryCov_9fa48("435"), "totalExpense"))
})), v.object(stryMutAct_9fa48("436") ? {} : (stryCov_9fa48("436"), {
  kind: v.literal(stryMutAct_9fa48("437") ? "" : (stryCov_9fa48("437"), "expenseAccount")),
  ledgerAccountId: ledgerAccount.fields.id
})), v.object(stryMutAct_9fa48("438") ? {} : (stryCov_9fa48("438"), {
  kind: v.literal(stryMutAct_9fa48("439") ? "" : (stryCov_9fa48("439"), "category")),
  categoryId: userCategory.fields.id
})));
export const budgetTarget = v.union(v.object(stryMutAct_9fa48("440") ? {} : (stryCov_9fa48("440"), {
  kind: v.literal(stryMutAct_9fa48("441") ? "" : (stryCov_9fa48("441"), "totalExpense"))
})), v.object(stryMutAct_9fa48("442") ? {} : (stryCov_9fa48("442"), {
  kind: v.literal(stryMutAct_9fa48("443") ? "" : (stryCov_9fa48("443"), "expenseAccount")),
  ledgerAccountId: ledgerAccount.fields.id,
  code: v.string(),
  name: v.string()
})), v.object(stryMutAct_9fa48("444") ? {} : (stryCov_9fa48("444"), {
  kind: v.literal(stryMutAct_9fa48("445") ? "" : (stryCov_9fa48("445"), "category")),
  categoryId: userCategory.fields.id,
  selectedSnapshot: categorySnapshot
})));
export const rollover = v.union(v.object(stryMutAct_9fa48("446") ? {} : (stryCov_9fa48("446"), {
  kind: v.literal(stryMutAct_9fa48("447") ? "" : (stryCov_9fa48("447"), "none"))
})), v.object(stryMutAct_9fa48("448") ? {} : (stryCov_9fa48("448"), {
  kind: v.literal(stryMutAct_9fa48("449") ? "" : (stryCov_9fa48("449"), "carryUnspent")),
  reset: v.literal(stryMutAct_9fa48("450") ? "" : (stryCov_9fa48("450"), "calendarYear")),
  cap: money
})));
export const effectiveChange = v.union(v.object(stryMutAct_9fa48("451") ? {} : (stryCov_9fa48("451"), {
  kind: v.literal(stryMutAct_9fa48("452") ? "" : (stryCov_9fa48("452"), "prospective")),
  month: periodKey
})), v.object(stryMutAct_9fa48("453") ? {} : (stryCov_9fa48("453"), {
  kind: v.literal(stryMutAct_9fa48("454") ? "" : (stryCov_9fa48("454"), "retrospective")),
  month: periodKey,
  reason: v.string(),
  confirmed: v.literal(stryMutAct_9fa48("455") ? false : (stryCov_9fa48("455"), true))
})));
const decision = v.object(stryMutAct_9fa48("456") ? {} : (stryCov_9fa48("456"), {
  revision: v.number(),
  decidedBy: v.string(),
  decidedAt: v.number(),
  policy: v.literal(stryMutAct_9fa48("457") ? "" : (stryCov_9fa48("457"), "budget-standing@1"))
}));
const limit = v.union(money, v.null());
export const limitDecision = v.object(stryMutAct_9fa48("458") ? {} : (stryCov_9fa48("458"), {
  ...decision.fields,
  effective: v.union(effectiveChange, v.object(stryMutAct_9fa48("459") ? {} : (stryCov_9fa48("459"), {
    kind: v.literal(stryMutAct_9fa48("460") ? "" : (stryCov_9fa48("460"), "initial")),
    month: periodKey
  }))),
  limit
}));
const budgetFields = stryMutAct_9fa48("461") ? {} : (stryCov_9fa48("461"), {
  workspaceId: workspace.fields.id,
  name: v.string(),
  nameDecision: decision,
  revision: v.number(),
  target: budgetTarget,
  cardinality: v.union(v.literal(stryMutAct_9fa48("462") ? "" : (stryCov_9fa48("462"), "singleStanding")), v.literal(stryMutAct_9fa48("463") ? "" : (stryCov_9fa48("463"), "multipleNamed"))),
  rollover,
  startMonth: periodKey,
  created: decision,
  lifecycle: v.union(v.object(stryMutAct_9fa48("464") ? {} : (stryCov_9fa48("464"), {
    kind: v.literal(stryMutAct_9fa48("465") ? "" : (stryCov_9fa48("465"), "standing"))
  })), v.object(stryMutAct_9fa48("466") ? {} : (stryCov_9fa48("466"), {
    kind: v.literal(stryMutAct_9fa48("467") ? "" : (stryCov_9fa48("467"), "retired")),
    effective: effectiveChange,
    decision
  }))),
  limits: v.array(limitDecision)
});
export const budget = v.object(stryMutAct_9fa48("468") ? {} : (stryCov_9fa48("468"), {
  id: v.string(),
  ...budgetFields
}));
export const budgetResult = v.object(stryMutAct_9fa48("469") ? {} : (stryCov_9fa48("469"), {
  budget,
  replay: v.boolean()
}));
export const budgetChange = v.union(v.object(stryMutAct_9fa48("470") ? {} : (stryCov_9fa48("470"), {
  kind: v.literal(stryMutAct_9fa48("471") ? "" : (stryCov_9fa48("471"), "rename")),
  name: v.string()
})), v.object(stryMutAct_9fa48("472") ? {} : (stryCov_9fa48("472"), {
  kind: v.literal(stryMutAct_9fa48("473") ? "" : (stryCov_9fa48("473"), "limit")),
  effective: effectiveChange,
  limit
})));
export const planningSelection = v.union(v.object(stryMutAct_9fa48("474") ? {} : (stryCov_9fa48("474"), {
  kind: v.literal(stryMutAct_9fa48("475") ? "" : (stryCov_9fa48("475"), "current"))
})), v.object(stryMutAct_9fa48("476") ? {} : (stryCov_9fa48("476"), {
  kind: v.literal(stryMutAct_9fa48("477") ? "" : (stryCov_9fa48("477"), "revision")),
  budgetId: budget.fields.id,
  revision: v.number()
})));
export const expenseProposal = v.object(stryMutAct_9fa48("478") ? {} : (stryCov_9fa48("478"), {
  financialAccountProfileId: v.string(),
  accountingDate: v.string(),
  amount: money,
  userCategoryId: v.optional(userCategory.fields.id),
  categoryRevision: v.optional(v.number()),
  ledgerAccountCode: v.optional(v.string())
}));
const proposedExpense = v.object(stryMutAct_9fa48("479") ? {} : (stryCov_9fa48("479"), {
  kind: v.literal(stryMutAct_9fa48("480") ? "" : (stryCov_9fa48("480"), "proposedExpense")),
  postingPolicy: v.literal(stryMutAct_9fa48("481") ? "" : (stryCov_9fa48("481"), "cash-expense@1")),
  financialAccountProfileId: v.string(),
  accountingDate: v.string(),
  month: periodKey,
  amount: money,
  account: v.object(stryMutAct_9fa48("482") ? {} : (stryCov_9fa48("482"), {
    code: v.string(),
    name: v.string(),
    nature: v.literal(stryMutAct_9fa48("483") ? "" : (stryCov_9fa48("483"), "Expense")),
    ledgerAccountId: v.optional(ledgerAccount.fields.id)
  })),
  category: v.optional(categorySnapshot)
}));
const postedExpense = v.object(stryMutAct_9fa48("484") ? {} : (stryCov_9fa48("484"), {
  kind: v.literal(stryMutAct_9fa48("485") ? "" : (stryCov_9fa48("485"), "postedExpense")),
  journalEntryId: v.string(),
  lineNumber: v.number(),
  accountingDate: v.string(),
  postedAt: v.number(),
  postedBy: v.string(),
  postingPolicy,
  reversesEntryId: v.optional(v.string()),
  account: v.object(stryMutAct_9fa48("486") ? {} : (stryCov_9fa48("486"), {
    id: ledgerAccount.fields.id,
    workspaceId: workspace.fields.id,
    code: v.string(),
    name: v.string(),
    nature: v.literal(stryMutAct_9fa48("487") ? "" : (stryCov_9fa48("487"), "Expense")),
    normalSide: v.union(v.literal(stryMutAct_9fa48("488") ? "" : (stryCov_9fa48("488"), "Debit")), v.literal(stryMutAct_9fa48("489") ? "" : (stryCov_9fa48("489"), "Credit"))),
    role: v.literal(stryMutAct_9fa48("490") ? "" : (stryCov_9fa48("490"), "Posting"))
  })),
  debitMinorUnits: v.number(),
  creditMinorUnits: v.number(),
  category: v.optional(categorySnapshot),
  categoryCorrection: v.optional(categoryCorrection)
}));
export const planningAmounts = v.union(v.object(stryMutAct_9fa48("491") ? {} : (stryCov_9fa48("491"), {
  kind: v.union(v.literal(stryMutAct_9fa48("492") ? "" : (stryCov_9fa48("492"), "notStarted")), v.literal(stryMutAct_9fa48("493") ? "" : (stryCov_9fa48("493"), "retired")), v.literal(stryMutAct_9fa48("494") ? "" : (stryCov_9fa48("494"), "noLimit")))
})), v.object(stryMutAct_9fa48("495") ? {} : (stryCov_9fa48("495"), {
  kind: v.literal(stryMutAct_9fa48("496") ? "" : (stryCov_9fa48("496"), "limited")),
  limit: money,
  carry: money,
  available: money,
  remaining: money,
  overage: money,
  carryOut: money
})));
const monthEvaluation = v.object(stryMutAct_9fa48("497") ? {} : (stryCov_9fa48("497"), {
  month: periodKey,
  actual: money,
  sources: v.array(postedExpense),
  selectedLimit: v.union(limitDecision, v.null()),
  planning: planningAmounts
}));
const budgetEvaluation = v.object(stryMutAct_9fa48("498") ? {} : (stryCov_9fa48("498"), {
  ...monthEvaluation.fields,
  budgetId: budget.fields.id,
  name: v.string(),
  target: budgetTarget,
  functionalCurrency: v.string(),
  selectedRevision: v.number(),
  currentRevision: v.number(),
  policy: v.literal(stryMutAct_9fa48("499") ? "" : (stryCov_9fa48("499"), "budget-standing@1")),
  rollover,
  evaluationContract: v.literal(stryMutAct_9fa48("500") ? "" : (stryCov_9fa48("500"), "independentRulesDoNotSum")),
  ledgerBasis: v.literal(stryMutAct_9fa48("501") ? "" : (stryCov_9fa48("501"), "currentPostedLines")),
  carryEvidence: v.array(monthEvaluation)
}));
export const budgetEvaluations = v.object(stryMutAct_9fa48("502") ? {} : (stryCov_9fa48("502"), {
  workspaceId: workspace.fields.id,
  month: periodKey,
  functionalCurrency: v.string(),
  evaluationContract: v.literal(stryMutAct_9fa48("503") ? "" : (stryCov_9fa48("503"), "independentRulesDoNotSum")),
  ledgerBasis: v.literal(stryMutAct_9fa48("504") ? "" : (stryCov_9fa48("504"), "currentPostedLines")),
  rows: v.array(budgetEvaluation)
}));
export const budgetImpact = v.object(stryMutAct_9fa48("505") ? {} : (stryCov_9fa48("505"), {
  kind: v.literal(stryMutAct_9fa48("506") ? "" : (stryCov_9fa48("506"), "advisory")),
  hasPostingAuthority: v.literal(stryMutAct_9fa48("507") ? true : (stryCov_9fa48("507"), false)),
  blocksPosting: v.literal(stryMutAct_9fa48("508") ? true : (stryCov_9fa48("508"), false)),
  evaluationContract: v.literal(stryMutAct_9fa48("509") ? "" : (stryCov_9fa48("509"), "independentRulesDoNotSum")),
  proposal: proposedExpense,
  impacts: v.array(v.object(stryMutAct_9fa48("510") ? {} : (stryCov_9fa48("510"), {
    evaluation: budgetEvaluation,
    proposedDelta: money,
    projected: v.object(stryMutAct_9fa48("511") ? {} : (stryCov_9fa48("511"), {
      actual: money,
      planning: planningAmounts
    }))
  })))
}));
export const budgetTables = stryMutAct_9fa48("512") ? {} : (stryCov_9fa48("512"), {
  budgets: defineTable(budgetFields).index(stryMutAct_9fa48("513") ? "" : (stryCov_9fa48("513"), "by_workspace"), stryMutAct_9fa48("514") ? [] : (stryCov_9fa48("514"), [stryMutAct_9fa48("515") ? "" : (stryCov_9fa48("515"), "workspaceId")])),
  budgetVersions: defineTable(stryMutAct_9fa48("516") ? {} : (stryCov_9fa48("516"), {
    budgetId: v.id(stryMutAct_9fa48("517") ? "" : (stryCov_9fa48("517"), "budgets")),
    revision: v.number(),
    budget
  })).index(stryMutAct_9fa48("518") ? "" : (stryCov_9fa48("518"), "by_budget_revision"), stryMutAct_9fa48("519") ? [] : (stryCov_9fa48("519"), [stryMutAct_9fa48("520") ? "" : (stryCov_9fa48("520"), "budgetId"), stryMutAct_9fa48("521") ? "" : (stryCov_9fa48("521"), "revision")])),
  budgetReceipts: defineTable(stryMutAct_9fa48("522") ? {} : (stryCov_9fa48("522"), {
    workspaceId: workspace.fields.id,
    idempotencyKey: v.string(),
    request: v.string(),
    budget
  })).index(stryMutAct_9fa48("523") ? "" : (stryCov_9fa48("523"), "by_workspace_key"), stryMutAct_9fa48("524") ? [] : (stryCov_9fa48("524"), [stryMutAct_9fa48("525") ? "" : (stryCov_9fa48("525"), "workspaceId"), stryMutAct_9fa48("526") ? "" : (stryCov_9fa48("526"), "idempotencyKey")]))
});