// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { ConvexError, v } from "convex/values";
import { AccountingError } from "../src/accounting/errors";
import { requirePeriodKey } from "../src/accounting/period";
import { createBudget as create, updateBudget as update, retireBudget as retire } from "../src/budget/commands";
import { listBudgets as list, evaluateBudgets as evaluate, budgetImpactWarning as impact } from "../src/budget/evaluation";
import { BudgetError } from "../src/budget/errors";
import { validateCreate, validateUpdate, validateRetire, validateSelection, validateProposal } from "../src/budget/input";
import { ownerMutation, ownerQuery } from "./lib/owner";
import { accountingPlanningReads } from "./accountingPlanningStore";
import { budgetReads, budgetStore } from "./budgetStore";
import * as b from "./budgetValidators";
import { periodKey } from "./validators";
async function result<T>(run: () => Promise<T>): Promise<T> {
  if (stryMutAct_9fa48("307")) {
    {}
  } else {
    stryCov_9fa48("307");
    try {
      if (stryMutAct_9fa48("308")) {
        {}
      } else {
        stryCov_9fa48("308");
        return await run();
      }
    } catch (error) {
      if (stryMutAct_9fa48("309")) {
        {}
      } else {
        stryCov_9fa48("309");
        if (stryMutAct_9fa48("312") ? error instanceof BudgetError && error instanceof AccountingError : stryMutAct_9fa48("311") ? false : stryMutAct_9fa48("310") ? true : (stryCov_9fa48("310", "311", "312"), error instanceof BudgetError || error instanceof AccountingError)) throw new ConvexError(stryMutAct_9fa48("314") ? {} : (stryCov_9fa48("314"), {
          code: error.code,
          message: error.message
        }));
        throw error;
      }
    }
  }
}
export const createBudget = ownerMutation(stryMutAct_9fa48("315") ? {} : (stryCov_9fa48("315"), {
  operation: stryMutAct_9fa48("316") ? "" : (stryCov_9fa48("316"), "budget.createBudget"),
  args: stryMutAct_9fa48("317") ? {} : (stryCov_9fa48("317"), {
    workspaceId: b.budget.fields.workspaceId,
    name: v.string(),
    startMonth: periodKey,
    target: b.targetSelection,
    cardinality: b.budget.fields.cardinality,
    rollover: b.rollover,
    limit: b.limitDecision.fields.limit,
    idempotencyKey: v.string()
  }),
  returns: b.budgetResult,
  handler: stryMutAct_9fa48("318") ? () => undefined : (stryCov_9fa48("318"), (ctx, args) => result(async () => {
    if (stryMutAct_9fa48("319")) {
      {}
    } else {
      stryCov_9fa48("319");
      if (stryMutAct_9fa48("320")) {
        ;
      } else {
        stryCov_9fa48("320");
        validateCreate(args);
      }
      const decidedAt = new Date();
      return create(stryMutAct_9fa48("321") ? {} : (stryCov_9fa48("321"), {
        store: budgetStore(ctx),
        accounting: accountingPlanningReads(ctx),
        clock: stryMutAct_9fa48("322") ? {} : (stryCov_9fa48("322"), {
          now: stryMutAct_9fa48("323") ? () => undefined : (stryCov_9fa48("323"), () => decidedAt)
        })
      }), stryMutAct_9fa48("324") ? {} : (stryCov_9fa48("324"), {
        ...args,
        actor: ctx.actor
      }));
    }
  }))
}));
export const updateBudget = ownerMutation(stryMutAct_9fa48("325") ? {} : (stryCov_9fa48("325"), {
  operation: stryMutAct_9fa48("326") ? "" : (stryCov_9fa48("326"), "budget.updateBudget"),
  args: stryMutAct_9fa48("327") ? {} : (stryCov_9fa48("327"), {
    workspaceId: b.budget.fields.workspaceId,
    budgetId: b.budget.fields.id,
    revision: v.number(),
    change: b.budgetChange,
    idempotencyKey: v.string()
  }),
  returns: b.budgetResult,
  handler: stryMutAct_9fa48("328") ? () => undefined : (stryCov_9fa48("328"), (ctx, args) => result(async () => {
    if (stryMutAct_9fa48("329")) {
      {}
    } else {
      stryCov_9fa48("329");
      if (stryMutAct_9fa48("330")) {
        ;
      } else {
        stryCov_9fa48("330");
        validateUpdate(args);
      }
      const decidedAt = new Date();
      return update(stryMutAct_9fa48("331") ? {} : (stryCov_9fa48("331"), {
        store: budgetStore(ctx),
        accounting: accountingPlanningReads(ctx),
        clock: stryMutAct_9fa48("332") ? {} : (stryCov_9fa48("332"), {
          now: stryMutAct_9fa48("333") ? () => undefined : (stryCov_9fa48("333"), () => decidedAt)
        })
      }), stryMutAct_9fa48("334") ? {} : (stryCov_9fa48("334"), {
        ...args,
        actor: ctx.actor
      }));
    }
  }))
}));
export const retireBudget = ownerMutation(stryMutAct_9fa48("335") ? {} : (stryCov_9fa48("335"), {
  operation: stryMutAct_9fa48("336") ? "" : (stryCov_9fa48("336"), "budget.retireBudget"),
  args: stryMutAct_9fa48("337") ? {} : (stryCov_9fa48("337"), {
    workspaceId: b.budget.fields.workspaceId,
    budgetId: b.budget.fields.id,
    revision: v.number(),
    effective: b.effectiveChange,
    idempotencyKey: v.string()
  }),
  returns: b.budgetResult,
  handler: stryMutAct_9fa48("338") ? () => undefined : (stryCov_9fa48("338"), (ctx, args) => result(async () => {
    if (stryMutAct_9fa48("339")) {
      {}
    } else {
      stryCov_9fa48("339");
      if (stryMutAct_9fa48("340")) {
        ;
      } else {
        stryCov_9fa48("340");
        validateRetire(args);
      }
      const decidedAt = new Date();
      return retire(stryMutAct_9fa48("341") ? {} : (stryCov_9fa48("341"), {
        store: budgetStore(ctx),
        accounting: accountingPlanningReads(ctx),
        clock: stryMutAct_9fa48("342") ? {} : (stryCov_9fa48("342"), {
          now: stryMutAct_9fa48("343") ? () => undefined : (stryCov_9fa48("343"), () => decidedAt)
        })
      }), stryMutAct_9fa48("344") ? {} : (stryCov_9fa48("344"), {
        ...args,
        actor: ctx.actor
      }));
    }
  }))
}));
export const listBudgets = ownerQuery(stryMutAct_9fa48("345") ? {} : (stryCov_9fa48("345"), {
  operation: stryMutAct_9fa48("346") ? "" : (stryCov_9fa48("346"), "budget.listBudgets"),
  args: stryMutAct_9fa48("347") ? {} : (stryCov_9fa48("347"), {
    workspaceId: b.budget.fields.workspaceId
  }),
  returns: v.array(b.budget),
  handler: stryMutAct_9fa48("348") ? () => undefined : (stryCov_9fa48("348"), (ctx, args) => result(stryMutAct_9fa48("349") ? () => undefined : (stryCov_9fa48("349"), () => list(budgetReads(ctx), accountingPlanningReads(ctx), stryMutAct_9fa48("350") ? {} : (stryCov_9fa48("350"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const evaluateBudgets = ownerQuery(stryMutAct_9fa48("351") ? {} : (stryCov_9fa48("351"), {
  operation: stryMutAct_9fa48("352") ? "" : (stryCov_9fa48("352"), "budget.evaluateBudgets"),
  args: stryMutAct_9fa48("353") ? {} : (stryCov_9fa48("353"), {
    workspaceId: b.budget.fields.workspaceId,
    month: periodKey,
    selection: v.optional(b.planningSelection)
  }),
  returns: b.budgetEvaluations,
  handler: stryMutAct_9fa48("354") ? () => undefined : (stryCov_9fa48("354"), (ctx, args) => result(async () => {
    if (stryMutAct_9fa48("355")) {
      {}
    } else {
      stryCov_9fa48("355");
      if (stryMutAct_9fa48("356")) {
        ;
      } else {
        stryCov_9fa48("356");
        requirePeriodKey(args.month);
      }
      const selection = stryMutAct_9fa48("357") ? args.selection && {
        kind: "current"
      } : (stryCov_9fa48("357"), args.selection ?? (stryMutAct_9fa48("358") ? {} : (stryCov_9fa48("358"), {
        kind: stryMutAct_9fa48("359") ? "" : (stryCov_9fa48("359"), "current")
      })));
      if (stryMutAct_9fa48("360")) {
        ;
      } else {
        stryCov_9fa48("360");
        validateSelection(selection);
      }
      return evaluate(budgetReads(ctx), accountingPlanningReads(ctx), stryMutAct_9fa48("361") ? {} : (stryCov_9fa48("361"), {
        ...args,
        selection,
        actor: ctx.actor
      }));
    }
  }))
}));
export const budgetImpactWarning = ownerQuery(stryMutAct_9fa48("362") ? {} : (stryCov_9fa48("362"), {
  operation: stryMutAct_9fa48("363") ? "" : (stryCov_9fa48("363"), "budget.budgetImpactWarning"),
  args: stryMutAct_9fa48("364") ? {} : (stryCov_9fa48("364"), {
    workspaceId: b.budget.fields.workspaceId,
    proposal: b.expenseProposal
  }),
  returns: b.budgetImpact,
  handler: stryMutAct_9fa48("365") ? () => undefined : (stryCov_9fa48("365"), (ctx, args) => result(async () => {
    if (stryMutAct_9fa48("366")) {
      {}
    } else {
      stryCov_9fa48("366");
      if (stryMutAct_9fa48("367")) {
        ;
      } else {
        stryCov_9fa48("367");
        validateProposal(args.proposal);
      }
      return impact(budgetReads(ctx), accountingPlanningReads(ctx), stryMutAct_9fa48("368") ? {} : (stryCov_9fa48("368"), {
        ...args,
        actor: ctx.actor
      }));
    }
  }))
}));