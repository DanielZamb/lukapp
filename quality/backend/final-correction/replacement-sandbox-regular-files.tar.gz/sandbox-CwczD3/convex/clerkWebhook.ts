// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { httpAction } from "./_generated/server";
import type { ActionCtx } from "./_generated/server";
import { internal } from "./_generated/api";
import { sanitizedProviderError, verifiedTerminalWebhook } from "./lib/clerk";
export async function reconcileClerkWebhook(ctx: ActionCtx, request: Request): Promise<Response> {
  if (stryMutAct_9fa48("800")) {
    {}
  } else {
    stryCov_9fa48("800");
    try {
      if (stryMutAct_9fa48("801")) {
        {}
      } else {
        stryCov_9fa48("801");
        const event = await verifiedTerminalWebhook(request);
        if (stryMutAct_9fa48("804") ? false : stryMutAct_9fa48("803") ? true : stryMutAct_9fa48("802") ? event : (stryCov_9fa48("802", "803", "804"), !event)) return new Response(stryMutAct_9fa48("805") ? "" : (stryCov_9fa48("805"), "ignored"), stryMutAct_9fa48("806") ? {} : (stryCov_9fa48("806"), {
          status: 200
        }));
        const prior = await ctx.runQuery(internal.providerWork.webhookDelivery, stryMutAct_9fa48("807") ? {} : (stryCov_9fa48("807"), {
          eventId: event.eventId
        }));
        if (stryMutAct_9fa48("809") ? false : stryMutAct_9fa48("808") ? true : (stryCov_9fa48("808", "809"), prior)) {
          if (stryMutAct_9fa48("810")) {
            {}
          } else {
            stryCov_9fa48("810");
            if (stryMutAct_9fa48("813") ? (prior.sid !== event.sid || prior.tokenIdentifier !== event.tokenIdentifier) && prior.eventType !== event.eventType : stryMutAct_9fa48("812") ? false : stryMutAct_9fa48("811") ? true : (stryCov_9fa48("811", "812", "813"), (stryMutAct_9fa48("815") ? prior.sid !== event.sid && prior.tokenIdentifier !== event.tokenIdentifier : stryMutAct_9fa48("814") ? false : (stryCov_9fa48("814", "815"), (stryMutAct_9fa48("817") ? prior.sid === event.sid : stryMutAct_9fa48("816") ? false : (stryCov_9fa48("816", "817"), prior.sid !== event.sid)) || (stryMutAct_9fa48("819") ? prior.tokenIdentifier === event.tokenIdentifier : stryMutAct_9fa48("818") ? false : (stryCov_9fa48("818", "819"), prior.tokenIdentifier !== event.tokenIdentifier)))) || (stryMutAct_9fa48("821") ? prior.eventType === event.eventType : stryMutAct_9fa48("820") ? false : (stryCov_9fa48("820", "821"), prior.eventType !== event.eventType)))) return new Response(stryMutAct_9fa48("822") ? "" : (stryCov_9fa48("822"), "provider_provenance_mismatch"), stryMutAct_9fa48("823") ? {} : (stryCov_9fa48("823"), {
              status: 400
            }));
            return new Response(stryMutAct_9fa48("824") ? "" : (stryCov_9fa48("824"), "duplicate"), stryMutAct_9fa48("825") ? {} : (stryCov_9fa48("825"), {
              status: 200
            }));
          }
        }
        const {
          sid,
          tokenIdentifier,
          issuer,
          subject
        } = event;
        await ctx.runMutation(internal.devices.applyClerkSessionRevocation, stryMutAct_9fa48("826") ? {} : (stryCov_9fa48("826"), {
          sid,
          tokenIdentifier,
          issuer,
          subject
        }));
        await ctx.runMutation(internal.providerWork.recordWebhook, event);
        return new Response(stryMutAct_9fa48("827") ? "" : (stryCov_9fa48("827"), "reconciled"), stryMutAct_9fa48("828") ? {} : (stryCov_9fa48("828"), {
          status: 200
        }));
      }
    } catch (error) {
      if (stryMutAct_9fa48("829")) {
        {}
      } else {
        stryCov_9fa48("829");
        const code = sanitizedProviderError(error);
        return new Response(code, stryMutAct_9fa48("830") ? {} : (stryCov_9fa48("830"), {
          status: (stryMutAct_9fa48("833") ? code === "provider_configuration_required" && code === "provider_unavailable" : stryMutAct_9fa48("832") ? false : stryMutAct_9fa48("831") ? true : (stryCov_9fa48("831", "832", "833"), (stryMutAct_9fa48("835") ? code !== "provider_configuration_required" : stryMutAct_9fa48("834") ? false : (stryCov_9fa48("834", "835"), code === (stryMutAct_9fa48("836") ? "" : (stryCov_9fa48("836"), "provider_configuration_required")))) || (stryMutAct_9fa48("838") ? code !== "provider_unavailable" : stryMutAct_9fa48("837") ? false : (stryCov_9fa48("837", "838"), code === (stryMutAct_9fa48("839") ? "" : (stryCov_9fa48("839"), "provider_unavailable")))))) ? 503 : 400
        }));
      }
    }
  }
}
export const terminalSession = httpAction(reconcileClerkWebhook);