// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { v } from "convex/values";
import { money, productKind, profileClassificationAnswers } from "./validators";
import { categoryNature, natureAnswer, categorySnapshot, correctionSource, userCategory } from "./categoryAnnotationValidators";
export { categoryFields, userCategory, categoryClassification, categorySnapshot, categoryCorrection } from "./categoryAnnotationValidators";
export const categorySelection = v.union(v.object(stryMutAct_9fa48("560") ? {} : (stryCov_9fa48("560"), {
  kind: v.literal(stryMutAct_9fa48("561") ? "" : (stryCov_9fa48("561"), "preset")),
  concept: v.string()
})), v.object(stryMutAct_9fa48("562") ? {} : (stryCov_9fa48("562"), {
  kind: v.literal(stryMutAct_9fa48("563") ? "" : (stryCov_9fa48("563"), "custom")),
  answer: natureAnswer,
  confirmation: v.union(v.literal(stryMutAct_9fa48("564") ? "" : (stryCov_9fa48("564"), "answered")), v.literal(stryMutAct_9fa48("565") ? "" : (stryCov_9fa48("565"), "lexiconConfirmed")))
})));
export const categoryChange = v.union(v.object(stryMutAct_9fa48("566") ? {} : (stryCov_9fa48("566"), {
  kind: v.literal(stryMutAct_9fa48("567") ? "" : (stryCov_9fa48("567"), "rename")),
  name: v.string()
})), v.object(stryMutAct_9fa48("568") ? {} : (stryCov_9fa48("568"), {
  kind: v.literal(stryMutAct_9fa48("569") ? "" : (stryCov_9fa48("569"), "archive"))
})), v.object(stryMutAct_9fa48("570") ? {} : (stryCov_9fa48("570"), {
  kind: v.literal(stryMutAct_9fa48("571") ? "" : (stryCov_9fa48("571"), "merge")),
  targetCategoryId: v.string()
})), v.object(stryMutAct_9fa48("572") ? {} : (stryCov_9fa48("572"), {
  kind: v.literal(stryMutAct_9fa48("573") ? "" : (stryCov_9fa48("573"), "defaultAccount")),
  accountCode: v.string()
})));
export const reclassificationTarget = v.union(v.object(stryMutAct_9fa48("574") ? {} : (stryCov_9fa48("574"), {
  kind: v.literal(stryMutAct_9fa48("575") ? "" : (stryCov_9fa48("575"), "category")),
  nature: categoryNature,
  accountCode: v.string()
})), v.object(stryMutAct_9fa48("576") ? {} : (stryCov_9fa48("576"), {
  kind: v.literal(stryMutAct_9fa48("577") ? "" : (stryCov_9fa48("577"), "profile")),
  setup: v.object(stryMutAct_9fa48("578") ? {} : (stryCov_9fa48("578"), {
    name: v.string(),
    productKind,
    classificationAnswers: v.optional(profileClassificationAnswers),
    amount: money,
    accountingDate: v.string(),
    description: v.string()
  }))
})));
export const reclassificationPreview = v.object(stryMutAct_9fa48("579") ? {} : (stryCov_9fa48("579"), {
  categoryId: v.string(),
  categoryRevision: v.number(),
  revisionToken: v.string(),
  entryCount: v.number(),
  lineCount: v.number(),
  amount: money,
  lockedEntryCount: v.number(),
  lockedAmount: money,
  correctionDates: v.array(v.string()),
  buckets: v.array(v.object(stryMutAct_9fa48("580") ? {} : (stryCov_9fa48("580"), {
    accountingDate: v.string(),
    ledgerAccountId: v.string(),
    signedMinorUnits: v.number(),
    sources: v.array(correctionSource),
    rootSources: v.array(correctionSource),
    priorLockedPeriods: v.array(v.string()),
    snapshot: categorySnapshot
  })))
}));
export const reclassificationResult = v.object(stryMutAct_9fa48("581") ? {} : (stryCov_9fa48("581"), {
  category: userCategory,
  correctionEntryIds: v.array(v.string()),
  financialAccountProfileId: v.optional(v.string()),
  replay: v.boolean()
}));