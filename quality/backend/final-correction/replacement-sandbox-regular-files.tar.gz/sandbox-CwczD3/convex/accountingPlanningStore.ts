// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import type { QueryCtx } from "./_generated/server";
import { convexReadStore } from "./store";
import { AccountingError } from "../src/accounting/errors";
import type { AccountingPlanningReads, PostedExpenseLine } from "../src/accounting/planningReads";
import { planningDocuments, requirePlanningReadHeadroom } from "./planningReadCapacity";
export function accountingPlanningReads({
  db,
  meta
}: Pick<QueryCtx, "db" | "meta">): AccountingPlanningReads {
  if (stryMutAct_9fa48("219")) {
    {}
  } else {
    stryCov_9fa48("219");
    const reads = convexReadStore(db);
    const accounts = new Map<string, Awaited<ReturnType<AccountingPlanningReads["getLedgerAccount"]>>>();
    let sourceQueries = 0;
    async function requireSourceRead() {
      if (stryMutAct_9fa48("220")) {
        {}
      } else {
        stryCov_9fa48("220");
        if (stryMutAct_9fa48("223") ? sourceQueries !== 2000 : stryMutAct_9fa48("222") ? false : stryMutAct_9fa48("221") ? true : (stryCov_9fa48("221", "222", "223"), sourceQueries === 2000)) throw new AccountingError(stryMutAct_9fa48("225") ? "" : (stryCov_9fa48("225"), "planning_read_limit"));
        await requirePlanningReadHeadroom(meta);
        stryMutAct_9fa48("226") ? sourceQueries-- : (stryCov_9fa48("226"), sourceQueries++);
      }
    }
    return stryMutAct_9fa48("227") ? {} : (stryCov_9fa48("227"), {
      getWorkspace: reads.getWorkspace,
      membershipRole: reads.membershipRole,
      getCategory: reads.getCategory,
      getLedgerAccount: reads.getLedgerAccount,
      getProfile: reads.getProfile,
      findLedgerAccountByCode: reads.findLedgerAccountByCode,
      async postedExpenseLines(workspaceId, month) {
        if (stryMutAct_9fa48("228")) {
          {}
        } else {
          stryCov_9fa48("228");
          const id = db.normalizeId(stryMutAct_9fa48("229") ? "" : (stryCov_9fa48("229"), "workspaces"), workspaceId);
          if (stryMutAct_9fa48("232") ? false : stryMutAct_9fa48("231") ? true : stryMutAct_9fa48("230") ? id : (stryCov_9fa48("230", "231", "232"), !id)) throw new AccountingError(stryMutAct_9fa48("234") ? "" : (stryCov_9fa48("234"), "workspace_membership_required"));
          await requireSourceRead();
          const entries = await planningDocuments(meta, db.query(stryMutAct_9fa48("235") ? "" : (stryCov_9fa48("235"), "journalEntries")).withIndex(stryMutAct_9fa48("236") ? "" : (stryCov_9fa48("236"), "by_workspace_period"), stryMutAct_9fa48("237") ? () => undefined : (stryCov_9fa48("237"), q => q.eq(stryMutAct_9fa48("238") ? "" : (stryCov_9fa48("238"), "workspaceId"), id).eq(stryMutAct_9fa48("239") ? "" : (stryCov_9fa48("239"), "periodYear"), month.year).eq(stryMutAct_9fa48("240") ? "" : (stryCov_9fa48("240"), "periodMonth"), month.month))), 1000);
          const result: PostedExpenseLine[] = stryMutAct_9fa48("241") ? ["Stryker was here"] : (stryCov_9fa48("241"), []);
          let count = 0;
          for (const entry of entries) {
            if (stryMutAct_9fa48("242")) {
              {}
            } else {
              stryCov_9fa48("242");
              await requireSourceRead();
              const lines = await planningDocuments(meta, db.query(stryMutAct_9fa48("243") ? "" : (stryCov_9fa48("243"), "journalLines")).withIndex(stryMutAct_9fa48("244") ? "" : (stryCov_9fa48("244"), "by_entry"), stryMutAct_9fa48("245") ? () => undefined : (stryCov_9fa48("245"), q => q.eq(stryMutAct_9fa48("246") ? "" : (stryCov_9fa48("246"), "journalEntryId"), entry._id))), stryMutAct_9fa48("247") ? 10000 + count : (stryCov_9fa48("247"), 10000 - count));
              stryMutAct_9fa48("248") ? count -= lines.length : (stryCov_9fa48("248"), count += lines.length);
              for (const line of lines) {
                if (stryMutAct_9fa48("249")) {
                  {}
                } else {
                  stryCov_9fa48("249");
                  if (stryMutAct_9fa48("252") ? line.workspaceId === id : stryMutAct_9fa48("251") ? false : stryMutAct_9fa48("250") ? true : (stryCov_9fa48("250", "251", "252"), line.workspaceId !== id)) throw new AccountingError(stryMutAct_9fa48("254") ? "" : (stryCov_9fa48("254"), "journal_line_invalid"));
                  if (stryMutAct_9fa48("257") ? false : stryMutAct_9fa48("256") ? true : stryMutAct_9fa48("255") ? accounts.has(line.ledgerAccountId) : (stryCov_9fa48("255", "256", "257"), !accounts.has(line.ledgerAccountId))) {
                    if (stryMutAct_9fa48("258")) {
                      {}
                    } else {
                      stryCov_9fa48("258");
                      await requireSourceRead();
                      if (stryMutAct_9fa48("259")) {
                        ;
                      } else {
                        stryCov_9fa48("259");
                        accounts.set(line.ledgerAccountId, await reads.getLedgerAccount(line.ledgerAccountId));
                      }
                      await requirePlanningReadHeadroom(meta);
                    }
                  }
                  const account = accounts.get(line.ledgerAccountId);
                  if (stryMutAct_9fa48("262") ? !account && account.workspaceId !== id : stryMutAct_9fa48("261") ? false : stryMutAct_9fa48("260") ? true : (stryCov_9fa48("260", "261", "262"), (stryMutAct_9fa48("263") ? account : (stryCov_9fa48("263"), !account)) || (stryMutAct_9fa48("265") ? account.workspaceId === id : stryMutAct_9fa48("264") ? false : (stryCov_9fa48("264", "265"), account.workspaceId !== id)))) throw new AccountingError(stryMutAct_9fa48("267") ? "" : (stryCov_9fa48("267"), "ledger_account_not_found"));
                  if (stryMutAct_9fa48("270") ? account.nature === "Expense" : stryMutAct_9fa48("269") ? false : stryMutAct_9fa48("268") ? true : (stryCov_9fa48("268", "269", "270"), account.nature !== (stryMutAct_9fa48("271") ? "" : (stryCov_9fa48("271"), "Expense")))) continue;
                  result.push(stryMutAct_9fa48("273") ? {} : (stryCov_9fa48("273"), {
                    kind: stryMutAct_9fa48("274") ? "" : (stryCov_9fa48("274"), "postedExpense"),
                    journalEntryId: entry._id,
                    lineNumber: line.lineNumber,
                    accountingDate: entry.accountingDate,
                    postedAt: entry.postedAt,
                    postedBy: entry.postedBy,
                    postingPolicy: entry.policy,
                    ...(entry.reversesEntryId ? stryMutAct_9fa48("275") ? {} : (stryCov_9fa48("275"), {
                      reversesEntryId: entry.reversesEntryId
                    }) : {}),
                    account: stryMutAct_9fa48("276") ? {} : (stryCov_9fa48("276"), {
                      ...account,
                      nature: stryMutAct_9fa48("277") ? "" : (stryCov_9fa48("277"), "Expense")
                    }),
                    debitMinorUnits: line.debitMinorUnits,
                    creditMinorUnits: line.creditMinorUnits,
                    ...(line.category ? stryMutAct_9fa48("278") ? {} : (stryCov_9fa48("278"), {
                      category: line.category
                    }) : {}),
                    ...(line.categoryCorrection ? stryMutAct_9fa48("279") ? {} : (stryCov_9fa48("279"), {
                      categoryCorrection: line.categoryCorrection
                    }) : {})
                  }));
                }
              }
            }
          }
          return stryMutAct_9fa48("280") ? result : (stryCov_9fa48("280"), result.sort(stryMutAct_9fa48("281") ? () => undefined : (stryCov_9fa48("281"), (a, b) => stryMutAct_9fa48("284") ? (a.accountingDate.localeCompare(b.accountingDate) || a.journalEntryId.localeCompare(b.journalEntryId)) && a.lineNumber - b.lineNumber : stryMutAct_9fa48("283") ? false : stryMutAct_9fa48("282") ? true : (stryCov_9fa48("282", "283", "284"), (stryMutAct_9fa48("286") ? a.accountingDate.localeCompare(b.accountingDate) && a.journalEntryId.localeCompare(b.journalEntryId) : stryMutAct_9fa48("285") ? false : (stryCov_9fa48("285", "286"), a.accountingDate.localeCompare(b.accountingDate) || a.journalEntryId.localeCompare(b.journalEntryId))) || (stryMutAct_9fa48("287") ? a.lineNumber + b.lineNumber : (stryCov_9fa48("287"), a.lineNumber - b.lineNumber))))));
        }
      }
    });
  }
}