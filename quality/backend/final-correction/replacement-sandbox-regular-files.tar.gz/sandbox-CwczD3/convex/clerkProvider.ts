// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { v } from "convex/values";
import type { Infer } from "convex/values";
import { action, internalAction } from "./_generated/server";
import type { ActionCtx } from "./_generated/server";
import type { Id } from "./_generated/dataModel";
import { api, internal } from "./_generated/api";
import { requireOwner, ownerAdmission } from "./lib/owner";
import { sessionDenial, verifiedSessionId } from "./lib/deviceAccess";
import { workSummary, providerSessionStatus } from "./providerValidators";
import { activeSession, clerkTransport, getOwnedSession, ownedSession, providerFailure, sanitizedProviderError, sessionIsTerminal, verifyProviderInstance } from "./lib/clerk";
async function liveOwner(ctx: ActionCtx, retrievingIntent = stryMutAct_9fa48("582") ? true : (stryCov_9fa48("582"), false)) {
  if (stryMutAct_9fa48("583")) {
    {}
  } else {
    stryCov_9fa48("583");
    const owner = await requireOwner(ctx);
    const sid = verifiedSessionId(owner.clerkIdentity);
    if (stryMutAct_9fa48("586") ? owner.identity.tokenIdentifier === `${owner.identity.issuer}|${owner.identity.subject}` : stryMutAct_9fa48("585") ? false : stryMutAct_9fa48("584") ? true : (stryCov_9fa48("584", "585", "586"), owner.identity.tokenIdentifier !== (stryMutAct_9fa48("587") ? `` : (stryCov_9fa48("587"), `${owner.identity.issuer}|${owner.identity.subject}`)))) providerFailure(stryMutAct_9fa48("589") ? "" : (stryCov_9fa48("589"), "provider_provenance_mismatch"));
    if (stryMutAct_9fa48("592") ? !retrievingIntent || (await ctx.runQuery(internal.providerWork.locallyDenied, {
      tokenIdentifier: owner.identity.tokenIdentifier,
      sid
    })) : stryMutAct_9fa48("591") ? false : stryMutAct_9fa48("590") ? true : (stryCov_9fa48("590", "591", "592"), (stryMutAct_9fa48("593") ? retrievingIntent : (stryCov_9fa48("593"), !retrievingIntent)) && (await ctx.runQuery(internal.providerWork.locallyDenied, stryMutAct_9fa48("594") ? {} : (stryCov_9fa48("594"), {
      tokenIdentifier: owner.identity.tokenIdentifier,
      sid
    }))))) providerFailure(stryMutAct_9fa48("596") ? "" : (stryCov_9fa48("596"), "provider_session_terminal"));
    const clerk = clerkTransport();
    await verifyProviderInstance(clerk, owner.identity.issuer);
    const session = await getOwnedSession(clerk, owner.identity.subject, sid);
    if (stryMutAct_9fa48("599") ? !session && sessionIsTerminal(session) : stryMutAct_9fa48("598") ? false : stryMutAct_9fa48("597") ? true : (stryCov_9fa48("597", "598", "599"), (stryMutAct_9fa48("600") ? session : (stryCov_9fa48("600"), !session)) || sessionIsTerminal(session))) {
      if (stryMutAct_9fa48("601")) {
        {}
      } else {
        stryCov_9fa48("601");
        await ctx.runMutation(internal.devices.applyClerkSessionRevocation, stryMutAct_9fa48("602") ? {} : (stryCov_9fa48("602"), {
          ...owner.identity,
          sid
        }));
        providerFailure(stryMutAct_9fa48("604") ? "" : (stryCov_9fa48("604"), "provider_session_terminal"));
      }
    }
    return stryMutAct_9fa48("605") ? {} : (stryCov_9fa48("605"), {
      owner,
      sid,
      session: activeSession(session)
    });
  }
}
export const checkSession = action(stryMutAct_9fa48("606") ? {} : (stryCov_9fa48("606"), {
  args: {},
  returns: providerSessionStatus,
  handler: async (ctx): Promise<Infer<typeof providerSessionStatus>> => {
    if (stryMutAct_9fa48("607")) {
      {}
    } else {
      stryCov_9fa48("607");
      const owner = await requireOwner(ctx);
      const denial = sessionDenial(owner.clerkIdentity);
      if (stryMutAct_9fa48("609") ? false : stryMutAct_9fa48("608") ? true : (stryCov_9fa48("608", "609"), denial)) return {
        kind: "denied",
        code: denial,
        directive: "wipe-local-input-and-sign-out"
      } as const;
      const local = await ctx.runQuery(api.devices.status, {});
      if (stryMutAct_9fa48("612") ? local.kind === "denied" || local.directive === "wipe-local-input-and-sign-out" : stryMutAct_9fa48("611") ? false : stryMutAct_9fa48("610") ? true : (stryCov_9fa48("610", "611", "612"), (stryMutAct_9fa48("614") ? local.kind !== "denied" : stryMutAct_9fa48("613") ? true : (stryCov_9fa48("613", "614"), local.kind === (stryMutAct_9fa48("615") ? "" : (stryCov_9fa48("615"), "denied")))) && (stryMutAct_9fa48("617") ? local.directive !== "wipe-local-input-and-sign-out" : stryMutAct_9fa48("616") ? true : (stryCov_9fa48("616", "617"), local.directive === (stryMutAct_9fa48("618") ? "" : (stryCov_9fa48("618"), "wipe-local-input-and-sign-out")))))) return stryMutAct_9fa48("619") ? {} : (stryCov_9fa48("619"), {
        kind: stryMutAct_9fa48("620") ? "" : (stryCov_9fa48("620"), "denied"),
        code: local.code,
        directive: local.directive
      });
      try {
        if (stryMutAct_9fa48("621")) {
          {}
        } else {
          stryCov_9fa48("621");
          const {
            session
          } = await liveOwner(ctx);
          return {
            kind: "active",
            providerCreatedAt: session.createdAt,
            providerExpiresAt: session.expireAt
          } as const;
        }
      } catch (error) {
        if (stryMutAct_9fa48("622")) {
          {}
        } else {
          stryCov_9fa48("622");
          const code = sanitizedProviderError(error);
          if (stryMutAct_9fa48("625") ? (code === "provider_session_terminal" || code === "provider_session_invalid") && code === "provider_provenance_mismatch" : stryMutAct_9fa48("624") ? false : stryMutAct_9fa48("623") ? true : (stryCov_9fa48("623", "624", "625"), (stryMutAct_9fa48("627") ? code === "provider_session_terminal" && code === "provider_session_invalid" : stryMutAct_9fa48("626") ? false : (stryCov_9fa48("626", "627"), (stryMutAct_9fa48("629") ? code !== "provider_session_terminal" : stryMutAct_9fa48("628") ? false : (stryCov_9fa48("628", "629"), code === (stryMutAct_9fa48("630") ? "" : (stryCov_9fa48("630"), "provider_session_terminal")))) || (stryMutAct_9fa48("632") ? code !== "provider_session_invalid" : stryMutAct_9fa48("631") ? false : (stryCov_9fa48("631", "632"), code === (stryMutAct_9fa48("633") ? "" : (stryCov_9fa48("633"), "provider_session_invalid")))))) || (stryMutAct_9fa48("635") ? code !== "provider_provenance_mismatch" : stryMutAct_9fa48("634") ? false : (stryCov_9fa48("634", "635"), code === (stryMutAct_9fa48("636") ? "" : (stryCov_9fa48("636"), "provider_provenance_mismatch")))))) {
            if (stryMutAct_9fa48("637")) {
              {}
            } else {
              stryCov_9fa48("637");
              return {
                kind: "denied",
                code,
                directive: "wipe-local-input-and-sign-out"
              } as const;
            }
          }
          return {
            kind: "unavailable",
            code
          } as const;
        }
      }
    }
  }
}));
export const beginRecovery = action(stryMutAct_9fa48("638") ? {} : (stryCov_9fa48("638"), {
  args: {},
  returns: v.object(stryMutAct_9fa48("639") ? {} : (stryCov_9fa48("639"), {
    intentId: v.id(stryMutAct_9fa48("640") ? "" : (stryCov_9fa48("640"), "clerkRecoveryIntents")),
    expiresAt: v.number()
  })),
  handler: async (ctx): Promise<{
    intentId: Id<"clerkRecoveryIntents">;
    expiresAt: number;
  }> => {
    if (stryMutAct_9fa48("641")) {
      {}
    } else {
      stryCov_9fa48("641");
      await requireOwner(ctx);
      try {
        if (stryMutAct_9fa48("642")) {
          {}
        } else {
          stryCov_9fa48("642");
          const {
            owner,
            sid
          } = await liveOwner(ctx, stryMutAct_9fa48("643") ? false : (stryCov_9fa48("643"), true));
          return await ctx.runMutation(internal.providerWork.beginIntent, stryMutAct_9fa48("644") ? {} : (stryCov_9fa48("644"), {
            ...owner.identity,
            initiatingSid: sid
          }));
        }
      } catch (error) {
        if (stryMutAct_9fa48("645")) {
          {}
        } else {
          stryCov_9fa48("645");
          if (stryMutAct_9fa48("646")) {
            ;
          } else {
            stryCov_9fa48("646");
            providerFailure(sanitizedProviderError(error));
          }
        }
      }
    }
  }
}));
export const completeRecovery = action(stryMutAct_9fa48("647") ? {} : (stryCov_9fa48("647"), {
  args: stryMutAct_9fa48("648") ? {} : (stryCov_9fa48("648"), {
    intentId: v.id(stryMutAct_9fa48("649") ? "" : (stryCov_9fa48("649"), "clerkRecoveryIntents"))
  }),
  returns: workSummary,
  handler: async (ctx, {
    intentId
  }): Promise<Infer<typeof workSummary>> => {
    if (stryMutAct_9fa48("650")) {
      {}
    } else {
      stryCov_9fa48("650");
      const owner = await requireOwner(ctx);
      try {
        if (stryMutAct_9fa48("651")) {
          {}
        } else {
          stryCov_9fa48("651");
          const {
            sid,
            session
          } = await liveOwner(ctx);
          const work = await ctx.runMutation(internal.providerWork.claimRecovery, stryMutAct_9fa48("652") ? {} : (stryCov_9fa48("652"), {
            ...owner.identity,
            intentId,
            sid,
            createdAt: session.createdAt
          }));
          await processProviderWork(ctx, work.workId);
          const current = await ctx.runQuery(internal.providerWork.get, stryMutAct_9fa48("653") ? {} : (stryCov_9fa48("653"), {
            workId: work.workId
          }));
          if (stryMutAct_9fa48("656") ? false : stryMutAct_9fa48("655") ? true : stryMutAct_9fa48("654") ? current : (stryCov_9fa48("654", "655", "656"), !current)) providerFailure(stryMutAct_9fa48("658") ? "" : (stryCov_9fa48("658"), "recovery_conflict"));
          return stryMutAct_9fa48("659") ? {} : (stryCov_9fa48("659"), {
            workId: current._id,
            state: current.state
          });
        }
      } catch (error) {
        if (stryMutAct_9fa48("660")) {
          {}
        } else {
          stryCov_9fa48("660");
          if (stryMutAct_9fa48("661")) {
            ;
          } else {
            stryCov_9fa48("661");
            providerFailure(sanitizedProviderError(error));
          }
        }
      }
    }
  }
}));
export async function processProviderWork(ctx: ActionCtx, workId: Id<"clerkProviderWork">): Promise<void> {
  if (stryMutAct_9fa48("662")) {
    {}
  } else {
    stryCov_9fa48("662");
    const work = await ctx.runMutation(internal.providerWork.claimAttempt, stryMutAct_9fa48("663") ? {} : (stryCov_9fa48("663"), {
      workId
    }));
    if (stryMutAct_9fa48("666") ? false : stryMutAct_9fa48("665") ? true : stryMutAct_9fa48("664") ? work : (stryCov_9fa48("664", "665", "666"), !work)) return;
    try {
      if (stryMutAct_9fa48("667")) {
        {}
      } else {
        stryCov_9fa48("667");
        if (stryMutAct_9fa48("670") ? ownerAdmission(work) && work.tokenIdentifier !== `${work.issuer}|${work.subject}` : stryMutAct_9fa48("669") ? false : stryMutAct_9fa48("668") ? true : (stryCov_9fa48("668", "669", "670"), ownerAdmission(work) || (stryMutAct_9fa48("672") ? work.tokenIdentifier === `${work.issuer}|${work.subject}` : stryMutAct_9fa48("671") ? false : (stryCov_9fa48("671", "672"), work.tokenIdentifier !== (stryMutAct_9fa48("673") ? `` : (stryCov_9fa48("673"), `${work.issuer}|${work.subject}`)))))) providerFailure(stryMutAct_9fa48("675") ? "" : (stryCov_9fa48("675"), "provider_provenance_mismatch"));
        const clerk = clerkTransport();
        await verifyProviderInstance(clerk, work.issuer);
        const actor = stryMutAct_9fa48("676") ? {} : (stryCov_9fa48("676"), {
          tokenIdentifier: work.tokenIdentifier,
          issuer: work.issuer,
          subject: work.subject
        });
        const deny = stryMutAct_9fa48("677") ? () => undefined : (stryCov_9fa48("677"), (() => {
          const deny = (sid: string) => ctx.runMutation(internal.devices.applyClerkSessionRevocation, stryMutAct_9fa48("678") ? {} : (stryCov_9fa48("678"), {
            ...actor,
            sid
          }));
          return deny;
        })());
        const revoke = async (sid: string) => {
          if (stryMutAct_9fa48("679")) {
            {}
          } else {
            stryCov_9fa48("679");
            await deny(sid);
            const session = await getOwnedSession(clerk, work.subject, sid);
            if (stryMutAct_9fa48("682") ? !session && sessionIsTerminal(session) : stryMutAct_9fa48("681") ? false : stryMutAct_9fa48("680") ? true : (stryCov_9fa48("680", "681", "682"), (stryMutAct_9fa48("683") ? session : (stryCov_9fa48("683"), !session)) || sessionIsTerminal(session))) return;
            const revoked = ownedSession(await clerk.sessions.revokeSession(sid), work.subject, sid);
            if (stryMutAct_9fa48("686") ? false : stryMutAct_9fa48("685") ? true : stryMutAct_9fa48("684") ? sessionIsTerminal(revoked) : (stryCov_9fa48("684", "685", "686"), !sessionIsTerminal(revoked))) providerFailure(stryMutAct_9fa48("688") ? "" : (stryCov_9fa48("688"), "provider_session_invalid"));
          }
        };
        const target = work.target;
        if (stryMutAct_9fa48("691") ? target.kind !== "revoke" : stryMutAct_9fa48("690") ? false : stryMutAct_9fa48("689") ? true : (stryCov_9fa48("689", "690", "691"), target.kind === (stryMutAct_9fa48("692") ? "" : (stryCov_9fa48("692"), "revoke")))) await revoke(target.sid);else {
          if (stryMutAct_9fa48("693")) {
            {}
          } else {
            stryCov_9fa48("693");
            let scan = target.scan;
            let finished = stryMutAct_9fa48("694") ? true : (stryCov_9fa48("694"), false);
            for (let pageNumber = 0; stryMutAct_9fa48("697") ? pageNumber >= 20 : stryMutAct_9fa48("696") ? pageNumber <= 20 : stryMutAct_9fa48("695") ? false : (stryCov_9fa48("695", "696", "697"), pageNumber < 20); stryMutAct_9fa48("698") ? pageNumber-- : (stryCov_9fa48("698"), pageNumber++)) {
              if (stryMutAct_9fa48("699")) {
                {}
              } else {
                stryCov_9fa48("699");
                const current = scan;
                const continuing = stryMutAct_9fa48("702") ? current.kind !== "continue" : stryMutAct_9fa48("701") ? false : stryMutAct_9fa48("700") ? true : (stryCov_9fa48("700", "701", "702"), current.kind === (stryMutAct_9fa48("703") ? "" : (stryCov_9fa48("703"), "continue")));
                const page = await clerk.sessions.getSessionList(stryMutAct_9fa48("704") ? {} : (stryCov_9fa48("704"), {
                  userId: work.subject,
                  limit: continuing ? 101 : 100,
                  offset: continuing ? stryMutAct_9fa48("705") ? current.offset + 1 : (stryCov_9fa48("705"), current.offset - 1) : 0
                }));
                if (stryMutAct_9fa48("708") ? !Number.isSafeInteger(page.totalCount) && page.totalCount < 0 : stryMutAct_9fa48("707") ? false : stryMutAct_9fa48("706") ? true : (stryCov_9fa48("706", "707", "708"), (stryMutAct_9fa48("709") ? Number.isSafeInteger(page.totalCount) : (stryCov_9fa48("709"), !Number.isSafeInteger(page.totalCount))) || (stryMutAct_9fa48("712") ? page.totalCount >= 0 : stryMutAct_9fa48("711") ? page.totalCount <= 0 : stryMutAct_9fa48("710") ? false : (stryCov_9fa48("710", "711", "712"), page.totalCount < 0)))) providerFailure(stryMutAct_9fa48("714") ? "" : (stryCov_9fa48("714"), "provider_session_invalid"));
                const sessions = page.data.map(stryMutAct_9fa48("715") ? () => undefined : (stryCov_9fa48("715"), item => ownedSession(item, work.subject, item.id)));
                if (stryMutAct_9fa48("718") ? continuing || page.totalCount !== current.totalCount || sessions[0]?.id !== current.anchorSid : stryMutAct_9fa48("717") ? false : stryMutAct_9fa48("716") ? true : (stryCov_9fa48("716", "717", "718"), continuing && (stryMutAct_9fa48("720") ? page.totalCount !== current.totalCount && sessions[0]?.id !== current.anchorSid : stryMutAct_9fa48("719") ? true : (stryCov_9fa48("719", "720"), (stryMutAct_9fa48("722") ? page.totalCount === current.totalCount : stryMutAct_9fa48("721") ? false : (stryCov_9fa48("721", "722"), page.totalCount !== current.totalCount)) || (stryMutAct_9fa48("724") ? sessions[0]?.id === current.anchorSid : stryMutAct_9fa48("723") ? false : (stryCov_9fa48("723", "724"), (stryMutAct_9fa48("725") ? sessions[0].id : (stryCov_9fa48("725"), sessions[0]?.id)) !== current.anchorSid)))))) {
                  if (stryMutAct_9fa48("726")) {
                    {}
                  } else {
                    stryCov_9fa48("726");
                    scan = stryMutAct_9fa48("727") ? {} : (stryCov_9fa48("727"), {
                      kind: stryMutAct_9fa48("728") ? "" : (stryCov_9fa48("728"), "start")
                    });
                    if (stryMutAct_9fa48("731") ? false : stryMutAct_9fa48("730") ? true : stryMutAct_9fa48("729") ? await ctx.runMutation(internal.providerWork.checkpointRecovery, {
                      workId,
                      attempt: work.attempts,
                      scan
                    }) : (stryCov_9fa48("729", "730", "731"), !(await ctx.runMutation(internal.providerWork.checkpointRecovery, stryMutAct_9fa48("732") ? {} : (stryCov_9fa48("732"), {
                      workId,
                      attempt: work.attempts,
                      scan
                    }))))) return;
                    continue;
                  }
                }
                const items = continuing ? stryMutAct_9fa48("733") ? sessions : (stryCov_9fa48("733"), sessions.slice(1)) : sessions;
                let hadLive = stryMutAct_9fa48("736") ? continuing || current.hadLive : stryMutAct_9fa48("735") ? false : stryMutAct_9fa48("734") ? true : (stryCov_9fa48("734", "735", "736"), continuing && current.hadLive);
                for (const session of items) {
                  if (stryMutAct_9fa48("737")) {
                    {}
                  } else {
                    stryCov_9fa48("737");
                    if (stryMutAct_9fa48("740") ? session.id !== target.sid || session.createdAt <= target.createdAt : stryMutAct_9fa48("739") ? false : stryMutAct_9fa48("738") ? true : (stryCov_9fa48("738", "739", "740"), (stryMutAct_9fa48("742") ? session.id === target.sid : stryMutAct_9fa48("741") ? true : (stryCov_9fa48("741", "742"), session.id !== target.sid)) && (stryMutAct_9fa48("745") ? session.createdAt > target.createdAt : stryMutAct_9fa48("744") ? session.createdAt < target.createdAt : stryMutAct_9fa48("743") ? true : (stryCov_9fa48("743", "744", "745"), session.createdAt <= target.createdAt)))) {
                      if (stryMutAct_9fa48("746")) {
                        {}
                      } else {
                        stryCov_9fa48("746");
                        stryMutAct_9fa48("747") ? hadLive &&= !sessionIsTerminal(session) : (stryCov_9fa48("747"), hadLive ||= stryMutAct_9fa48("748") ? sessionIsTerminal(session) : (stryCov_9fa48("748"), !sessionIsTerminal(session)));
                        await revoke(session.id);
                      }
                    }
                  }
                }
                const offset = stryMutAct_9fa48("749") ? (continuing ? current.offset : 0) - items.length : (stryCov_9fa48("749"), (continuing ? current.offset : 0) + items.length);
                if (stryMutAct_9fa48("752") ? offset < page.totalCount || items.length === 0 : stryMutAct_9fa48("751") ? false : stryMutAct_9fa48("750") ? true : (stryCov_9fa48("750", "751", "752"), (stryMutAct_9fa48("755") ? offset >= page.totalCount : stryMutAct_9fa48("754") ? offset <= page.totalCount : stryMutAct_9fa48("753") ? true : (stryCov_9fa48("753", "754", "755"), offset < page.totalCount)) && (stryMutAct_9fa48("757") ? items.length !== 0 : stryMutAct_9fa48("756") ? true : (stryCov_9fa48("756", "757"), items.length === 0)))) providerFailure(stryMutAct_9fa48("759") ? "" : (stryCov_9fa48("759"), "provider_unavailable"));
                finished = stryMutAct_9fa48("762") ? offset >= page.totalCount || !hadLive : stryMutAct_9fa48("761") ? false : stryMutAct_9fa48("760") ? true : (stryCov_9fa48("760", "761", "762"), (stryMutAct_9fa48("765") ? offset < page.totalCount : stryMutAct_9fa48("764") ? offset > page.totalCount : stryMutAct_9fa48("763") ? true : (stryCov_9fa48("763", "764", "765"), offset >= page.totalCount)) && (stryMutAct_9fa48("766") ? hadLive : (stryCov_9fa48("766"), !hadLive)));
                const last = items.at(stryMutAct_9fa48("767") ? +1 : (stryCov_9fa48("767"), -1));
                if (stryMutAct_9fa48("771") ? offset < page.totalCount : stryMutAct_9fa48("770") ? offset > page.totalCount : stryMutAct_9fa48("769") ? false : stryMutAct_9fa48("768") ? true : (stryCov_9fa48("768", "769", "770", "771"), offset >= page.totalCount)) scan = stryMutAct_9fa48("772") ? {} : (stryCov_9fa48("772"), {
                  kind: stryMutAct_9fa48("773") ? "" : (stryCov_9fa48("773"), "start")
                });else {
                  if (stryMutAct_9fa48("774")) {
                    {}
                  } else {
                    stryCov_9fa48("774");
                    if (stryMutAct_9fa48("777") ? false : stryMutAct_9fa48("776") ? true : stryMutAct_9fa48("775") ? last : (stryCov_9fa48("775", "776", "777"), !last)) providerFailure(stryMutAct_9fa48("779") ? "" : (stryCov_9fa48("779"), "provider_session_invalid"));
                    scan = stryMutAct_9fa48("780") ? {} : (stryCov_9fa48("780"), {
                      kind: stryMutAct_9fa48("781") ? "" : (stryCov_9fa48("781"), "continue"),
                      offset,
                      hadLive,
                      totalCount: page.totalCount,
                      anchorSid: last.id
                    });
                  }
                }
                if (stryMutAct_9fa48("784") ? false : stryMutAct_9fa48("783") ? true : stryMutAct_9fa48("782") ? await ctx.runMutation(internal.providerWork.checkpointRecovery, {
                  workId,
                  attempt: work.attempts,
                  scan
                }) : (stryCov_9fa48("782", "783", "784"), !(await ctx.runMutation(internal.providerWork.checkpointRecovery, stryMutAct_9fa48("785") ? {} : (stryCov_9fa48("785"), {
                  workId,
                  attempt: work.attempts,
                  scan
                }))))) return;
                if (stryMutAct_9fa48("787") ? false : stryMutAct_9fa48("786") ? true : (stryCov_9fa48("786", "787"), finished)) break;
              }
            }
            if (stryMutAct_9fa48("790") ? false : stryMutAct_9fa48("789") ? true : stryMutAct_9fa48("788") ? finished : (stryCov_9fa48("788", "789", "790"), !finished)) {
              if (stryMutAct_9fa48("791")) {
                {}
              } else {
                stryCov_9fa48("791");
                await ctx.runMutation(internal.providerWork.continueRecovery, stryMutAct_9fa48("792") ? {} : (stryCov_9fa48("792"), {
                  workId,
                  attempt: work.attempts
                }));
                return;
              }
            }
          }
        }
        await ctx.runMutation(internal.providerWork.recordAttempt, stryMutAct_9fa48("793") ? {} : (stryCov_9fa48("793"), {
          workId,
          attempt: work.attempts
        }));
      }
    } catch (error) {
      if (stryMutAct_9fa48("794")) {
        {}
      } else {
        stryCov_9fa48("794");
        await ctx.runMutation(internal.providerWork.recordAttempt, stryMutAct_9fa48("795") ? {} : (stryCov_9fa48("795"), {
          workId,
          attempt: work.attempts,
          error: sanitizedProviderError(error)
        }));
      }
    }
  }
}
export const process = internalAction(stryMutAct_9fa48("796") ? {} : (stryCov_9fa48("796"), {
  args: stryMutAct_9fa48("797") ? {} : (stryCov_9fa48("797"), {
    workId: v.id(stryMutAct_9fa48("798") ? "" : (stryCov_9fa48("798"), "clerkProviderWork"))
  }),
  returns: v.null(),
  handler: async (ctx, {
    workId
  }) => {
    if (stryMutAct_9fa48("799")) {
      {}
    } else {
      stryCov_9fa48("799");
      await processProviderWork(ctx, workId);
      return null;
    }
  }
}));