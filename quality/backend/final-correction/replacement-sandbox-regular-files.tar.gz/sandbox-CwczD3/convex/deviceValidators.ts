// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { v } from "convex/values";
import { accessDenials, accessPolicy, operations } from "../src/access/protocol";
export const devicePlatform = v.union(v.literal(stryMutAct_9fa48("840") ? "" : (stryCov_9fa48("840"), "ios")), v.literal(stryMutAct_9fa48("841") ? "" : (stryCov_9fa48("841"), "android")));
export const deviceState = v.union(v.object(stryMutAct_9fa48("842") ? {} : (stryCov_9fa48("842"), {
  kind: v.literal(stryMutAct_9fa48("843") ? "" : (stryCov_9fa48("843"), "active"))
})), v.object(stryMutAct_9fa48("844") ? {} : (stryCov_9fa48("844"), {
  kind: v.literal(stryMutAct_9fa48("845") ? "" : (stryCov_9fa48("845"), "revoked")),
  at: v.number(),
  reason: v.union(v.literal(stryMutAct_9fa48("846") ? "" : (stryCov_9fa48("846"), "owner")), v.literal(stryMutAct_9fa48("847") ? "" : (stryCov_9fa48("847"), "recovery")), v.literal(stryMutAct_9fa48("848") ? "" : (stryCov_9fa48("848"), "provider")))
})));
export const accessOperation = v.union(...operations.map(stryMutAct_9fa48("849") ? () => undefined : (stryCov_9fa48("849"), operation => v.literal(operation))));
export const deviceProof = v.object(stryMutAct_9fa48("850") ? {} : (stryCov_9fa48("850"), {
  challengeId: v.id(stryMutAct_9fa48("851") ? "" : (stryCov_9fa48("851"), "deviceChallenges")),
  signature: v.string()
}));
export const deviceSummary = v.object(stryMutAct_9fa48("852") ? {} : (stryCov_9fa48("852"), {
  id: v.id(stryMutAct_9fa48("853") ? "" : (stryCov_9fa48("853"), "mobileDevices")),
  name: v.string(),
  platform: devicePlatform,
  createdAt: v.number(),
  lastSeenAt: v.number(),
  state: deviceState
}));
export const contactDirective = v.union(v.literal(stryMutAct_9fa48("854") ? "" : (stryCov_9fa48("854"), "register-device")), v.literal(stryMutAct_9fa48("855") ? "" : (stryCov_9fa48("855"), "wipe-local-input-and-sign-out")), v.literal(stryMutAct_9fa48("856") ? "" : (stryCov_9fa48("856"), "unlock-online")));
export const deviceStatus = v.union(v.object(stryMutAct_9fa48("857") ? {} : (stryCov_9fa48("857"), {
  kind: v.literal(stryMutAct_9fa48("858") ? "" : (stryCov_9fa48("858"), "denied")),
  code: v.union(...accessDenials.map(stryMutAct_9fa48("859") ? () => undefined : (stryCov_9fa48("859"), code => v.literal(code)))),
  directive: contactDirective
})), v.object(stryMutAct_9fa48("860") ? {} : (stryCov_9fa48("860"), {
  kind: v.literal(stryMutAct_9fa48("861") ? "" : (stryCov_9fa48("861"), "registered")),
  device: deviceSummary,
  policy: v.object(stryMutAct_9fa48("862") ? {} : (stryCov_9fa48("862"), {
    version: v.literal(accessPolicy.version),
    challengeLifetimeMs: v.number(),
    inactivityLifetimeMs: v.number(),
    maximumLifetimeMs: v.number(),
    localInputLifetimeMs: v.number(),
    ordinaryLockMs: v.number(),
    monthCloseLockMs: v.number()
  }))
})));
export const preparedChallenge = v.object(stryMutAct_9fa48("863") ? {} : (stryCov_9fa48("863"), {
  challengeId: v.id(stryMutAct_9fa48("864") ? "" : (stryCov_9fa48("864"), "deviceChallenges")),
  expiresAt: v.number(),
  message: v.string()
}));