// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { ConvexError, v } from "convex/values";
import { AccountingError } from "../src/accounting/errors";
import { RecoveryError } from "../src/savingsRecovery/amounts";
import { createRecoveryCommands } from "../src/savingsRecovery/commands";
import { createRecoveryQueries } from "../src/savingsRecovery/queries";
import { ownerMutation, ownerQuery } from "./lib/owner";
import { recoveryLedger, recoveryStore, recoveryReadStore } from "./recoveryStore";
import { allocationIntent, candidateDecision, candidatesResult, cashInput, planTerms, progressResult, proposalDecision, waterfallResult } from "./recoveryValidators";
const workspace = stryMutAct_9fa48("2421") ? {} : (stryCov_9fa48("2421"), {
  workspaceId: v.string()
});
const command = stryMutAct_9fa48("2422") ? {} : (stryCov_9fa48("2422"), {
  ...workspace,
  idempotencyKey: v.string()
});
async function run<T>(work: () => Promise<T>): Promise<T> {
  if (stryMutAct_9fa48("2423")) {
    {}
  } else {
    stryCov_9fa48("2423");
    try {
      if (stryMutAct_9fa48("2424")) {
        {}
      } else {
        stryCov_9fa48("2424");
        return await work();
      }
    } catch (error) {
      if (stryMutAct_9fa48("2425")) {
        {}
      } else {
        stryCov_9fa48("2425");
        if (stryMutAct_9fa48("2428") ? error instanceof RecoveryError && error instanceof AccountingError : stryMutAct_9fa48("2427") ? false : stryMutAct_9fa48("2426") ? true : (stryCov_9fa48("2426", "2427", "2428"), error instanceof RecoveryError || error instanceof AccountingError)) throw new ConvexError(stryMutAct_9fa48("2430") ? {} : (stryCov_9fa48("2430"), {
          code: error.code
        }));
        throw error;
      }
    }
  }
}
export const saveDraft = ownerMutation(stryMutAct_9fa48("2431") ? {} : (stryCov_9fa48("2431"), {
  operation: stryMutAct_9fa48("2432") ? "" : (stryCov_9fa48("2432"), "savingsRecovery.saveDraft"),
  args: stryMutAct_9fa48("2433") ? {} : (stryCov_9fa48("2433"), {
    ...command,
    planId: v.union(v.string(), v.null()),
    expectedRevision: v.union(v.number(), v.null()),
    terms: planTerms
  }),
  returns: v.string(),
  handler: stryMutAct_9fa48("2434") ? () => undefined : (stryCov_9fa48("2434"), async (ctx, args) => run(stryMutAct_9fa48("2435") ? () => undefined : (stryCov_9fa48("2435"), () => createRecoveryCommands(recoveryStore(ctx.db), recoveryLedger(ctx.db)).saveDraft(stryMutAct_9fa48("2436") ? {} : (stryCov_9fa48("2436"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const activatePlan = ownerMutation(stryMutAct_9fa48("2437") ? {} : (stryCov_9fa48("2437"), {
  operation: stryMutAct_9fa48("2438") ? "" : (stryCov_9fa48("2438"), "savingsRecovery.activatePlan"),
  args: stryMutAct_9fa48("2439") ? {} : (stryCov_9fa48("2439"), {
    ...command,
    planId: v.string(),
    expectedRevision: v.number()
  }),
  returns: v.string(),
  handler: stryMutAct_9fa48("2440") ? () => undefined : (stryCov_9fa48("2440"), async (ctx, args) => run(stryMutAct_9fa48("2441") ? () => undefined : (stryCov_9fa48("2441"), () => createRecoveryCommands(recoveryStore(ctx.db), recoveryLedger(ctx.db)).activatePlan(stryMutAct_9fa48("2442") ? {} : (stryCov_9fa48("2442"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const cancelPlan = ownerMutation(stryMutAct_9fa48("2443") ? {} : (stryCov_9fa48("2443"), {
  operation: stryMutAct_9fa48("2444") ? "" : (stryCov_9fa48("2444"), "savingsRecovery.cancelPlan"),
  args: stryMutAct_9fa48("2445") ? {} : (stryCov_9fa48("2445"), {
    ...command,
    planId: v.string(),
    reason: v.string()
  }),
  returns: v.string(),
  handler: stryMutAct_9fa48("2446") ? () => undefined : (stryCov_9fa48("2446"), async (ctx, args) => run(stryMutAct_9fa48("2447") ? () => undefined : (stryCov_9fa48("2447"), () => createRecoveryCommands(recoveryStore(ctx.db), recoveryLedger(ctx.db)).cancelPlan(stryMutAct_9fa48("2448") ? {} : (stryCov_9fa48("2448"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const replacePlan = ownerMutation(stryMutAct_9fa48("2449") ? {} : (stryCov_9fa48("2449"), {
  operation: stryMutAct_9fa48("2450") ? "" : (stryCov_9fa48("2450"), "savingsRecovery.replacePlan"),
  args: stryMutAct_9fa48("2451") ? {} : (stryCov_9fa48("2451"), {
    ...command,
    planId: v.string(),
    terms: planTerms,
    reason: v.string()
  }),
  returns: v.string(),
  handler: stryMutAct_9fa48("2452") ? () => undefined : (stryCov_9fa48("2452"), async (ctx, args) => run(stryMutAct_9fa48("2453") ? () => undefined : (stryCov_9fa48("2453"), () => createRecoveryCommands(recoveryStore(ctx.db), recoveryLedger(ctx.db)).replacePlan(stryMutAct_9fa48("2454") ? {} : (stryCov_9fa48("2454"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const reconcilePlans = ownerMutation(stryMutAct_9fa48("2455") ? {} : (stryCov_9fa48("2455"), {
  operation: stryMutAct_9fa48("2456") ? "" : (stryCov_9fa48("2456"), "savingsRecovery.reconcilePlans"),
  args: stryMutAct_9fa48("2457") ? {} : (stryCov_9fa48("2457"), {
    ...command
  }),
  returns: v.string(),
  handler: stryMutAct_9fa48("2458") ? () => undefined : (stryCov_9fa48("2458"), async (ctx, args) => run(stryMutAct_9fa48("2459") ? () => undefined : (stryCov_9fa48("2459"), () => createRecoveryCommands(recoveryStore(ctx.db), recoveryLedger(ctx.db)).reconcilePlans(stryMutAct_9fa48("2460") ? {} : (stryCov_9fa48("2460"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const decideCandidate = ownerMutation(stryMutAct_9fa48("2461") ? {} : (stryCov_9fa48("2461"), {
  operation: stryMutAct_9fa48("2462") ? "" : (stryCov_9fa48("2462"), "savingsRecovery.decideCandidate"),
  args: stryMutAct_9fa48("2463") ? {} : (stryCov_9fa48("2463"), {
    ...command,
    entryId: v.string(),
    decision: candidateDecision
  }),
  returns: v.string(),
  handler: stryMutAct_9fa48("2464") ? () => undefined : (stryCov_9fa48("2464"), async (ctx, args) => run(stryMutAct_9fa48("2465") ? () => undefined : (stryCov_9fa48("2465"), () => createRecoveryCommands(recoveryStore(ctx.db), recoveryLedger(ctx.db)).decideCandidate(stryMutAct_9fa48("2466") ? {} : (stryCov_9fa48("2466"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const recordContribution = ownerMutation(stryMutAct_9fa48("2467") ? {} : (stryCov_9fa48("2467"), {
  operation: stryMutAct_9fa48("2468") ? "" : (stryCov_9fa48("2468"), "savingsRecovery.recordContribution"),
  args: stryMutAct_9fa48("2469") ? {} : (stryCov_9fa48("2469"), {
    ...command,
    transferEntryId: v.string(),
    allocations: v.array(allocationIntent)
  }),
  returns: v.string(),
  handler: stryMutAct_9fa48("2470") ? () => undefined : (stryCov_9fa48("2470"), async (ctx, args) => run(stryMutAct_9fa48("2471") ? () => undefined : (stryCov_9fa48("2471"), () => createRecoveryCommands(recoveryStore(ctx.db), recoveryLedger(ctx.db)).recordContribution(stryMutAct_9fa48("2472") ? {} : (stryCov_9fa48("2472"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const reverseContribution = ownerMutation(stryMutAct_9fa48("2473") ? {} : (stryCov_9fa48("2473"), {
  operation: stryMutAct_9fa48("2474") ? "" : (stryCov_9fa48("2474"), "savingsRecovery.reverseContribution"),
  args: stryMutAct_9fa48("2475") ? {} : (stryCov_9fa48("2475"), {
    ...command,
    contributionId: v.string(),
    reason: v.string()
  }),
  returns: v.string(),
  handler: stryMutAct_9fa48("2476") ? () => undefined : (stryCov_9fa48("2476"), async (ctx, args) => run(stryMutAct_9fa48("2477") ? () => undefined : (stryCov_9fa48("2477"), () => createRecoveryCommands(recoveryStore(ctx.db), recoveryLedger(ctx.db)).reverseContribution(stryMutAct_9fa48("2478") ? {} : (stryCov_9fa48("2478"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const proposeAllocation = ownerMutation(stryMutAct_9fa48("2479") ? {} : (stryCov_9fa48("2479"), {
  operation: stryMutAct_9fa48("2480") ? "" : (stryCov_9fa48("2480"), "savingsRecovery.proposeAllocation"),
  args: stryMutAct_9fa48("2481") ? {} : (stryCov_9fa48("2481"), {
    ...command,
    transferEntryId: v.string(),
    allocations: v.array(allocationIntent),
    importReference: v.string()
  }),
  returns: v.string(),
  handler: stryMutAct_9fa48("2482") ? () => undefined : (stryCov_9fa48("2482"), async (ctx, args) => run(stryMutAct_9fa48("2483") ? () => undefined : (stryCov_9fa48("2483"), () => createRecoveryCommands(recoveryStore(ctx.db), recoveryLedger(ctx.db)).proposeAllocation(stryMutAct_9fa48("2484") ? {} : (stryCov_9fa48("2484"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const decideProposal = ownerMutation(stryMutAct_9fa48("2485") ? {} : (stryCov_9fa48("2485"), {
  operation: stryMutAct_9fa48("2486") ? "" : (stryCov_9fa48("2486"), "savingsRecovery.decideProposal"),
  args: stryMutAct_9fa48("2487") ? {} : (stryCov_9fa48("2487"), {
    ...command,
    proposalId: v.string(),
    decision: proposalDecision
  }),
  returns: v.string(),
  handler: stryMutAct_9fa48("2488") ? () => undefined : (stryCov_9fa48("2488"), async (ctx, args) => run(stryMutAct_9fa48("2489") ? () => undefined : (stryCov_9fa48("2489"), () => createRecoveryCommands(recoveryStore(ctx.db), recoveryLedger(ctx.db)).decideProposal(stryMutAct_9fa48("2490") ? {} : (stryCov_9fa48("2490"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const declareOpeningProgress = ownerMutation(stryMutAct_9fa48("2491") ? {} : (stryCov_9fa48("2491"), {
  operation: stryMutAct_9fa48("2492") ? "" : (stryCov_9fa48("2492"), "savingsRecovery.declareOpeningProgress"),
  args: stryMutAct_9fa48("2493") ? {} : (stryCov_9fa48("2493"), {
    ...command,
    planId: v.string(),
    amountMinor: v.number(),
    throughDate: v.string(),
    provenance: v.string(),
    evidenceUnavailable: v.literal(stryMutAct_9fa48("2494") ? false : (stryCov_9fa48("2494"), true))
  }),
  returns: v.string(),
  handler: stryMutAct_9fa48("2495") ? () => undefined : (stryCov_9fa48("2495"), async (ctx, args) => run(stryMutAct_9fa48("2496") ? () => undefined : (stryCov_9fa48("2496"), () => createRecoveryCommands(recoveryStore(ctx.db), recoveryLedger(ctx.db)).declareOpeningProgress(stryMutAct_9fa48("2497") ? {} : (stryCov_9fa48("2497"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const listCandidates = ownerQuery(stryMutAct_9fa48("2498") ? {} : (stryCov_9fa48("2498"), {
  operation: stryMutAct_9fa48("2499") ? "" : (stryCov_9fa48("2499"), "savingsRecovery.listCandidates"),
  args: stryMutAct_9fa48("2500") ? {} : (stryCov_9fa48("2500"), {
    ...workspace,
    from: v.string(),
    through: v.string()
  }),
  returns: candidatesResult,
  handler: stryMutAct_9fa48("2501") ? () => undefined : (stryCov_9fa48("2501"), async (ctx, args) => run(stryMutAct_9fa48("2502") ? () => undefined : (stryCov_9fa48("2502"), () => createRecoveryQueries(recoveryReadStore(ctx.db), recoveryLedger(ctx.db)).listCandidates(stryMutAct_9fa48("2503") ? {} : (stryCov_9fa48("2503"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const progress = ownerQuery(stryMutAct_9fa48("2504") ? {} : (stryCov_9fa48("2504"), {
  operation: stryMutAct_9fa48("2505") ? "" : (stryCov_9fa48("2505"), "savingsRecovery.progress"),
  args: stryMutAct_9fa48("2506") ? {} : (stryCov_9fa48("2506"), {
    ...workspace,
    asKnownAt: v.optional(v.number())
  }),
  returns: progressResult,
  handler: stryMutAct_9fa48("2507") ? () => undefined : (stryCov_9fa48("2507"), async (ctx, args) => run(stryMutAct_9fa48("2508") ? () => undefined : (stryCov_9fa48("2508"), () => createRecoveryQueries(recoveryReadStore(ctx.db), recoveryLedger(ctx.db)).progress(stryMutAct_9fa48("2509") ? {} : (stryCov_9fa48("2509"), {
    ...args,
    actor: ctx.actor
  })))))
}));
export const monthlyWaterfall = ownerQuery(stryMutAct_9fa48("2510") ? {} : (stryCov_9fa48("2510"), {
  operation: stryMutAct_9fa48("2511") ? "" : (stryCov_9fa48("2511"), "savingsRecovery.monthlyWaterfall"),
  args: stryMutAct_9fa48("2512") ? {} : (stryCov_9fa48("2512"), {
    ...workspace,
    month: v.string(),
    cash: cashInput,
    includePrepayment: v.boolean()
  }),
  returns: waterfallResult,
  handler: stryMutAct_9fa48("2513") ? () => undefined : (stryCov_9fa48("2513"), async (ctx, args) => run(stryMutAct_9fa48("2514") ? () => undefined : (stryCov_9fa48("2514"), () => createRecoveryQueries(recoveryReadStore(ctx.db), recoveryLedger(ctx.db)).monthlyWaterfall(stryMutAct_9fa48("2515") ? {} : (stryCov_9fa48("2515"), {
    ...args,
    actor: ctx.actor
  })))))
}));