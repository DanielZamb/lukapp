// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { providerActor, providerState, providerTarget } from "./providerValidators";
import { firstRunResult } from "./onboardingValidators";
import { categoryFields, userCategory, categorySnapshot, categoryCorrection } from "./categoryAnnotationValidators";
import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { accessOperation, devicePlatform, deviceState } from "./deviceValidators";
import { accountNature, normalSide, periodStatus, postingPolicy, productKind, profileClassificationAnswers, storedOpening, cashCategoryInput } from "./validators";
import { budgetTables } from "./budgetValidators";
import { planFields, eventFields } from "./recoveryValidators";
export default defineSchema(stryMutAct_9fa48("2516") ? {} : (stryCov_9fa48("2516"), {
  firstRunCompletions: defineTable(stryMutAct_9fa48("2517") ? {} : (stryCov_9fa48("2517"), {
    tokenIdentifier: v.string(),
    request: v.string(),
    result: firstRunResult
  })).index(stryMutAct_9fa48("2518") ? "" : (stryCov_9fa48("2518"), "by_identity"), stryMutAct_9fa48("2519") ? [] : (stryCov_9fa48("2519"), [stryMutAct_9fa48("2520") ? "" : (stryCov_9fa48("2520"), "tokenIdentifier")])),
  ...budgetTables,
  recoveryPlans: defineTable(planFields).index(stryMutAct_9fa48("2521") ? "" : (stryCov_9fa48("2521"), "by_workspace"), stryMutAct_9fa48("2522") ? [] : (stryCov_9fa48("2522"), [stryMutAct_9fa48("2523") ? "" : (stryCov_9fa48("2523"), "workspaceId")])),
  recoveryEvents: defineTable(eventFields).index(stryMutAct_9fa48("2524") ? "" : (stryCov_9fa48("2524"), "by_workspace"), stryMutAct_9fa48("2525") ? [] : (stryCov_9fa48("2525"), [stryMutAct_9fa48("2526") ? "" : (stryCov_9fa48("2526"), "workspaceId")])),
  recoveryReceipts: defineTable(stryMutAct_9fa48("2527") ? {} : (stryCov_9fa48("2527"), {
    workspaceId: v.string(),
    key: v.string(),
    fingerprint: v.string(),
    resultId: v.string()
  })).index(stryMutAct_9fa48("2528") ? "" : (stryCov_9fa48("2528"), "by_workspace_key"), stryMutAct_9fa48("2529") ? [] : (stryCov_9fa48("2529"), [stryMutAct_9fa48("2530") ? "" : (stryCov_9fa48("2530"), "workspaceId"), stryMutAct_9fa48("2531") ? "" : (stryCov_9fa48("2531"), "key")])),
  clerkProviderWork: defineTable(stryMutAct_9fa48("2532") ? {} : (stryCov_9fa48("2532"), {
    ...providerActor,
    target: providerTarget,
    state: providerState,
    attempts: v.number()
  })).index(stryMutAct_9fa48("2533") ? "" : (stryCov_9fa48("2533"), "by_identity"), stryMutAct_9fa48("2534") ? [] : (stryCov_9fa48("2534"), [stryMutAct_9fa48("2535") ? "" : (stryCov_9fa48("2535"), "tokenIdentifier")])),
  clerkRecoveryIntents: defineTable(stryMutAct_9fa48("2536") ? {} : (stryCov_9fa48("2536"), {
    ...providerActor,
    initiatingSid: v.string(),
    createdAt: v.number(),
    expiresAt: v.number(),
    workId: v.optional(v.id(stryMutAct_9fa48("2537") ? "" : (stryCov_9fa48("2537"), "clerkProviderWork")))
  })).index(stryMutAct_9fa48("2538") ? "" : (stryCov_9fa48("2538"), "by_identity"), stryMutAct_9fa48("2539") ? [] : (stryCov_9fa48("2539"), [stryMutAct_9fa48("2540") ? "" : (stryCov_9fa48("2540"), "tokenIdentifier")])),
  clerkWebhookDeliveries: defineTable(stryMutAct_9fa48("2541") ? {} : (stryCov_9fa48("2541"), {
    ...providerActor,
    sid: v.string(),
    eventId: v.string(),
    eventType: v.string(),
    timestamp: v.number()
  })).index(stryMutAct_9fa48("2542") ? "" : (stryCov_9fa48("2542"), "by_event"), stryMutAct_9fa48("2543") ? [] : (stryCov_9fa48("2543"), [stryMutAct_9fa48("2544") ? "" : (stryCov_9fa48("2544"), "eventId")])),
  mobileDevices: defineTable(stryMutAct_9fa48("2545") ? {} : (stryCov_9fa48("2545"), {
    tokenIdentifier: v.string(),
    sid: v.string(),
    publicKey: v.string(),
    name: v.string(),
    platform: devicePlatform,
    createdAt: v.number(),
    lastSeenAt: v.number(),
    state: deviceState
  })).index(stryMutAct_9fa48("2546") ? "" : (stryCov_9fa48("2546"), "by_identity_sid"), stryMutAct_9fa48("2547") ? [] : (stryCov_9fa48("2547"), [stryMutAct_9fa48("2548") ? "" : (stryCov_9fa48("2548"), "tokenIdentifier"), stryMutAct_9fa48("2549") ? "" : (stryCov_9fa48("2549"), "sid")])).index(stryMutAct_9fa48("2550") ? "" : (stryCov_9fa48("2550"), "by_identity_platform"), stryMutAct_9fa48("2551") ? [] : (stryCov_9fa48("2551"), [stryMutAct_9fa48("2552") ? "" : (stryCov_9fa48("2552"), "tokenIdentifier"), stryMutAct_9fa48("2553") ? "" : (stryCov_9fa48("2553"), "platform")])).index(stryMutAct_9fa48("2554") ? "" : (stryCov_9fa48("2554"), "by_identity_key"), stryMutAct_9fa48("2555") ? [] : (stryCov_9fa48("2555"), [stryMutAct_9fa48("2556") ? "" : (stryCov_9fa48("2556"), "tokenIdentifier"), stryMutAct_9fa48("2557") ? "" : (stryCov_9fa48("2557"), "publicKey")])).index(stryMutAct_9fa48("2558") ? "" : (stryCov_9fa48("2558"), "by_identity"), stryMutAct_9fa48("2559") ? [] : (stryCov_9fa48("2559"), [stryMutAct_9fa48("2560") ? "" : (stryCov_9fa48("2560"), "tokenIdentifier")])),
  deviceChallenges: defineTable(stryMutAct_9fa48("2561") ? {} : (stryCov_9fa48("2561"), {
    tokenIdentifier: v.string(),
    sid: v.string(),
    operation: accessOperation,
    deviceId: v.optional(v.id(stryMutAct_9fa48("2562") ? "" : (stryCov_9fa48("2562"), "mobileDevices"))),
    publicKey: v.string(),
    payloadHash: v.string(),
    nonce: v.string(),
    expiresAt: v.number(),
    consumedAt: v.optional(v.number())
  })).index(stryMutAct_9fa48("2563") ? "" : (stryCov_9fa48("2563"), "by_identity_sid"), stryMutAct_9fa48("2564") ? [] : (stryCov_9fa48("2564"), [stryMutAct_9fa48("2565") ? "" : (stryCov_9fa48("2565"), "tokenIdentifier"), stryMutAct_9fa48("2566") ? "" : (stryCov_9fa48("2566"), "sid")])),
  deviceSessionDenials: defineTable(stryMutAct_9fa48("2567") ? {} : (stryCov_9fa48("2567"), {
    tokenIdentifier: v.string(),
    sid: v.string(),
    at: v.number()
  })).index(stryMutAct_9fa48("2568") ? "" : (stryCov_9fa48("2568"), "by_identity_sid"), stryMutAct_9fa48("2569") ? [] : (stryCov_9fa48("2569"), [stryMutAct_9fa48("2570") ? "" : (stryCov_9fa48("2570"), "tokenIdentifier"), stryMutAct_9fa48("2571") ? "" : (stryCov_9fa48("2571"), "sid")])),
  deviceRecoveryBarriers: defineTable(stryMutAct_9fa48("2572") ? {} : (stryCov_9fa48("2572"), {
    tokenIdentifier: v.string()
  })).index(stryMutAct_9fa48("2573") ? "" : (stryCov_9fa48("2573"), "by_identity"), stryMutAct_9fa48("2574") ? [] : (stryCov_9fa48("2574"), [stryMutAct_9fa48("2575") ? "" : (stryCov_9fa48("2575"), "tokenIdentifier")])),
  deviceRegistrationApprovals: defineTable(stryMutAct_9fa48("2576") ? {} : (stryCov_9fa48("2576"), {
    tokenIdentifier: v.string(),
    sid: v.string()
  })).index(stryMutAct_9fa48("2577") ? "" : (stryCov_9fa48("2577"), "by_identity_sid"), stryMutAct_9fa48("2578") ? [] : (stryCov_9fa48("2578"), [stryMutAct_9fa48("2579") ? "" : (stryCov_9fa48("2579"), "tokenIdentifier"), stryMutAct_9fa48("2580") ? "" : (stryCov_9fa48("2580"), "sid")])),
  deviceRecoveryEvents: defineTable(stryMutAct_9fa48("2581") ? {} : (stryCov_9fa48("2581"), {
    tokenIdentifier: v.string(),
    eventId: v.string(),
    recoveredSid: v.string()
  })).index(stryMutAct_9fa48("2582") ? "" : (stryCov_9fa48("2582"), "by_identity_event"), stryMutAct_9fa48("2583") ? [] : (stryCov_9fa48("2583"), [stryMutAct_9fa48("2584") ? "" : (stryCov_9fa48("2584"), "tokenIdentifier"), stryMutAct_9fa48("2585") ? "" : (stryCov_9fa48("2585"), "eventId")])),
  personalWorkspaceOwners: defineTable(stryMutAct_9fa48("2586") ? {} : (stryCov_9fa48("2586"), {
    tokenIdentifier: v.string(),
    issuer: v.string(),
    subject: v.string(),
    workspaceId: v.id(stryMutAct_9fa48("2587") ? "" : (stryCov_9fa48("2587"), "workspaces"))
  })).index(stryMutAct_9fa48("2588") ? "" : (stryCov_9fa48("2588"), "by_identity"), stryMutAct_9fa48("2589") ? [] : (stryCov_9fa48("2589"), [stryMutAct_9fa48("2590") ? "" : (stryCov_9fa48("2590"), "tokenIdentifier")])),
  householdWorkspaceCreations: defineTable(stryMutAct_9fa48("2591") ? {} : (stryCov_9fa48("2591"), {
    ownerUserId: v.string(),
    idempotencyKey: v.string(),
    workspaceId: v.id(stryMutAct_9fa48("2592") ? "" : (stryCov_9fa48("2592"), "workspaces"))
  })).index(stryMutAct_9fa48("2593") ? "" : (stryCov_9fa48("2593"), "by_owner_key"), stryMutAct_9fa48("2594") ? [] : (stryCov_9fa48("2594"), [stryMutAct_9fa48("2595") ? "" : (stryCov_9fa48("2595"), "ownerUserId"), stryMutAct_9fa48("2596") ? "" : (stryCov_9fa48("2596"), "idempotencyKey")])),
  workspaces: defineTable(stryMutAct_9fa48("2597") ? {} : (stryCov_9fa48("2597"), {
    kind: v.union(v.literal(stryMutAct_9fa48("2598") ? "" : (stryCov_9fa48("2598"), "Personal")), v.literal(stryMutAct_9fa48("2599") ? "" : (stryCov_9fa48("2599"), "Household"))),
    functionalCurrency: v.string(),
    chartOfAccountsTemplate: v.string()
  })),
  workspaceMemberships: defineTable(stryMutAct_9fa48("2600") ? {} : (stryCov_9fa48("2600"), {
    workspaceId: v.id(stryMutAct_9fa48("2601") ? "" : (stryCov_9fa48("2601"), "workspaces")),
    userId: v.string(),
    role: v.union(v.literal(stryMutAct_9fa48("2602") ? "" : (stryCov_9fa48("2602"), "Owner")), v.literal(stryMutAct_9fa48("2603") ? "" : (stryCov_9fa48("2603"), "Accountant")), v.literal(stryMutAct_9fa48("2604") ? "" : (stryCov_9fa48("2604"), "Preparer")), v.literal(stryMutAct_9fa48("2605") ? "" : (stryCov_9fa48("2605"), "Viewer")))
  })).index(stryMutAct_9fa48("2606") ? "" : (stryCov_9fa48("2606"), "by_workspace_user"), stryMutAct_9fa48("2607") ? [] : (stryCov_9fa48("2607"), [stryMutAct_9fa48("2608") ? "" : (stryCov_9fa48("2608"), "workspaceId"), stryMutAct_9fa48("2609") ? "" : (stryCov_9fa48("2609"), "userId")])).index(stryMutAct_9fa48("2610") ? "" : (stryCov_9fa48("2610"), "by_user_role"), stryMutAct_9fa48("2611") ? [] : (stryCov_9fa48("2611"), [stryMutAct_9fa48("2612") ? "" : (stryCov_9fa48("2612"), "userId"), stryMutAct_9fa48("2613") ? "" : (stryCov_9fa48("2613"), "role")])),
  ledgerAccounts: defineTable(stryMutAct_9fa48("2614") ? {} : (stryCov_9fa48("2614"), {
    workspaceId: v.id(stryMutAct_9fa48("2615") ? "" : (stryCov_9fa48("2615"), "workspaces")),
    code: v.string(),
    name: v.string(),
    nature: accountNature,
    normalSide,
    role: v.literal(stryMutAct_9fa48("2616") ? "" : (stryCov_9fa48("2616"), "Posting"))
  })).index(stryMutAct_9fa48("2617") ? "" : (stryCov_9fa48("2617"), "by_workspace"), stryMutAct_9fa48("2618") ? [] : (stryCov_9fa48("2618"), [stryMutAct_9fa48("2619") ? "" : (stryCov_9fa48("2619"), "workspaceId")])).index(stryMutAct_9fa48("2620") ? "" : (stryCov_9fa48("2620"), "by_workspace_code"), stryMutAct_9fa48("2621") ? [] : (stryCov_9fa48("2621"), [stryMutAct_9fa48("2622") ? "" : (stryCov_9fa48("2622"), "workspaceId"), stryMutAct_9fa48("2623") ? "" : (stryCov_9fa48("2623"), "code")])),
  userCategories: defineTable(categoryFields).index(stryMutAct_9fa48("2624") ? "" : (stryCov_9fa48("2624"), "by_workspace"), stryMutAct_9fa48("2625") ? [] : (stryCov_9fa48("2625"), [stryMutAct_9fa48("2626") ? "" : (stryCov_9fa48("2626"), "workspaceId")])),
  categoryReceipts: defineTable(stryMutAct_9fa48("2627") ? {} : (stryCov_9fa48("2627"), {
    workspaceId: v.string(),
    idempotencyKey: v.string(),
    request: v.string(),
    category: userCategory,
    correctionEntryIds: v.array(v.string()),
    financialAccountProfileId: v.optional(v.string())
  })).index(stryMutAct_9fa48("2628") ? "" : (stryCov_9fa48("2628"), "by_workspace_key"), stryMutAct_9fa48("2629") ? [] : (stryCov_9fa48("2629"), [stryMutAct_9fa48("2630") ? "" : (stryCov_9fa48("2630"), "workspaceId"), stryMutAct_9fa48("2631") ? "" : (stryCov_9fa48("2631"), "idempotencyKey")])),
  financialAccountProfiles: defineTable(stryMutAct_9fa48("2632") ? {} : (stryCov_9fa48("2632"), {
    workspaceId: v.id(stryMutAct_9fa48("2633") ? "" : (stryCov_9fa48("2633"), "workspaces")),
    name: v.string(),
    productKind,
    classificationPolicy: v.string(),
    classificationAnswers: v.optional(profileClassificationAnswers),
    postingAccountId: v.id(stryMutAct_9fa48("2634") ? "" : (stryCov_9fa48("2634"), "ledgerAccounts")),
    setupIdempotencyKey: v.optional(v.string()),
    opening: v.optional(storedOpening)
  })).index(stryMutAct_9fa48("2635") ? "" : (stryCov_9fa48("2635"), "by_workspace"), stryMutAct_9fa48("2636") ? [] : (stryCov_9fa48("2636"), [stryMutAct_9fa48("2637") ? "" : (stryCov_9fa48("2637"), "workspaceId")])).index(stryMutAct_9fa48("2638") ? "" : (stryCov_9fa48("2638"), "by_workspace_setup"), stryMutAct_9fa48("2639") ? [] : (stryCov_9fa48("2639"), [stryMutAct_9fa48("2640") ? "" : (stryCov_9fa48("2640"), "workspaceId"), stryMutAct_9fa48("2641") ? "" : (stryCov_9fa48("2641"), "setupIdempotencyKey")])),
  openingPositions: defineTable(stryMutAct_9fa48("2642") ? {} : (stryCov_9fa48("2642"), {
    workspaceId: v.id(stryMutAct_9fa48("2643") ? "" : (stryCov_9fa48("2643"), "workspaces")),
    financialAccountProfileId: v.id(stryMutAct_9fa48("2644") ? "" : (stryCov_9fa48("2644"), "financialAccountProfiles")),
    description: v.string(),
    replacesOpeningKey: v.optional(v.string()),
    idempotencyKey: v.string(),
    opening: storedOpening
  })).index(stryMutAct_9fa48("2645") ? "" : (stryCov_9fa48("2645"), "by_workspace_idempotency"), stryMutAct_9fa48("2646") ? [] : (stryCov_9fa48("2646"), [stryMutAct_9fa48("2647") ? "" : (stryCov_9fa48("2647"), "workspaceId"), stryMutAct_9fa48("2648") ? "" : (stryCov_9fa48("2648"), "idempotencyKey")])),
  journalSourceEffects: defineTable(stryMutAct_9fa48("2649") ? {} : (stryCov_9fa48("2649"), {
    workspaceId: v.id(stryMutAct_9fa48("2650") ? "" : (stryCov_9fa48("2650"), "workspaces")),
    sourceEntryId: v.id(stryMutAct_9fa48("2651") ? "" : (stryCov_9fa48("2651"), "journalEntries")),
    journalEntryId: v.id(stryMutAct_9fa48("2652") ? "" : (stryCov_9fa48("2652"), "journalEntries")),
    expenseDeltaMinorUnits: v.number(),
    sourceSequence: v.number()
  })).index(stryMutAct_9fa48("2653") ? "" : (stryCov_9fa48("2653"), "by_workspace_source"), stryMutAct_9fa48("2654") ? [] : (stryCov_9fa48("2654"), [stryMutAct_9fa48("2655") ? "" : (stryCov_9fa48("2655"), "workspaceId"), stryMutAct_9fa48("2656") ? "" : (stryCov_9fa48("2656"), "sourceEntryId")])),
  journalEntries: defineTable(stryMutAct_9fa48("2657") ? {} : (stryCov_9fa48("2657"), {
    cashCategoryInput: v.optional(cashCategoryInput),
    workspaceId: v.id(stryMutAct_9fa48("2658") ? "" : (stryCov_9fa48("2658"), "workspaces")),
    accountingDate: v.string(),
    periodYear: v.number(),
    periodMonth: v.number(),
    description: v.string(),
    idempotencyKey: v.string(),
    policy: postingPolicy,
    sourceExpenseEffects: v.optional(v.array(v.object(stryMutAct_9fa48("2659") ? {} : (stryCov_9fa48("2659"), {
      sourceEntryId: v.string(),
      expenseDeltaMinorUnits: v.number()
    })))),
    financialAccountProfileId: v.optional(v.id(stryMutAct_9fa48("2660") ? "" : (stryCov_9fa48("2660"), "financialAccountProfiles"))),
    reversesEntryId: v.optional(v.id(stryMutAct_9fa48("2661") ? "" : (stryCov_9fa48("2661"), "journalEntries"))),
    postedBy: v.string(),
    postedAt: v.number()
  })).index(stryMutAct_9fa48("2662") ? "" : (stryCov_9fa48("2662"), "by_workspace"), stryMutAct_9fa48("2663") ? [] : (stryCov_9fa48("2663"), [stryMutAct_9fa48("2664") ? "" : (stryCov_9fa48("2664"), "workspaceId")])).index(stryMutAct_9fa48("2665") ? "" : (stryCov_9fa48("2665"), "by_workspace_idempotency"), stryMutAct_9fa48("2666") ? [] : (stryCov_9fa48("2666"), [stryMutAct_9fa48("2667") ? "" : (stryCov_9fa48("2667"), "workspaceId"), stryMutAct_9fa48("2668") ? "" : (stryCov_9fa48("2668"), "idempotencyKey")])).index(stryMutAct_9fa48("2669") ? "" : (stryCov_9fa48("2669"), "by_workspace_period"), stryMutAct_9fa48("2670") ? [] : (stryCov_9fa48("2670"), [stryMutAct_9fa48("2671") ? "" : (stryCov_9fa48("2671"), "workspaceId"), stryMutAct_9fa48("2672") ? "" : (stryCov_9fa48("2672"), "periodYear"), stryMutAct_9fa48("2673") ? "" : (stryCov_9fa48("2673"), "periodMonth")])).index(stryMutAct_9fa48("2674") ? "" : (stryCov_9fa48("2674"), "by_workspace_policy_date"), stryMutAct_9fa48("2675") ? [] : (stryCov_9fa48("2675"), [stryMutAct_9fa48("2676") ? "" : (stryCov_9fa48("2676"), "workspaceId"), stryMutAct_9fa48("2677") ? "" : (stryCov_9fa48("2677"), "policy"), stryMutAct_9fa48("2678") ? "" : (stryCov_9fa48("2678"), "accountingDate")])).index(stryMutAct_9fa48("2679") ? "" : (stryCov_9fa48("2679"), "by_reverses"), stryMutAct_9fa48("2680") ? [] : (stryCov_9fa48("2680"), [stryMutAct_9fa48("2681") ? "" : (stryCov_9fa48("2681"), "reversesEntryId")])),
  journalLines: defineTable(stryMutAct_9fa48("2682") ? {} : (stryCov_9fa48("2682"), {
    category: v.optional(categorySnapshot),
    categoryCorrection: v.optional(categoryCorrection),
    workspaceId: v.id(stryMutAct_9fa48("2683") ? "" : (stryCov_9fa48("2683"), "workspaces")),
    journalEntryId: v.id(stryMutAct_9fa48("2684") ? "" : (stryCov_9fa48("2684"), "journalEntries")),
    lineNumber: v.number(),
    ledgerAccountId: v.id(stryMutAct_9fa48("2685") ? "" : (stryCov_9fa48("2685"), "ledgerAccounts")),
    debitMinorUnits: v.number(),
    creditMinorUnits: v.number()
  })).index(stryMutAct_9fa48("2686") ? "" : (stryCov_9fa48("2686"), "by_workspace"), stryMutAct_9fa48("2687") ? [] : (stryCov_9fa48("2687"), [stryMutAct_9fa48("2688") ? "" : (stryCov_9fa48("2688"), "workspaceId")])).index(stryMutAct_9fa48("2689") ? "" : (stryCov_9fa48("2689"), "by_entry"), stryMutAct_9fa48("2690") ? [] : (stryCov_9fa48("2690"), [stryMutAct_9fa48("2691") ? "" : (stryCov_9fa48("2691"), "journalEntryId"), stryMutAct_9fa48("2692") ? "" : (stryCov_9fa48("2692"), "lineNumber")])),
  accountingPeriods: defineTable(stryMutAct_9fa48("2693") ? {} : (stryCov_9fa48("2693"), {
    workspaceId: v.id(stryMutAct_9fa48("2694") ? "" : (stryCov_9fa48("2694"), "workspaces")),
    year: v.number(),
    month: v.number(),
    status: periodStatus
  })).index(stryMutAct_9fa48("2695") ? "" : (stryCov_9fa48("2695"), "by_workspace_year_month"), stryMutAct_9fa48("2696") ? [] : (stryCov_9fa48("2696"), [stryMutAct_9fa48("2697") ? "" : (stryCov_9fa48("2697"), "workspaceId"), stryMutAct_9fa48("2698") ? "" : (stryCov_9fa48("2698"), "year"), stryMutAct_9fa48("2699") ? "" : (stryCov_9fa48("2699"), "month")])),
  periodControlDecisions: defineTable(stryMutAct_9fa48("2700") ? {} : (stryCov_9fa48("2700"), {
    workspaceId: v.id(stryMutAct_9fa48("2701") ? "" : (stryCov_9fa48("2701"), "workspaces")),
    year: v.number(),
    month: v.number(),
    action: v.literal(stryMutAct_9fa48("2702") ? "" : (stryCov_9fa48("2702"), "Lock")),
    decidedBy: v.string(),
    decidedAt: v.number(),
    reason: v.optional(v.string())
  })).index(stryMutAct_9fa48("2703") ? "" : (stryCov_9fa48("2703"), "by_workspace_year_month"), stryMutAct_9fa48("2704") ? [] : (stryCov_9fa48("2704"), [stryMutAct_9fa48("2705") ? "" : (stryCov_9fa48("2705"), "workspaceId"), stryMutAct_9fa48("2706") ? "" : (stryCov_9fa48("2706"), "year"), stryMutAct_9fa48("2707") ? "" : (stryCov_9fa48("2707"), "month")]))
}));