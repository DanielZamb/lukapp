// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { v } from "convex/values";
import { accessDenials } from "../src/access/protocol";
export const providerError = v.union(v.literal(stryMutAct_9fa48("1989") ? "" : (stryCov_9fa48("1989"), "provider_configuration_required")), v.literal(stryMutAct_9fa48("1990") ? "" : (stryCov_9fa48("1990"), "provider_instance_mismatch")), v.literal(stryMutAct_9fa48("1991") ? "" : (stryCov_9fa48("1991"), "provider_unavailable")), v.literal(stryMutAct_9fa48("1992") ? "" : (stryCov_9fa48("1992"), "provider_provenance_mismatch")), v.literal(stryMutAct_9fa48("1993") ? "" : (stryCov_9fa48("1993"), "provider_session_invalid")), v.literal(stryMutAct_9fa48("1994") ? "" : (stryCov_9fa48("1994"), "provider_session_terminal")), v.literal(stryMutAct_9fa48("1995") ? "" : (stryCov_9fa48("1995"), "recovery_fresh_sign_in_required")), v.literal(stryMutAct_9fa48("1996") ? "" : (stryCov_9fa48("1996"), "recovery_intent_expired")), v.literal(stryMutAct_9fa48("1997") ? "" : (stryCov_9fa48("1997"), "recovery_conflict")));
export const providerState = v.union(v.object(stryMutAct_9fa48("1998") ? {} : (stryCov_9fa48("1998"), {
  kind: v.literal(stryMutAct_9fa48("1999") ? "" : (stryCov_9fa48("1999"), "pending")),
  nextAttemptAt: v.number(),
  error: v.optional(providerError)
})), v.object(stryMutAct_9fa48("2000") ? {} : (stryCov_9fa48("2000"), {
  kind: v.literal(stryMutAct_9fa48("2001") ? "" : (stryCov_9fa48("2001"), "succeeded")),
  at: v.number()
})));
export const recoveryScan = v.union(v.object(stryMutAct_9fa48("2002") ? {} : (stryCov_9fa48("2002"), {
  kind: v.literal(stryMutAct_9fa48("2003") ? "" : (stryCov_9fa48("2003"), "start"))
})), v.object(stryMutAct_9fa48("2004") ? {} : (stryCov_9fa48("2004"), {
  kind: v.literal(stryMutAct_9fa48("2005") ? "" : (stryCov_9fa48("2005"), "continue")),
  offset: v.number(),
  hadLive: v.boolean(),
  totalCount: v.number(),
  anchorSid: v.string()
})));
export const providerTarget = v.union(v.object(stryMutAct_9fa48("2006") ? {} : (stryCov_9fa48("2006"), {
  kind: v.literal(stryMutAct_9fa48("2007") ? "" : (stryCov_9fa48("2007"), "revoke")),
  sid: v.string()
})), v.object(stryMutAct_9fa48("2008") ? {} : (stryCov_9fa48("2008"), {
  kind: v.literal(stryMutAct_9fa48("2009") ? "" : (stryCov_9fa48("2009"), "recovery")),
  sid: v.string(),
  createdAt: v.number(),
  scan: recoveryScan,
  intentId: v.id(stryMutAct_9fa48("2010") ? "" : (stryCov_9fa48("2010"), "clerkRecoveryIntents"))
})));
export const providerActor = stryMutAct_9fa48("2011") ? {} : (stryCov_9fa48("2011"), {
  tokenIdentifier: v.string(),
  issuer: v.string(),
  subject: v.string()
});
export const workSummary = v.object(stryMutAct_9fa48("2012") ? {} : (stryCov_9fa48("2012"), {
  workId: v.id(stryMutAct_9fa48("2013") ? "" : (stryCov_9fa48("2013"), "clerkProviderWork")),
  state: providerState
}));
export const providerSessionStatus = v.union(v.object(stryMutAct_9fa48("2014") ? {} : (stryCov_9fa48("2014"), {
  kind: v.literal(stryMutAct_9fa48("2015") ? "" : (stryCov_9fa48("2015"), "active")),
  providerCreatedAt: v.number(),
  providerExpiresAt: v.number()
})), v.object(stryMutAct_9fa48("2016") ? {} : (stryCov_9fa48("2016"), {
  kind: v.literal(stryMutAct_9fa48("2017") ? "" : (stryCov_9fa48("2017"), "denied")),
  code: v.union(providerError, ...accessDenials.map(stryMutAct_9fa48("2018") ? () => undefined : (stryCov_9fa48("2018"), code => v.literal(code)))),
  directive: v.literal(stryMutAct_9fa48("2019") ? "" : (stryCov_9fa48("2019"), "wipe-local-input-and-sign-out"))
})), v.object(stryMutAct_9fa48("2020") ? {} : (stryCov_9fa48("2020"), {
  kind: v.literal(stryMutAct_9fa48("2021") ? "" : (stryCov_9fa48("2021"), "unavailable")),
  code: providerError
})));