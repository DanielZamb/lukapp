// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { v } from "convex/values";
import { accountBalance, money, postedExpense } from "./validators";
export const sourceAllocation = v.object(stryMutAct_9fa48("2358") ? {} : (stryCov_9fa48("2358"), {
  entryId: v.string(),
  principalMinor: v.number()
}));
export const planTerms = v.object(stryMutAct_9fa48("2359") ? {} : (stryCov_9fa48("2359"), {
  name: v.string(),
  destinationProfileId: v.string(),
  sources: v.array(sourceAllocation),
  installmentCount: v.number(),
  installmentAmountMinor: v.number()
}));
export const installment = v.object(stryMutAct_9fa48("2360") ? {} : (stryCov_9fa48("2360"), {
  month: v.string(),
  amountMinor: v.number(),
  principalMinor: v.number(),
  premiumMinor: v.number()
}));
export const commitment = v.object(stryMutAct_9fa48("2361") ? {} : (stryCov_9fa48("2361"), {
  activatedOn: v.string(),
  activatedAt: v.number(),
  sourceEffectCuts: v.record(v.string(), v.number()),
  principalMinor: v.number(),
  impliedMonthlyRate: v.number(),
  schedule: v.array(installment)
}));
export const planState = v.union(v.object(stryMutAct_9fa48("2362") ? {} : (stryCov_9fa48("2362"), {
  kind: v.literal(stryMutAct_9fa48("2363") ? "" : (stryCov_9fa48("2363"), "Draft"))
})), v.object(stryMutAct_9fa48("2364") ? {} : (stryCov_9fa48("2364"), {
  kind: v.literal(stryMutAct_9fa48("2365") ? "" : (stryCov_9fa48("2365"), "Activated")),
  commitment
})));
export const planFields = stryMutAct_9fa48("2366") ? {} : (stryCov_9fa48("2366"), {
  workspaceId: v.string(),
  revision: v.number(),
  terms: planTerms,
  replacesPlanId: v.union(v.string(), v.null()),
  state: planState
});
export const plan = v.object(stryMutAct_9fa48("2367") ? {} : (stryCov_9fa48("2367"), {
  id: v.string(),
  ...planFields
}));
export const installmentAllocation = v.object(stryMutAct_9fa48("2368") ? {} : (stryCov_9fa48("2368"), {
  installmentIndex: v.number(),
  principalMinor: v.number(),
  premiumMinor: v.number(),
  prepayment: v.boolean()
}));
export const contributionAllocation = v.object(stryMutAct_9fa48("2369") ? {} : (stryCov_9fa48("2369"), {
  planId: v.string(),
  amountMinor: v.number(),
  principalMinor: v.number(),
  premiumMinor: v.number(),
  installments: v.array(installmentAllocation),
  sources: v.array(sourceAllocation)
}));
export const allocationIntent = v.object(stryMutAct_9fa48("2370") ? {} : (stryCov_9fa48("2370"), {
  planId: v.string(),
  amountMinor: v.number()
}));
export const candidateDecision = v.union(v.literal(stryMutAct_9fa48("2371") ? "" : (stryCov_9fa48("2371"), "eligible")), v.literal(stryMutAct_9fa48("2372") ? "" : (stryCov_9fa48("2372"), "deferred")), v.literal(stryMutAct_9fa48("2373") ? "" : (stryCov_9fa48("2373"), "excluded")));
export const proposalDecision = v.union(v.literal(stryMutAct_9fa48("2374") ? "" : (stryCov_9fa48("2374"), "accepted")), v.literal(stryMutAct_9fa48("2375") ? "" : (stryCov_9fa48("2375"), "rejected")));
export const eventData = v.union(v.object(stryMutAct_9fa48("2376") ? {} : (stryCov_9fa48("2376"), {
  kind: v.literal(stryMutAct_9fa48("2377") ? "" : (stryCov_9fa48("2377"), "candidateDecision")),
  entryId: v.string(),
  decision: candidateDecision
})), v.object(stryMutAct_9fa48("2378") ? {} : (stryCov_9fa48("2378"), {
  kind: v.literal(stryMutAct_9fa48("2379") ? "" : (stryCov_9fa48("2379"), "cancelled")),
  planId: v.string(),
  reason: v.string()
})), v.object(stryMutAct_9fa48("2380") ? {} : (stryCov_9fa48("2380"), {
  kind: v.literal(stryMutAct_9fa48("2381") ? "" : (stryCov_9fa48("2381"), "suspended")),
  planId: v.string(),
  entryIds: v.array(v.string())
})), v.object(stryMutAct_9fa48("2382") ? {} : (stryCov_9fa48("2382"), {
  kind: v.literal(stryMutAct_9fa48("2383") ? "" : (stryCov_9fa48("2383"), "contribution")),
  transferEntryId: v.string(),
  contributionDate: v.string(),
  allocations: v.array(contributionAllocation),
  intent: v.union(v.literal(stryMutAct_9fa48("2384") ? "" : (stryCov_9fa48("2384"), "explicit")), v.literal(stryMutAct_9fa48("2385") ? "" : (stryCov_9fa48("2385"), "acceptedProposal"))),
  proposalId: v.union(v.string(), v.null())
})), v.object(stryMutAct_9fa48("2386") ? {} : (stryCov_9fa48("2386"), {
  kind: v.literal(stryMutAct_9fa48("2387") ? "" : (stryCov_9fa48("2387"), "contributionReversal")),
  contributionId: v.string(),
  reason: v.string()
})), v.object(stryMutAct_9fa48("2388") ? {} : (stryCov_9fa48("2388"), {
  kind: v.literal(stryMutAct_9fa48("2389") ? "" : (stryCov_9fa48("2389"), "proposal")),
  transferEntryId: v.string(),
  allocations: v.array(allocationIntent),
  importReference: v.string()
})), v.object(stryMutAct_9fa48("2390") ? {} : (stryCov_9fa48("2390"), {
  kind: v.literal(stryMutAct_9fa48("2391") ? "" : (stryCov_9fa48("2391"), "proposalDecision")),
  proposalId: v.string(),
  decision: proposalDecision,
  contributionId: v.union(v.string(), v.null())
})), v.object(stryMutAct_9fa48("2392") ? {} : (stryCov_9fa48("2392"), {
  kind: v.literal(stryMutAct_9fa48("2393") ? "" : (stryCov_9fa48("2393"), "openingProgress")),
  planId: v.string(),
  throughDate: v.string(),
  provenance: v.string(),
  evidenceUnavailable: v.literal(stryMutAct_9fa48("2394") ? false : (stryCov_9fa48("2394"), true)),
  allocation: contributionAllocation
})));
export const eventFields = stryMutAct_9fa48("2395") ? {} : (stryCov_9fa48("2395"), {
  workspaceId: v.string(),
  recordedAt: v.number(),
  actorId: v.string(),
  data: eventData
});
export const event = v.object(stryMutAct_9fa48("2396") ? {} : (stryCov_9fa48("2396"), {
  id: v.string(),
  ...eventFields
}));
export const protections = v.object(stryMutAct_9fa48("2397") ? {} : (stryCov_9fa48("2397"), {
  essentialSpendingMinor: v.number(),
  taxesMinor: v.number(),
  requiredReservesMinor: v.number(),
  externalObligationsMinor: v.number(),
  provenance: v.string()
}));
export const cashInput = v.union(v.object(stryMutAct_9fa48("2398") ? {} : (stryCov_9fa48("2398"), {
  kind: v.literal(stryMutAct_9fa48("2399") ? "" : (stryCov_9fa48("2399"), "computed")),
  liquidProfileIds: v.array(v.string()),
  protections
})), v.object(stryMutAct_9fa48("2400") ? {} : (stryCov_9fa48("2400"), {
  kind: v.literal(stryMutAct_9fa48("2401") ? "" : (stryCov_9fa48("2401"), "entered")),
  availableMinor: v.number(),
  protections,
  attestation: v.string()
})));
const paid = v.object(stryMutAct_9fa48("2402") ? {} : (stryCov_9fa48("2402"), {
  amountMinor: v.number(),
  principalMinor: v.number(),
  premiumMinor: v.number()
}));
export const progressResult = v.object(stryMutAct_9fa48("2403") ? {} : (stryCov_9fa48("2403"), {
  currency: v.string(),
  asKnownAt: v.number(),
  plans: v.array(v.object(stryMutAct_9fa48("2404") ? {} : (stryCov_9fa48("2404"), {
    plan,
    status: v.object(stryMutAct_9fa48("2405") ? {} : (stryCov_9fa48("2405"), {
      kind: v.union(v.literal(stryMutAct_9fa48("2406") ? "" : (stryCov_9fa48("2406"), "Draft")), v.literal(stryMutAct_9fa48("2407") ? "" : (stryCov_9fa48("2407"), "Active")), v.literal(stryMutAct_9fa48("2408") ? "" : (stryCov_9fa48("2408"), "Completed")), v.literal(stryMutAct_9fa48("2409") ? "" : (stryCov_9fa48("2409"), "Suspended")), v.literal(stryMutAct_9fa48("2410") ? "" : (stryCov_9fa48("2410"), "Cancelled"))),
      unsupportedEntryIds: v.array(v.string())
    })),
    verified: paid,
    declaredBaseline: paid,
    destinationBalance: v.union(money, v.null())
  }))),
  contributions: v.array(v.object(stryMutAct_9fa48("2411") ? {} : (stryCov_9fa48("2411"), {
    id: v.string(),
    ...eventFields,
    voided: v.boolean(),
    corrected: v.boolean()
  }))),
  history: v.array(event)
}));
export const candidatesResult = v.array(v.object(stryMutAct_9fa48("2412") ? {} : (stryCov_9fa48("2412"), {
  expense: postedExpense,
  decision: candidateDecision,
  recoveredPrincipalMinor: v.number(),
  remainingEligibleMinor: v.number(),
  reservedBy: v.union(v.string(), v.null())
})));
const fundedInstallment = v.object(stryMutAct_9fa48("2413") ? {} : (stryCov_9fa48("2413"), {
  planId: v.string(),
  installmentIndex: v.number(),
  month: v.string(),
  outstandingMinor: v.number(),
  allocatedMinor: v.number()
}));
export const waterfallResult = v.object(stryMutAct_9fa48("2414") ? {} : (stryCov_9fa48("2414"), {
  month: v.string(),
  currency: v.string(),
  availableCash: v.object(stryMutAct_9fa48("2415") ? {} : (stryCov_9fa48("2415"), {
    mode: v.union(v.literal(stryMutAct_9fa48("2416") ? "" : (stryCov_9fa48("2416"), "entered")), v.literal(stryMutAct_9fa48("2417") ? "" : (stryCov_9fa48("2417"), "computed"))),
    availableMinor: v.number(),
    ledgerCashMinor: v.union(v.number(), v.null()),
    selectedBalances: v.array(accountBalance),
    protectedMinor: v.number(),
    protectionInputs: protections,
    attestation: v.union(v.string(), v.null()),
    coverage: v.literal(stryMutAct_9fa48("2418") ? "" : (stryCov_9fa48("2418"), "user-declared-protections-only")),
    unmodeledObligationsProtected: v.literal(stryMutAct_9fa48("2419") ? true : (stryCov_9fa48("2419"), false))
  })),
  combinedRecoveryPaymentMinor: v.number(),
  shortfalls: v.array(fundedInstallment),
  currentInstallments: v.array(fundedInstallment),
  expenseRecovery: v.array(v.object(stryMutAct_9fa48("2420") ? {} : (stryCov_9fa48("2420"), {
    entryId: v.string(),
    outstandingMinor: v.number(),
    allocatedMinor: v.number()
  }))),
  prepayment: v.array(fundedInstallment),
  ordinarySavingMinor: v.number()
}));