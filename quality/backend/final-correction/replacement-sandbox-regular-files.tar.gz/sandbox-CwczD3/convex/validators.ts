// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { categorySnapshot, categoryCorrection } from "./categoryAnnotationValidators";
import { v } from "convex/values";
export const accountNature = v.union(v.literal(stryMutAct_9fa48("3075") ? "" : (stryCov_9fa48("3075"), "Asset")), v.literal(stryMutAct_9fa48("3076") ? "" : (stryCov_9fa48("3076"), "Liability")), v.literal(stryMutAct_9fa48("3077") ? "" : (stryCov_9fa48("3077"), "Equity")), v.literal(stryMutAct_9fa48("3078") ? "" : (stryCov_9fa48("3078"), "Revenue")), v.literal(stryMutAct_9fa48("3079") ? "" : (stryCov_9fa48("3079"), "Expense")));
export const normalSide = v.union(v.literal(stryMutAct_9fa48("3080") ? "" : (stryCov_9fa48("3080"), "Debit")), v.literal(stryMutAct_9fa48("3081") ? "" : (stryCov_9fa48("3081"), "Credit")));
export const catalogUse = v.union(v.literal(stryMutAct_9fa48("3082") ? "" : (stryCov_9fa48("3082"), "expense")), v.literal(stryMutAct_9fa48("3083") ? "" : (stryCov_9fa48("3083"), "income")), v.literal(stryMutAct_9fa48("3084") ? "" : (stryCov_9fa48("3084"), "openingBalance")), v.literal(stryMutAct_9fa48("3085") ? "" : (stryCov_9fa48("3085"), "general")));
export const productKind = v.union(v.literal(stryMutAct_9fa48("3086") ? "" : (stryCov_9fa48("3086"), "cash")), v.literal(stryMutAct_9fa48("3087") ? "" : (stryCov_9fa48("3087"), "bankAccount")), v.literal(stryMutAct_9fa48("3088") ? "" : (stryCov_9fa48("3088"), "savingsAccount")), v.literal(stryMutAct_9fa48("3089") ? "" : (stryCov_9fa48("3089"), "creditCard")), v.literal(stryMutAct_9fa48("3090") ? "" : (stryCov_9fa48("3090"), "loan")), v.literal(stryMutAct_9fa48("3091") ? "" : (stryCov_9fa48("3091"), "receivable")), v.literal(stryMutAct_9fa48("3092") ? "" : (stryCov_9fa48("3092"), "investment")), v.literal(stryMutAct_9fa48("3093") ? "" : (stryCov_9fa48("3093"), "personalDebt")));
export const profileClassificationAnswers = v.union(v.object(stryMutAct_9fa48("3094") ? {} : (stryCov_9fa48("3094"), {
  kind: v.literal(stryMutAct_9fa48("3095") ? "" : (stryCov_9fa48("3095"), "receivable")),
  security: v.union(v.literal(stryMutAct_9fa48("3096") ? "" : (stryCov_9fa48("3096"), "secured")), v.literal(stryMutAct_9fa48("3097") ? "" : (stryCov_9fa48("3097"), "unsecured"))),
  counterpartyName: v.string()
})), v.object(stryMutAct_9fa48("3098") ? {} : (stryCov_9fa48("3098"), {
  kind: v.literal(stryMutAct_9fa48("3099") ? "" : (stryCov_9fa48("3099"), "investment")),
  form: v.union(v.literal(stryMutAct_9fa48("3100") ? "" : (stryCov_9fa48("3100"), "termDeposit")), v.literal(stryMutAct_9fa48("3101") ? "" : (stryCov_9fa48("3101"), "fund"))),
  counterpartyName: v.optional(v.string())
})), v.object(stryMutAct_9fa48("3102") ? {} : (stryCov_9fa48("3102"), {
  kind: v.literal(stryMutAct_9fa48("3103") ? "" : (stryCov_9fa48("3103"), "personalDebt")),
  counterpartyName: v.string()
})));
export const postingPolicy = v.union(v.literal(stryMutAct_9fa48("3104") ? "" : (stryCov_9fa48("3104"), "cash-expense@1")), v.literal(stryMutAct_9fa48("3105") ? "" : (stryCov_9fa48("3105"), "cash-income@1")), v.literal(stryMutAct_9fa48("3106") ? "" : (stryCov_9fa48("3106"), "reversal@1")), v.literal(stryMutAct_9fa48("3107") ? "" : (stryCov_9fa48("3107"), "account-transfer@1")), v.literal(stryMutAct_9fa48("3108") ? "" : (stryCov_9fa48("3108"), "opening-position@1")), v.literal(stryMutAct_9fa48("3109") ? "" : (stryCov_9fa48("3109"), "category-reclassification@1")));
export const periodStatus = v.union(v.literal(stryMutAct_9fa48("3110") ? "" : (stryCov_9fa48("3110"), "open")), v.literal(stryMutAct_9fa48("3111") ? "" : (stryCov_9fa48("3111"), "locked")));
export const money = v.object(stryMutAct_9fa48("3112") ? {} : (stryCov_9fa48("3112"), {
  currency: v.string(),
  minorUnits: v.number()
}));
export const periodKey = v.object(stryMutAct_9fa48("3113") ? {} : (stryCov_9fa48("3113"), {
  year: v.number(),
  month: v.number()
}));
export const accountingPeriod = v.object(stryMutAct_9fa48("3114") ? {} : (stryCov_9fa48("3114"), {
  year: v.number(),
  month: v.number(),
  status: v.union(v.literal(stryMutAct_9fa48("3115") ? "" : (stryCov_9fa48("3115"), "open")), v.literal(stryMutAct_9fa48("3116") ? "" : (stryCov_9fa48("3116"), "locked")), v.literal(stryMutAct_9fa48("3117") ? "" : (stryCov_9fa48("3117"), "not_opened")))
}));
export const workspace = v.object(stryMutAct_9fa48("3118") ? {} : (stryCov_9fa48("3118"), {
  id: v.string(),
  kind: v.union(v.literal(stryMutAct_9fa48("3119") ? "" : (stryCov_9fa48("3119"), "Personal")), v.literal(stryMutAct_9fa48("3120") ? "" : (stryCov_9fa48("3120"), "Household"))),
  functionalCurrency: v.string(),
  chartOfAccountsTemplate: v.string(),
  currentAccountingPeriod: accountingPeriod
}));
export const storedOpening = v.union(v.object(stryMutAct_9fa48("3121") ? {} : (stryCov_9fa48("3121"), {
  kind: v.literal(stryMutAct_9fa48("3122") ? "" : (stryCov_9fa48("3122"), "zero")),
  accountingDate: v.string(),
  idempotencyKey: v.string(),
  amount: money
})), v.object(stryMutAct_9fa48("3123") ? {} : (stryCov_9fa48("3123"), {
  kind: v.literal(stryMutAct_9fa48("3124") ? "" : (stryCov_9fa48("3124"), "posted")),
  accountingDate: v.string(),
  idempotencyKey: v.string(),
  amount: money,
  journalEntryId: v.string()
})));
export const openingStatus = v.union(v.object(stryMutAct_9fa48("3125") ? {} : (stryCov_9fa48("3125"), {
  status: v.literal(stryMutAct_9fa48("3126") ? "" : (stryCov_9fa48("3126"), "not_started"))
})), v.object(stryMutAct_9fa48("3127") ? {} : (stryCov_9fa48("3127"), {
  status: v.literal(stryMutAct_9fa48("3128") ? "" : (stryCov_9fa48("3128"), "zero")),
  accountingDate: v.string(),
  idempotencyKey: v.string(),
  amount: money
})), v.object(stryMutAct_9fa48("3129") ? {} : (stryCov_9fa48("3129"), {
  status: v.union(v.literal(stryMutAct_9fa48("3130") ? "" : (stryCov_9fa48("3130"), "posted")), v.literal(stryMutAct_9fa48("3131") ? "" : (stryCov_9fa48("3131"), "reversed"))),
  accountingDate: v.string(),
  idempotencyKey: v.string(),
  amount: money,
  journalEntryId: v.string()
})));
export const financialAccountProfile = v.object(stryMutAct_9fa48("3132") ? {} : (stryCov_9fa48("3132"), {
  id: v.string(),
  workspaceId: v.string(),
  name: v.string(),
  productKind,
  classificationAnswers: v.optional(profileClassificationAnswers),
  ledgerAccountId: v.string(),
  opening: openingStatus
}));
export const ledgerAccount = v.object(stryMutAct_9fa48("3133") ? {} : (stryCov_9fa48("3133"), {
  id: v.string(),
  code: v.string(),
  name: v.string(),
  nature: accountNature,
  normalSide,
  role: v.literal(stryMutAct_9fa48("3134") ? "" : (stryCov_9fa48("3134"), "Posting")),
  financialAccountProfileId: v.optional(v.string())
}));
export const catalogAccount = v.object(stryMutAct_9fa48("3135") ? {} : (stryCov_9fa48("3135"), {
  code: v.string(),
  name: v.string(),
  nature: accountNature,
  normalSide,
  use: catalogUse,
  reportingConcept: v.optional(v.string()),
  ancestors: v.array(v.object(stryMutAct_9fa48("3136") ? {} : (stryCov_9fa48("3136"), {
    code: v.string(),
    name: v.string()
  }))),
  ledgerAccountId: v.optional(v.string())
}));
export const journalLine = v.object(stryMutAct_9fa48("3137") ? {} : (stryCov_9fa48("3137"), {
  category: v.optional(categorySnapshot),
  categoryCorrection: v.optional(categoryCorrection),
  ledgerAccountId: v.string(),
  financialAccountProfileId: v.optional(v.string()),
  code: v.string(),
  name: v.string(),
  nature: accountNature,
  debitMinorUnits: v.number(),
  creditMinorUnits: v.number()
}));
export const cashCategoryInput = v.object(stryMutAct_9fa48("3138") ? {} : (stryCov_9fa48("3138"), {
  userCategoryId: v.string(),
  categoryRevision: v.optional(v.number()),
  ledgerAccountCode: v.optional(v.string())
}));
export const postedJournalEntry = v.object(stryMutAct_9fa48("3139") ? {} : (stryCov_9fa48("3139"), {
  cashCategoryInput: v.optional(cashCategoryInput),
  id: v.string(),
  policy: postingPolicy,
  sourceExpenseEffects: v.optional(v.array(v.object(stryMutAct_9fa48("3140") ? {} : (stryCov_9fa48("3140"), {
    sourceEntryId: v.string(),
    expenseDeltaMinorUnits: v.number()
  })))),
  description: v.string(),
  accountingDate: v.string(),
  accountingPeriod,
  amount: money,
  financialAccountProfileId: v.optional(v.string()),
  financialAccountProfileName: v.optional(v.string()),
  accountTransfer: v.optional(v.object(stryMutAct_9fa48("3141") ? {} : (stryCov_9fa48("3141"), {
    sourceFinancialAccountProfileId: v.string(),
    destinationFinancialAccountProfileId: v.string(),
    sourceNature: accountNature,
    destinationNature: accountNature
  }))),
  reversesEntryId: v.optional(v.string()),
  reversedByEntryId: v.optional(v.string()),
  postedBy: v.string(),
  postedAt: v.number(),
  replay: v.boolean(),
  lines: v.array(journalLine)
}));
export const accountBalance = v.object(stryMutAct_9fa48("3142") ? {} : (stryCov_9fa48("3142"), {
  financialAccountProfileId: v.string(),
  name: v.string(),
  nature: accountNature,
  debitMinorUnits: v.number(),
  creditMinorUnits: v.number(),
  balance: money
}));
export const trialBalanceRow = v.object(stryMutAct_9fa48("3143") ? {} : (stryCov_9fa48("3143"), {
  ledgerAccountId: v.string(),
  code: v.string(),
  name: v.string(),
  nature: accountNature,
  debitMinorUnits: v.number(),
  creditMinorUnits: v.number()
}));
export const openingPositionResult = v.object(stryMutAct_9fa48("3144") ? {} : (stryCov_9fa48("3144"), {
  profile: financialAccountProfile,
  journalEntry: v.union(postedJournalEntry, v.null()),
  replay: v.boolean()
}));
export const postedExpense = v.object(stryMutAct_9fa48("3145") ? {} : (stryCov_9fa48("3145"), {
  entryId: v.string(),
  accountingDate: v.string(),
  description: v.string(),
  amount: money,
  currentEligibleAmount: money,
  sourceEffects: v.array(v.object(stryMutAct_9fa48("3146") ? {} : (stryCov_9fa48("3146"), {
    workspaceId: v.string(),
    sourceEntryId: v.string(),
    journalEntryId: v.string(),
    expenseDeltaMinorUnits: v.number(),
    sourceSequence: v.number(),
    accountingDate: v.string(),
    recordedAt: v.number(),
    reversedByEntryId: v.union(v.string(), v.null())
  }))),
  expenseLines: v.array(v.object(stryMutAct_9fa48("3147") ? {} : (stryCov_9fa48("3147"), {
    ledgerAccountId: v.string(),
    amount: money
  }))),
  reversal: v.union(v.null(), v.object(stryMutAct_9fa48("3148") ? {} : (stryCov_9fa48("3148"), {
    entryId: v.string(),
    accountingDate: v.string(),
    recordedAt: v.number()
  })))
}));