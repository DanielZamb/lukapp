// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { v, ConvexError } from "convex/values";
import { internalMutation, internalQuery, query } from "./_generated/server";
import { internal } from "./_generated/api";
import { providerActor, providerError, recoveryScan, workSummary } from "./providerValidators";
import { enqueueProviderWork } from "./lib/providerWork";
import { ownerAdmission, requireOwner } from "./lib/owner";
import { providerFailure } from "./lib/clerk";
import { providerSessionDenied, verifiedSessionId } from "./lib/deviceAccess";
function admittedActor(actor: {
  tokenIdentifier: string;
  issuer: string;
  subject: string;
}) {
  if (stryMutAct_9fa48("2022")) {
    {}
  } else {
    stryCov_9fa48("2022");
    const error = ownerAdmission(actor);
    if (stryMutAct_9fa48("2024") ? false : stryMutAct_9fa48("2023") ? true : (stryCov_9fa48("2023", "2024"), error)) throw new ConvexError(stryMutAct_9fa48("2026") ? {} : (stryCov_9fa48("2026"), {
      code: error
    }));
    if (stryMutAct_9fa48("2029") ? actor.tokenIdentifier === `${actor.issuer}|${actor.subject}` : stryMutAct_9fa48("2028") ? false : stryMutAct_9fa48("2027") ? true : (stryCov_9fa48("2027", "2028", "2029"), actor.tokenIdentifier !== (stryMutAct_9fa48("2030") ? `` : (stryCov_9fa48("2030"), `${actor.issuer}|${actor.subject}`)))) providerFailure(stryMutAct_9fa48("2032") ? "" : (stryCov_9fa48("2032"), "provider_provenance_mismatch"));
  }
}
export const get = internalQuery(stryMutAct_9fa48("2033") ? {} : (stryCov_9fa48("2033"), {
  args: stryMutAct_9fa48("2034") ? {} : (stryCov_9fa48("2034"), {
    workId: v.id(stryMutAct_9fa48("2035") ? "" : (stryCov_9fa48("2035"), "clerkProviderWork"))
  }),
  handler: stryMutAct_9fa48("2036") ? () => undefined : (stryCov_9fa48("2036"), (ctx, {
    workId
  }) => ctx.db.get(workId))
}));
export const status = query(stryMutAct_9fa48("2037") ? {} : (stryCov_9fa48("2037"), {
  args: stryMutAct_9fa48("2038") ? {} : (stryCov_9fa48("2038"), {
    workId: v.id(stryMutAct_9fa48("2039") ? "" : (stryCov_9fa48("2039"), "clerkProviderWork"))
  }),
  returns: workSummary,
  handler: async (ctx, {
    workId
  }) => {
    if (stryMutAct_9fa48("2040")) {
      {}
    } else {
      stryCov_9fa48("2040");
      const owner = await requireOwner(ctx);
      if (stryMutAct_9fa48("2041")) {
        ;
      } else {
        stryCov_9fa48("2041");
        verifiedSessionId(owner.clerkIdentity);
      }
      const work = await ctx.db.get(workId);
      if (stryMutAct_9fa48("2044") ? !work && work.tokenIdentifier !== owner.identity.tokenIdentifier : stryMutAct_9fa48("2043") ? false : stryMutAct_9fa48("2042") ? true : (stryCov_9fa48("2042", "2043", "2044"), (stryMutAct_9fa48("2045") ? work : (stryCov_9fa48("2045"), !work)) || (stryMutAct_9fa48("2047") ? work.tokenIdentifier === owner.identity.tokenIdentifier : stryMutAct_9fa48("2046") ? false : (stryCov_9fa48("2046", "2047"), work.tokenIdentifier !== owner.identity.tokenIdentifier)))) providerFailure(stryMutAct_9fa48("2049") ? "" : (stryCov_9fa48("2049"), "provider_provenance_mismatch"));
      return stryMutAct_9fa48("2050") ? {} : (stryCov_9fa48("2050"), {
        workId,
        state: work.state
      });
    }
  }
}));
export const recordAttempt = internalMutation(stryMutAct_9fa48("2051") ? {} : (stryCov_9fa48("2051"), {
  args: stryMutAct_9fa48("2052") ? {} : (stryCov_9fa48("2052"), {
    workId: v.id(stryMutAct_9fa48("2053") ? "" : (stryCov_9fa48("2053"), "clerkProviderWork")),
    attempt: v.number(),
    error: v.optional(providerError)
  }),
  returns: v.null(),
  handler: async (ctx, {
    workId,
    attempt,
    error
  }) => {
    if (stryMutAct_9fa48("2054")) {
      {}
    } else {
      stryCov_9fa48("2054");
      const work = await ctx.db.get(workId);
      if (stryMutAct_9fa48("2057") ? (!work || work.state.kind === "succeeded") && work.attempts !== attempt : stryMutAct_9fa48("2056") ? false : stryMutAct_9fa48("2055") ? true : (stryCov_9fa48("2055", "2056", "2057"), (stryMutAct_9fa48("2059") ? !work && work.state.kind === "succeeded" : stryMutAct_9fa48("2058") ? false : (stryCov_9fa48("2058", "2059"), (stryMutAct_9fa48("2060") ? work : (stryCov_9fa48("2060"), !work)) || (stryMutAct_9fa48("2062") ? work.state.kind !== "succeeded" : stryMutAct_9fa48("2061") ? false : (stryCov_9fa48("2061", "2062"), work.state.kind === (stryMutAct_9fa48("2063") ? "" : (stryCov_9fa48("2063"), "succeeded")))))) || (stryMutAct_9fa48("2065") ? work.attempts === attempt : stryMutAct_9fa48("2064") ? false : (stryCov_9fa48("2064", "2065"), work.attempts !== attempt)))) return null;
      if (stryMutAct_9fa48("2068") ? false : stryMutAct_9fa48("2067") ? true : stryMutAct_9fa48("2066") ? error : (stryCov_9fa48("2066", "2067", "2068"), !error)) await ctx.db.patch(workId, stryMutAct_9fa48("2069") ? {} : (stryCov_9fa48("2069"), {
        state: stryMutAct_9fa48("2070") ? {} : (stryCov_9fa48("2070"), {
          kind: stryMutAct_9fa48("2071") ? "" : (stryCov_9fa48("2071"), "succeeded"),
          at: Date.now()
        })
      }));else {
        if (stryMutAct_9fa48("2072")) {
          {}
        } else {
          stryCov_9fa48("2072");
          const delay = stryMutAct_9fa48("2073") ? Math.max(60 * 60 * 1000, 1000 * 2 ** Math.min(work.attempts, 12)) : (stryCov_9fa48("2073"), Math.min(stryMutAct_9fa48("2074") ? 60 * 60 / 1000 : (stryCov_9fa48("2074"), (stryMutAct_9fa48("2075") ? 60 / 60 : (stryCov_9fa48("2075"), 60 * 60)) * 1000), stryMutAct_9fa48("2076") ? 1000 / 2 ** Math.min(work.attempts, 12) : (stryCov_9fa48("2076"), 1000 * 2 ** (stryMutAct_9fa48("2077") ? Math.max(work.attempts, 12) : (stryCov_9fa48("2077"), Math.min(work.attempts, 12))))));
          await ctx.db.patch(workId, stryMutAct_9fa48("2078") ? {} : (stryCov_9fa48("2078"), {
            state: stryMutAct_9fa48("2079") ? {} : (stryCov_9fa48("2079"), {
              kind: stryMutAct_9fa48("2080") ? "" : (stryCov_9fa48("2080"), "pending"),
              nextAttemptAt: stryMutAct_9fa48("2081") ? Date.now() - delay : (stryCov_9fa48("2081"), Date.now() + delay),
              error
            })
          }));
          await ctx.scheduler.runAfter(delay, internal.clerkProvider.process, stryMutAct_9fa48("2082") ? {} : (stryCov_9fa48("2082"), {
            workId
          }));
        }
      }
      return null;
    }
  }
}));
export const beginIntent = internalMutation(stryMutAct_9fa48("2083") ? {} : (stryCov_9fa48("2083"), {
  args: stryMutAct_9fa48("2084") ? {} : (stryCov_9fa48("2084"), {
    ...providerActor,
    initiatingSid: v.string()
  }),
  returns: v.object(stryMutAct_9fa48("2085") ? {} : (stryCov_9fa48("2085"), {
    intentId: v.id(stryMutAct_9fa48("2086") ? "" : (stryCov_9fa48("2086"), "clerkRecoveryIntents")),
    expiresAt: v.number()
  })),
  handler: async (ctx, actor) => {
    if (stryMutAct_9fa48("2087")) {
      {}
    } else {
      stryCov_9fa48("2087");
      if (stryMutAct_9fa48("2088")) {
        ;
      } else {
        stryCov_9fa48("2088");
        admittedActor(actor);
      }
      const intents = await ctx.db.query(stryMutAct_9fa48("2089") ? "" : (stryCov_9fa48("2089"), "clerkRecoveryIntents")).withIndex(stryMutAct_9fa48("2090") ? "" : (stryCov_9fa48("2090"), "by_identity"), stryMutAct_9fa48("2091") ? () => undefined : (stryCov_9fa48("2091"), q => q.eq(stryMutAct_9fa48("2092") ? "" : (stryCov_9fa48("2092"), "tokenIdentifier"), actor.tokenIdentifier))).collect();
      for (const intent of intents) {
        if (stryMutAct_9fa48("2093")) {
          {}
        } else {
          stryCov_9fa48("2093");
          if (stryMutAct_9fa48("2095") ? false : stryMutAct_9fa48("2094") ? true : (stryCov_9fa48("2094", "2095"), intent.workId)) {
            if (stryMutAct_9fa48("2096")) {
              {}
            } else {
              stryCov_9fa48("2096");
              const work = await ctx.db.get(intent.workId);
              if (stryMutAct_9fa48("2099") ? work?.state.kind !== "pending" : stryMutAct_9fa48("2098") ? false : stryMutAct_9fa48("2097") ? true : (stryCov_9fa48("2097", "2098", "2099"), (stryMutAct_9fa48("2100") ? work.state.kind : (stryCov_9fa48("2100"), work?.state.kind)) === (stryMutAct_9fa48("2101") ? "" : (stryCov_9fa48("2101"), "pending")))) providerFailure(stryMutAct_9fa48("2103") ? "" : (stryCov_9fa48("2103"), "recovery_conflict"));
            }
          } else if (stryMutAct_9fa48("2107") ? intent.expiresAt <= Date.now() : stryMutAct_9fa48("2106") ? intent.expiresAt >= Date.now() : stryMutAct_9fa48("2105") ? false : stryMutAct_9fa48("2104") ? true : (stryCov_9fa48("2104", "2105", "2106", "2107"), intent.expiresAt > Date.now())) {
            if (stryMutAct_9fa48("2108")) {
              {}
            } else {
              stryCov_9fa48("2108");
              return stryMutAct_9fa48("2109") ? {} : (stryCov_9fa48("2109"), {
                intentId: intent._id,
                expiresAt: intent.expiresAt
              });
            }
          }
        }
      }
      if (stryMutAct_9fa48("2111") ? false : stryMutAct_9fa48("2110") ? true : (stryCov_9fa48("2110", "2111"), await providerSessionDenied(ctx, actor.tokenIdentifier, actor.initiatingSid))) providerFailure(stryMutAct_9fa48("2113") ? "" : (stryCov_9fa48("2113"), "provider_session_terminal"));
      const identity = stryMutAct_9fa48("2114") ? {} : (stryCov_9fa48("2114"), {
        tokenIdentifier: actor.tokenIdentifier,
        issuer: actor.issuer,
        subject: actor.subject
      });
      await ctx.runMutation(internal.devices.applyClerkSessionRevocation, stryMutAct_9fa48("2115") ? {} : (stryCov_9fa48("2115"), {
        ...identity,
        sid: actor.initiatingSid
      }));
      await enqueueProviderWork(ctx, identity, stryMutAct_9fa48("2116") ? {} : (stryCov_9fa48("2116"), {
        kind: stryMutAct_9fa48("2117") ? "" : (stryCov_9fa48("2117"), "revoke"),
        sid: actor.initiatingSid
      }));
      const expiresAt = stryMutAct_9fa48("2118") ? Date.now() - 10 * 60 * 1000 : (stryCov_9fa48("2118"), Date.now() + (stryMutAct_9fa48("2119") ? 10 * 60 / 1000 : (stryCov_9fa48("2119"), (stryMutAct_9fa48("2120") ? 10 / 60 : (stryCov_9fa48("2120"), 10 * 60)) * 1000)));
      const intentId = await ctx.db.insert(stryMutAct_9fa48("2121") ? "" : (stryCov_9fa48("2121"), "clerkRecoveryIntents"), stryMutAct_9fa48("2122") ? {} : (stryCov_9fa48("2122"), {
        ...actor,
        createdAt: Date.now(),
        expiresAt
      }));
      return stryMutAct_9fa48("2123") ? {} : (stryCov_9fa48("2123"), {
        intentId,
        expiresAt
      });
    }
  }
}));
export const claimRecovery = internalMutation(stryMutAct_9fa48("2124") ? {} : (stryCov_9fa48("2124"), {
  args: stryMutAct_9fa48("2125") ? {} : (stryCov_9fa48("2125"), {
    ...providerActor,
    intentId: v.id(stryMutAct_9fa48("2126") ? "" : (stryCov_9fa48("2126"), "clerkRecoveryIntents")),
    sid: v.string(),
    createdAt: v.number()
  }),
  returns: workSummary,
  handler: async (ctx, args) => {
    if (stryMutAct_9fa48("2127")) {
      {}
    } else {
      stryCov_9fa48("2127");
      if (stryMutAct_9fa48("2128")) {
        ;
      } else {
        stryCov_9fa48("2128");
        admittedActor(args);
      }
      const intent = await ctx.db.get(args.intentId);
      if (stryMutAct_9fa48("2131") ? !intent && intent.tokenIdentifier !== args.tokenIdentifier : stryMutAct_9fa48("2130") ? false : stryMutAct_9fa48("2129") ? true : (stryCov_9fa48("2129", "2130", "2131"), (stryMutAct_9fa48("2132") ? intent : (stryCov_9fa48("2132"), !intent)) || (stryMutAct_9fa48("2134") ? intent.tokenIdentifier === args.tokenIdentifier : stryMutAct_9fa48("2133") ? false : (stryCov_9fa48("2133", "2134"), intent.tokenIdentifier !== args.tokenIdentifier)))) providerFailure(stryMutAct_9fa48("2136") ? "" : (stryCov_9fa48("2136"), "provider_provenance_mismatch"));
      if (stryMutAct_9fa48("2138") ? false : stryMutAct_9fa48("2137") ? true : (stryCov_9fa48("2137", "2138"), intent.workId)) {
        if (stryMutAct_9fa48("2139")) {
          {}
        } else {
          stryCov_9fa48("2139");
          const work = await ctx.db.get(intent.workId);
          if (stryMutAct_9fa48("2142") ? (!work || work.target.sid !== args.sid) && work.target.kind !== "recovery" : stryMutAct_9fa48("2141") ? false : stryMutAct_9fa48("2140") ? true : (stryCov_9fa48("2140", "2141", "2142"), (stryMutAct_9fa48("2144") ? !work && work.target.sid !== args.sid : stryMutAct_9fa48("2143") ? false : (stryCov_9fa48("2143", "2144"), (stryMutAct_9fa48("2145") ? work : (stryCov_9fa48("2145"), !work)) || (stryMutAct_9fa48("2147") ? work.target.sid === args.sid : stryMutAct_9fa48("2146") ? false : (stryCov_9fa48("2146", "2147"), work.target.sid !== args.sid)))) || (stryMutAct_9fa48("2149") ? work.target.kind === "recovery" : stryMutAct_9fa48("2148") ? false : (stryCov_9fa48("2148", "2149"), work.target.kind !== (stryMutAct_9fa48("2150") ? "" : (stryCov_9fa48("2150"), "recovery")))))) providerFailure(stryMutAct_9fa48("2152") ? "" : (stryCov_9fa48("2152"), "recovery_conflict"));
          return stryMutAct_9fa48("2153") ? {} : (stryCov_9fa48("2153"), {
            workId: work._id,
            state: work.state
          });
        }
      }
      if (stryMutAct_9fa48("2157") ? intent.expiresAt > Date.now() : stryMutAct_9fa48("2156") ? intent.expiresAt < Date.now() : stryMutAct_9fa48("2155") ? false : stryMutAct_9fa48("2154") ? true : (stryCov_9fa48("2154", "2155", "2156", "2157"), intent.expiresAt <= Date.now())) providerFailure(stryMutAct_9fa48("2159") ? "" : (stryCov_9fa48("2159"), "recovery_intent_expired"));
      if (stryMutAct_9fa48("2162") ? (args.sid === intent.initiatingSid || args.createdAt <= intent.createdAt) && args.createdAt > Date.now() : stryMutAct_9fa48("2161") ? false : stryMutAct_9fa48("2160") ? true : (stryCov_9fa48("2160", "2161", "2162"), (stryMutAct_9fa48("2164") ? args.sid === intent.initiatingSid && args.createdAt <= intent.createdAt : stryMutAct_9fa48("2163") ? false : (stryCov_9fa48("2163", "2164"), (stryMutAct_9fa48("2166") ? args.sid !== intent.initiatingSid : stryMutAct_9fa48("2165") ? false : (stryCov_9fa48("2165", "2166"), args.sid === intent.initiatingSid)) || (stryMutAct_9fa48("2169") ? args.createdAt > intent.createdAt : stryMutAct_9fa48("2168") ? args.createdAt < intent.createdAt : stryMutAct_9fa48("2167") ? false : (stryCov_9fa48("2167", "2168", "2169"), args.createdAt <= intent.createdAt)))) || (stryMutAct_9fa48("2172") ? args.createdAt <= Date.now() : stryMutAct_9fa48("2171") ? args.createdAt >= Date.now() : stryMutAct_9fa48("2170") ? false : (stryCov_9fa48("2170", "2171", "2172"), args.createdAt > Date.now())))) providerFailure(stryMutAct_9fa48("2174") ? "" : (stryCov_9fa48("2174"), "recovery_fresh_sign_in_required"));
      if (stryMutAct_9fa48("2176") ? false : stryMutAct_9fa48("2175") ? true : (stryCov_9fa48("2175", "2176"), await providerSessionDenied(ctx, args.tokenIdentifier, args.sid))) providerFailure(stryMutAct_9fa48("2178") ? "" : (stryCov_9fa48("2178"), "provider_session_terminal"));
      if (stryMutAct_9fa48("2180") ? false : stryMutAct_9fa48("2179") ? true : (stryCov_9fa48("2179", "2180"), await ctx.db.query(stryMutAct_9fa48("2181") ? "" : (stryCov_9fa48("2181"), "mobileDevices")).withIndex(stryMutAct_9fa48("2182") ? "" : (stryCov_9fa48("2182"), "by_identity_sid"), stryMutAct_9fa48("2183") ? () => undefined : (stryCov_9fa48("2183"), q => q.eq(stryMutAct_9fa48("2184") ? "" : (stryCov_9fa48("2184"), "tokenIdentifier"), args.tokenIdentifier).eq(stryMutAct_9fa48("2185") ? "" : (stryCov_9fa48("2185"), "sid"), args.sid))).unique())) providerFailure(stryMutAct_9fa48("2187") ? "" : (stryCov_9fa48("2187"), "recovery_conflict"));
      await ctx.runMutation(internal.devices.applyClerkRecovery, stryMutAct_9fa48("2188") ? {} : (stryCov_9fa48("2188"), {
        tokenIdentifier: args.tokenIdentifier,
        issuer: args.issuer,
        subject: args.subject,
        recoveredSid: args.sid,
        eventId: stryMutAct_9fa48("2189") ? `` : (stryCov_9fa48("2189"), `recovery:${intent._id}`)
      }));
      const work = await enqueueProviderWork(ctx, stryMutAct_9fa48("2190") ? {} : (stryCov_9fa48("2190"), {
        tokenIdentifier: args.tokenIdentifier,
        issuer: args.issuer,
        subject: args.subject
      }), stryMutAct_9fa48("2191") ? {} : (stryCov_9fa48("2191"), {
        kind: stryMutAct_9fa48("2192") ? "" : (stryCov_9fa48("2192"), "recovery"),
        sid: args.sid,
        createdAt: args.createdAt,
        scan: stryMutAct_9fa48("2193") ? {} : (stryCov_9fa48("2193"), {
          kind: stryMutAct_9fa48("2194") ? "" : (stryCov_9fa48("2194"), "start")
        }),
        intentId: intent._id
      }));
      await ctx.db.patch(intent._id, stryMutAct_9fa48("2195") ? {} : (stryCov_9fa48("2195"), {
        workId: work._id
      }));
      return stryMutAct_9fa48("2196") ? {} : (stryCov_9fa48("2196"), {
        workId: work._id,
        state: work.state
      });
    }
  }
}));
export const webhookDelivery = internalQuery(stryMutAct_9fa48("2197") ? {} : (stryCov_9fa48("2197"), {
  args: stryMutAct_9fa48("2198") ? {} : (stryCov_9fa48("2198"), {
    eventId: v.string()
  }),
  handler: stryMutAct_9fa48("2199") ? () => undefined : (stryCov_9fa48("2199"), (ctx, {
    eventId
  }) => ctx.db.query(stryMutAct_9fa48("2200") ? "" : (stryCov_9fa48("2200"), "clerkWebhookDeliveries")).withIndex(stryMutAct_9fa48("2201") ? "" : (stryCov_9fa48("2201"), "by_event"), stryMutAct_9fa48("2202") ? () => undefined : (stryCov_9fa48("2202"), q => q.eq(stryMutAct_9fa48("2203") ? "" : (stryCov_9fa48("2203"), "eventId"), eventId))).unique())
}));
export const recordWebhook = internalMutation(stryMutAct_9fa48("2204") ? {} : (stryCov_9fa48("2204"), {
  args: stryMutAct_9fa48("2205") ? {} : (stryCov_9fa48("2205"), {
    ...providerActor,
    eventId: v.string(),
    sid: v.string(),
    eventType: v.string(),
    timestamp: v.number()
  }),
  returns: v.null(),
  handler: async (ctx, args) => {
    if (stryMutAct_9fa48("2206")) {
      {}
    } else {
      stryCov_9fa48("2206");
      if (stryMutAct_9fa48("2207")) {
        ;
      } else {
        stryCov_9fa48("2207");
        admittedActor(args);
      }
      const prior = await ctx.db.query(stryMutAct_9fa48("2208") ? "" : (stryCov_9fa48("2208"), "clerkWebhookDeliveries")).withIndex(stryMutAct_9fa48("2209") ? "" : (stryCov_9fa48("2209"), "by_event"), stryMutAct_9fa48("2210") ? () => undefined : (stryCov_9fa48("2210"), q => q.eq(stryMutAct_9fa48("2211") ? "" : (stryCov_9fa48("2211"), "eventId"), args.eventId))).unique();
      if (stryMutAct_9fa48("2214") ? false : stryMutAct_9fa48("2213") ? true : stryMutAct_9fa48("2212") ? prior : (stryCov_9fa48("2212", "2213", "2214"), !prior)) await ctx.db.insert(stryMutAct_9fa48("2215") ? "" : (stryCov_9fa48("2215"), "clerkWebhookDeliveries"), args);else if (stryMutAct_9fa48("2218") ? (prior.sid !== args.sid || prior.tokenIdentifier !== args.tokenIdentifier) && prior.eventType !== args.eventType : stryMutAct_9fa48("2217") ? false : stryMutAct_9fa48("2216") ? true : (stryCov_9fa48("2216", "2217", "2218"), (stryMutAct_9fa48("2220") ? prior.sid !== args.sid && prior.tokenIdentifier !== args.tokenIdentifier : stryMutAct_9fa48("2219") ? false : (stryCov_9fa48("2219", "2220"), (stryMutAct_9fa48("2222") ? prior.sid === args.sid : stryMutAct_9fa48("2221") ? false : (stryCov_9fa48("2221", "2222"), prior.sid !== args.sid)) || (stryMutAct_9fa48("2224") ? prior.tokenIdentifier === args.tokenIdentifier : stryMutAct_9fa48("2223") ? false : (stryCov_9fa48("2223", "2224"), prior.tokenIdentifier !== args.tokenIdentifier)))) || (stryMutAct_9fa48("2226") ? prior.eventType === args.eventType : stryMutAct_9fa48("2225") ? false : (stryCov_9fa48("2225", "2226"), prior.eventType !== args.eventType)))) providerFailure(stryMutAct_9fa48("2228") ? "" : (stryCov_9fa48("2228"), "provider_provenance_mismatch"));
      return null;
    }
  }
}));
export const locallyDenied = internalQuery(stryMutAct_9fa48("2229") ? {} : (stryCov_9fa48("2229"), {
  args: stryMutAct_9fa48("2230") ? {} : (stryCov_9fa48("2230"), {
    tokenIdentifier: v.string(),
    sid: v.string()
  }),
  handler: stryMutAct_9fa48("2231") ? () => undefined : (stryCov_9fa48("2231"), (ctx, args) => providerSessionDenied(ctx, args.tokenIdentifier, args.sid))
}));
export const claimAttempt = internalMutation(stryMutAct_9fa48("2232") ? {} : (stryCov_9fa48("2232"), {
  args: stryMutAct_9fa48("2233") ? {} : (stryCov_9fa48("2233"), {
    workId: v.id(stryMutAct_9fa48("2234") ? "" : (stryCov_9fa48("2234"), "clerkProviderWork"))
  }),
  handler: async (ctx, {
    workId
  }) => {
    if (stryMutAct_9fa48("2235")) {
      {}
    } else {
      stryCov_9fa48("2235");
      const work = await ctx.db.get(workId);
      if (stryMutAct_9fa48("2238") ? (!work || work.state.kind === "succeeded") && work.state.nextAttemptAt > Date.now() : stryMutAct_9fa48("2237") ? false : stryMutAct_9fa48("2236") ? true : (stryCov_9fa48("2236", "2237", "2238"), (stryMutAct_9fa48("2240") ? !work && work.state.kind === "succeeded" : stryMutAct_9fa48("2239") ? false : (stryCov_9fa48("2239", "2240"), (stryMutAct_9fa48("2241") ? work : (stryCov_9fa48("2241"), !work)) || (stryMutAct_9fa48("2243") ? work.state.kind !== "succeeded" : stryMutAct_9fa48("2242") ? false : (stryCov_9fa48("2242", "2243"), work.state.kind === (stryMutAct_9fa48("2244") ? "" : (stryCov_9fa48("2244"), "succeeded")))))) || (stryMutAct_9fa48("2247") ? work.state.nextAttemptAt <= Date.now() : stryMutAct_9fa48("2246") ? work.state.nextAttemptAt >= Date.now() : stryMutAct_9fa48("2245") ? false : (stryCov_9fa48("2245", "2246", "2247"), work.state.nextAttemptAt > Date.now())))) return null;
      const state = {
        kind: "pending",
        nextAttemptAt: Date.now() + 60_000
      } as const;
      await ctx.db.patch(workId, stryMutAct_9fa48("2248") ? {} : (stryCov_9fa48("2248"), {
        state,
        attempts: stryMutAct_9fa48("2249") ? work.attempts - 1 : (stryCov_9fa48("2249"), work.attempts + 1)
      }));
      return stryMutAct_9fa48("2250") ? {} : (stryCov_9fa48("2250"), {
        ...work,
        state,
        attempts: stryMutAct_9fa48("2251") ? work.attempts - 1 : (stryCov_9fa48("2251"), work.attempts + 1)
      });
    }
  }
}));
export const checkpointRecovery = internalMutation(stryMutAct_9fa48("2252") ? {} : (stryCov_9fa48("2252"), {
  args: stryMutAct_9fa48("2253") ? {} : (stryCov_9fa48("2253"), {
    workId: v.id(stryMutAct_9fa48("2254") ? "" : (stryCov_9fa48("2254"), "clerkProviderWork")),
    attempt: v.number(),
    scan: recoveryScan
  }),
  returns: v.boolean(),
  handler: async (ctx, {
    workId,
    attempt,
    scan
  }) => {
    if (stryMutAct_9fa48("2255")) {
      {}
    } else {
      stryCov_9fa48("2255");
      const work = await ctx.db.get(workId);
      if (stryMutAct_9fa48("2258") ? (!work || work.state.kind === "succeeded" || work.target.kind !== "recovery") && work.attempts !== attempt : stryMutAct_9fa48("2257") ? false : stryMutAct_9fa48("2256") ? true : (stryCov_9fa48("2256", "2257", "2258"), (stryMutAct_9fa48("2260") ? (!work || work.state.kind === "succeeded") && work.target.kind !== "recovery" : stryMutAct_9fa48("2259") ? false : (stryCov_9fa48("2259", "2260"), (stryMutAct_9fa48("2262") ? !work && work.state.kind === "succeeded" : stryMutAct_9fa48("2261") ? false : (stryCov_9fa48("2261", "2262"), (stryMutAct_9fa48("2263") ? work : (stryCov_9fa48("2263"), !work)) || (stryMutAct_9fa48("2265") ? work.state.kind !== "succeeded" : stryMutAct_9fa48("2264") ? false : (stryCov_9fa48("2264", "2265"), work.state.kind === (stryMutAct_9fa48("2266") ? "" : (stryCov_9fa48("2266"), "succeeded")))))) || (stryMutAct_9fa48("2268") ? work.target.kind === "recovery" : stryMutAct_9fa48("2267") ? false : (stryCov_9fa48("2267", "2268"), work.target.kind !== (stryMutAct_9fa48("2269") ? "" : (stryCov_9fa48("2269"), "recovery")))))) || (stryMutAct_9fa48("2271") ? work.attempts === attempt : stryMutAct_9fa48("2270") ? false : (stryCov_9fa48("2270", "2271"), work.attempts !== attempt)))) return stryMutAct_9fa48("2272") ? true : (stryCov_9fa48("2272"), false);
      await ctx.db.patch(workId, stryMutAct_9fa48("2273") ? {} : (stryCov_9fa48("2273"), {
        target: stryMutAct_9fa48("2274") ? {} : (stryCov_9fa48("2274"), {
          ...work.target,
          scan
        })
      }));
      return stryMutAct_9fa48("2275") ? false : (stryCov_9fa48("2275"), true);
    }
  }
}));
export const continueRecovery = internalMutation(stryMutAct_9fa48("2276") ? {} : (stryCov_9fa48("2276"), {
  args: stryMutAct_9fa48("2277") ? {} : (stryCov_9fa48("2277"), {
    workId: v.id(stryMutAct_9fa48("2278") ? "" : (stryCov_9fa48("2278"), "clerkProviderWork")),
    attempt: v.number()
  }),
  returns: v.null(),
  handler: async (ctx, {
    workId,
    attempt
  }) => {
    if (stryMutAct_9fa48("2279")) {
      {}
    } else {
      stryCov_9fa48("2279");
      const work = await ctx.db.get(workId);
      if (stryMutAct_9fa48("2282") ? (!work || work.state.kind === "succeeded") && work.attempts !== attempt : stryMutAct_9fa48("2281") ? false : stryMutAct_9fa48("2280") ? true : (stryCov_9fa48("2280", "2281", "2282"), (stryMutAct_9fa48("2284") ? !work && work.state.kind === "succeeded" : stryMutAct_9fa48("2283") ? false : (stryCov_9fa48("2283", "2284"), (stryMutAct_9fa48("2285") ? work : (stryCov_9fa48("2285"), !work)) || (stryMutAct_9fa48("2287") ? work.state.kind !== "succeeded" : stryMutAct_9fa48("2286") ? false : (stryCov_9fa48("2286", "2287"), work.state.kind === (stryMutAct_9fa48("2288") ? "" : (stryCov_9fa48("2288"), "succeeded")))))) || (stryMutAct_9fa48("2290") ? work.attempts === attempt : stryMutAct_9fa48("2289") ? false : (stryCov_9fa48("2289", "2290"), work.attempts !== attempt)))) return null;
      await ctx.db.patch(workId, stryMutAct_9fa48("2291") ? {} : (stryCov_9fa48("2291"), {
        state: stryMutAct_9fa48("2292") ? {} : (stryCov_9fa48("2292"), {
          kind: stryMutAct_9fa48("2293") ? "" : (stryCov_9fa48("2293"), "pending"),
          nextAttemptAt: Date.now()
        })
      }));
      await ctx.scheduler.runAfter(0, internal.clerkProvider.process, stryMutAct_9fa48("2294") ? {} : (stryCov_9fa48("2294"), {
        workId
      }));
      return null;
    }
  }
}));
export const dispatch = internalMutation(stryMutAct_9fa48("2295") ? {} : (stryCov_9fa48("2295"), {
  args: stryMutAct_9fa48("2296") ? {} : (stryCov_9fa48("2296"), {
    workId: v.id(stryMutAct_9fa48("2297") ? "" : (stryCov_9fa48("2297"), "clerkProviderWork"))
  }),
  returns: v.null(),
  handler: async (ctx, {
    workId
  }) => {
    if (stryMutAct_9fa48("2298")) {
      {}
    } else {
      stryCov_9fa48("2298");
      const work = await ctx.db.get(workId);
      if (stryMutAct_9fa48("2301") ? !work && work.state.kind === "succeeded" : stryMutAct_9fa48("2300") ? false : stryMutAct_9fa48("2299") ? true : (stryCov_9fa48("2299", "2300", "2301"), (stryMutAct_9fa48("2302") ? work : (stryCov_9fa48("2302"), !work)) || (stryMutAct_9fa48("2304") ? work.state.kind !== "succeeded" : stryMutAct_9fa48("2303") ? false : (stryCov_9fa48("2303", "2304"), work.state.kind === (stryMutAct_9fa48("2305") ? "" : (stryCov_9fa48("2305"), "succeeded")))))) return null;
      if (stryMutAct_9fa48("2309") ? work.state.nextAttemptAt > Date.now() : stryMutAct_9fa48("2308") ? work.state.nextAttemptAt < Date.now() : stryMutAct_9fa48("2307") ? false : stryMutAct_9fa48("2306") ? true : (stryCov_9fa48("2306", "2307", "2308", "2309"), work.state.nextAttemptAt <= Date.now())) await ctx.scheduler.runAfter(0, internal.clerkProvider.process, stryMutAct_9fa48("2310") ? {} : (stryCov_9fa48("2310"), {
        workId
      }));
      await ctx.scheduler.runAfter(stryMutAct_9fa48("2311") ? Math.min(60_000, work.state.nextAttemptAt - Date.now()) : (stryCov_9fa48("2311"), Math.max(60_000, stryMutAct_9fa48("2312") ? work.state.nextAttemptAt + Date.now() : (stryCov_9fa48("2312"), work.state.nextAttemptAt - Date.now()))), internal.providerWork.dispatch, stryMutAct_9fa48("2313") ? {} : (stryCov_9fa48("2313"), {
        workId
      }));
      return null;
    }
  }
}));