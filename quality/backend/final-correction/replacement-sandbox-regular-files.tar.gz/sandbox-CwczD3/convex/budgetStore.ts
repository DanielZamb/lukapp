// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import type { MutationCtx, QueryCtx } from "./_generated/server";
import { BudgetError } from "../src/budget/errors";
import { budgetPolicy } from "../src/budget/types";
import type { BudgetReads, BudgetStore } from "../src/budget/types";
import { planningDocuments, requirePlanningReadHeadroom } from "./planningReadCapacity";
export function budgetReads({
  db,
  meta
}: Pick<QueryCtx, "db" | "meta">): BudgetReads {
  if (stryMutAct_9fa48("369")) {
    {}
  } else {
    stryCov_9fa48("369");
    return stryMutAct_9fa48("370") ? {} : (stryCov_9fa48("370"), {
      async getBudget(id) {
        if (stryMutAct_9fa48("371")) {
          {}
        } else {
          stryCov_9fa48("371");
          const normalized = db.normalizeId(stryMutAct_9fa48("372") ? "" : (stryCov_9fa48("372"), "budgets"), id);
          await requirePlanningReadHeadroom(meta);
          const doc = stryMutAct_9fa48("375") ? normalized || (await db.get(normalized)) : stryMutAct_9fa48("374") ? false : stryMutAct_9fa48("373") ? true : (stryCov_9fa48("373", "374", "375"), normalized && (await db.get(normalized)));
          await requirePlanningReadHeadroom(meta);
          if (stryMutAct_9fa48("378") ? false : stryMutAct_9fa48("377") ? true : stryMutAct_9fa48("376") ? doc : (stryCov_9fa48("376", "377", "378"), !doc)) return undefined;
          const {
            _id,
            _creationTime,
            ...fields
          } = doc;
          return stryMutAct_9fa48("379") ? {} : (stryCov_9fa48("379"), {
            id: _id,
            ...fields
          });
        }
      },
      async getVersion(id, revision) {
        if (stryMutAct_9fa48("380")) {
          {}
        } else {
          stryCov_9fa48("380");
          const normalized = db.normalizeId(stryMutAct_9fa48("381") ? "" : (stryCov_9fa48("381"), "budgets"), id);
          if (stryMutAct_9fa48("384") ? false : stryMutAct_9fa48("383") ? true : stryMutAct_9fa48("382") ? normalized : (stryCov_9fa48("382", "383", "384"), !normalized)) return undefined;
          await requirePlanningReadHeadroom(meta);
          const version = await db.query(stryMutAct_9fa48("385") ? "" : (stryCov_9fa48("385"), "budgetVersions")).withIndex(stryMutAct_9fa48("386") ? "" : (stryCov_9fa48("386"), "by_budget_revision"), stryMutAct_9fa48("387") ? () => undefined : (stryCov_9fa48("387"), q => q.eq(stryMutAct_9fa48("388") ? "" : (stryCov_9fa48("388"), "budgetId"), normalized).eq(stryMutAct_9fa48("389") ? "" : (stryCov_9fa48("389"), "revision"), revision))).unique();
          await requirePlanningReadHeadroom(meta);
          return stryMutAct_9fa48("390") ? version.budget : (stryCov_9fa48("390"), version?.budget);
        }
      },
      async listBudgets(workspaceId) {
        if (stryMutAct_9fa48("391")) {
          {}
        } else {
          stryCov_9fa48("391");
          const docs = await planningDocuments(meta, db.query(stryMutAct_9fa48("392") ? "" : (stryCov_9fa48("392"), "budgets")).withIndex(stryMutAct_9fa48("393") ? "" : (stryCov_9fa48("393"), "by_workspace"), stryMutAct_9fa48("394") ? () => undefined : (stryCov_9fa48("394"), q => q.eq(stryMutAct_9fa48("395") ? "" : (stryCov_9fa48("395"), "workspaceId"), workspaceId))), stryMutAct_9fa48("396") ? budgetPolicy.maxWorkspaceBudgets - 1 : (stryCov_9fa48("396"), budgetPolicy.maxWorkspaceBudgets + 1));
          if (stryMutAct_9fa48("400") ? docs.length <= budgetPolicy.maxWorkspaceBudgets : stryMutAct_9fa48("399") ? docs.length >= budgetPolicy.maxWorkspaceBudgets : stryMutAct_9fa48("398") ? false : stryMutAct_9fa48("397") ? true : (stryCov_9fa48("397", "398", "399", "400"), docs.length > budgetPolicy.maxWorkspaceBudgets)) throw new BudgetError(stryMutAct_9fa48("402") ? "" : (stryCov_9fa48("402"), "budget_workspace_limit"));
          return stryMutAct_9fa48("403") ? docs.map(({
            _id,
            _creationTime,
            ...fields
          }) => ({
            id: _id,
            ...fields
          })) : (stryCov_9fa48("403"), docs.map(stryMutAct_9fa48("404") ? () => undefined : (stryCov_9fa48("404"), ({
            _id,
            _creationTime,
            ...fields
          }) => stryMutAct_9fa48("405") ? {} : (stryCov_9fa48("405"), {
            id: _id,
            ...fields
          }))).sort(stryMutAct_9fa48("406") ? () => undefined : (stryCov_9fa48("406"), (a, b) => a.id.localeCompare(b.id))));
        }
      },
      async getReceipt(workspaceId, key) {
        if (stryMutAct_9fa48("407")) {
          {}
        } else {
          stryCov_9fa48("407");
          await requirePlanningReadHeadroom(meta);
          const doc = await db.query(stryMutAct_9fa48("408") ? "" : (stryCov_9fa48("408"), "budgetReceipts")).withIndex(stryMutAct_9fa48("409") ? "" : (stryCov_9fa48("409"), "by_workspace_key"), stryMutAct_9fa48("410") ? () => undefined : (stryCov_9fa48("410"), q => q.eq(stryMutAct_9fa48("411") ? "" : (stryCov_9fa48("411"), "workspaceId"), workspaceId).eq(stryMutAct_9fa48("412") ? "" : (stryCov_9fa48("412"), "idempotencyKey"), key))).unique();
          await requirePlanningReadHeadroom(meta);
          if (stryMutAct_9fa48("415") ? false : stryMutAct_9fa48("414") ? true : stryMutAct_9fa48("413") ? doc : (stryCov_9fa48("413", "414", "415"), !doc)) return undefined;
          const {
            _id,
            _creationTime,
            ...receipt
          } = doc;
          return receipt;
        }
      }
    });
  }
}
export function budgetStore(ctx: Pick<MutationCtx, "db" | "meta">): BudgetStore {
  if (stryMutAct_9fa48("416")) {
    {}
  } else {
    stryCov_9fa48("416");
    const {
      db
    } = ctx;
    function idFor(id: string) {
      if (stryMutAct_9fa48("417")) {
        {}
      } else {
        stryCov_9fa48("417");
        const normalized = db.normalizeId(stryMutAct_9fa48("418") ? "" : (stryCov_9fa48("418"), "budgets"), id);
        if (stryMutAct_9fa48("421") ? false : stryMutAct_9fa48("420") ? true : stryMutAct_9fa48("419") ? normalized : (stryCov_9fa48("419", "420", "421"), !normalized)) throw new BudgetError(stryMutAct_9fa48("423") ? "" : (stryCov_9fa48("423"), "budget_not_found"));
        return normalized;
      }
    }
    return stryMutAct_9fa48("424") ? {} : (stryCov_9fa48("424"), {
      ...budgetReads(ctx),
      async insertBudget(fields) {
        if (stryMutAct_9fa48("425")) {
          {}
        } else {
          stryCov_9fa48("425");
          const id = await db.insert(stryMutAct_9fa48("426") ? "" : (stryCov_9fa48("426"), "budgets"), fields);
          return stryMutAct_9fa48("427") ? {} : (stryCov_9fa48("427"), {
            id,
            ...fields
          });
        }
      },
      async saveBudget(budget) {
        if (stryMutAct_9fa48("428")) {
          {}
        } else {
          stryCov_9fa48("428");
          const {
            id,
            ...fields
          } = budget;
          await db.replace(idFor(id), fields);
        }
      },
      async appendVersion(budget) {
        if (stryMutAct_9fa48("429")) {
          {}
        } else {
          stryCov_9fa48("429");
          await db.insert(stryMutAct_9fa48("430") ? "" : (stryCov_9fa48("430"), "budgetVersions"), stryMutAct_9fa48("431") ? {} : (stryCov_9fa48("431"), {
            budgetId: idFor(budget.id),
            revision: budget.revision,
            budget
          }));
        }
      },
      async saveReceipt(receipt) {
        if (stryMutAct_9fa48("432")) {
          {}
        } else {
          stryCov_9fa48("432");
          await db.insert(stryMutAct_9fa48("433") ? "" : (stryCov_9fa48("433"), "budgetReceipts"), receipt);
        }
      }
    });
  }
}