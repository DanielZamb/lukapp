// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import type { GenericMutationCtx, GenericQueryCtx } from "convex/server";
import { AccountingError } from "../src/accounting/errors";
import type { AccountingPeriod, AccountingStore, LedgerAccount, StoredJournalEntry, StoredPeriodStatus, StoredProfile, StoredWorkspace } from "../src/accounting/types";
import type { DataModel, Doc, Id, TableNames } from "./_generated/dataModel";
type ReadDb = GenericQueryCtx<DataModel>["db"];
type WriteDb = GenericMutationCtx<DataModel>["db"];
type ReadMethods = Omit<AccountingStore, WriteMethod>;
type WriteMethod = "insertCategory" | "saveCategory" | "saveCategoryReceipt" | "saveHouseholdWorkspaceCreation" | "insertWorkspace" | "insertLedgerAccount" | "insertProfile" | "clearProfileOpening" | "saveOpeningPosition" | "insertJournalEntry" | "insertAccountingPeriod" | "setAccountingPeriodStatus" | "insertPeriodControlDecision";

/** Caller-supplied ids arrive as strings; anything malformed or from another table reads as absent. */
function idFor<Table extends TableNames>(db: ReadDb, table: Table, id: string): Id<Table> | null {
  if (stryMutAct_9fa48("2708")) {
    {}
  } else {
    stryCov_9fa48("2708");
    return db.normalizeId(table, id);
  }
}
function requiredId<Table extends TableNames>(db: ReadDb, table: Table, id: string): Id<Table> {
  if (stryMutAct_9fa48("2709")) {
    {}
  } else {
    stryCov_9fa48("2709");
    const normalized = idFor(db, table, id);
    if (stryMutAct_9fa48("2712") ? false : stryMutAct_9fa48("2711") ? true : stryMutAct_9fa48("2710") ? normalized : (stryCov_9fa48("2710", "2711", "2712"), !normalized)) throw new Error(stryMutAct_9fa48("2714") ? `` : (stryCov_9fa48("2714"), `Store received an invalid ${table} id`));
    return normalized;
  }
}
function findAccountingPeriod(db: ReadDb, workspaceId: Id<"workspaces">, period: {
  year: number;
  month: number;
}) {
  if (stryMutAct_9fa48("2715")) {
    {}
  } else {
    stryCov_9fa48("2715");
    return db.query(stryMutAct_9fa48("2716") ? "" : (stryCov_9fa48("2716"), "accountingPeriods")).withIndex(stryMutAct_9fa48("2717") ? "" : (stryCov_9fa48("2717"), "by_workspace_year_month"), stryMutAct_9fa48("2718") ? () => undefined : (stryCov_9fa48("2718"), q => q.eq(stryMutAct_9fa48("2719") ? "" : (stryCov_9fa48("2719"), "workspaceId"), workspaceId).eq(stryMutAct_9fa48("2720") ? "" : (stryCov_9fa48("2720"), "year"), period.year).eq(stryMutAct_9fa48("2721") ? "" : (stryCov_9fa48("2721"), "month"), period.month))).unique();
  }
}
function toAccountingPeriod(doc: {
  year: number;
  month: number;
  status: StoredPeriodStatus;
}): AccountingPeriod {
  if (stryMutAct_9fa48("2722")) {
    {}
  } else {
    stryCov_9fa48("2722");
    return stryMutAct_9fa48("2723") ? {} : (stryCov_9fa48("2723"), {
      year: doc.year,
      month: doc.month,
      status: doc.status
    });
  }
}
function toLedgerAccount(doc: Doc<"ledgerAccounts">): LedgerAccount {
  if (stryMutAct_9fa48("2724")) {
    {}
  } else {
    stryCov_9fa48("2724");
    return stryMutAct_9fa48("2725") ? {} : (stryCov_9fa48("2725"), {
      id: doc._id,
      workspaceId: doc.workspaceId,
      code: doc.code,
      name: doc.name,
      nature: doc.nature,
      normalSide: doc.normalSide,
      role: doc.role
    });
  }
}
function toProfile(doc: Doc<"financialAccountProfiles">): StoredProfile {
  if (stryMutAct_9fa48("2726")) {
    {}
  } else {
    stryCov_9fa48("2726");
    return stryMutAct_9fa48("2727") ? {} : (stryCov_9fa48("2727"), {
      id: doc._id,
      workspaceId: doc.workspaceId,
      name: doc.name,
      productKind: doc.productKind,
      classificationPolicy: doc.classificationPolicy,
      ...(doc.classificationAnswers ? stryMutAct_9fa48("2728") ? {} : (stryCov_9fa48("2728"), {
        classificationAnswers: doc.classificationAnswers
      }) : {}),
      postingAccountId: doc.postingAccountId,
      ...((stryMutAct_9fa48("2731") ? doc.setupIdempotencyKey === undefined : stryMutAct_9fa48("2730") ? false : stryMutAct_9fa48("2729") ? true : (stryCov_9fa48("2729", "2730", "2731"), doc.setupIdempotencyKey !== undefined)) ? stryMutAct_9fa48("2732") ? {} : (stryCov_9fa48("2732"), {
        setupIdempotencyKey: doc.setupIdempotencyKey
      }) : {}),
      ...(doc.opening ? stryMutAct_9fa48("2733") ? {} : (stryCov_9fa48("2733"), {
        opening: doc.opening
      }) : {})
    });
  }
}
function toEntry(doc: Doc<"journalEntries">, lines: Doc<"journalLines">[]): StoredJournalEntry {
  if (stryMutAct_9fa48("2734")) {
    {}
  } else {
    stryCov_9fa48("2734");
    const entry: StoredJournalEntry = stryMutAct_9fa48("2735") ? {} : (stryCov_9fa48("2735"), {
      id: doc._id,
      workspaceId: doc.workspaceId,
      accountingDate: doc.accountingDate,
      period: stryMutAct_9fa48("2736") ? {} : (stryCov_9fa48("2736"), {
        year: doc.periodYear,
        month: doc.periodMonth
      }),
      description: doc.description,
      idempotencyKey: doc.idempotencyKey,
      policy: doc.policy,
      ...(doc.cashCategoryInput ? stryMutAct_9fa48("2737") ? {} : (stryCov_9fa48("2737"), {
        cashCategoryInput: doc.cashCategoryInput
      }) : {}),
      ...(doc.sourceExpenseEffects ? stryMutAct_9fa48("2738") ? {} : (stryCov_9fa48("2738"), {
        sourceExpenseEffects: doc.sourceExpenseEffects
      }) : {}),
      postedBy: doc.postedBy,
      postedAt: doc.postedAt,
      lines: stryMutAct_9fa48("2740") ? lines.sort((a, b) => a.lineNumber - b.lineNumber).map(line => ({
        ...(line.category ? {
          category: line.category
        } : {}),
        ...(line.categoryCorrection ? {
          categoryCorrection: line.categoryCorrection
        } : {}),
        ledgerAccountId: line.ledgerAccountId,
        debitMinorUnits: line.debitMinorUnits,
        creditMinorUnits: line.creditMinorUnits
      })) : stryMutAct_9fa48("2739") ? lines.filter(line => line.journalEntryId === doc._id).map(line => ({
        ...(line.category ? {
          category: line.category
        } : {}),
        ...(line.categoryCorrection ? {
          categoryCorrection: line.categoryCorrection
        } : {}),
        ledgerAccountId: line.ledgerAccountId,
        debitMinorUnits: line.debitMinorUnits,
        creditMinorUnits: line.creditMinorUnits
      })) : (stryCov_9fa48("2739", "2740"), lines.filter(stryMutAct_9fa48("2741") ? () => undefined : (stryCov_9fa48("2741"), line => stryMutAct_9fa48("2744") ? line.journalEntryId !== doc._id : stryMutAct_9fa48("2743") ? false : stryMutAct_9fa48("2742") ? true : (stryCov_9fa48("2742", "2743", "2744"), line.journalEntryId === doc._id))).sort(stryMutAct_9fa48("2745") ? () => undefined : (stryCov_9fa48("2745"), (a, b) => stryMutAct_9fa48("2746") ? a.lineNumber + b.lineNumber : (stryCov_9fa48("2746"), a.lineNumber - b.lineNumber))).map(stryMutAct_9fa48("2747") ? () => undefined : (stryCov_9fa48("2747"), line => stryMutAct_9fa48("2748") ? {} : (stryCov_9fa48("2748"), {
        ...(line.category ? stryMutAct_9fa48("2749") ? {} : (stryCov_9fa48("2749"), {
          category: line.category
        }) : {}),
        ...(line.categoryCorrection ? stryMutAct_9fa48("2750") ? {} : (stryCov_9fa48("2750"), {
          categoryCorrection: line.categoryCorrection
        }) : {}),
        ledgerAccountId: line.ledgerAccountId,
        debitMinorUnits: line.debitMinorUnits,
        creditMinorUnits: line.creditMinorUnits
      }))))
    });
    if (stryMutAct_9fa48("2752") ? false : stryMutAct_9fa48("2751") ? true : (stryCov_9fa48("2751", "2752"), doc.financialAccountProfileId)) {
      if (stryMutAct_9fa48("2753")) {
        {}
      } else {
        stryCov_9fa48("2753");
        entry.financialAccountProfileId = doc.financialAccountProfileId;
      }
    }
    if (stryMutAct_9fa48("2755") ? false : stryMutAct_9fa48("2754") ? true : (stryCov_9fa48("2754", "2755"), doc.reversesEntryId)) {
      if (stryMutAct_9fa48("2756")) {
        {}
      } else {
        stryCov_9fa48("2756");
        entry.reversesEntryId = doc.reversesEntryId;
      }
    }
    return entry;
  }
}
function readStore(db: ReadDb): ReadMethods {
  if (stryMutAct_9fa48("2757")) {
    {}
  } else {
    stryCov_9fa48("2757");
    async function withLines(doc: Doc<"journalEntries"> | null) {
      if (stryMutAct_9fa48("2758")) {
        {}
      } else {
        stryCov_9fa48("2758");
        if (stryMutAct_9fa48("2761") ? false : stryMutAct_9fa48("2760") ? true : stryMutAct_9fa48("2759") ? doc : (stryCov_9fa48("2759", "2760", "2761"), !doc)) {
          if (stryMutAct_9fa48("2762")) {
            {}
          } else {
            stryCov_9fa48("2762");
            return undefined;
          }
        }
        const lines = await db.query(stryMutAct_9fa48("2763") ? "" : (stryCov_9fa48("2763"), "journalLines")).withIndex(stryMutAct_9fa48("2764") ? "" : (stryCov_9fa48("2764"), "by_entry"), stryMutAct_9fa48("2765") ? () => undefined : (stryCov_9fa48("2765"), q => q.eq(stryMutAct_9fa48("2766") ? "" : (stryCov_9fa48("2766"), "journalEntryId"), doc._id))).collect();
        return toEntry(doc, lines);
      }
    }
    async function entriesInRange(workspaceId: string, policy: StoredJournalEntry["policy"], from: string, through: string) {
      if (stryMutAct_9fa48("2767")) {
        {}
      } else {
        stryCov_9fa48("2767");
        const docs = await db.query(stryMutAct_9fa48("2768") ? "" : (stryCov_9fa48("2768"), "journalEntries")).withIndex(stryMutAct_9fa48("2769") ? "" : (stryCov_9fa48("2769"), "by_workspace_policy_date"), stryMutAct_9fa48("2770") ? () => undefined : (stryCov_9fa48("2770"), q => q.eq(stryMutAct_9fa48("2771") ? "" : (stryCov_9fa48("2771"), "workspaceId"), requiredId(db, stryMutAct_9fa48("2772") ? "" : (stryCov_9fa48("2772"), "workspaces"), workspaceId)).eq(stryMutAct_9fa48("2773") ? "" : (stryCov_9fa48("2773"), "policy"), policy).gte(stryMutAct_9fa48("2774") ? "" : (stryCov_9fa48("2774"), "accountingDate"), from).lte(stryMutAct_9fa48("2775") ? "" : (stryCov_9fa48("2775"), "accountingDate"), through))).collect();
        const entries = await Promise.all(docs.map(withLines));
        return stryMutAct_9fa48("2776") ? entries : (stryCov_9fa48("2776"), entries.filter(stryMutAct_9fa48("2777") ? () => undefined : (stryCov_9fa48("2777"), (entry): entry is StoredJournalEntry => stryMutAct_9fa48("2780") ? entry === undefined : stryMutAct_9fa48("2779") ? false : stryMutAct_9fa48("2778") ? true : (stryCov_9fa48("2778", "2779", "2780"), entry !== undefined))));
      }
    }
    return stryMutAct_9fa48("2781") ? {} : (stryCov_9fa48("2781"), {
      async getCategory(categoryId) {
        if (stryMutAct_9fa48("2782")) {
          {}
        } else {
          stryCov_9fa48("2782");
          const id = idFor(db, stryMutAct_9fa48("2783") ? "" : (stryCov_9fa48("2783"), "userCategories"), categoryId);
          const doc = stryMutAct_9fa48("2786") ? id || (await db.get(id)) : stryMutAct_9fa48("2785") ? false : stryMutAct_9fa48("2784") ? true : (stryCov_9fa48("2784", "2785", "2786"), id && (await db.get(id)));
          if (stryMutAct_9fa48("2789") ? false : stryMutAct_9fa48("2788") ? true : stryMutAct_9fa48("2787") ? doc : (stryCov_9fa48("2787", "2788", "2789"), !doc)) return undefined;
          const {
            _id,
            _creationTime,
            ...category
          } = doc;
          return stryMutAct_9fa48("2790") ? {} : (stryCov_9fa48("2790"), {
            id: _id,
            ...category
          });
        }
      },
      async listCategories(workspaceId) {
        if (stryMutAct_9fa48("2791")) {
          {}
        } else {
          stryCov_9fa48("2791");
          const docs = await db.query(stryMutAct_9fa48("2792") ? "" : (stryCov_9fa48("2792"), "userCategories")).withIndex(stryMutAct_9fa48("2793") ? "" : (stryCov_9fa48("2793"), "by_workspace"), stryMutAct_9fa48("2794") ? () => undefined : (stryCov_9fa48("2794"), q => q.eq(stryMutAct_9fa48("2795") ? "" : (stryCov_9fa48("2795"), "workspaceId"), workspaceId))).collect();
          return docs.map(stryMutAct_9fa48("2796") ? () => undefined : (stryCov_9fa48("2796"), ({
            _id,
            _creationTime,
            ...category
          }) => stryMutAct_9fa48("2797") ? {} : (stryCov_9fa48("2797"), {
            id: _id,
            ...category
          })));
        }
      },
      async getCategoryReceipt(workspaceId, key) {
        if (stryMutAct_9fa48("2798")) {
          {}
        } else {
          stryCov_9fa48("2798");
          const doc = await db.query(stryMutAct_9fa48("2799") ? "" : (stryCov_9fa48("2799"), "categoryReceipts")).withIndex(stryMutAct_9fa48("2800") ? "" : (stryCov_9fa48("2800"), "by_workspace_key"), stryMutAct_9fa48("2801") ? () => undefined : (stryCov_9fa48("2801"), q => q.eq(stryMutAct_9fa48("2802") ? "" : (stryCov_9fa48("2802"), "workspaceId"), workspaceId).eq(stryMutAct_9fa48("2803") ? "" : (stryCov_9fa48("2803"), "idempotencyKey"), key))).unique();
          if (stryMutAct_9fa48("2806") ? false : stryMutAct_9fa48("2805") ? true : stryMutAct_9fa48("2804") ? doc : (stryCov_9fa48("2804", "2805", "2806"), !doc)) return undefined;
          const {
            _id,
            _creationTime,
            ...receipt
          } = doc;
          return receipt;
        }
      },
      async getWorkspace(workspaceId) {
        if (stryMutAct_9fa48("2807")) {
          {}
        } else {
          stryCov_9fa48("2807");
          const id = idFor(db, stryMutAct_9fa48("2808") ? "" : (stryCov_9fa48("2808"), "workspaces"), workspaceId);
          const doc = stryMutAct_9fa48("2811") ? id || (await db.get(id)) : stryMutAct_9fa48("2810") ? false : stryMutAct_9fa48("2809") ? true : (stryCov_9fa48("2809", "2810", "2811"), id && (await db.get(id)));
          if (stryMutAct_9fa48("2814") ? false : stryMutAct_9fa48("2813") ? true : stryMutAct_9fa48("2812") ? doc : (stryCov_9fa48("2812", "2813", "2814"), !doc)) {
            if (stryMutAct_9fa48("2815")) {
              {}
            } else {
              stryCov_9fa48("2815");
              return undefined;
            }
          }
          const stored: StoredWorkspace = stryMutAct_9fa48("2816") ? {} : (stryCov_9fa48("2816"), {
            id: doc._id,
            kind: doc.kind,
            functionalCurrency: doc.functionalCurrency,
            chartOfAccountsTemplate: doc.chartOfAccountsTemplate
          });
          return stored;
        }
      },
      async listOwnedWorkspaceIds(userId) {
        if (stryMutAct_9fa48("2817")) {
          {}
        } else {
          stryCov_9fa48("2817");
          const memberships = await db.query(stryMutAct_9fa48("2818") ? "" : (stryCov_9fa48("2818"), "workspaceMemberships")).withIndex(stryMutAct_9fa48("2819") ? "" : (stryCov_9fa48("2819"), "by_user_role"), stryMutAct_9fa48("2820") ? () => undefined : (stryCov_9fa48("2820"), q => q.eq(stryMutAct_9fa48("2821") ? "" : (stryCov_9fa48("2821"), "userId"), userId).eq(stryMutAct_9fa48("2822") ? "" : (stryCov_9fa48("2822"), "role"), stryMutAct_9fa48("2823") ? "" : (stryCov_9fa48("2823"), "Owner")))).collect();
          const ids: string[] = stryMutAct_9fa48("2824") ? ["Stryker was here"] : (stryCov_9fa48("2824"), []);
          for (const membership of memberships) {
            if (stryMutAct_9fa48("2825")) {
              {}
            } else {
              stryCov_9fa48("2825");
              if (stryMutAct_9fa48("2827") ? false : stryMutAct_9fa48("2826") ? true : (stryCov_9fa48("2826", "2827"), await db.get(membership.workspaceId))) if (stryMutAct_9fa48("2828")) {
                ;
              } else {
                stryCov_9fa48("2828");
                ids.push(membership.workspaceId);
              }
            }
          }
          return ids;
        }
      },
      async findHouseholdWorkspaceByKey(userId, key) {
        if (stryMutAct_9fa48("2829")) {
          {}
        } else {
          stryCov_9fa48("2829");
          const receipt = await db.query(stryMutAct_9fa48("2830") ? "" : (stryCov_9fa48("2830"), "householdWorkspaceCreations")).withIndex(stryMutAct_9fa48("2831") ? "" : (stryCov_9fa48("2831"), "by_owner_key"), stryMutAct_9fa48("2832") ? () => undefined : (stryCov_9fa48("2832"), q => q.eq(stryMutAct_9fa48("2833") ? "" : (stryCov_9fa48("2833"), "ownerUserId"), userId).eq(stryMutAct_9fa48("2834") ? "" : (stryCov_9fa48("2834"), "idempotencyKey"), key))).unique();
          return stryMutAct_9fa48("2835") ? receipt.workspaceId : (stryCov_9fa48("2835"), receipt?.workspaceId);
        }
      },
      async membershipRole(workspaceId, userId) {
        if (stryMutAct_9fa48("2836")) {
          {}
        } else {
          stryCov_9fa48("2836");
          const id = idFor(db, stryMutAct_9fa48("2837") ? "" : (stryCov_9fa48("2837"), "workspaces"), workspaceId);
          if (stryMutAct_9fa48("2840") ? false : stryMutAct_9fa48("2839") ? true : stryMutAct_9fa48("2838") ? id : (stryCov_9fa48("2838", "2839", "2840"), !id)) {
            if (stryMutAct_9fa48("2841")) {
              {}
            } else {
              stryCov_9fa48("2841");
              return undefined;
            }
          }
          const membership = await db.query(stryMutAct_9fa48("2842") ? "" : (stryCov_9fa48("2842"), "workspaceMemberships")).withIndex(stryMutAct_9fa48("2843") ? "" : (stryCov_9fa48("2843"), "by_workspace_user"), stryMutAct_9fa48("2844") ? () => undefined : (stryCov_9fa48("2844"), q => q.eq(stryMutAct_9fa48("2845") ? "" : (stryCov_9fa48("2845"), "workspaceId"), id).eq(stryMutAct_9fa48("2846") ? "" : (stryCov_9fa48("2846"), "userId"), userId))).unique();
          return stryMutAct_9fa48("2847") ? membership.role : (stryCov_9fa48("2847"), membership?.role);
        }
      },
      async getLedgerAccount(accountId) {
        if (stryMutAct_9fa48("2848")) {
          {}
        } else {
          stryCov_9fa48("2848");
          const id = idFor(db, stryMutAct_9fa48("2849") ? "" : (stryCov_9fa48("2849"), "ledgerAccounts"), accountId);
          const doc = stryMutAct_9fa48("2852") ? id || (await db.get(id)) : stryMutAct_9fa48("2851") ? false : stryMutAct_9fa48("2850") ? true : (stryCov_9fa48("2850", "2851", "2852"), id && (await db.get(id)));
          return doc ? toLedgerAccount(doc) : undefined;
        }
      },
      async findLedgerAccountByCode(workspaceId, code) {
        if (stryMutAct_9fa48("2853")) {
          {}
        } else {
          stryCov_9fa48("2853");
          const doc = await db.query(stryMutAct_9fa48("2854") ? "" : (stryCov_9fa48("2854"), "ledgerAccounts")).withIndex(stryMutAct_9fa48("2855") ? "" : (stryCov_9fa48("2855"), "by_workspace_code"), stryMutAct_9fa48("2856") ? () => undefined : (stryCov_9fa48("2856"), q => q.eq(stryMutAct_9fa48("2857") ? "" : (stryCov_9fa48("2857"), "workspaceId"), requiredId(db, stryMutAct_9fa48("2858") ? "" : (stryCov_9fa48("2858"), "workspaces"), workspaceId)).eq(stryMutAct_9fa48("2859") ? "" : (stryCov_9fa48("2859"), "code"), code))).unique();
          return doc ? toLedgerAccount(doc) : undefined;
        }
      },
      async listLedgerAccounts(workspaceId) {
        if (stryMutAct_9fa48("2860")) {
          {}
        } else {
          stryCov_9fa48("2860");
          const docs = await db.query(stryMutAct_9fa48("2861") ? "" : (stryCov_9fa48("2861"), "ledgerAccounts")).withIndex(stryMutAct_9fa48("2862") ? "" : (stryCov_9fa48("2862"), "by_workspace"), stryMutAct_9fa48("2863") ? () => undefined : (stryCov_9fa48("2863"), q => q.eq(stryMutAct_9fa48("2864") ? "" : (stryCov_9fa48("2864"), "workspaceId"), requiredId(db, stryMutAct_9fa48("2865") ? "" : (stryCov_9fa48("2865"), "workspaces"), workspaceId)))).collect();
          return docs.map(toLedgerAccount);
        }
      },
      async getProfile(profileId) {
        if (stryMutAct_9fa48("2866")) {
          {}
        } else {
          stryCov_9fa48("2866");
          const id = idFor(db, stryMutAct_9fa48("2867") ? "" : (stryCov_9fa48("2867"), "financialAccountProfiles"), profileId);
          const doc = stryMutAct_9fa48("2870") ? id || (await db.get(id)) : stryMutAct_9fa48("2869") ? false : stryMutAct_9fa48("2868") ? true : (stryCov_9fa48("2868", "2869", "2870"), id && (await db.get(id)));
          return doc ? toProfile(doc) : undefined;
        }
      },
      async findProfileBySetupKey(workspaceId, key) {
        if (stryMutAct_9fa48("2871")) {
          {}
        } else {
          stryCov_9fa48("2871");
          const doc = await db.query(stryMutAct_9fa48("2872") ? "" : (stryCov_9fa48("2872"), "financialAccountProfiles")).withIndex(stryMutAct_9fa48("2873") ? "" : (stryCov_9fa48("2873"), "by_workspace_setup"), stryMutAct_9fa48("2874") ? () => undefined : (stryCov_9fa48("2874"), q => q.eq(stryMutAct_9fa48("2875") ? "" : (stryCov_9fa48("2875"), "workspaceId"), requiredId(db, stryMutAct_9fa48("2876") ? "" : (stryCov_9fa48("2876"), "workspaces"), workspaceId)).eq(stryMutAct_9fa48("2877") ? "" : (stryCov_9fa48("2877"), "setupIdempotencyKey"), key))).unique();
          return doc ? toProfile(doc) : undefined;
        }
      },
      async findOpeningPositionByKey(workspaceId, key) {
        if (stryMutAct_9fa48("2878")) {
          {}
        } else {
          stryCov_9fa48("2878");
          const doc = await db.query(stryMutAct_9fa48("2879") ? "" : (stryCov_9fa48("2879"), "openingPositions")).withIndex(stryMutAct_9fa48("2880") ? "" : (stryCov_9fa48("2880"), "by_workspace_idempotency"), stryMutAct_9fa48("2881") ? () => undefined : (stryCov_9fa48("2881"), q => q.eq(stryMutAct_9fa48("2882") ? "" : (stryCov_9fa48("2882"), "workspaceId"), requiredId(db, stryMutAct_9fa48("2883") ? "" : (stryCov_9fa48("2883"), "workspaces"), workspaceId)).eq(stryMutAct_9fa48("2884") ? "" : (stryCov_9fa48("2884"), "idempotencyKey"), key))).unique();
          return doc ? stryMutAct_9fa48("2885") ? {} : (stryCov_9fa48("2885"), {
            workspaceId: doc.workspaceId,
            financialAccountProfileId: doc.financialAccountProfileId,
            description: doc.description,
            opening: doc.opening,
            ...((stryMutAct_9fa48("2888") ? doc.replacesOpeningKey === undefined : stryMutAct_9fa48("2887") ? false : stryMutAct_9fa48("2886") ? true : (stryCov_9fa48("2886", "2887", "2888"), doc.replacesOpeningKey !== undefined)) ? stryMutAct_9fa48("2889") ? {} : (stryCov_9fa48("2889"), {
              replacesOpeningKey: doc.replacesOpeningKey
            }) : {})
          }) : undefined;
        }
      },
      async listProfiles(workspaceId) {
        if (stryMutAct_9fa48("2890")) {
          {}
        } else {
          stryCov_9fa48("2890");
          const docs = await db.query(stryMutAct_9fa48("2891") ? "" : (stryCov_9fa48("2891"), "financialAccountProfiles")).withIndex(stryMutAct_9fa48("2892") ? "" : (stryCov_9fa48("2892"), "by_workspace"), stryMutAct_9fa48("2893") ? () => undefined : (stryCov_9fa48("2893"), q => q.eq(stryMutAct_9fa48("2894") ? "" : (stryCov_9fa48("2894"), "workspaceId"), requiredId(db, stryMutAct_9fa48("2895") ? "" : (stryCov_9fa48("2895"), "workspaces"), workspaceId)))).collect();
          return docs.map(toProfile);
        }
      },
      async getJournalEntry(entryId) {
        if (stryMutAct_9fa48("2896")) {
          {}
        } else {
          stryCov_9fa48("2896");
          const id = idFor(db, stryMutAct_9fa48("2897") ? "" : (stryCov_9fa48("2897"), "journalEntries"), entryId);
          return withLines(stryMutAct_9fa48("2900") ? id || (await db.get(id)) : stryMutAct_9fa48("2899") ? false : stryMutAct_9fa48("2898") ? true : (stryCov_9fa48("2898", "2899", "2900"), id && (await db.get(id))));
        }
      },
      async findJournalEntryByIdempotencyKey(workspaceId, idempotencyKey) {
        if (stryMutAct_9fa48("2901")) {
          {}
        } else {
          stryCov_9fa48("2901");
          return withLines(await db.query(stryMutAct_9fa48("2902") ? "" : (stryCov_9fa48("2902"), "journalEntries")).withIndex(stryMutAct_9fa48("2903") ? "" : (stryCov_9fa48("2903"), "by_workspace_idempotency"), stryMutAct_9fa48("2904") ? () => undefined : (stryCov_9fa48("2904"), q => q.eq(stryMutAct_9fa48("2905") ? "" : (stryCov_9fa48("2905"), "workspaceId"), requiredId(db, stryMutAct_9fa48("2906") ? "" : (stryCov_9fa48("2906"), "workspaces"), workspaceId)).eq(stryMutAct_9fa48("2907") ? "" : (stryCov_9fa48("2907"), "idempotencyKey"), idempotencyKey))).unique());
        }
      },
      async findReversalOf(entryId) {
        if (stryMutAct_9fa48("2908")) {
          {}
        } else {
          stryCov_9fa48("2908");
          return withLines(await db.query(stryMutAct_9fa48("2909") ? "" : (stryCov_9fa48("2909"), "journalEntries")).withIndex(stryMutAct_9fa48("2910") ? "" : (stryCov_9fa48("2910"), "by_reverses"), stryMutAct_9fa48("2911") ? () => undefined : (stryCov_9fa48("2911"), q => q.eq(stryMutAct_9fa48("2912") ? "" : (stryCov_9fa48("2912"), "reversesEntryId"), requiredId(db, stryMutAct_9fa48("2913") ? "" : (stryCov_9fa48("2913"), "journalEntries"), entryId)))).first());
        }
      },
      async listJournalEntries(workspaceId) {
        if (stryMutAct_9fa48("2914")) {
          {}
        } else {
          stryCov_9fa48("2914");
          const workspace = requiredId(db, stryMutAct_9fa48("2915") ? "" : (stryCov_9fa48("2915"), "workspaces"), workspaceId);
          const [docs, lines] = await Promise.all(stryMutAct_9fa48("2916") ? [] : (stryCov_9fa48("2916"), [db.query(stryMutAct_9fa48("2917") ? "" : (stryCov_9fa48("2917"), "journalEntries")).withIndex(stryMutAct_9fa48("2918") ? "" : (stryCov_9fa48("2918"), "by_workspace"), stryMutAct_9fa48("2919") ? () => undefined : (stryCov_9fa48("2919"), q => q.eq(stryMutAct_9fa48("2920") ? "" : (stryCov_9fa48("2920"), "workspaceId"), workspace))).collect(), db.query(stryMutAct_9fa48("2921") ? "" : (stryCov_9fa48("2921"), "journalLines")).withIndex(stryMutAct_9fa48("2922") ? "" : (stryCov_9fa48("2922"), "by_workspace"), stryMutAct_9fa48("2923") ? () => undefined : (stryCov_9fa48("2923"), q => q.eq(stryMutAct_9fa48("2924") ? "" : (stryCov_9fa48("2924"), "workspaceId"), workspace))).collect()]));
          return docs.map(stryMutAct_9fa48("2925") ? () => undefined : (stryCov_9fa48("2925"), doc => toEntry(doc, lines)));
        }
      },
      async listJournalSourceEffects(workspaceId, sourceEntryId) {
        if (stryMutAct_9fa48("2926")) {
          {}
        } else {
          stryCov_9fa48("2926");
          const docs = await db.query(stryMutAct_9fa48("2927") ? "" : (stryCov_9fa48("2927"), "journalSourceEffects")).withIndex(stryMutAct_9fa48("2928") ? "" : (stryCov_9fa48("2928"), "by_workspace_source"), stryMutAct_9fa48("2929") ? () => undefined : (stryCov_9fa48("2929"), q => q.eq(stryMutAct_9fa48("2930") ? "" : (stryCov_9fa48("2930"), "workspaceId"), requiredId(db, stryMutAct_9fa48("2931") ? "" : (stryCov_9fa48("2931"), "workspaces"), workspaceId)).eq(stryMutAct_9fa48("2932") ? "" : (stryCov_9fa48("2932"), "sourceEntryId"), requiredId(db, stryMutAct_9fa48("2933") ? "" : (stryCov_9fa48("2933"), "journalEntries"), sourceEntryId)))).collect();
          return docs.map(stryMutAct_9fa48("2934") ? () => undefined : (stryCov_9fa48("2934"), ({
            workspaceId,
            sourceEntryId,
            journalEntryId,
            expenseDeltaMinorUnits,
            sourceSequence
          }) => stryMutAct_9fa48("2935") ? {} : (stryCov_9fa48("2935"), {
            workspaceId,
            sourceEntryId,
            journalEntryId,
            expenseDeltaMinorUnits,
            sourceSequence
          })));
        }
      },
      listExpenseEntriesInRange: stryMutAct_9fa48("2936") ? () => undefined : (stryCov_9fa48("2936"), (workspaceId, from, through) => entriesInRange(workspaceId, stryMutAct_9fa48("2937") ? "" : (stryCov_9fa48("2937"), "cash-expense@1"), from, through)),
      listAccountTransferEntriesInRange: stryMutAct_9fa48("2938") ? () => undefined : (stryCov_9fa48("2938"), (workspaceId, from, through) => entriesInRange(workspaceId, stryMutAct_9fa48("2939") ? "" : (stryCov_9fa48("2939"), "account-transfer@1"), from, through)),
      async getAccountingPeriod(workspaceId, period) {
        if (stryMutAct_9fa48("2940")) {
          {}
        } else {
          stryCov_9fa48("2940");
          const doc = await findAccountingPeriod(db, requiredId(db, stryMutAct_9fa48("2941") ? "" : (stryCov_9fa48("2941"), "workspaces"), workspaceId), period);
          return doc ? toAccountingPeriod(doc) : undefined;
        }
      }
    });
  }
}
function writeStore(db: WriteDb): Pick<AccountingStore, WriteMethod> {
  if (stryMutAct_9fa48("2942")) {
    {}
  } else {
    stryCov_9fa48("2942");
    return stryMutAct_9fa48("2943") ? {} : (stryCov_9fa48("2943"), {
      async insertCategory(category) {
        if (stryMutAct_9fa48("2944")) {
          {}
        } else {
          stryCov_9fa48("2944");
          const id = await db.insert(stryMutAct_9fa48("2945") ? "" : (stryCov_9fa48("2945"), "userCategories"), category);
          return stryMutAct_9fa48("2946") ? {} : (stryCov_9fa48("2946"), {
            id,
            ...category
          });
        }
      },
      async saveCategory(category) {
        if (stryMutAct_9fa48("2947")) {
          {}
        } else {
          stryCov_9fa48("2947");
          const {
            id,
            ...fields
          } = category;
          await db.replace(requiredId(db, stryMutAct_9fa48("2948") ? "" : (stryCov_9fa48("2948"), "userCategories"), id), fields);
        }
      },
      async saveCategoryReceipt(receipt) {
        if (stryMutAct_9fa48("2949")) {
          {}
        } else {
          stryCov_9fa48("2949");
          await db.insert(stryMutAct_9fa48("2950") ? "" : (stryCov_9fa48("2950"), "categoryReceipts"), receipt);
        }
      },
      async saveHouseholdWorkspaceCreation(input) {
        if (stryMutAct_9fa48("2951")) {
          {}
        } else {
          stryCov_9fa48("2951");
          await db.insert(stryMutAct_9fa48("2952") ? "" : (stryCov_9fa48("2952"), "householdWorkspaceCreations"), stryMutAct_9fa48("2953") ? {} : (stryCov_9fa48("2953"), {
            ...input,
            workspaceId: requiredId(db, stryMutAct_9fa48("2954") ? "" : (stryCov_9fa48("2954"), "workspaces"), input.workspaceId)
          }));
        }
      },
      async insertWorkspace(workspace, ownerUserId) {
        if (stryMutAct_9fa48("2955")) {
          {}
        } else {
          stryCov_9fa48("2955");
          const workspaceId = await db.insert(stryMutAct_9fa48("2956") ? "" : (stryCov_9fa48("2956"), "workspaces"), workspace);
          await db.insert(stryMutAct_9fa48("2957") ? "" : (stryCov_9fa48("2957"), "workspaceMemberships"), stryMutAct_9fa48("2958") ? {} : (stryCov_9fa48("2958"), {
            workspaceId,
            userId: ownerUserId,
            role: stryMutAct_9fa48("2959") ? "" : (stryCov_9fa48("2959"), "Owner")
          }));
          return stryMutAct_9fa48("2960") ? {} : (stryCov_9fa48("2960"), {
            id: workspaceId,
            ...workspace
          });
        }
      },
      async insertLedgerAccount(account) {
        if (stryMutAct_9fa48("2961")) {
          {}
        } else {
          stryCov_9fa48("2961");
          const id = await db.insert(stryMutAct_9fa48("2962") ? "" : (stryCov_9fa48("2962"), "ledgerAccounts"), stryMutAct_9fa48("2963") ? {} : (stryCov_9fa48("2963"), {
            ...account,
            workspaceId: requiredId(db, stryMutAct_9fa48("2964") ? "" : (stryCov_9fa48("2964"), "workspaces"), account.workspaceId)
          }));
          return stryMutAct_9fa48("2965") ? {} : (stryCov_9fa48("2965"), {
            id,
            ...account
          });
        }
      },
      async insertProfile(profile) {
        if (stryMutAct_9fa48("2966")) {
          {}
        } else {
          stryCov_9fa48("2966");
          const id = await db.insert(stryMutAct_9fa48("2967") ? "" : (stryCov_9fa48("2967"), "financialAccountProfiles"), stryMutAct_9fa48("2968") ? {} : (stryCov_9fa48("2968"), {
            ...profile,
            workspaceId: requiredId(db, stryMutAct_9fa48("2969") ? "" : (stryCov_9fa48("2969"), "workspaces"), profile.workspaceId),
            postingAccountId: requiredId(db, stryMutAct_9fa48("2970") ? "" : (stryCov_9fa48("2970"), "ledgerAccounts"), profile.postingAccountId)
          }));
          return stryMutAct_9fa48("2971") ? {} : (stryCov_9fa48("2971"), {
            id,
            ...profile
          });
        }
      },
      async clearProfileOpening(profileId) {
        if (stryMutAct_9fa48("2972")) {
          {}
        } else {
          stryCov_9fa48("2972");
          await db.patch(requiredId(db, stryMutAct_9fa48("2973") ? "" : (stryCov_9fa48("2973"), "financialAccountProfiles"), profileId), stryMutAct_9fa48("2974") ? {} : (stryCov_9fa48("2974"), {
            opening: undefined
          }));
        }
      },
      async saveOpeningPosition(position) {
        if (stryMutAct_9fa48("2975")) {
          {}
        } else {
          stryCov_9fa48("2975");
          await db.insert(stryMutAct_9fa48("2976") ? "" : (stryCov_9fa48("2976"), "openingPositions"), stryMutAct_9fa48("2977") ? {} : (stryCov_9fa48("2977"), {
            ...position,
            workspaceId: requiredId(db, stryMutAct_9fa48("2978") ? "" : (stryCov_9fa48("2978"), "workspaces"), position.workspaceId),
            financialAccountProfileId: requiredId(db, stryMutAct_9fa48("2979") ? "" : (stryCov_9fa48("2979"), "financialAccountProfiles"), position.financialAccountProfileId),
            idempotencyKey: position.opening.idempotencyKey
          }));
          await db.patch(requiredId(db, stryMutAct_9fa48("2980") ? "" : (stryCov_9fa48("2980"), "financialAccountProfiles"), position.financialAccountProfileId), stryMutAct_9fa48("2981") ? {} : (stryCov_9fa48("2981"), {
            opening: position.opening
          }));
        }
      },
      async insertJournalEntry(entry) {
        if (stryMutAct_9fa48("2982")) {
          {}
        } else {
          stryCov_9fa48("2982");
          const workspaceId = requiredId(db, stryMutAct_9fa48("2983") ? "" : (stryCov_9fa48("2983"), "workspaces"), entry.workspaceId);
          const journalEntryId = await db.insert(stryMutAct_9fa48("2984") ? "" : (stryCov_9fa48("2984"), "journalEntries"), stryMutAct_9fa48("2985") ? {} : (stryCov_9fa48("2985"), {
            workspaceId,
            accountingDate: entry.accountingDate,
            periodYear: entry.period.year,
            periodMonth: entry.period.month,
            description: entry.description,
            idempotencyKey: entry.idempotencyKey,
            policy: entry.policy,
            ...(entry.cashCategoryInput ? stryMutAct_9fa48("2986") ? {} : (stryCov_9fa48("2986"), {
              cashCategoryInput: entry.cashCategoryInput
            }) : {}),
            ...(entry.sourceExpenseEffects ? stryMutAct_9fa48("2987") ? {} : (stryCov_9fa48("2987"), {
              sourceExpenseEffects: entry.sourceExpenseEffects
            }) : {}),
            postedBy: entry.postedBy,
            postedAt: entry.postedAt,
            ...(entry.financialAccountProfileId ? stryMutAct_9fa48("2988") ? {} : (stryCov_9fa48("2988"), {
              financialAccountProfileId: requiredId(db, stryMutAct_9fa48("2989") ? "" : (stryCov_9fa48("2989"), "financialAccountProfiles"), entry.financialAccountProfileId)
            }) : {}),
            ...(entry.reversesEntryId ? stryMutAct_9fa48("2990") ? {} : (stryCov_9fa48("2990"), {
              reversesEntryId: requiredId(db, stryMutAct_9fa48("2991") ? "" : (stryCov_9fa48("2991"), "journalEntries"), entry.reversesEntryId)
            }) : {})
          }));
          for (const effect of stryMutAct_9fa48("2992") ? entry.sourceExpenseEffects && [] : (stryCov_9fa48("2992"), entry.sourceExpenseEffects ?? (stryMutAct_9fa48("2993") ? ["Stryker was here"] : (stryCov_9fa48("2993"), [])))) {
            if (stryMutAct_9fa48("2994")) {
              {}
            } else {
              stryCov_9fa48("2994");
              const sourceEntryId = requiredId(db, stryMutAct_9fa48("2995") ? "" : (stryCov_9fa48("2995"), "journalEntries"), effect.sourceEntryId);
              const earlierEffects = await db.query(stryMutAct_9fa48("2996") ? "" : (stryCov_9fa48("2996"), "journalSourceEffects")).withIndex(stryMutAct_9fa48("2997") ? "" : (stryCov_9fa48("2997"), "by_workspace_source"), stryMutAct_9fa48("2998") ? () => undefined : (stryCov_9fa48("2998"), q => q.eq(stryMutAct_9fa48("2999") ? "" : (stryCov_9fa48("2999"), "workspaceId"), workspaceId).eq(stryMutAct_9fa48("3000") ? "" : (stryCov_9fa48("3000"), "sourceEntryId"), sourceEntryId))).collect();
              const sourceSequence = stryMutAct_9fa48("3001") ? Math.max(0, ...earlierEffects.map(row => row.sourceSequence)) - 1 : (stryCov_9fa48("3001"), (stryMutAct_9fa48("3002") ? Math.min(0, ...earlierEffects.map(row => row.sourceSequence)) : (stryCov_9fa48("3002"), Math.max(0, ...earlierEffects.map(stryMutAct_9fa48("3003") ? () => undefined : (stryCov_9fa48("3003"), row => row.sourceSequence))))) + 1);
              if (stryMutAct_9fa48("3006") ? false : stryMutAct_9fa48("3005") ? true : stryMutAct_9fa48("3004") ? Number.isSafeInteger(sourceSequence) : (stryCov_9fa48("3004", "3005", "3006"), !Number.isSafeInteger(sourceSequence))) throw new AccountingError(stryMutAct_9fa48("3008") ? "" : (stryCov_9fa48("3008"), "journal_line_invalid"));
              await db.insert(stryMutAct_9fa48("3009") ? "" : (stryCov_9fa48("3009"), "journalSourceEffects"), stryMutAct_9fa48("3010") ? {} : (stryCov_9fa48("3010"), {
                workspaceId,
                journalEntryId,
                sourceEntryId,
                expenseDeltaMinorUnits: effect.expenseDeltaMinorUnits,
                sourceSequence
              }));
            }
          }
          for (const [lineNumber, line] of entry.lines.entries()) {
            if (stryMutAct_9fa48("3011")) {
              {}
            } else {
              stryCov_9fa48("3011");
              await db.insert(stryMutAct_9fa48("3012") ? "" : (stryCov_9fa48("3012"), "journalLines"), stryMutAct_9fa48("3013") ? {} : (stryCov_9fa48("3013"), {
                workspaceId,
                journalEntryId,
                lineNumber,
                ledgerAccountId: requiredId(db, stryMutAct_9fa48("3014") ? "" : (stryCov_9fa48("3014"), "ledgerAccounts"), line.ledgerAccountId),
                ...(line.category ? stryMutAct_9fa48("3015") ? {} : (stryCov_9fa48("3015"), {
                  category: line.category
                }) : {}),
                ...(line.categoryCorrection ? stryMutAct_9fa48("3016") ? {} : (stryCov_9fa48("3016"), {
                  categoryCorrection: line.categoryCorrection
                }) : {}),
                debitMinorUnits: line.debitMinorUnits,
                creditMinorUnits: line.creditMinorUnits
              }));
            }
          }
          return stryMutAct_9fa48("3017") ? {} : (stryCov_9fa48("3017"), {
            ...entry,
            id: journalEntryId
          });
        }
      },
      async insertAccountingPeriod(workspaceId, period) {
        if (stryMutAct_9fa48("3018")) {
          {}
        } else {
          stryCov_9fa48("3018");
          const id = requiredId(db, stryMutAct_9fa48("3019") ? "" : (stryCov_9fa48("3019"), "workspaces"), workspaceId);
          const existing = await findAccountingPeriod(db, id, period);
          if (stryMutAct_9fa48("3021") ? false : stryMutAct_9fa48("3020") ? true : (stryCov_9fa48("3020", "3021"), existing)) {
            if (stryMutAct_9fa48("3022")) {
              {}
            } else {
              stryCov_9fa48("3022");
              return toAccountingPeriod(existing);
            }
          }
          await db.insert(stryMutAct_9fa48("3023") ? "" : (stryCov_9fa48("3023"), "accountingPeriods"), stryMutAct_9fa48("3024") ? {} : (stryCov_9fa48("3024"), {
            workspaceId: id,
            ...period
          }));
          return period;
        }
      },
      async setAccountingPeriodStatus(workspaceId, period, status) {
        if (stryMutAct_9fa48("3025")) {
          {}
        } else {
          stryCov_9fa48("3025");
          const doc = await findAccountingPeriod(db, requiredId(db, stryMutAct_9fa48("3026") ? "" : (stryCov_9fa48("3026"), "workspaces"), workspaceId), period);
          if (stryMutAct_9fa48("3029") ? false : stryMutAct_9fa48("3028") ? true : stryMutAct_9fa48("3027") ? doc : (stryCov_9fa48("3027", "3028", "3029"), !doc)) {
            if (stryMutAct_9fa48("3030")) {
              {}
            } else {
              stryCov_9fa48("3030");
              throw new AccountingError(stryMutAct_9fa48("3032") ? "" : (stryCov_9fa48("3032"), "accounting_period_not_found"));
            }
          }
          await db.patch(doc._id, stryMutAct_9fa48("3033") ? {} : (stryCov_9fa48("3033"), {
            status
          }));
          return toAccountingPeriod(stryMutAct_9fa48("3034") ? {} : (stryCov_9fa48("3034"), {
            ...doc,
            status
          }));
        }
      },
      async insertPeriodControlDecision(workspaceId, decision) {
        if (stryMutAct_9fa48("3035")) {
          {}
        } else {
          stryCov_9fa48("3035");
          await db.insert(stryMutAct_9fa48("3036") ? "" : (stryCov_9fa48("3036"), "periodControlDecisions"), stryMutAct_9fa48("3037") ? {} : (stryCov_9fa48("3037"), {
            workspaceId: requiredId(db, stryMutAct_9fa48("3038") ? "" : (stryCov_9fa48("3038"), "workspaces"), workspaceId),
            year: decision.period.year,
            month: decision.period.month,
            action: decision.action,
            decidedBy: decision.decidedBy,
            decidedAt: decision.decidedAt,
            ...(decision.reason ? stryMutAct_9fa48("3039") ? {} : (stryCov_9fa48("3039"), {
              reason: decision.reason
            }) : {})
          }));
        }
      }
    });
  }
}
function unavailable(method: string): never {
  if (stryMutAct_9fa48("3040")) {
    {}
  } else {
    stryCov_9fa48("3040");
    throw new Error(stryMutAct_9fa48("3042") ? `` : (stryCov_9fa48("3042"), `${method} is not available on a read`));
  }
}
function readOnlyWrites(): Pick<AccountingStore, WriteMethod> {
  if (stryMutAct_9fa48("3043")) {
    {}
  } else {
    stryCov_9fa48("3043");
    return stryMutAct_9fa48("3044") ? {} : (stryCov_9fa48("3044"), {
      insertCategory: stryMutAct_9fa48("3045") ? () => undefined : (stryCov_9fa48("3045"), async () => unavailable(stryMutAct_9fa48("3046") ? "" : (stryCov_9fa48("3046"), "insertCategory"))),
      saveCategory: stryMutAct_9fa48("3047") ? () => undefined : (stryCov_9fa48("3047"), async () => unavailable(stryMutAct_9fa48("3048") ? "" : (stryCov_9fa48("3048"), "saveCategory"))),
      saveCategoryReceipt: stryMutAct_9fa48("3049") ? () => undefined : (stryCov_9fa48("3049"), async () => unavailable(stryMutAct_9fa48("3050") ? "" : (stryCov_9fa48("3050"), "saveCategoryReceipt"))),
      saveHouseholdWorkspaceCreation: stryMutAct_9fa48("3051") ? () => undefined : (stryCov_9fa48("3051"), async () => unavailable(stryMutAct_9fa48("3052") ? "" : (stryCov_9fa48("3052"), "saveHouseholdWorkspaceCreation"))),
      insertWorkspace: stryMutAct_9fa48("3053") ? () => undefined : (stryCov_9fa48("3053"), async () => unavailable(stryMutAct_9fa48("3054") ? "" : (stryCov_9fa48("3054"), "insertWorkspace"))),
      insertLedgerAccount: stryMutAct_9fa48("3055") ? () => undefined : (stryCov_9fa48("3055"), async () => unavailable(stryMutAct_9fa48("3056") ? "" : (stryCov_9fa48("3056"), "insertLedgerAccount"))),
      insertProfile: stryMutAct_9fa48("3057") ? () => undefined : (stryCov_9fa48("3057"), async () => unavailable(stryMutAct_9fa48("3058") ? "" : (stryCov_9fa48("3058"), "insertProfile"))),
      clearProfileOpening: stryMutAct_9fa48("3059") ? () => undefined : (stryCov_9fa48("3059"), async () => unavailable(stryMutAct_9fa48("3060") ? "" : (stryCov_9fa48("3060"), "clearProfileOpening"))),
      saveOpeningPosition: stryMutAct_9fa48("3061") ? () => undefined : (stryCov_9fa48("3061"), async () => unavailable(stryMutAct_9fa48("3062") ? "" : (stryCov_9fa48("3062"), "saveOpeningPosition"))),
      insertJournalEntry: stryMutAct_9fa48("3063") ? () => undefined : (stryCov_9fa48("3063"), async () => unavailable(stryMutAct_9fa48("3064") ? "" : (stryCov_9fa48("3064"), "insertJournalEntry"))),
      insertAccountingPeriod: stryMutAct_9fa48("3065") ? () => undefined : (stryCov_9fa48("3065"), async () => unavailable(stryMutAct_9fa48("3066") ? "" : (stryCov_9fa48("3066"), "insertAccountingPeriod"))),
      setAccountingPeriodStatus: stryMutAct_9fa48("3067") ? () => undefined : (stryCov_9fa48("3067"), async () => unavailable(stryMutAct_9fa48("3068") ? "" : (stryCov_9fa48("3068"), "setAccountingPeriodStatus"))),
      insertPeriodControlDecision: stryMutAct_9fa48("3069") ? () => undefined : (stryCov_9fa48("3069"), async () => unavailable(stryMutAct_9fa48("3070") ? "" : (stryCov_9fa48("3070"), "insertPeriodControlDecision")))
    });
  }
}
export function convexReadStore(db: ReadDb): AccountingStore {
  if (stryMutAct_9fa48("3071")) {
    {}
  } else {
    stryCov_9fa48("3071");
    return stryMutAct_9fa48("3072") ? {} : (stryCov_9fa48("3072"), {
      ...readStore(db),
      ...readOnlyWrites()
    });
  }
}
export function convexStore(db: WriteDb): AccountingStore {
  if (stryMutAct_9fa48("3073")) {
    {}
  } else {
    stryCov_9fa48("3073");
    return stryMutAct_9fa48("3074") ? {} : (stryCov_9fa48("3074"), {
      ...readStore(db),
      ...writeStore(db)
    });
  }
}