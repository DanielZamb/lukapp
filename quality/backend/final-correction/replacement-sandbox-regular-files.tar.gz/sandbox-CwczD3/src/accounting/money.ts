// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { functionalCurrencyCodes } from "./currencies";
import { AccountingError } from "./errors";
import type { Money, StoredWorkspace } from "./types";
export function requireFunctionalCurrencyCode(currency: string): string {
  if (stryMutAct_9fa48("4908")) {
    {}
  } else {
    stryCov_9fa48("4908");
    if (stryMutAct_9fa48("4911") ? false : stryMutAct_9fa48("4910") ? true : stryMutAct_9fa48("4909") ? functionalCurrencyCodes.has(currency) : (stryCov_9fa48("4909", "4910", "4911"), !functionalCurrencyCodes.has(currency))) {
      if (stryMutAct_9fa48("4912")) {
        {}
      } else {
        stryCov_9fa48("4912");
        throw new AccountingError(stryMutAct_9fa48("4914") ? "" : (stryCov_9fa48("4914"), "functional_currency_invalid"));
      }
    }
    return currency;
  }
}

/** A positive whole number of minor units in the Workspace Functional Currency. */
export function requireFunctionalAmount(workspace: StoredWorkspace, amount: Money): number {
  if (stryMutAct_9fa48("4915")) {
    {}
  } else {
    stryCov_9fa48("4915");
    if (stryMutAct_9fa48("4918") ? !Number.isSafeInteger(amount.minorUnits) && amount.minorUnits <= 0 : stryMutAct_9fa48("4917") ? false : stryMutAct_9fa48("4916") ? true : (stryCov_9fa48("4916", "4917", "4918"), (stryMutAct_9fa48("4919") ? Number.isSafeInteger(amount.minorUnits) : (stryCov_9fa48("4919"), !Number.isSafeInteger(amount.minorUnits))) || (stryMutAct_9fa48("4922") ? amount.minorUnits > 0 : stryMutAct_9fa48("4921") ? amount.minorUnits < 0 : stryMutAct_9fa48("4920") ? false : (stryCov_9fa48("4920", "4921", "4922"), amount.minorUnits <= 0)))) {
      if (stryMutAct_9fa48("4923")) {
        {}
      } else {
        stryCov_9fa48("4923");
        throw new AccountingError(stryMutAct_9fa48("4925") ? "" : (stryCov_9fa48("4925"), "amount_must_be_positive"));
      }
    }
    if (stryMutAct_9fa48("4928") ? amount.currency === workspace.functionalCurrency : stryMutAct_9fa48("4927") ? false : stryMutAct_9fa48("4926") ? true : (stryCov_9fa48("4926", "4927", "4928"), amount.currency !== workspace.functionalCurrency)) {
      if (stryMutAct_9fa48("4929")) {
        {}
      } else {
        stryCov_9fa48("4929");
        throw new AccountingError(stryMutAct_9fa48("4931") ? "" : (stryCov_9fa48("4931"), "currency_mismatch"));
      }
    }
    return amount.minorUnits;
  }
}