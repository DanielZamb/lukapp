// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { resolveCashCategory } from "./cashCategory";
import { resolveTemplateAccount } from "./chartOfAccounts";
import { AccountingError } from "./errors";
import { requireFunctionalAmount } from "./money";
import { periodFromAccountingDate } from "./period";
import type { CategorySnapshot, CategoryCorrection } from "./categoryTypes";
import type { AccountingStore, CashActivityInput, LedgerAccount, Money, PeriodKey, PostingPolicy, StoredWorkspace } from "./types";
export type PostedExpenseLine = {
  kind: "postedExpense";
  journalEntryId: string;
  lineNumber: number;
  accountingDate: string;
  postedAt: number;
  postedBy: string;
  postingPolicy: PostingPolicy;
  reversesEntryId?: string;
  account: Omit<LedgerAccount, "nature"> & {
    nature: "Expense";
  };
  debitMinorUnits: number;
  creditMinorUnits: number;
  category?: CategorySnapshot;
  categoryCorrection?: CategoryCorrection;
};
export type CashExpenseProposal = Pick<CashActivityInput, "financialAccountProfileId" | "accountingDate" | "amount" | "userCategoryId" | "categoryRevision" | "ledgerAccountCode">;
export type ProposedExpense = {
  kind: "proposedExpense";
  postingPolicy: "cash-expense@1";
  financialAccountProfileId: CashActivityInput["financialAccountProfileId"];
  accountingDate: string;
  month: PeriodKey;
  amount: Money;
  account: {
    code: string;
    name: string;
    nature: "Expense";
    ledgerAccountId?: LedgerAccount["id"];
  };
  category?: CategorySnapshot;
};
export type AccountingPlanningReads = Pick<AccountingStore, "getWorkspace" | "membershipRole" | "getCategory" | "getLedgerAccount" | "getProfile" | "findLedgerAccountByCode"> & {
  postedExpenseLines(workspaceId: StoredWorkspace["id"], month: PeriodKey): Promise<PostedExpenseLine[]>;
};
export async function resolveExpenseProposal(reads: AccountingPlanningReads, workspace: StoredWorkspace, proposal: CashExpenseProposal): Promise<ProposedExpense> {
  if (stryMutAct_9fa48("5118")) {
    {}
  } else {
    stryCov_9fa48("5118");
    if (stryMutAct_9fa48("5119")) {
      ;
    } else {
      stryCov_9fa48("5119");
      requireFunctionalAmount(workspace, proposal.amount);
    }
    const month = periodFromAccountingDate(proposal.accountingDate);
    const profile = await reads.getProfile(proposal.financialAccountProfileId);
    if (stryMutAct_9fa48("5122") ? !profile && profile.workspaceId !== workspace.id : stryMutAct_9fa48("5121") ? false : stryMutAct_9fa48("5120") ? true : (stryCov_9fa48("5120", "5121", "5122"), (stryMutAct_9fa48("5123") ? profile : (stryCov_9fa48("5123"), !profile)) || (stryMutAct_9fa48("5125") ? profile.workspaceId === workspace.id : stryMutAct_9fa48("5124") ? false : (stryCov_9fa48("5124", "5125"), profile.workspaceId !== workspace.id)))) throw new AccountingError(stryMutAct_9fa48("5127") ? "" : (stryCov_9fa48("5127"), "financial_account_profile_not_found"));
    const category = await resolveCashCategory(reads, stryMutAct_9fa48("5128") ? {} : (stryCov_9fa48("5128"), {
      ...proposal,
      workspaceId: workspace.id
    }), stryMutAct_9fa48("5129") ? "" : (stryCov_9fa48("5129"), "expense"));
    const account = resolveTemplateAccount(workspace, stryMutAct_9fa48("5130") ? "" : (stryCov_9fa48("5130"), "expense"), stryMutAct_9fa48("5131") ? proposal.ledgerAccountCode && category?.account.accountCode : (stryCov_9fa48("5131"), proposal.ledgerAccountCode ?? (stryMutAct_9fa48("5132") ? category.account.accountCode : (stryCov_9fa48("5132"), category?.account.accountCode))));
    if (stryMutAct_9fa48("5135") ? account.nature === "Expense" : stryMutAct_9fa48("5134") ? false : stryMutAct_9fa48("5133") ? true : (stryCov_9fa48("5133", "5134", "5135"), account.nature !== (stryMutAct_9fa48("5136") ? "" : (stryCov_9fa48("5136"), "Expense")))) throw new AccountingError(stryMutAct_9fa48("5138") ? "" : (stryCov_9fa48("5138"), "cash_expense_account_invalid"));
    const activated = await reads.findLedgerAccountByCode(workspace.id, account.code);
    return stryMutAct_9fa48("5139") ? {} : (stryCov_9fa48("5139"), {
      kind: stryMutAct_9fa48("5140") ? "" : (stryCov_9fa48("5140"), "proposedExpense"),
      postingPolicy: stryMutAct_9fa48("5141") ? "" : (stryCov_9fa48("5141"), "cash-expense@1"),
      financialAccountProfileId: profile.id,
      accountingDate: proposal.accountingDate,
      month,
      amount: proposal.amount,
      account: stryMutAct_9fa48("5142") ? {} : (stryCov_9fa48("5142"), {
        code: account.code,
        name: account.name,
        nature: stryMutAct_9fa48("5143") ? "" : (stryCov_9fa48("5143"), "Expense"),
        ...(activated ? stryMutAct_9fa48("5144") ? {} : (stryCov_9fa48("5144"), {
          ledgerAccountId: activated.id
        }) : {})
      }),
      ...(category ? stryMutAct_9fa48("5145") ? {} : (stryCov_9fa48("5145"), {
        category
      }) : {})
    });
  }
}