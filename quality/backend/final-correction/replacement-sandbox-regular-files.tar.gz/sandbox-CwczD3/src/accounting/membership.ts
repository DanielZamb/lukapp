// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "./errors";
import type { AccountingStore, Actor, StoredWorkspace, WorkspaceRole } from "./types";
export type WorkspacePermission = "view" | "prepare" | "post" | "correct" | "manageRecoveryPlans" | "managePeriods" | "administerMembership" | "manageBudgets";
export const workspaceRolePolicyVersion = stryMutAct_9fa48("4866") ? "" : (stryCov_9fa48("4866"), "workspace-roles@3");
export const workspaceRolePolicy = (stryMutAct_9fa48("4867") ? {} : (stryCov_9fa48("4867"), {
  Owner: stryMutAct_9fa48("4868") ? [] : (stryCov_9fa48("4868"), [stryMutAct_9fa48("4869") ? "" : (stryCov_9fa48("4869"), "view"), stryMutAct_9fa48("4870") ? "" : (stryCov_9fa48("4870"), "prepare"), stryMutAct_9fa48("4871") ? "" : (stryCov_9fa48("4871"), "post"), stryMutAct_9fa48("4872") ? "" : (stryCov_9fa48("4872"), "correct"), stryMutAct_9fa48("4873") ? "" : (stryCov_9fa48("4873"), "managePeriods"), stryMutAct_9fa48("4874") ? "" : (stryCov_9fa48("4874"), "administerMembership"), stryMutAct_9fa48("4875") ? "" : (stryCov_9fa48("4875"), "manageBudgets"), stryMutAct_9fa48("4876") ? "" : (stryCov_9fa48("4876"), "manageRecoveryPlans")]),
  Accountant: stryMutAct_9fa48("4877") ? [] : (stryCov_9fa48("4877"), [stryMutAct_9fa48("4878") ? "" : (stryCov_9fa48("4878"), "view"), stryMutAct_9fa48("4879") ? "" : (stryCov_9fa48("4879"), "prepare"), stryMutAct_9fa48("4880") ? "" : (stryCov_9fa48("4880"), "post"), stryMutAct_9fa48("4881") ? "" : (stryCov_9fa48("4881"), "correct"), stryMutAct_9fa48("4882") ? "" : (stryCov_9fa48("4882"), "managePeriods")]),
  Preparer: stryMutAct_9fa48("4883") ? [] : (stryCov_9fa48("4883"), [stryMutAct_9fa48("4884") ? "" : (stryCov_9fa48("4884"), "view"), stryMutAct_9fa48("4885") ? "" : (stryCov_9fa48("4885"), "prepare")]),
  Viewer: stryMutAct_9fa48("4886") ? [] : (stryCov_9fa48("4886"), [stryMutAct_9fa48("4887") ? "" : (stryCov_9fa48("4887"), "view")])
})) satisfies Record<WorkspaceRole, readonly WorkspacePermission[]>;
export function hasWorkspacePermission(role: WorkspaceRole, permission: WorkspacePermission): boolean {
  if (stryMutAct_9fa48("4888")) {
    {}
  } else {
    stryCov_9fa48("4888");
    const permissions: readonly WorkspacePermission[] = workspaceRolePolicy[role];
    return permissions.includes(permission);
  }
}
export async function requireWorkspace(store: Pick<AccountingStore, "membershipRole" | "getWorkspace">, workspaceId: string, actor: Actor, permission: WorkspacePermission = stryMutAct_9fa48("4889") ? "" : (stryCov_9fa48("4889"), "view")): Promise<StoredWorkspace> {
  if (stryMutAct_9fa48("4890")) {
    {}
  } else {
    stryCov_9fa48("4890");
    const role = await store.membershipRole(workspaceId, actor.userId);
    const workspace = stryMutAct_9fa48("4893") ? role || (await store.getWorkspace(workspaceId)) : stryMutAct_9fa48("4892") ? false : stryMutAct_9fa48("4891") ? true : (stryCov_9fa48("4891", "4892", "4893"), role && (await store.getWorkspace(workspaceId)));
    if (stryMutAct_9fa48("4896") ? !role && !workspace : stryMutAct_9fa48("4895") ? false : stryMutAct_9fa48("4894") ? true : (stryCov_9fa48("4894", "4895", "4896"), (stryMutAct_9fa48("4897") ? role : (stryCov_9fa48("4897"), !role)) || (stryMutAct_9fa48("4898") ? workspace : (stryCov_9fa48("4898"), !workspace)))) {
      if (stryMutAct_9fa48("4899")) {
        {}
      } else {
        stryCov_9fa48("4899");
        throw new AccountingError(stryMutAct_9fa48("4901") ? "" : (stryCov_9fa48("4901"), "workspace_membership_required"));
      }
    }
    if (stryMutAct_9fa48("4904") ? false : stryMutAct_9fa48("4903") ? true : stryMutAct_9fa48("4902") ? hasWorkspacePermission(role, permission) : (stryCov_9fa48("4902", "4903", "4904"), !hasWorkspacePermission(role, permission))) {
      if (stryMutAct_9fa48("4905")) {
        {}
      } else {
        stryCov_9fa48("4905");
        throw new AccountingError(stryMutAct_9fa48("4907") ? "" : (stryCov_9fa48("4907"), "workspace_permission_required"));
      }
    }
    return workspace;
  }
}