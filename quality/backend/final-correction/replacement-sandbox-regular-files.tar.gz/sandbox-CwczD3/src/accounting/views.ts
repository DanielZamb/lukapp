// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "./errors";
import type { AccountingPeriod, AccountingStore, FinancialAccountProfile, LedgerAccount, PostedJournalEntry, StoredJournalEntry, StoredProfile, StoredWorkspace, Workspace } from "./types";
export function toWorkspace(workspace: StoredWorkspace, currentAccountingPeriod: AccountingPeriod): Workspace {
  if (stryMutAct_9fa48("6933")) {
    {}
  } else {
    stryCov_9fa48("6933");
    return stryMutAct_9fa48("6934") ? {} : (stryCov_9fa48("6934"), {
      id: workspace.id,
      kind: workspace.kind,
      functionalCurrency: workspace.functionalCurrency,
      chartOfAccountsTemplate: workspace.chartOfAccountsTemplate,
      currentAccountingPeriod
    });
  }
}
export async function toProfile(store: AccountingStore, profile: StoredProfile): Promise<FinancialAccountProfile> {
  if (stryMutAct_9fa48("6935")) {
    {}
  } else {
    stryCov_9fa48("6935");
    return stryMutAct_9fa48("6936") ? {} : (stryCov_9fa48("6936"), {
      id: profile.id,
      workspaceId: profile.workspaceId,
      name: profile.name,
      productKind: profile.productKind,
      ...(profile.classificationAnswers ? stryMutAct_9fa48("6937") ? {} : (stryCov_9fa48("6937"), {
        classificationAnswers: profile.classificationAnswers
      }) : {}),
      ledgerAccountId: profile.postingAccountId,
      opening: (stryMutAct_9fa48("6938") ? profile.opening : (stryCov_9fa48("6938"), !profile.opening)) ? stryMutAct_9fa48("6939") ? {} : (stryCov_9fa48("6939"), {
        status: stryMutAct_9fa48("6940") ? "" : (stryCov_9fa48("6940"), "not_started")
      }) : (stryMutAct_9fa48("6943") ? profile.opening.kind !== "zero" : stryMutAct_9fa48("6942") ? false : stryMutAct_9fa48("6941") ? true : (stryCov_9fa48("6941", "6942", "6943"), profile.opening.kind === (stryMutAct_9fa48("6944") ? "" : (stryCov_9fa48("6944"), "zero")))) ? stryMutAct_9fa48("6945") ? {} : (stryCov_9fa48("6945"), {
        status: stryMutAct_9fa48("6946") ? "" : (stryCov_9fa48("6946"), "zero"),
        accountingDate: profile.opening.accountingDate,
        amount: profile.opening.amount,
        idempotencyKey: profile.opening.idempotencyKey
      }) : stryMutAct_9fa48("6947") ? {} : (stryCov_9fa48("6947"), {
        status: (await store.findReversalOf(profile.opening.journalEntryId)) ? stryMutAct_9fa48("6948") ? "" : (stryCov_9fa48("6948"), "reversed") : stryMutAct_9fa48("6949") ? "" : (stryCov_9fa48("6949"), "posted"),
        accountingDate: profile.opening.accountingDate,
        amount: profile.opening.amount,
        idempotencyKey: profile.opening.idempotencyKey,
        journalEntryId: profile.opening.journalEntryId
      })
    });
  }
}

/** Reads what a view of one Workspace's entries needs, once, for any number of entries. */
export async function journalContext(store: AccountingStore, workspace: StoredWorkspace) {
  if (stryMutAct_9fa48("6950")) {
    {}
  } else {
    stryCov_9fa48("6950");
    const [accounts, profiles] = await Promise.all(stryMutAct_9fa48("6951") ? [] : (stryCov_9fa48("6951"), [store.listLedgerAccounts(workspace.id), store.listProfiles(workspace.id)]));
    return stryMutAct_9fa48("6952") ? {} : (stryCov_9fa48("6952"), {
      workspace,
      accounts: new Map(accounts.map(stryMutAct_9fa48("6953") ? () => undefined : (stryCov_9fa48("6953"), account => stryMutAct_9fa48("6954") ? [] : (stryCov_9fa48("6954"), [account.id, account])))),
      profiles: new Map(profiles.map(stryMutAct_9fa48("6955") ? () => undefined : (stryCov_9fa48("6955"), profile => stryMutAct_9fa48("6956") ? [] : (stryCov_9fa48("6956"), [profile.id, profile])))),
      profileByAccount: new Map(profiles.map(stryMutAct_9fa48("6957") ? () => undefined : (stryCov_9fa48("6957"), profile => stryMutAct_9fa48("6958") ? [] : (stryCov_9fa48("6958"), [profile.postingAccountId, profile.id]))))
    });
  }
}
export type JournalContext = Awaited<ReturnType<typeof journalContext>>;
export async function toPostedJournalEntry(store: AccountingStore, context: JournalContext, entry: StoredJournalEntry, links: {
  replay: boolean;
  reversedByEntryId?: string;
}): Promise<PostedJournalEntry> {
  if (stryMutAct_9fa48("6959")) {
    {}
  } else {
    stryCov_9fa48("6959");
    const period = await store.getAccountingPeriod(context.workspace.id, entry.period);
    if (stryMutAct_9fa48("6962") ? false : stryMutAct_9fa48("6961") ? true : stryMutAct_9fa48("6960") ? period : (stryCov_9fa48("6960", "6961", "6962"), !period)) {
      if (stryMutAct_9fa48("6963")) {
        {}
      } else {
        stryCov_9fa48("6963");
        throw new AccountingError(stryMutAct_9fa48("6965") ? "" : (stryCov_9fa48("6965"), "accounting_period_not_found"));
      }
    }
    const profile = entry.financialAccountProfileId ? context.profiles.get(entry.financialAccountProfileId) : undefined;
    const view: PostedJournalEntry = stryMutAct_9fa48("6966") ? {} : (stryCov_9fa48("6966"), {
      id: entry.id,
      policy: entry.policy,
      ...(entry.cashCategoryInput ? stryMutAct_9fa48("6967") ? {} : (stryCov_9fa48("6967"), {
        cashCategoryInput: entry.cashCategoryInput
      }) : {}),
      ...(entry.sourceExpenseEffects ? stryMutAct_9fa48("6968") ? {} : (stryCov_9fa48("6968"), {
        sourceExpenseEffects: entry.sourceExpenseEffects
      }) : {}),
      description: entry.description,
      accountingDate: entry.accountingDate,
      accountingPeriod: period,
      amount: stryMutAct_9fa48("6969") ? {} : (stryCov_9fa48("6969"), {
        currency: context.workspace.functionalCurrency,
        minorUnits: entry.lines.reduce(stryMutAct_9fa48("6970") ? () => undefined : (stryCov_9fa48("6970"), (sum, line) => stryMutAct_9fa48("6971") ? sum - line.debitMinorUnits : (stryCov_9fa48("6971"), sum + line.debitMinorUnits)), 0)
      }),
      postedBy: entry.postedBy,
      postedAt: entry.postedAt,
      replay: links.replay,
      lines: entry.lines.map(line => {
        if (stryMutAct_9fa48("6972")) {
          {}
        } else {
          stryCov_9fa48("6972");
          const account = requireAccount(context.accounts, line.ledgerAccountId);
          const financialAccountProfileId = context.profileByAccount.get(line.ledgerAccountId);
          return stryMutAct_9fa48("6973") ? {} : (stryCov_9fa48("6973"), {
            ...(line.category ? stryMutAct_9fa48("6974") ? {} : (stryCov_9fa48("6974"), {
              category: line.category
            }) : {}),
            ...(line.categoryCorrection ? stryMutAct_9fa48("6975") ? {} : (stryCov_9fa48("6975"), {
              categoryCorrection: line.categoryCorrection
            }) : {}),
            ledgerAccountId: line.ledgerAccountId,
            ...((stryMutAct_9fa48("6978") ? financialAccountProfileId === undefined : stryMutAct_9fa48("6977") ? false : stryMutAct_9fa48("6976") ? true : (stryCov_9fa48("6976", "6977", "6978"), financialAccountProfileId !== undefined)) ? stryMutAct_9fa48("6979") ? {} : (stryCov_9fa48("6979"), {
              financialAccountProfileId
            }) : {}),
            code: account.code,
            name: account.name,
            nature: account.nature,
            debitMinorUnits: line.debitMinorUnits,
            creditMinorUnits: line.creditMinorUnits
          });
        }
      })
    });
    if (stryMutAct_9fa48("6981") ? false : stryMutAct_9fa48("6980") ? true : (stryCov_9fa48("6980", "6981"), profile)) {
      if (stryMutAct_9fa48("6982")) {
        {}
      } else {
        stryCov_9fa48("6982");
        view.financialAccountProfileId = profile.id;
        view.financialAccountProfileName = profile.name;
      }
    }
    if (stryMutAct_9fa48("6985") ? entry.policy !== "account-transfer@1" : stryMutAct_9fa48("6984") ? false : stryMutAct_9fa48("6983") ? true : (stryCov_9fa48("6983", "6984", "6985"), entry.policy === (stryMutAct_9fa48("6986") ? "" : (stryCov_9fa48("6986"), "account-transfer@1")))) {
      if (stryMutAct_9fa48("6987")) {
        {}
      } else {
        stryCov_9fa48("6987");
        const sourceLine = view.lines.find(stryMutAct_9fa48("6988") ? () => undefined : (stryCov_9fa48("6988"), line => stryMutAct_9fa48("6992") ? line.creditMinorUnits <= 0 : stryMutAct_9fa48("6991") ? line.creditMinorUnits >= 0 : stryMutAct_9fa48("6990") ? false : stryMutAct_9fa48("6989") ? true : (stryCov_9fa48("6989", "6990", "6991", "6992"), line.creditMinorUnits > 0)));
        const destinationLine = view.lines.find(stryMutAct_9fa48("6993") ? () => undefined : (stryCov_9fa48("6993"), line => stryMutAct_9fa48("6997") ? line.debitMinorUnits <= 0 : stryMutAct_9fa48("6996") ? line.debitMinorUnits >= 0 : stryMutAct_9fa48("6995") ? false : stryMutAct_9fa48("6994") ? true : (stryCov_9fa48("6994", "6995", "6996", "6997"), line.debitMinorUnits > 0)));
        if (stryMutAct_9fa48("7000") ? !sourceLine?.financialAccountProfileId && !destinationLine?.financialAccountProfileId : stryMutAct_9fa48("6999") ? false : stryMutAct_9fa48("6998") ? true : (stryCov_9fa48("6998", "6999", "7000"), (stryMutAct_9fa48("7001") ? sourceLine?.financialAccountProfileId : (stryCov_9fa48("7001"), !(stryMutAct_9fa48("7002") ? sourceLine.financialAccountProfileId : (stryCov_9fa48("7002"), sourceLine?.financialAccountProfileId)))) || (stryMutAct_9fa48("7003") ? destinationLine?.financialAccountProfileId : (stryCov_9fa48("7003"), !(stryMutAct_9fa48("7004") ? destinationLine.financialAccountProfileId : (stryCov_9fa48("7004"), destinationLine?.financialAccountProfileId)))))) {
          if (stryMutAct_9fa48("7005")) {
            {}
          } else {
            stryCov_9fa48("7005");
            throw new AccountingError(stryMutAct_9fa48("7007") ? "" : (stryCov_9fa48("7007"), "financial_account_profile_not_found"));
          }
        }
        view.accountTransfer = stryMutAct_9fa48("7008") ? {} : (stryCov_9fa48("7008"), {
          sourceFinancialAccountProfileId: sourceLine.financialAccountProfileId,
          destinationFinancialAccountProfileId: destinationLine.financialAccountProfileId,
          sourceNature: sourceLine.nature,
          destinationNature: destinationLine.nature
        });
      }
    }
    if (stryMutAct_9fa48("7010") ? false : stryMutAct_9fa48("7009") ? true : (stryCov_9fa48("7009", "7010"), entry.reversesEntryId)) {
      if (stryMutAct_9fa48("7011")) {
        {}
      } else {
        stryCov_9fa48("7011");
        view.reversesEntryId = entry.reversesEntryId;
      }
    }
    if (stryMutAct_9fa48("7013") ? false : stryMutAct_9fa48("7012") ? true : (stryCov_9fa48("7012", "7013"), links.reversedByEntryId)) {
      if (stryMutAct_9fa48("7014")) {
        {}
      } else {
        stryCov_9fa48("7014");
        view.reversedByEntryId = links.reversedByEntryId;
      }
    }
    return view;
  }
}

/** Chart of Accounts order: hierarchical codes sort as strings, so 1105 comes before 111005 and 2105. */
export function byCode(a: {
  code: string;
}, b: {
  code: string;
}): number {
  if (stryMutAct_9fa48("7015")) {
    {}
  } else {
    stryCov_9fa48("7015");
    return (stryMutAct_9fa48("7019") ? a.code >= b.code : stryMutAct_9fa48("7018") ? a.code <= b.code : stryMutAct_9fa48("7017") ? false : stryMutAct_9fa48("7016") ? true : (stryCov_9fa48("7016", "7017", "7018", "7019"), a.code < b.code)) ? stryMutAct_9fa48("7020") ? +1 : (stryCov_9fa48("7020"), -1) : (stryMutAct_9fa48("7024") ? a.code <= b.code : stryMutAct_9fa48("7023") ? a.code >= b.code : stryMutAct_9fa48("7022") ? false : stryMutAct_9fa48("7021") ? true : (stryCov_9fa48("7021", "7022", "7023", "7024"), a.code > b.code)) ? 1 : 0;
  }
}
function requireAccount(accounts: Map<string, LedgerAccount>, accountId: string): LedgerAccount {
  if (stryMutAct_9fa48("7025")) {
    {}
  } else {
    stryCov_9fa48("7025");
    const account = accounts.get(accountId);
    if (stryMutAct_9fa48("7028") ? false : stryMutAct_9fa48("7027") ? true : stryMutAct_9fa48("7026") ? account : (stryCov_9fa48("7026", "7027", "7028"), !account)) {
      if (stryMutAct_9fa48("7029")) {
        {}
      } else {
        stryCov_9fa48("7029");
        throw new AccountingError(stryMutAct_9fa48("7031") ? "" : (stryCov_9fa48("7031"), "ledger_account_not_found"));
      }
    }
    return account;
  }
}