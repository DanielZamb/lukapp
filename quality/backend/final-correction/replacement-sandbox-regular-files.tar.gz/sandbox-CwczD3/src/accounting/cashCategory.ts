// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { categorySnapshot, requireCategory } from "./categories";
import { AccountingError } from "./errors";
import type { CategorySnapshot } from "./categoryTypes";
import type { AccountingStore, CashActivityInput } from "./types";
export async function resolveCashCategory(store: Pick<AccountingStore, "getCategory">, input: Pick<CashActivityInput, "workspaceId" | "userCategoryId" | "categoryRevision" | "ledgerAccountCode">, counterpart: "expense" | "income", recorded?: CategorySnapshot): Promise<CategorySnapshot | undefined> {
  if (stryMutAct_9fa48("3457")) {
    {}
  } else {
    stryCov_9fa48("3457");
    if (stryMutAct_9fa48("3460") ? input.userCategoryId !== undefined : stryMutAct_9fa48("3459") ? false : stryMutAct_9fa48("3458") ? true : (stryCov_9fa48("3458", "3459", "3460"), input.userCategoryId === undefined)) {
      if (stryMutAct_9fa48("3461")) {
        {}
      } else {
        stryCov_9fa48("3461");
        if (stryMutAct_9fa48("3464") ? input.categoryRevision === undefined : stryMutAct_9fa48("3463") ? false : stryMutAct_9fa48("3462") ? true : (stryCov_9fa48("3462", "3463", "3464"), input.categoryRevision !== undefined)) throw new AccountingError(stryMutAct_9fa48("3466") ? "" : (stryCov_9fa48("3466"), "category_not_found"));
        return undefined;
      }
    }
    let category = recorded;
    if (stryMutAct_9fa48("3469") ? false : stryMutAct_9fa48("3468") ? true : stryMutAct_9fa48("3467") ? category : (stryCov_9fa48("3467", "3468", "3469"), !category)) {
      if (stryMutAct_9fa48("3470")) {
        {}
      } else {
        stryCov_9fa48("3470");
        const record = await requireCategory(store, input.workspaceId, input.userCategoryId);
        if (stryMutAct_9fa48("3473") ? record.status === "active" : stryMutAct_9fa48("3472") ? false : stryMutAct_9fa48("3471") ? true : (stryCov_9fa48("3471", "3472", "3473"), record.status !== (stryMutAct_9fa48("3474") ? "" : (stryCov_9fa48("3474"), "active")))) throw new AccountingError(stryMutAct_9fa48("3476") ? "" : (stryCov_9fa48("3476"), "category_inactive"));
        category = categorySnapshot(record);
      }
    }
    if (stryMutAct_9fa48("3479") ? category.nature === (counterpart === "expense" ? "Expense" : "Income") : stryMutAct_9fa48("3478") ? false : stryMutAct_9fa48("3477") ? true : (stryCov_9fa48("3477", "3478", "3479"), category.nature !== ((stryMutAct_9fa48("3482") ? counterpart !== "expense" : stryMutAct_9fa48("3481") ? false : stryMutAct_9fa48("3480") ? true : (stryCov_9fa48("3480", "3481", "3482"), counterpart === (stryMutAct_9fa48("3483") ? "" : (stryCov_9fa48("3483"), "expense")))) ? stryMutAct_9fa48("3484") ? "" : (stryCov_9fa48("3484"), "Expense") : stryMutAct_9fa48("3485") ? "" : (stryCov_9fa48("3485"), "Income")))) throw new AccountingError(stryMutAct_9fa48("3487") ? "" : (stryCov_9fa48("3487"), "category_nature_mismatch"));
    if (stryMutAct_9fa48("3490") ? input.categoryRevision !== undefined || category.revision !== input.categoryRevision : stryMutAct_9fa48("3489") ? false : stryMutAct_9fa48("3488") ? true : (stryCov_9fa48("3488", "3489", "3490"), (stryMutAct_9fa48("3492") ? input.categoryRevision === undefined : stryMutAct_9fa48("3491") ? true : (stryCov_9fa48("3491", "3492"), input.categoryRevision !== undefined)) && (stryMutAct_9fa48("3494") ? category.revision === input.categoryRevision : stryMutAct_9fa48("3493") ? true : (stryCov_9fa48("3493", "3494"), category.revision !== input.categoryRevision)))) throw new AccountingError(stryMutAct_9fa48("3496") ? "" : (stryCov_9fa48("3496"), "category_revision_stale"));
    return stryMutAct_9fa48("3497") ? {} : (stryCov_9fa48("3497"), {
      ...category,
      account: (stryMutAct_9fa48("3500") ? input.ledgerAccountCode === undefined : stryMutAct_9fa48("3499") ? false : stryMutAct_9fa48("3498") ? true : (stryCov_9fa48("3498", "3499", "3500"), input.ledgerAccountCode !== undefined)) ? stryMutAct_9fa48("3501") ? {} : (stryCov_9fa48("3501"), {
        kind: stryMutAct_9fa48("3502") ? "" : (stryCov_9fa48("3502"), "advanced"),
        accountCode: input.ledgerAccountCode
      }) : category.account
    });
  }
}