// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { commandIdentity } from "./commandIdentity";
import { AccountingError } from "./errors";
import { requireWorkspace } from "./membership";
import { assertCategoryAccount, categoryPolicy, resolveCategoryAccount, resolvePreset, suggestCategoryNature } from "./categoryPolicy";
import type { AccountingStore } from "./types";
import type { CategoryScope, CategorySnapshot, CreateCategoryInput, ChangeCategoryInput, UserCategory, CategoryClassification } from "./categoryTypes";
export async function requireCategory(store: Pick<AccountingStore, "getCategory">, workspaceId: string, id: string): Promise<UserCategory> {
  if (stryMutAct_9fa48("3503")) {
    {}
  } else {
    stryCov_9fa48("3503");
    const category = await store.getCategory(id);
    if (stryMutAct_9fa48("3506") ? !category && category.workspaceId !== workspaceId : stryMutAct_9fa48("3505") ? false : stryMutAct_9fa48("3504") ? true : (stryCov_9fa48("3504", "3505", "3506"), (stryMutAct_9fa48("3507") ? category : (stryCov_9fa48("3507"), !category)) || (stryMutAct_9fa48("3509") ? category.workspaceId === workspaceId : stryMutAct_9fa48("3508") ? false : (stryCov_9fa48("3508", "3509"), category.workspaceId !== workspaceId)))) throw new AccountingError(stryMutAct_9fa48("3511") ? "" : (stryCov_9fa48("3511"), "category_not_found"));
    return category;
  }
}
export function categorySnapshot(category: UserCategory): CategorySnapshot {
  if (stryMutAct_9fa48("3512")) {
    {}
  } else {
    stryCov_9fa48("3512");
    if (stryMutAct_9fa48("3515") ? category.classification.kind === "resolved" : stryMutAct_9fa48("3514") ? false : stryMutAct_9fa48("3513") ? true : (stryCov_9fa48("3513", "3514", "3515"), category.classification.kind !== (stryMutAct_9fa48("3516") ? "" : (stryCov_9fa48("3516"), "resolved")))) throw new AccountingError(stryMutAct_9fa48("3518") ? "" : (stryCov_9fa48("3518"), "category_unresolved"));
    return stryMutAct_9fa48("3519") ? {} : (stryCov_9fa48("3519"), {
      categoryId: category.id,
      revision: category.revision,
      name: category.name,
      nature: category.classification.nature,
      natureProvenance: category.classification.natureProvenance,
      account: category.classification.account
    });
  }
}
export async function createUserCategory(store: AccountingStore, input: CreateCategoryInput) {
  if (stryMutAct_9fa48("3520")) {
    {}
  } else {
    stryCov_9fa48("3520");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("3521") ? "" : (stryCov_9fa48("3521"), "prepare"));
    const name = stryMutAct_9fa48("3522") ? input.name : (stryCov_9fa48("3522"), input.name.trim());
    if (stryMutAct_9fa48("3525") ? false : stryMutAct_9fa48("3524") ? true : stryMutAct_9fa48("3523") ? name : (stryCov_9fa48("3523", "3524", "3525"), !name)) throw new AccountingError(stryMutAct_9fa48("3527") ? "" : (stryCov_9fa48("3527"), "name_required"));
    if (stryMutAct_9fa48("3530") ? false : stryMutAct_9fa48("3529") ? true : stryMutAct_9fa48("3528") ? input.idempotencyKey : (stryCov_9fa48("3528", "3529", "3530"), !input.idempotencyKey)) throw new AccountingError(stryMutAct_9fa48("3532") ? "" : (stryCov_9fa48("3532"), "idempotency_key_required"));
    const selection = input.selection;
    const request = commandIdentity(stryMutAct_9fa48("3533") ? {} : (stryCov_9fa48("3533"), {
      command: stryMutAct_9fa48("3534") ? "" : (stryCov_9fa48("3534"), "create"),
      name,
      selection
    }));
    const receipt = await store.getCategoryReceipt(input.workspaceId, input.idempotencyKey);
    if (stryMutAct_9fa48("3536") ? false : stryMutAct_9fa48("3535") ? true : (stryCov_9fa48("3535", "3536"), receipt)) {
      if (stryMutAct_9fa48("3537")) {
        {}
      } else {
        stryCov_9fa48("3537");
        if (stryMutAct_9fa48("3540") ? receipt.request === request : stryMutAct_9fa48("3539") ? false : stryMutAct_9fa48("3538") ? true : (stryCov_9fa48("3538", "3539", "3540"), receipt.request !== request)) throw new AccountingError(stryMutAct_9fa48("3542") ? "" : (stryCov_9fa48("3542"), "idempotency_key_conflict"));
        return stryMutAct_9fa48("3543") ? {} : (stryCov_9fa48("3543"), {
          kind: "category" as const,
          category: receipt.category,
          replay: stryMutAct_9fa48("3544") ? false : (stryCov_9fa48("3544"), true)
        });
      }
    }
    if (stryMutAct_9fa48("3547") ? selection.kind === "custom" && selection.confirmation === "lexiconConfirmed" || !suggestCategoryNature(name).suggestions.includes(selection.answer) : stryMutAct_9fa48("3546") ? false : stryMutAct_9fa48("3545") ? true : (stryCov_9fa48("3545", "3546", "3547"), (stryMutAct_9fa48("3549") ? selection.kind === "custom" || selection.confirmation === "lexiconConfirmed" : stryMutAct_9fa48("3548") ? true : (stryCov_9fa48("3548", "3549"), (stryMutAct_9fa48("3551") ? selection.kind !== "custom" : stryMutAct_9fa48("3550") ? true : (stryCov_9fa48("3550", "3551"), selection.kind === (stryMutAct_9fa48("3552") ? "" : (stryCov_9fa48("3552"), "custom")))) && (stryMutAct_9fa48("3554") ? selection.confirmation !== "lexiconConfirmed" : stryMutAct_9fa48("3553") ? true : (stryCov_9fa48("3553", "3554"), selection.confirmation === (stryMutAct_9fa48("3555") ? "" : (stryCov_9fa48("3555"), "lexiconConfirmed")))))) && (stryMutAct_9fa48("3556") ? suggestCategoryNature(name).suggestions.includes(selection.answer) : (stryCov_9fa48("3556"), !suggestCategoryNature(name).suggestions.includes(selection.answer))))) throw new AccountingError(stryMutAct_9fa48("3558") ? "" : (stryCov_9fa48("3558"), "category_suggestion_invalid"));
    if (stryMutAct_9fa48("3561") ? selection.kind === "custom" || selection.answer === "stillMine" || selection.answer === "payingDebt" : stryMutAct_9fa48("3560") ? false : stryMutAct_9fa48("3559") ? true : (stryCov_9fa48("3559", "3560", "3561"), (stryMutAct_9fa48("3563") ? selection.kind !== "custom" : stryMutAct_9fa48("3562") ? true : (stryCov_9fa48("3562", "3563"), selection.kind === (stryMutAct_9fa48("3564") ? "" : (stryCov_9fa48("3564"), "custom")))) && (stryMutAct_9fa48("3566") ? selection.answer === "stillMine" && selection.answer === "payingDebt" : stryMutAct_9fa48("3565") ? true : (stryCov_9fa48("3565", "3566"), (stryMutAct_9fa48("3568") ? selection.answer !== "stillMine" : stryMutAct_9fa48("3567") ? false : (stryCov_9fa48("3567", "3568"), selection.answer === (stryMutAct_9fa48("3569") ? "" : (stryCov_9fa48("3569"), "stillMine")))) || (stryMutAct_9fa48("3571") ? selection.answer !== "payingDebt" : stryMutAct_9fa48("3570") ? false : (stryCov_9fa48("3570", "3571"), selection.answer === (stryMutAct_9fa48("3572") ? "" : (stryCov_9fa48("3572"), "payingDebt")))))))) return stryMutAct_9fa48("3573") ? {} : (stryCov_9fa48("3573"), {
      kind: "profileRequired" as const,
      answer: selection.answer
    });
    let classification: CategoryClassification;
    if (stryMutAct_9fa48("3576") ? selection.kind !== "preset" : stryMutAct_9fa48("3575") ? false : stryMutAct_9fa48("3574") ? true : (stryCov_9fa48("3574", "3575", "3576"), selection.kind === (stryMutAct_9fa48("3577") ? "" : (stryCov_9fa48("3577"), "preset")))) classification = resolvePreset(workspace.chartOfAccountsTemplate, selection.concept);else {
      if (stryMutAct_9fa48("3578")) {
        {}
      } else {
        stryCov_9fa48("3578");
        const answer = selection.answer;
        if (stryMutAct_9fa48("3581") ? answer !== "Expense" || answer !== "Income" : stryMutAct_9fa48("3580") ? false : stryMutAct_9fa48("3579") ? true : (stryCov_9fa48("3579", "3580", "3581"), (stryMutAct_9fa48("3583") ? answer === "Expense" : stryMutAct_9fa48("3582") ? true : (stryCov_9fa48("3582", "3583"), answer !== (stryMutAct_9fa48("3584") ? "" : (stryCov_9fa48("3584"), "Expense")))) && (stryMutAct_9fa48("3586") ? answer === "Income" : stryMutAct_9fa48("3585") ? true : (stryCov_9fa48("3585", "3586"), answer !== (stryMutAct_9fa48("3587") ? "" : (stryCov_9fa48("3587"), "Income")))))) throw new AccountingError(stryMutAct_9fa48("3589") ? "" : (stryCov_9fa48("3589"), "category_nature_mismatch"));
        classification = stryMutAct_9fa48("3590") ? {} : (stryCov_9fa48("3590"), {
          kind: stryMutAct_9fa48("3591") ? "" : (stryCov_9fa48("3591"), "resolved"),
          nature: answer,
          natureProvenance: (stryMutAct_9fa48("3594") ? selection.confirmation !== "answered" : stryMutAct_9fa48("3593") ? false : stryMutAct_9fa48("3592") ? true : (stryCov_9fa48("3592", "3593", "3594"), selection.confirmation === (stryMutAct_9fa48("3595") ? "" : (stryCov_9fa48("3595"), "answered")))) ? stryMutAct_9fa48("3596") ? {} : (stryCov_9fa48("3596"), {
            kind: stryMutAct_9fa48("3597") ? "" : (stryCov_9fa48("3597"), "answered")
          }) : stryMutAct_9fa48("3598") ? {} : (stryCov_9fa48("3598"), {
            kind: stryMutAct_9fa48("3599") ? "" : (stryCov_9fa48("3599"), "lexiconConfirmed"),
            policy: categoryPolicy,
            answer
          }),
          account: resolveCategoryAccount(workspace.chartOfAccountsTemplate, name, answer)
        });
      }
    }
    const category = await store.insertCategory(stryMutAct_9fa48("3600") ? {} : (stryCov_9fa48("3600"), {
      workspaceId: input.workspaceId,
      name,
      revision: 1,
      status: stryMutAct_9fa48("3601") ? "" : (stryCov_9fa48("3601"), "active"),
      classification
    }));
    await store.saveCategoryReceipt(stryMutAct_9fa48("3602") ? {} : (stryCov_9fa48("3602"), {
      workspaceId: input.workspaceId,
      idempotencyKey: input.idempotencyKey,
      request,
      category,
      correctionEntryIds: stryMutAct_9fa48("3603") ? ["Stryker was here"] : (stryCov_9fa48("3603"), [])
    }));
    return stryMutAct_9fa48("3604") ? {} : (stryCov_9fa48("3604"), {
      kind: "category" as const,
      category,
      replay: stryMutAct_9fa48("3605") ? true : (stryCov_9fa48("3605"), false)
    });
  }
}
export async function changeUserCategory(store: AccountingStore, input: ChangeCategoryInput) {
  if (stryMutAct_9fa48("3606")) {
    {}
  } else {
    stryCov_9fa48("3606");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("3607") ? "" : (stryCov_9fa48("3607"), "prepare"));
    if (stryMutAct_9fa48("3610") ? false : stryMutAct_9fa48("3609") ? true : stryMutAct_9fa48("3608") ? input.confirmed : (stryCov_9fa48("3608", "3609", "3610"), !input.confirmed)) throw new AccountingError(stryMutAct_9fa48("3612") ? "" : (stryCov_9fa48("3612"), "category_confirmation_required"));
    if (stryMutAct_9fa48("3615") ? false : stryMutAct_9fa48("3614") ? true : stryMutAct_9fa48("3613") ? input.idempotencyKey : (stryCov_9fa48("3613", "3614", "3615"), !input.idempotencyKey)) throw new AccountingError(stryMutAct_9fa48("3617") ? "" : (stryCov_9fa48("3617"), "idempotency_key_required"));
    const request = commandIdentity(stryMutAct_9fa48("3618") ? {} : (stryCov_9fa48("3618"), {
      command: stryMutAct_9fa48("3619") ? "" : (stryCov_9fa48("3619"), "change"),
      categoryId: input.categoryId,
      revision: input.revision,
      change: input.change
    }));
    const receipt = await store.getCategoryReceipt(input.workspaceId, input.idempotencyKey);
    if (stryMutAct_9fa48("3621") ? false : stryMutAct_9fa48("3620") ? true : (stryCov_9fa48("3620", "3621"), receipt)) {
      if (stryMutAct_9fa48("3622")) {
        {}
      } else {
        stryCov_9fa48("3622");
        if (stryMutAct_9fa48("3625") ? receipt.request === request : stryMutAct_9fa48("3624") ? false : stryMutAct_9fa48("3623") ? true : (stryCov_9fa48("3623", "3624", "3625"), receipt.request !== request)) throw new AccountingError(stryMutAct_9fa48("3627") ? "" : (stryCov_9fa48("3627"), "idempotency_key_conflict"));
        return stryMutAct_9fa48("3628") ? {} : (stryCov_9fa48("3628"), {
          category: receipt.category,
          replay: stryMutAct_9fa48("3629") ? false : (stryCov_9fa48("3629"), true)
        });
      }
    }
    const category = await requireCategory(store, input.workspaceId, input.categoryId);
    if (stryMutAct_9fa48("3632") ? category.revision === input.revision : stryMutAct_9fa48("3631") ? false : stryMutAct_9fa48("3630") ? true : (stryCov_9fa48("3630", "3631", "3632"), category.revision !== input.revision)) throw new AccountingError(stryMutAct_9fa48("3634") ? "" : (stryCov_9fa48("3634"), "category_revision_stale"));
    if (stryMutAct_9fa48("3637") ? category.status === "active" : stryMutAct_9fa48("3636") ? false : stryMutAct_9fa48("3635") ? true : (stryCov_9fa48("3635", "3636", "3637"), category.status !== (stryMutAct_9fa48("3638") ? "" : (stryCov_9fa48("3638"), "active")))) throw new AccountingError(stryMutAct_9fa48("3640") ? "" : (stryCov_9fa48("3640"), "category_inactive"));
    const updated = stryMutAct_9fa48("3641") ? {} : (stryCov_9fa48("3641"), {
      ...category,
      revision: stryMutAct_9fa48("3642") ? category.revision - 1 : (stryCov_9fa48("3642"), category.revision + 1)
    });
    switch (input.change.kind) {
      case stryMutAct_9fa48("3644") ? "" : (stryCov_9fa48("3644"), "rename"):
        if (stryMutAct_9fa48("3643")) {} else {
          stryCov_9fa48("3643");
          updated.name = stryMutAct_9fa48("3645") ? input.change.name : (stryCov_9fa48("3645"), input.change.name.trim());
          if (stryMutAct_9fa48("3648") ? false : stryMutAct_9fa48("3647") ? true : stryMutAct_9fa48("3646") ? updated.name : (stryCov_9fa48("3646", "3647", "3648"), !updated.name)) throw new AccountingError(stryMutAct_9fa48("3650") ? "" : (stryCov_9fa48("3650"), "name_required"));
          break;
        }
      case stryMutAct_9fa48("3652") ? "" : (stryCov_9fa48("3652"), "archive"):
        if (stryMutAct_9fa48("3651")) {} else {
          stryCov_9fa48("3651");
          updated.status = stryMutAct_9fa48("3653") ? "" : (stryCov_9fa48("3653"), "archived");
          break;
        }
      case stryMutAct_9fa48("3655") ? "" : (stryCov_9fa48("3655"), "merge"):
        if (stryMutAct_9fa48("3654")) {} else {
          stryCov_9fa48("3654");
          {
            if (stryMutAct_9fa48("3656")) {
              {}
            } else {
              stryCov_9fa48("3656");
              const target = await requireCategory(store, input.workspaceId, input.change.targetCategoryId);
              if (stryMutAct_9fa48("3659") ? (target.id === category.id || target.status !== "active" || target.classification.kind !== "resolved" || category.classification.kind !== "resolved") && target.classification.nature !== category.classification.nature : stryMutAct_9fa48("3658") ? false : stryMutAct_9fa48("3657") ? true : (stryCov_9fa48("3657", "3658", "3659"), (stryMutAct_9fa48("3661") ? (target.id === category.id || target.status !== "active" || target.classification.kind !== "resolved") && category.classification.kind !== "resolved" : stryMutAct_9fa48("3660") ? false : (stryCov_9fa48("3660", "3661"), (stryMutAct_9fa48("3663") ? (target.id === category.id || target.status !== "active") && target.classification.kind !== "resolved" : stryMutAct_9fa48("3662") ? false : (stryCov_9fa48("3662", "3663"), (stryMutAct_9fa48("3665") ? target.id === category.id && target.status !== "active" : stryMutAct_9fa48("3664") ? false : (stryCov_9fa48("3664", "3665"), (stryMutAct_9fa48("3667") ? target.id !== category.id : stryMutAct_9fa48("3666") ? false : (stryCov_9fa48("3666", "3667"), target.id === category.id)) || (stryMutAct_9fa48("3669") ? target.status === "active" : stryMutAct_9fa48("3668") ? false : (stryCov_9fa48("3668", "3669"), target.status !== (stryMutAct_9fa48("3670") ? "" : (stryCov_9fa48("3670"), "active")))))) || (stryMutAct_9fa48("3672") ? target.classification.kind === "resolved" : stryMutAct_9fa48("3671") ? false : (stryCov_9fa48("3671", "3672"), target.classification.kind !== (stryMutAct_9fa48("3673") ? "" : (stryCov_9fa48("3673"), "resolved")))))) || (stryMutAct_9fa48("3675") ? category.classification.kind === "resolved" : stryMutAct_9fa48("3674") ? false : (stryCov_9fa48("3674", "3675"), category.classification.kind !== (stryMutAct_9fa48("3676") ? "" : (stryCov_9fa48("3676"), "resolved")))))) || (stryMutAct_9fa48("3678") ? target.classification.nature === category.classification.nature : stryMutAct_9fa48("3677") ? false : (stryCov_9fa48("3677", "3678"), target.classification.nature !== category.classification.nature)))) throw new AccountingError(stryMutAct_9fa48("3680") ? "" : (stryCov_9fa48("3680"), "category_merge_invalid"));
              updated.status = stryMutAct_9fa48("3681") ? "" : (stryCov_9fa48("3681"), "archived");
              updated.mergedIntoCategoryId = target.id;
              break;
            }
          }
        }
      case stryMutAct_9fa48("3683") ? "" : (stryCov_9fa48("3683"), "defaultAccount"):
        if (stryMutAct_9fa48("3682")) {} else {
          stryCov_9fa48("3682");
          if (stryMutAct_9fa48("3686") ? category.classification.kind === "resolved" : stryMutAct_9fa48("3685") ? false : stryMutAct_9fa48("3684") ? true : (stryCov_9fa48("3684", "3685", "3686"), category.classification.kind !== (stryMutAct_9fa48("3687") ? "" : (stryCov_9fa48("3687"), "resolved")))) throw new AccountingError(stryMutAct_9fa48("3689") ? "" : (stryCov_9fa48("3689"), "category_unresolved"));
          if (stryMutAct_9fa48("3690")) {
            ;
          } else {
            stryCov_9fa48("3690");
            assertCategoryAccount(workspace.chartOfAccountsTemplate, category.classification.nature, input.change.accountCode);
          }
          updated.classification = stryMutAct_9fa48("3691") ? {} : (stryCov_9fa48("3691"), {
            ...category.classification,
            account: stryMutAct_9fa48("3692") ? {} : (stryCov_9fa48("3692"), {
              kind: stryMutAct_9fa48("3693") ? "" : (stryCov_9fa48("3693"), "advanced"),
              accountCode: input.change.accountCode
            })
          });
          break;
        }
      default:
        if (stryMutAct_9fa48("3694")) {} else {
          stryCov_9fa48("3694");
          {
            if (stryMutAct_9fa48("3695")) {
              {}
            } else {
              stryCov_9fa48("3695");
              const exhaustive: never = input.change;
              return exhaustive;
            }
          }
        }
    }
    await store.saveCategory(updated);
    await store.saveCategoryReceipt(stryMutAct_9fa48("3696") ? {} : (stryCov_9fa48("3696"), {
      workspaceId: input.workspaceId,
      idempotencyKey: input.idempotencyKey,
      request,
      category: updated,
      correctionEntryIds: stryMutAct_9fa48("3697") ? ["Stryker was here"] : (stryCov_9fa48("3697"), [])
    }));
    return stryMutAct_9fa48("3698") ? {} : (stryCov_9fa48("3698"), {
      category: updated,
      replay: stryMutAct_9fa48("3699") ? true : (stryCov_9fa48("3699"), false)
    });
  }
}
export async function listUserCategories(store: AccountingStore, input: CategoryScope) {
  if (stryMutAct_9fa48("3700")) {
    {}
  } else {
    stryCov_9fa48("3700");
    await requireWorkspace(store, input.workspaceId, input.actor);
    return stryMutAct_9fa48("3701") ? await store.listCategories(input.workspaceId) : (stryCov_9fa48("3701"), (await store.listCategories(input.workspaceId)).sort(stryMutAct_9fa48("3702") ? () => undefined : (stryCov_9fa48("3702"), (a, b) => a.id.localeCompare(b.id))));
  }
}
export async function categoryTotals(store: AccountingStore, input: CategoryScope) {
  if (stryMutAct_9fa48("3703")) {
    {}
  } else {
    stryCov_9fa48("3703");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor);
    const totals = new Map<string, {
      categoryId: string;
      year: number;
      month: number;
      expense: number;
      income: number;
    }>();
    for (const entry of await store.listJournalEntries(input.workspaceId)) for (const line of entry.lines) {
      if (stryMutAct_9fa48("3704")) {
        {}
      } else {
        stryCov_9fa48("3704");
        if (stryMutAct_9fa48("3707") ? false : stryMutAct_9fa48("3706") ? true : stryMutAct_9fa48("3705") ? line.category : (stryCov_9fa48("3705", "3706", "3707"), !line.category)) continue;
        const key = stryMutAct_9fa48("3708") ? `` : (stryCov_9fa48("3708"), `${line.category.categoryId}:${entry.period.year}:${entry.period.month}`);
        const total = stryMutAct_9fa48("3709") ? totals.get(key) && {
          categoryId: line.category.categoryId,
          ...entry.period,
          expense: 0,
          income: 0
        } : (stryCov_9fa48("3709"), totals.get(key) ?? (stryMutAct_9fa48("3710") ? {} : (stryCov_9fa48("3710"), {
          categoryId: line.category.categoryId,
          ...entry.period,
          expense: 0,
          income: 0
        })));
        const field = (stryMutAct_9fa48("3713") ? line.category.nature !== "Expense" : stryMutAct_9fa48("3712") ? false : stryMutAct_9fa48("3711") ? true : (stryCov_9fa48("3711", "3712", "3713"), line.category.nature === (stryMutAct_9fa48("3714") ? "" : (stryCov_9fa48("3714"), "Expense")))) ? stryMutAct_9fa48("3715") ? "" : (stryCov_9fa48("3715"), "expense") : stryMutAct_9fa48("3716") ? "" : (stryCov_9fa48("3716"), "income");
        stryMutAct_9fa48("3717") ? total[field] -= field === "expense" ? line.debitMinorUnits - line.creditMinorUnits : line.creditMinorUnits - line.debitMinorUnits : (stryCov_9fa48("3717"), total[field] += (stryMutAct_9fa48("3720") ? field !== "expense" : stryMutAct_9fa48("3719") ? false : stryMutAct_9fa48("3718") ? true : (stryCov_9fa48("3718", "3719", "3720"), field === (stryMutAct_9fa48("3721") ? "" : (stryCov_9fa48("3721"), "expense")))) ? stryMutAct_9fa48("3722") ? line.debitMinorUnits + line.creditMinorUnits : (stryCov_9fa48("3722"), line.debitMinorUnits - line.creditMinorUnits) : stryMutAct_9fa48("3723") ? line.creditMinorUnits + line.debitMinorUnits : (stryCov_9fa48("3723"), line.creditMinorUnits - line.debitMinorUnits));
        if (stryMutAct_9fa48("3726") ? false : stryMutAct_9fa48("3725") ? true : stryMutAct_9fa48("3724") ? Number.isSafeInteger(total[field]) : (stryCov_9fa48("3724", "3725", "3726"), !Number.isSafeInteger(total[field]))) throw new AccountingError(stryMutAct_9fa48("3728") ? "" : (stryCov_9fa48("3728"), "journal_line_invalid"));
        if (stryMutAct_9fa48("3729")) {
          ;
        } else {
          stryCov_9fa48("3729");
          totals.set(key, total);
        }
      }
    }
    return stryMutAct_9fa48("3730") ? [...totals.values()].map(row => ({
      ...row,
      expense: {
        currency: workspace.functionalCurrency,
        minorUnits: row.expense
      },
      income: {
        currency: workspace.functionalCurrency,
        minorUnits: row.income
      }
    })) : (stryCov_9fa48("3730"), (stryMutAct_9fa48("3731") ? [] : (stryCov_9fa48("3731"), [...totals.values()])).sort(stryMutAct_9fa48("3732") ? () => undefined : (stryCov_9fa48("3732"), (a, b) => stryMutAct_9fa48("3735") ? (a.categoryId.localeCompare(b.categoryId) || a.year - b.year) && a.month - b.month : stryMutAct_9fa48("3734") ? false : stryMutAct_9fa48("3733") ? true : (stryCov_9fa48("3733", "3734", "3735"), (stryMutAct_9fa48("3737") ? a.categoryId.localeCompare(b.categoryId) && a.year - b.year : stryMutAct_9fa48("3736") ? false : (stryCov_9fa48("3736", "3737"), a.categoryId.localeCompare(b.categoryId) || (stryMutAct_9fa48("3738") ? a.year + b.year : (stryCov_9fa48("3738"), a.year - b.year)))) || (stryMutAct_9fa48("3739") ? a.month + b.month : (stryCov_9fa48("3739"), a.month - b.month))))).map(stryMutAct_9fa48("3740") ? () => undefined : (stryCov_9fa48("3740"), row => stryMutAct_9fa48("3741") ? {} : (stryCov_9fa48("3741"), {
      ...row,
      expense: stryMutAct_9fa48("3742") ? {} : (stryCov_9fa48("3742"), {
        currency: workspace.functionalCurrency,
        minorUnits: row.expense
      }),
      income: stryMutAct_9fa48("3743") ? {} : (stryCov_9fa48("3743"), {
        currency: workspace.functionalCurrency,
        minorUnits: row.income
      })
    }))));
  }
}
export async function categoryNatureSuggestion(store: AccountingStore, input: CategoryScope & {
  name: string;
}) {
  if (stryMutAct_9fa48("3744")) {
    {}
  } else {
    stryCov_9fa48("3744");
    await requireWorkspace(store, input.workspaceId, input.actor);
    return suggestCategoryNature(input.name);
  }
}