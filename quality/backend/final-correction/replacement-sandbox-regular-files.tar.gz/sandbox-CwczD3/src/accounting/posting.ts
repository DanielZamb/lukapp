// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { commandIdentity } from "./commandIdentity";
import { assertOpeningDates } from "./openingDate";
import { AccountingError } from "./errors";
import { requireWorkspace } from "./membership";
import { periodFromAccountingDate } from "./period";
import { requirePostablePeriod } from "./periodControl";
import type { AccountingClock, AccountingStore, Actor, DraftJournalLine, JournalEntryDraft, StoredJournalEntry } from "./types";
export type PostingResult = {
  entry: StoredJournalEntry;
  replay: boolean;
};
export async function postJournalEntry(store: AccountingStore, clock: AccountingClock, input: {
  actor: Actor;
  workspaceId: string;
  draft: JournalEntryDraft;
}): Promise<PostingResult> {
  if (stryMutAct_9fa48("5146")) {
    {}
  } else {
    stryCov_9fa48("5146");
    const {
      draft
    } = input;
    await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("5147") ? "" : (stryCov_9fa48("5147"), "post"));
    if (stryMutAct_9fa48("5150") ? false : stryMutAct_9fa48("5149") ? true : stryMutAct_9fa48("5148") ? draft.idempotencyKey : (stryCov_9fa48("5148", "5149", "5150"), !draft.idempotencyKey)) {
      if (stryMutAct_9fa48("5151")) {
        {}
      } else {
        stryCov_9fa48("5151");
        throw new AccountingError(stryMutAct_9fa48("5153") ? "" : (stryCov_9fa48("5153"), "idempotency_key_required"));
      }
    }
    const existing = await store.findJournalEntryByIdempotencyKey(input.workspaceId, draft.idempotencyKey);
    if (stryMutAct_9fa48("5155") ? false : stryMutAct_9fa48("5154") ? true : (stryCov_9fa48("5154", "5155"), existing)) {
      if (stryMutAct_9fa48("5156")) {
        {}
      } else {
        stryCov_9fa48("5156");
        if (stryMutAct_9fa48("5159") ? false : stryMutAct_9fa48("5158") ? true : stryMutAct_9fa48("5157") ? sameDraft(existing, draft) : (stryCov_9fa48("5157", "5158", "5159"), !sameDraft(existing, draft))) {
          if (stryMutAct_9fa48("5160")) {
            {}
          } else {
            stryCov_9fa48("5160");
            throw new AccountingError(stryMutAct_9fa48("5162") ? "" : (stryCov_9fa48("5162"), "idempotency_key_conflict"));
          }
        }
        return stryMutAct_9fa48("5163") ? {} : (stryCov_9fa48("5163"), {
          entry: existing,
          replay: stryMutAct_9fa48("5164") ? false : (stryCov_9fa48("5164"), true)
        });
      }
    }
    if (stryMutAct_9fa48("5166") ? false : stryMutAct_9fa48("5165") ? true : (stryCov_9fa48("5165", "5166"), await store.findOpeningPositionByKey(input.workspaceId, draft.idempotencyKey))) {
      if (stryMutAct_9fa48("5167")) {
        {}
      } else {
        stryCov_9fa48("5167");
        throw new AccountingError(stryMutAct_9fa48("5169") ? "" : (stryCov_9fa48("5169"), "idempotency_key_conflict"));
      }
    }
    if (stryMutAct_9fa48("5170")) {
      ;
    } else {
      stryCov_9fa48("5170");
      assertBalancedLines(draft.lines);
    }
    await assertPostingAccounts(store, input.workspaceId, draft.lines);
    await assertLinkedRecords(store, input.workspaceId, draft);
    const period = periodFromAccountingDate(draft.accountingDate);
    await assertOpeningDates(store, input.workspaceId, draft);
    await requirePostablePeriod(store, input.workspaceId, draft.accountingDate);
    const entry = await store.insertJournalEntry(stryMutAct_9fa48("5171") ? {} : (stryCov_9fa48("5171"), {
      ...draft,
      workspaceId: input.workspaceId,
      period,
      postedBy: input.actor.userId,
      postedAt: clock.now().getTime()
    }));
    return stryMutAct_9fa48("5172") ? {} : (stryCov_9fa48("5172"), {
      entry,
      replay: stryMutAct_9fa48("5173") ? true : (stryCov_9fa48("5173"), false)
    });
  }
}

/** Minimum completeness, one positive side per line, and debits equal to credits. */
export function assertBalancedLines(lines: DraftJournalLine[]): void {
  if (stryMutAct_9fa48("5174")) {
    {}
  } else {
    stryCov_9fa48("5174");
    if (stryMutAct_9fa48("5178") ? lines.length >= 2 : stryMutAct_9fa48("5177") ? lines.length <= 2 : stryMutAct_9fa48("5176") ? false : stryMutAct_9fa48("5175") ? true : (stryCov_9fa48("5175", "5176", "5177", "5178"), lines.length < 2)) {
      if (stryMutAct_9fa48("5179")) {
        {}
      } else {
        stryCov_9fa48("5179");
        throw new AccountingError(stryMutAct_9fa48("5181") ? "" : (stryCov_9fa48("5181"), "journal_entry_incomplete"));
      }
    }
    let debit = 0;
    let credit = 0;
    for (const line of lines) {
      if (stryMutAct_9fa48("5182")) {
        {}
      } else {
        stryCov_9fa48("5182");
        const {
          debitMinorUnits: d,
          creditMinorUnits: c
        } = line;
        if (stryMutAct_9fa48("5185") ? (!Number.isSafeInteger(d) || !Number.isSafeInteger(c) || d < 0 || c < 0) && d > 0 === c > 0 : stryMutAct_9fa48("5184") ? false : stryMutAct_9fa48("5183") ? true : (stryCov_9fa48("5183", "5184", "5185"), (stryMutAct_9fa48("5187") ? (!Number.isSafeInteger(d) || !Number.isSafeInteger(c) || d < 0) && c < 0 : stryMutAct_9fa48("5186") ? false : (stryCov_9fa48("5186", "5187"), (stryMutAct_9fa48("5189") ? (!Number.isSafeInteger(d) || !Number.isSafeInteger(c)) && d < 0 : stryMutAct_9fa48("5188") ? false : (stryCov_9fa48("5188", "5189"), (stryMutAct_9fa48("5191") ? !Number.isSafeInteger(d) && !Number.isSafeInteger(c) : stryMutAct_9fa48("5190") ? false : (stryCov_9fa48("5190", "5191"), (stryMutAct_9fa48("5192") ? Number.isSafeInteger(d) : (stryCov_9fa48("5192"), !Number.isSafeInteger(d))) || (stryMutAct_9fa48("5193") ? Number.isSafeInteger(c) : (stryCov_9fa48("5193"), !Number.isSafeInteger(c))))) || (stryMutAct_9fa48("5196") ? d >= 0 : stryMutAct_9fa48("5195") ? d <= 0 : stryMutAct_9fa48("5194") ? false : (stryCov_9fa48("5194", "5195", "5196"), d < 0)))) || (stryMutAct_9fa48("5199") ? c >= 0 : stryMutAct_9fa48("5198") ? c <= 0 : stryMutAct_9fa48("5197") ? false : (stryCov_9fa48("5197", "5198", "5199"), c < 0)))) || (stryMutAct_9fa48("5201") ? d > 0 !== c > 0 : stryMutAct_9fa48("5200") ? false : (stryCov_9fa48("5200", "5201"), (stryMutAct_9fa48("5205") ? d <= 0 : stryMutAct_9fa48("5204") ? d >= 0 : stryMutAct_9fa48("5203") ? false : stryMutAct_9fa48("5202") ? true : (stryCov_9fa48("5202", "5203", "5204", "5205"), d > 0)) === (stryMutAct_9fa48("5209") ? c <= 0 : stryMutAct_9fa48("5208") ? c >= 0 : stryMutAct_9fa48("5207") ? false : stryMutAct_9fa48("5206") ? true : (stryCov_9fa48("5206", "5207", "5208", "5209"), c > 0)))))) {
          if (stryMutAct_9fa48("5210")) {
            {}
          } else {
            stryCov_9fa48("5210");
            throw new AccountingError(stryMutAct_9fa48("5212") ? "" : (stryCov_9fa48("5212"), "journal_line_invalid"));
          }
        }
        stryMutAct_9fa48("5213") ? debit -= d : (stryCov_9fa48("5213"), debit += d);
        stryMutAct_9fa48("5214") ? credit -= c : (stryCov_9fa48("5214"), credit += c);
      }
    }
    if (stryMutAct_9fa48("5217") ? !Number.isSafeInteger(debit) && debit !== credit : stryMutAct_9fa48("5216") ? false : stryMutAct_9fa48("5215") ? true : (stryCov_9fa48("5215", "5216", "5217"), (stryMutAct_9fa48("5218") ? Number.isSafeInteger(debit) : (stryCov_9fa48("5218"), !Number.isSafeInteger(debit))) || (stryMutAct_9fa48("5220") ? debit === credit : stryMutAct_9fa48("5219") ? false : (stryCov_9fa48("5219", "5220"), debit !== credit)))) {
      if (stryMutAct_9fa48("5221")) {
        {}
      } else {
        stryCov_9fa48("5221");
        throw new AccountingError(stryMutAct_9fa48("5223") ? "" : (stryCov_9fa48("5223"), "posted_journal_entry_unbalanced"));
      }
    }
  }
}
async function assertPostingAccounts(store: AccountingStore, workspaceId: string, lines: DraftJournalLine[]): Promise<void> {
  if (stryMutAct_9fa48("5224")) {
    {}
  } else {
    stryCov_9fa48("5224");
    for (const line of lines) {
      if (stryMutAct_9fa48("5225")) {
        {}
      } else {
        stryCov_9fa48("5225");
        const account = await store.getLedgerAccount(line.ledgerAccountId);
        if (stryMutAct_9fa48("5228") ? !account && account.workspaceId !== workspaceId : stryMutAct_9fa48("5227") ? false : stryMutAct_9fa48("5226") ? true : (stryCov_9fa48("5226", "5227", "5228"), (stryMutAct_9fa48("5229") ? account : (stryCov_9fa48("5229"), !account)) || (stryMutAct_9fa48("5231") ? account.workspaceId === workspaceId : stryMutAct_9fa48("5230") ? false : (stryCov_9fa48("5230", "5231"), account.workspaceId !== workspaceId)))) {
          if (stryMutAct_9fa48("5232")) {
            {}
          } else {
            stryCov_9fa48("5232");
            throw new AccountingError(stryMutAct_9fa48("5234") ? "" : (stryCov_9fa48("5234"), "ledger_account_not_found"));
          }
        }
      }
    }
  }
}
async function assertLinkedRecords(store: AccountingStore, workspaceId: string, draft: JournalEntryDraft): Promise<void> {
  if (stryMutAct_9fa48("5235")) {
    {}
  } else {
    stryCov_9fa48("5235");
    for (const effect of stryMutAct_9fa48("5236") ? draft.sourceExpenseEffects && [] : (stryCov_9fa48("5236"), draft.sourceExpenseEffects ?? (stryMutAct_9fa48("5237") ? ["Stryker was here"] : (stryCov_9fa48("5237"), [])))) {
      if (stryMutAct_9fa48("5238")) {
        {}
      } else {
        stryCov_9fa48("5238");
        const source = await store.getJournalEntry(effect.sourceEntryId);
        if (stryMutAct_9fa48("5241") ? (!source || source.workspaceId !== workspaceId) && source.policy !== "cash-expense@1" && source.policy !== "cash-income@1" : stryMutAct_9fa48("5240") ? false : stryMutAct_9fa48("5239") ? true : (stryCov_9fa48("5239", "5240", "5241"), (stryMutAct_9fa48("5243") ? !source && source.workspaceId !== workspaceId : stryMutAct_9fa48("5242") ? false : (stryCov_9fa48("5242", "5243"), (stryMutAct_9fa48("5244") ? source : (stryCov_9fa48("5244"), !source)) || (stryMutAct_9fa48("5246") ? source.workspaceId === workspaceId : stryMutAct_9fa48("5245") ? false : (stryCov_9fa48("5245", "5246"), source.workspaceId !== workspaceId)))) || (stryMutAct_9fa48("5248") ? source.policy !== "cash-expense@1" || source.policy !== "cash-income@1" : stryMutAct_9fa48("5247") ? false : (stryCov_9fa48("5247", "5248"), (stryMutAct_9fa48("5250") ? source.policy === "cash-expense@1" : stryMutAct_9fa48("5249") ? true : (stryCov_9fa48("5249", "5250"), source.policy !== (stryMutAct_9fa48("5251") ? "" : (stryCov_9fa48("5251"), "cash-expense@1")))) && (stryMutAct_9fa48("5253") ? source.policy === "cash-income@1" : stryMutAct_9fa48("5252") ? true : (stryCov_9fa48("5252", "5253"), source.policy !== (stryMutAct_9fa48("5254") ? "" : (stryCov_9fa48("5254"), "cash-income@1")))))))) throw new AccountingError(stryMutAct_9fa48("5256") ? "" : (stryCov_9fa48("5256"), "journal_entry_not_found"));
        if (stryMutAct_9fa48("5259") ? false : stryMutAct_9fa48("5258") ? true : stryMutAct_9fa48("5257") ? Number.isSafeInteger(effect.expenseDeltaMinorUnits) : (stryCov_9fa48("5257", "5258", "5259"), !Number.isSafeInteger(effect.expenseDeltaMinorUnits))) throw new AccountingError(stryMutAct_9fa48("5261") ? "" : (stryCov_9fa48("5261"), "journal_line_invalid"));
      }
    }
    for (const line of draft.lines) {
      if (stryMutAct_9fa48("5262")) {
        {}
      } else {
        stryCov_9fa48("5262");
        if (stryMutAct_9fa48("5264") ? false : stryMutAct_9fa48("5263") ? true : (stryCov_9fa48("5263", "5264"), line.category)) {
          if (stryMutAct_9fa48("5265")) {
            {}
          } else {
            stryCov_9fa48("5265");
            const category = await store.getCategory(line.category.categoryId);
            if (stryMutAct_9fa48("5268") ? !category && category.workspaceId !== workspaceId : stryMutAct_9fa48("5267") ? false : stryMutAct_9fa48("5266") ? true : (stryCov_9fa48("5266", "5267", "5268"), (stryMutAct_9fa48("5269") ? category : (stryCov_9fa48("5269"), !category)) || (stryMutAct_9fa48("5271") ? category.workspaceId === workspaceId : stryMutAct_9fa48("5270") ? false : (stryCov_9fa48("5270", "5271"), category.workspaceId !== workspaceId)))) throw new AccountingError(stryMutAct_9fa48("5273") ? "" : (stryCov_9fa48("5273"), "category_not_found"));
          }
        }
        for (const ref of stryMutAct_9fa48("5274") ? line.categoryCorrection?.sources && [] : (stryCov_9fa48("5274"), (stryMutAct_9fa48("5275") ? line.categoryCorrection.sources : (stryCov_9fa48("5275"), line.categoryCorrection?.sources)) ?? (stryMutAct_9fa48("5276") ? ["Stryker was here"] : (stryCov_9fa48("5276"), [])))) {
          if (stryMutAct_9fa48("5277")) {
            {}
          } else {
            stryCov_9fa48("5277");
            const source = await store.getJournalEntry(ref.entryId);
            if (stryMutAct_9fa48("5280") ? (!source || source.workspaceId !== workspaceId) && !source.lines[ref.lineNumber] : stryMutAct_9fa48("5279") ? false : stryMutAct_9fa48("5278") ? true : (stryCov_9fa48("5278", "5279", "5280"), (stryMutAct_9fa48("5282") ? !source && source.workspaceId !== workspaceId : stryMutAct_9fa48("5281") ? false : (stryCov_9fa48("5281", "5282"), (stryMutAct_9fa48("5283") ? source : (stryCov_9fa48("5283"), !source)) || (stryMutAct_9fa48("5285") ? source.workspaceId === workspaceId : stryMutAct_9fa48("5284") ? false : (stryCov_9fa48("5284", "5285"), source.workspaceId !== workspaceId)))) || (stryMutAct_9fa48("5286") ? source.lines[ref.lineNumber] : (stryCov_9fa48("5286"), !source.lines[ref.lineNumber])))) throw new AccountingError(stryMutAct_9fa48("5288") ? "" : (stryCov_9fa48("5288"), "journal_entry_not_found"));
          }
        }
      }
    }
    if (stryMutAct_9fa48("5291") ? draft.financialAccountProfileId === undefined : stryMutAct_9fa48("5290") ? false : stryMutAct_9fa48("5289") ? true : (stryCov_9fa48("5289", "5290", "5291"), draft.financialAccountProfileId !== undefined)) {
      if (stryMutAct_9fa48("5292")) {
        {}
      } else {
        stryCov_9fa48("5292");
        const profile = await store.getProfile(draft.financialAccountProfileId);
        if (stryMutAct_9fa48("5295") ? !profile && profile.workspaceId !== workspaceId : stryMutAct_9fa48("5294") ? false : stryMutAct_9fa48("5293") ? true : (stryCov_9fa48("5293", "5294", "5295"), (stryMutAct_9fa48("5296") ? profile : (stryCov_9fa48("5296"), !profile)) || (stryMutAct_9fa48("5298") ? profile.workspaceId === workspaceId : stryMutAct_9fa48("5297") ? false : (stryCov_9fa48("5297", "5298"), profile.workspaceId !== workspaceId)))) {
          if (stryMutAct_9fa48("5299")) {
            {}
          } else {
            stryCov_9fa48("5299");
            throw new AccountingError(stryMutAct_9fa48("5301") ? "" : (stryCov_9fa48("5301"), "financial_account_profile_not_found"));
          }
        }
      }
    }
    if (stryMutAct_9fa48("5304") ? draft.reversesEntryId === undefined : stryMutAct_9fa48("5303") ? false : stryMutAct_9fa48("5302") ? true : (stryCov_9fa48("5302", "5303", "5304"), draft.reversesEntryId !== undefined)) {
      if (stryMutAct_9fa48("5305")) {
        {}
      } else {
        stryCov_9fa48("5305");
        const reversed = await store.getJournalEntry(draft.reversesEntryId);
        if (stryMutAct_9fa48("5308") ? !reversed && reversed.workspaceId !== workspaceId : stryMutAct_9fa48("5307") ? false : stryMutAct_9fa48("5306") ? true : (stryCov_9fa48("5306", "5307", "5308"), (stryMutAct_9fa48("5309") ? reversed : (stryCov_9fa48("5309"), !reversed)) || (stryMutAct_9fa48("5311") ? reversed.workspaceId === workspaceId : stryMutAct_9fa48("5310") ? false : (stryCov_9fa48("5310", "5311"), reversed.workspaceId !== workspaceId)))) {
          if (stryMutAct_9fa48("5312")) {
            {}
          } else {
            stryCov_9fa48("5312");
            throw new AccountingError(stryMutAct_9fa48("5314") ? "" : (stryCov_9fa48("5314"), "journal_entry_not_found"));
          }
        }
      }
    }
  }
}
function sameDraft(entry: StoredJournalEntry, draft: JournalEntryDraft): boolean {
  if (stryMutAct_9fa48("5315")) {
    {}
  } else {
    stryCov_9fa48("5315");
    return stryMutAct_9fa48("5318") ? entry.accountingDate === draft.accountingDate && entry.description === draft.description && entry.policy === draft.policy && commandIdentity(entry.cashCategoryInput) === commandIdentity(draft.cashCategoryInput) && commandIdentity(entry.sourceExpenseEffects) === commandIdentity(draft.sourceExpenseEffects) && entry.financialAccountProfileId === draft.financialAccountProfileId && entry.reversesEntryId === draft.reversesEntryId && entry.lines.length === draft.lines.length || entry.lines.every((line, index) => {
      const other = draft.lines[index];
      return other !== undefined && commandIdentity(line.category) === commandIdentity(other.category) && commandIdentity(line.categoryCorrection) === commandIdentity(other.categoryCorrection) && line.ledgerAccountId === other.ledgerAccountId && line.debitMinorUnits === other.debitMinorUnits && line.creditMinorUnits === other.creditMinorUnits;
    }) : stryMutAct_9fa48("5317") ? false : stryMutAct_9fa48("5316") ? true : (stryCov_9fa48("5316", "5317", "5318"), (stryMutAct_9fa48("5320") ? entry.accountingDate === draft.accountingDate && entry.description === draft.description && entry.policy === draft.policy && commandIdentity(entry.cashCategoryInput) === commandIdentity(draft.cashCategoryInput) && commandIdentity(entry.sourceExpenseEffects) === commandIdentity(draft.sourceExpenseEffects) && entry.financialAccountProfileId === draft.financialAccountProfileId && entry.reversesEntryId === draft.reversesEntryId || entry.lines.length === draft.lines.length : stryMutAct_9fa48("5319") ? true : (stryCov_9fa48("5319", "5320"), (stryMutAct_9fa48("5322") ? entry.accountingDate === draft.accountingDate && entry.description === draft.description && entry.policy === draft.policy && commandIdentity(entry.cashCategoryInput) === commandIdentity(draft.cashCategoryInput) && commandIdentity(entry.sourceExpenseEffects) === commandIdentity(draft.sourceExpenseEffects) && entry.financialAccountProfileId === draft.financialAccountProfileId || entry.reversesEntryId === draft.reversesEntryId : stryMutAct_9fa48("5321") ? true : (stryCov_9fa48("5321", "5322"), (stryMutAct_9fa48("5324") ? entry.accountingDate === draft.accountingDate && entry.description === draft.description && entry.policy === draft.policy && commandIdentity(entry.cashCategoryInput) === commandIdentity(draft.cashCategoryInput) && commandIdentity(entry.sourceExpenseEffects) === commandIdentity(draft.sourceExpenseEffects) || entry.financialAccountProfileId === draft.financialAccountProfileId : stryMutAct_9fa48("5323") ? true : (stryCov_9fa48("5323", "5324"), (stryMutAct_9fa48("5326") ? entry.accountingDate === draft.accountingDate && entry.description === draft.description && entry.policy === draft.policy && commandIdentity(entry.cashCategoryInput) === commandIdentity(draft.cashCategoryInput) || commandIdentity(entry.sourceExpenseEffects) === commandIdentity(draft.sourceExpenseEffects) : stryMutAct_9fa48("5325") ? true : (stryCov_9fa48("5325", "5326"), (stryMutAct_9fa48("5328") ? entry.accountingDate === draft.accountingDate && entry.description === draft.description && entry.policy === draft.policy || commandIdentity(entry.cashCategoryInput) === commandIdentity(draft.cashCategoryInput) : stryMutAct_9fa48("5327") ? true : (stryCov_9fa48("5327", "5328"), (stryMutAct_9fa48("5330") ? entry.accountingDate === draft.accountingDate && entry.description === draft.description || entry.policy === draft.policy : stryMutAct_9fa48("5329") ? true : (stryCov_9fa48("5329", "5330"), (stryMutAct_9fa48("5332") ? entry.accountingDate === draft.accountingDate || entry.description === draft.description : stryMutAct_9fa48("5331") ? true : (stryCov_9fa48("5331", "5332"), (stryMutAct_9fa48("5334") ? entry.accountingDate !== draft.accountingDate : stryMutAct_9fa48("5333") ? true : (stryCov_9fa48("5333", "5334"), entry.accountingDate === draft.accountingDate)) && (stryMutAct_9fa48("5336") ? entry.description !== draft.description : stryMutAct_9fa48("5335") ? true : (stryCov_9fa48("5335", "5336"), entry.description === draft.description)))) && (stryMutAct_9fa48("5338") ? entry.policy !== draft.policy : stryMutAct_9fa48("5337") ? true : (stryCov_9fa48("5337", "5338"), entry.policy === draft.policy)))) && (stryMutAct_9fa48("5340") ? commandIdentity(entry.cashCategoryInput) !== commandIdentity(draft.cashCategoryInput) : stryMutAct_9fa48("5339") ? true : (stryCov_9fa48("5339", "5340"), commandIdentity(entry.cashCategoryInput) === commandIdentity(draft.cashCategoryInput))))) && (stryMutAct_9fa48("5342") ? commandIdentity(entry.sourceExpenseEffects) !== commandIdentity(draft.sourceExpenseEffects) : stryMutAct_9fa48("5341") ? true : (stryCov_9fa48("5341", "5342"), commandIdentity(entry.sourceExpenseEffects) === commandIdentity(draft.sourceExpenseEffects))))) && (stryMutAct_9fa48("5344") ? entry.financialAccountProfileId !== draft.financialAccountProfileId : stryMutAct_9fa48("5343") ? true : (stryCov_9fa48("5343", "5344"), entry.financialAccountProfileId === draft.financialAccountProfileId)))) && (stryMutAct_9fa48("5346") ? entry.reversesEntryId !== draft.reversesEntryId : stryMutAct_9fa48("5345") ? true : (stryCov_9fa48("5345", "5346"), entry.reversesEntryId === draft.reversesEntryId)))) && (stryMutAct_9fa48("5348") ? entry.lines.length !== draft.lines.length : stryMutAct_9fa48("5347") ? true : (stryCov_9fa48("5347", "5348"), entry.lines.length === draft.lines.length)))) && (stryMutAct_9fa48("5349") ? entry.lines.some((line, index) => {
      const other = draft.lines[index];
      return other !== undefined && commandIdentity(line.category) === commandIdentity(other.category) && commandIdentity(line.categoryCorrection) === commandIdentity(other.categoryCorrection) && line.ledgerAccountId === other.ledgerAccountId && line.debitMinorUnits === other.debitMinorUnits && line.creditMinorUnits === other.creditMinorUnits;
    }) : (stryCov_9fa48("5349"), entry.lines.every((line, index) => {
      if (stryMutAct_9fa48("5350")) {
        {}
      } else {
        stryCov_9fa48("5350");
        const other = draft.lines[index];
        return stryMutAct_9fa48("5353") ? other !== undefined && commandIdentity(line.category) === commandIdentity(other.category) && commandIdentity(line.categoryCorrection) === commandIdentity(other.categoryCorrection) && line.ledgerAccountId === other.ledgerAccountId && line.debitMinorUnits === other.debitMinorUnits || line.creditMinorUnits === other.creditMinorUnits : stryMutAct_9fa48("5352") ? false : stryMutAct_9fa48("5351") ? true : (stryCov_9fa48("5351", "5352", "5353"), (stryMutAct_9fa48("5355") ? other !== undefined && commandIdentity(line.category) === commandIdentity(other.category) && commandIdentity(line.categoryCorrection) === commandIdentity(other.categoryCorrection) && line.ledgerAccountId === other.ledgerAccountId || line.debitMinorUnits === other.debitMinorUnits : stryMutAct_9fa48("5354") ? true : (stryCov_9fa48("5354", "5355"), (stryMutAct_9fa48("5357") ? other !== undefined && commandIdentity(line.category) === commandIdentity(other.category) && commandIdentity(line.categoryCorrection) === commandIdentity(other.categoryCorrection) || line.ledgerAccountId === other.ledgerAccountId : stryMutAct_9fa48("5356") ? true : (stryCov_9fa48("5356", "5357"), (stryMutAct_9fa48("5359") ? other !== undefined && commandIdentity(line.category) === commandIdentity(other.category) || commandIdentity(line.categoryCorrection) === commandIdentity(other.categoryCorrection) : stryMutAct_9fa48("5358") ? true : (stryCov_9fa48("5358", "5359"), (stryMutAct_9fa48("5361") ? other !== undefined || commandIdentity(line.category) === commandIdentity(other.category) : stryMutAct_9fa48("5360") ? true : (stryCov_9fa48("5360", "5361"), (stryMutAct_9fa48("5363") ? other === undefined : stryMutAct_9fa48("5362") ? true : (stryCov_9fa48("5362", "5363"), other !== undefined)) && (stryMutAct_9fa48("5365") ? commandIdentity(line.category) !== commandIdentity(other.category) : stryMutAct_9fa48("5364") ? true : (stryCov_9fa48("5364", "5365"), commandIdentity(line.category) === commandIdentity(other.category))))) && (stryMutAct_9fa48("5367") ? commandIdentity(line.categoryCorrection) !== commandIdentity(other.categoryCorrection) : stryMutAct_9fa48("5366") ? true : (stryCov_9fa48("5366", "5367"), commandIdentity(line.categoryCorrection) === commandIdentity(other.categoryCorrection))))) && (stryMutAct_9fa48("5369") ? line.ledgerAccountId !== other.ledgerAccountId : stryMutAct_9fa48("5368") ? true : (stryCov_9fa48("5368", "5369"), line.ledgerAccountId === other.ledgerAccountId)))) && (stryMutAct_9fa48("5371") ? line.debitMinorUnits !== other.debitMinorUnits : stryMutAct_9fa48("5370") ? true : (stryCov_9fa48("5370", "5371"), line.debitMinorUnits === other.debitMinorUnits)))) && (stryMutAct_9fa48("5373") ? line.creditMinorUnits !== other.creditMinorUnits : stryMutAct_9fa48("5372") ? true : (stryCov_9fa48("5372", "5373"), line.creditMinorUnits === other.creditMinorUnits)));
      }
    }))));
  }
}