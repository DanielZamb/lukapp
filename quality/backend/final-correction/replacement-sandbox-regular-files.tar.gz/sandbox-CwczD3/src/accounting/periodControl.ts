// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "./errors";
import { firstDayOf, nextPeriod, periodFromAccountingDate } from "./period";
import type { AccountingPeriod, AccountingStore, PeriodKey } from "./types";

/** An Accounting Period opens the first time an entry is dated into it. */
export async function ensureOpenPeriod(store: AccountingStore, workspaceId: string, period: PeriodKey): Promise<AccountingPeriod> {
  if (stryMutAct_9fa48("5095")) {
    {}
  } else {
    stryCov_9fa48("5095");
    const stored = await store.getAccountingPeriod(workspaceId, period);
    if (stryMutAct_9fa48("5097") ? false : stryMutAct_9fa48("5096") ? true : (stryCov_9fa48("5096", "5097"), stored)) {
      if (stryMutAct_9fa48("5098")) {
        {}
      } else {
        stryCov_9fa48("5098");
        return stored;
      }
    }
    return store.insertAccountingPeriod(workspaceId, stryMutAct_9fa48("5099") ? {} : (stryCov_9fa48("5099"), {
      ...period,
      status: stryMutAct_9fa48("5100") ? "" : (stryCov_9fa48("5100"), "open")
    }));
  }
}
export async function requirePostablePeriod(store: AccountingStore, workspaceId: string, accountingDate: string): Promise<AccountingPeriod> {
  if (stryMutAct_9fa48("5101")) {
    {}
  } else {
    stryCov_9fa48("5101");
    const period = await ensureOpenPeriod(store, workspaceId, periodFromAccountingDate(accountingDate));
    if (stryMutAct_9fa48("5104") ? period.status !== "locked" : stryMutAct_9fa48("5103") ? false : stryMutAct_9fa48("5102") ? true : (stryCov_9fa48("5102", "5103", "5104"), period.status === (stryMutAct_9fa48("5105") ? "" : (stryCov_9fa48("5105"), "locked")))) {
      if (stryMutAct_9fa48("5106")) {
        {}
      } else {
        stryCov_9fa48("5106");
        throw new AccountingError(stryMutAct_9fa48("5108") ? "" : (stryCov_9fa48("5108"), "locked_period"));
      }
    }
    return period;
  }
}

/**
 * The date itself when its period is open; otherwise the first day of the next
 * period that is not locked (primer invariant 35).
 */
export async function earliestPermittedDate(store: AccountingStore, workspaceId: string, accountingDate: string): Promise<string> {
  if (stryMutAct_9fa48("5109")) {
    {}
  } else {
    stryCov_9fa48("5109");
    let period = periodFromAccountingDate(accountingDate);
    let candidate = accountingDate;
    if (stryMutAct_9fa48("5110")) {
      for (; false;) {
        const stored = await store.getAccountingPeriod(workspaceId, period);
        if (stored?.status !== "locked") {
          return candidate;
        }
        period = nextPeriod(period);
        candidate = firstDayOf(period);
      }
    } else {
      stryCov_9fa48("5110");
      for (;;) {
        if (stryMutAct_9fa48("5111")) {
          {}
        } else {
          stryCov_9fa48("5111");
          const stored = await store.getAccountingPeriod(workspaceId, period);
          if (stryMutAct_9fa48("5114") ? stored?.status === "locked" : stryMutAct_9fa48("5113") ? false : stryMutAct_9fa48("5112") ? true : (stryCov_9fa48("5112", "5113", "5114"), (stryMutAct_9fa48("5115") ? stored.status : (stryCov_9fa48("5115"), stored?.status)) !== (stryMutAct_9fa48("5116") ? "" : (stryCov_9fa48("5116"), "locked")))) {
            if (stryMutAct_9fa48("5117")) {
              {}
            } else {
              stryCov_9fa48("5117");
              return candidate;
            }
          }
          period = nextPeriod(period);
          candidate = firstDayOf(period);
        }
      }
    }
  }
}