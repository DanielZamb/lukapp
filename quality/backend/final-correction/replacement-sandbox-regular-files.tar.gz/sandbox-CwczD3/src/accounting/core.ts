// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { createUserCategory, changeUserCategory, listUserCategories, categoryTotals, categoryNatureSuggestion } from "./categories";
import { previewCategoryReclassification, confirmCategoryReclassification } from "./reclassification";
import { createHouseholdWorkspace } from "./commands/createHouseholdWorkspace";
import { listOwnedWorkspaces } from "./queries/listOwnedWorkspaces";
import { recordAccountTransfer } from "./commands/recordAccountTransfer";
import { recordOpeningPosition } from "./commands/recordOpeningPosition";
import { setupFinancialAccount } from "./commands/setupFinancialAccount";
import { createFinancialAccountProfile } from "./commands/createFinancialAccountProfile";
import { createPersonalWorkspace } from "./commands/createPersonalWorkspace";
import { lockAccountingPeriod } from "./commands/lockAccountingPeriod";
import { recordCashExpense } from "./commands/recordCashExpense";
import { recordCashIncome } from "./commands/recordCashIncome";
import { reversePostedEntry } from "./commands/reversePostedEntry";
import { listPostedExpenses } from "./queries/listPostedExpenses";
import { balances } from "./queries/balances";
import { listCatalogAccounts } from "./queries/listCatalogAccounts";
import { listFinancialAccountProfiles } from "./queries/listFinancialAccountProfiles";
import { listJournalEntries } from "./queries/listJournalEntries";
import { listLedgerAccounts } from "./queries/listLedgerAccounts";
import { openWorkspace } from "./queries/openWorkspace";
import { trialBalance } from "./queries/trialBalance";
import type { AccountingClock, AccountingCore, AccountingStore } from "./types";
export function createAccountingCore(store: AccountingStore, clock: AccountingClock = stryMutAct_9fa48("4629") ? {} : (stryCov_9fa48("4629"), {
  now: stryMutAct_9fa48("4630") ? () => undefined : (stryCov_9fa48("4630"), () => new Date())
})): AccountingCore {
  if (stryMutAct_9fa48("4631")) {
    {}
  } else {
    stryCov_9fa48("4631");
    return stryMutAct_9fa48("4632") ? {} : (stryCov_9fa48("4632"), {
      createUserCategory: stryMutAct_9fa48("4633") ? () => undefined : (stryCov_9fa48("4633"), input => createUserCategory(store, input)),
      suggestCategoryNature: stryMutAct_9fa48("4634") ? () => undefined : (stryCov_9fa48("4634"), input => categoryNatureSuggestion(store, input)),
      listUserCategories: stryMutAct_9fa48("4635") ? () => undefined : (stryCov_9fa48("4635"), input => listUserCategories(store, input)),
      categoryTotals: stryMutAct_9fa48("4636") ? () => undefined : (stryCov_9fa48("4636"), input => categoryTotals(store, input)),
      changeUserCategory: stryMutAct_9fa48("4637") ? () => undefined : (stryCov_9fa48("4637"), input => changeUserCategory(store, input)),
      previewCategoryReclassification: stryMutAct_9fa48("4638") ? () => undefined : (stryCov_9fa48("4638"), input => previewCategoryReclassification(store, input)),
      confirmCategoryReclassification: stryMutAct_9fa48("4639") ? () => undefined : (stryCov_9fa48("4639"), input => confirmCategoryReclassification(store, clock, input)),
      createPersonalWorkspace: stryMutAct_9fa48("4640") ? () => undefined : (stryCov_9fa48("4640"), input => createPersonalWorkspace(store, clock, input)),
      createHouseholdWorkspace: stryMutAct_9fa48("4641") ? () => undefined : (stryCov_9fa48("4641"), input => createHouseholdWorkspace(store, clock, input)),
      listOwnedWorkspaces: stryMutAct_9fa48("4642") ? () => undefined : (stryCov_9fa48("4642"), input => listOwnedWorkspaces(store, clock, input)),
      openWorkspace: stryMutAct_9fa48("4643") ? () => undefined : (stryCov_9fa48("4643"), input => openWorkspace(store, clock, input)),
      createFinancialAccountProfile: stryMutAct_9fa48("4644") ? () => undefined : (stryCov_9fa48("4644"), input => createFinancialAccountProfile(store, input)),
      listFinancialAccountProfiles: stryMutAct_9fa48("4645") ? () => undefined : (stryCov_9fa48("4645"), input => listFinancialAccountProfiles(store, input)),
      listLedgerAccounts: stryMutAct_9fa48("4646") ? () => undefined : (stryCov_9fa48("4646"), input => listLedgerAccounts(store, input)),
      listCatalogAccounts: stryMutAct_9fa48("4647") ? () => undefined : (stryCov_9fa48("4647"), input => listCatalogAccounts(store, input)),
      recordAccountTransfer: stryMutAct_9fa48("4648") ? () => undefined : (stryCov_9fa48("4648"), input => recordAccountTransfer(store, clock, input)),
      recordOpeningPosition: stryMutAct_9fa48("4649") ? () => undefined : (stryCov_9fa48("4649"), input => recordOpeningPosition(store, clock, input)),
      setupFinancialAccount: stryMutAct_9fa48("4650") ? () => undefined : (stryCov_9fa48("4650"), input => setupFinancialAccount(store, clock, input)),
      recordCashExpense: stryMutAct_9fa48("4651") ? () => undefined : (stryCov_9fa48("4651"), input => recordCashExpense(store, clock, input)),
      recordCashIncome: stryMutAct_9fa48("4652") ? () => undefined : (stryCov_9fa48("4652"), input => recordCashIncome(store, clock, input)),
      reversePostedEntry: stryMutAct_9fa48("4653") ? () => undefined : (stryCov_9fa48("4653"), input => reversePostedEntry(store, clock, input)),
      listJournalEntries: stryMutAct_9fa48("4654") ? () => undefined : (stryCov_9fa48("4654"), input => listJournalEntries(store, input)),
      listPostedExpenses: stryMutAct_9fa48("4655") ? () => undefined : (stryCov_9fa48("4655"), input => listPostedExpenses(store, input)),
      balances: stryMutAct_9fa48("4656") ? () => undefined : (stryCov_9fa48("4656"), input => balances(store, input)),
      trialBalance: stryMutAct_9fa48("4657") ? () => undefined : (stryCov_9fa48("4657"), input => trialBalance(store, input)),
      lockAccountingPeriod: stryMutAct_9fa48("4658") ? () => undefined : (stryCov_9fa48("4658"), input => lockAccountingPeriod(store, clock, input))
    });
  }
}