/*
 * COA Template for a Colombian Personal Workspace, built on the commercial PUC
 * (Decreto 2650 de 1993). Codes up to six digits are the decree's own; eight-digit
 * codes are auxiliaries the decree lets each entity add from the seventh digit
 * (Art. 7), used here for personal concepts the commercial PUC has no subaccount for.
 * Cohesive data file: one template, one version; see ADR-0082.
 */
// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import type { ChartOfAccountsTemplate } from "../types";
export const coPucPersonalTemplate = (stryMutAct_9fa48("5940") ? {} : (stryCov_9fa48("5940"), {
  version: stryMutAct_9fa48("5941") ? "" : (stryCov_9fa48("5941"), "co-puc-personal@1"),
  applicableWorkspaceKinds: stryMutAct_9fa48("5942") ? [] : (stryCov_9fa48("5942"), [stryMutAct_9fa48("5943") ? "" : (stryCov_9fa48("5943"), "Personal"), stryMutAct_9fa48("5944") ? "" : (stryCov_9fa48("5944"), "Household")]),
  natureByClass: stryMutAct_9fa48("5945") ? {} : (stryCov_9fa48("5945"), {
    "1": stryMutAct_9fa48("5946") ? "" : (stryCov_9fa48("5946"), "Asset"),
    "2": stryMutAct_9fa48("5947") ? "" : (stryCov_9fa48("5947"), "Liability"),
    "3": stryMutAct_9fa48("5948") ? "" : (stryCov_9fa48("5948"), "Equity"),
    "4": stryMutAct_9fa48("5949") ? "" : (stryCov_9fa48("5949"), "Revenue"),
    "5": stryMutAct_9fa48("5950") ? "" : (stryCov_9fa48("5950"), "Expense")
  }),
  defaults: stryMutAct_9fa48("5951") ? {} : (stryCov_9fa48("5951"), {
    expense: stryMutAct_9fa48("5952") ? "" : (stryCov_9fa48("5952"), "51959595"),
    income: stryMutAct_9fa48("5953") ? "" : (stryCov_9fa48("5953"), "42959595"),
    openingBalance: stryMutAct_9fa48("5954") ? "" : (stryCov_9fa48("5954"), "313001")
  }),
  financialAccountParents: stryMutAct_9fa48("5955") ? {} : (stryCov_9fa48("5955"), {
    cash: stryMutAct_9fa48("5956") ? "" : (stryCov_9fa48("5956"), "110505"),
    bankAccount: stryMutAct_9fa48("5957") ? "" : (stryCov_9fa48("5957"), "111005"),
    savingsAccount: stryMutAct_9fa48("5958") ? "" : (stryCov_9fa48("5958"), "112005"),
    creditCard: stryMutAct_9fa48("5959") ? "" : (stryCov_9fa48("5959"), "210510"),
    loan: stryMutAct_9fa48("5960") ? "" : (stryCov_9fa48("5960"), "210510"),
    securedReceivable: stryMutAct_9fa48("5961") ? "" : (stryCov_9fa48("5961"), "137005"),
    unsecuredReceivable: stryMutAct_9fa48("5962") ? "" : (stryCov_9fa48("5962"), "137010"),
    termDeposit: stryMutAct_9fa48("5963") ? "" : (stryCov_9fa48("5963"), "122505"),
    investmentFund: stryMutAct_9fa48("5964") ? "" : (stryCov_9fa48("5964"), "124505"),
    personalDebt: stryMutAct_9fa48("5965") ? "" : (stryCov_9fa48("5965"), "219505")
  }),
  accounts: stryMutAct_9fa48("5966") ? [] : (stryCov_9fa48("5966"), [// 1 Activo
  stryMutAct_9fa48("5967") ? {} : (stryCov_9fa48("5967"), {
    code: stryMutAct_9fa48("5968") ? "" : (stryCov_9fa48("5968"), "122505"),
    name: stryMutAct_9fa48("5969") ? "" : (stryCov_9fa48("5969"), "Certificados de depósito a término (CDT)"),
    use: stryMutAct_9fa48("5970") ? "" : (stryCov_9fa48("5970"), "general")
  }), stryMutAct_9fa48("5971") ? {} : (stryCov_9fa48("5971"), {
    code: stryMutAct_9fa48("5972") ? "" : (stryCov_9fa48("5972"), "124505"),
    name: stryMutAct_9fa48("5973") ? "" : (stryCov_9fa48("5973"), "Fideicomisos de inversión moneda nacional"),
    use: stryMutAct_9fa48("5974") ? "" : (stryCov_9fa48("5974"), "general")
  }), stryMutAct_9fa48("5975") ? {} : (stryCov_9fa48("5975"), {
    code: stryMutAct_9fa48("5976") ? "" : (stryCov_9fa48("5976"), "133005"),
    name: stryMutAct_9fa48("5977") ? "" : (stryCov_9fa48("5977"), "Anticipos a proveedores"),
    use: stryMutAct_9fa48("5978") ? "" : (stryCov_9fa48("5978"), "general")
  }), stryMutAct_9fa48("5979") ? {} : (stryCov_9fa48("5979"), {
    code: stryMutAct_9fa48("5980") ? "" : (stryCov_9fa48("5980"), "134505"),
    name: stryMutAct_9fa48("5981") ? "" : (stryCov_9fa48("5981"), "Dividendos y participaciones por cobrar"),
    use: stryMutAct_9fa48("5982") ? "" : (stryCov_9fa48("5982"), "general")
  }), stryMutAct_9fa48("5983") ? {} : (stryCov_9fa48("5983"), {
    code: stryMutAct_9fa48("5984") ? "" : (stryCov_9fa48("5984"), "134510"),
    name: stryMutAct_9fa48("5985") ? "" : (stryCov_9fa48("5985"), "Intereses por cobrar"),
    use: stryMutAct_9fa48("5986") ? "" : (stryCov_9fa48("5986"), "general")
  }), stryMutAct_9fa48("5987") ? {} : (stryCov_9fa48("5987"), {
    code: stryMutAct_9fa48("5988") ? "" : (stryCov_9fa48("5988"), "134530"),
    name: stryMutAct_9fa48("5989") ? "" : (stryCov_9fa48("5989"), "Arrendamientos por cobrar"),
    use: stryMutAct_9fa48("5990") ? "" : (stryCov_9fa48("5990"), "general")
  }), stryMutAct_9fa48("5991") ? {} : (stryCov_9fa48("5991"), {
    code: stryMutAct_9fa48("5992") ? "" : (stryCov_9fa48("5992"), "137005"),
    name: stryMutAct_9fa48("5993") ? "" : (stryCov_9fa48("5993"), "Préstamos a particulares con garantía real"),
    use: stryMutAct_9fa48("5994") ? "" : (stryCov_9fa48("5994"), "general")
  }), stryMutAct_9fa48("5995") ? {} : (stryCov_9fa48("5995"), {
    code: stryMutAct_9fa48("5996") ? "" : (stryCov_9fa48("5996"), "137010"),
    name: stryMutAct_9fa48("5997") ? "" : (stryCov_9fa48("5997"), "Préstamos a particulares con garantía personal"),
    use: stryMutAct_9fa48("5998") ? "" : (stryCov_9fa48("5998"), "general")
  }), stryMutAct_9fa48("5999") ? {} : (stryCov_9fa48("5999"), {
    code: stryMutAct_9fa48("6000") ? "" : (stryCov_9fa48("6000"), "138025"),
    name: stryMutAct_9fa48("6001") ? "" : (stryCov_9fa48("6001"), "Pagos por cuenta de terceros"),
    use: stryMutAct_9fa48("6002") ? "" : (stryCov_9fa48("6002"), "general")
  }), stryMutAct_9fa48("6003") ? {} : (stryCov_9fa48("6003"), {
    code: stryMutAct_9fa48("6004") ? "" : (stryCov_9fa48("6004"), "150405"),
    name: stryMutAct_9fa48("6005") ? "" : (stryCov_9fa48("6005"), "Terrenos urbanos"),
    use: stryMutAct_9fa48("6006") ? "" : (stryCov_9fa48("6006"), "general")
  }), stryMutAct_9fa48("6007") ? {} : (stryCov_9fa48("6007"), {
    code: stryMutAct_9fa48("6008") ? "" : (stryCov_9fa48("6008"), "151605"),
    name: stryMutAct_9fa48("6009") ? "" : (stryCov_9fa48("6009"), "Edificios"),
    use: stryMutAct_9fa48("6010") ? "" : (stryCov_9fa48("6010"), "general")
  }), stryMutAct_9fa48("6011") ? {} : (stryCov_9fa48("6011"), {
    code: stryMutAct_9fa48("6012") ? "" : (stryCov_9fa48("6012"), "152405"),
    name: stryMutAct_9fa48("6013") ? "" : (stryCov_9fa48("6013"), "Muebles y enseres"),
    use: stryMutAct_9fa48("6014") ? "" : (stryCov_9fa48("6014"), "general")
  }), stryMutAct_9fa48("6015") ? {} : (stryCov_9fa48("6015"), {
    code: stryMutAct_9fa48("6016") ? "" : (stryCov_9fa48("6016"), "152805"),
    name: stryMutAct_9fa48("6017") ? "" : (stryCov_9fa48("6017"), "Equipos de procesamiento de datos"),
    use: stryMutAct_9fa48("6018") ? "" : (stryCov_9fa48("6018"), "general")
  }), stryMutAct_9fa48("6019") ? {} : (stryCov_9fa48("6019"), {
    code: stryMutAct_9fa48("6020") ? "" : (stryCov_9fa48("6020"), "154005"),
    name: stryMutAct_9fa48("6021") ? "" : (stryCov_9fa48("6021"), "Autos, camionetas y camperos"),
    use: stryMutAct_9fa48("6022") ? "" : (stryCov_9fa48("6022"), "general")
  }), stryMutAct_9fa48("6023") ? {} : (stryCov_9fa48("6023"), {
    code: stryMutAct_9fa48("6024") ? "" : (stryCov_9fa48("6024"), "154030"),
    name: stryMutAct_9fa48("6025") ? "" : (stryCov_9fa48("6025"), "Motocicletas"),
    use: stryMutAct_9fa48("6026") ? "" : (stryCov_9fa48("6026"), "general")
  }), stryMutAct_9fa48("6027") ? {} : (stryCov_9fa48("6027"), {
    code: stryMutAct_9fa48("6028") ? "" : (stryCov_9fa48("6028"), "159205"),
    name: stryMutAct_9fa48("6029") ? "" : (stryCov_9fa48("6029"), "Depreciación acumulada de construcciones y edificaciones"),
    use: stryMutAct_9fa48("6030") ? "" : (stryCov_9fa48("6030"), "general"),
    normalSide: stryMutAct_9fa48("6031") ? "" : (stryCov_9fa48("6031"), "Credit")
  }), stryMutAct_9fa48("6032") ? {} : (stryCov_9fa48("6032"), {
    code: stryMutAct_9fa48("6033") ? "" : (stryCov_9fa48("6033"), "159215"),
    name: stryMutAct_9fa48("6034") ? "" : (stryCov_9fa48("6034"), "Depreciación acumulada de equipo de oficina"),
    use: stryMutAct_9fa48("6035") ? "" : (stryCov_9fa48("6035"), "general"),
    normalSide: stryMutAct_9fa48("6036") ? "" : (stryCov_9fa48("6036"), "Credit")
  }), stryMutAct_9fa48("6037") ? {} : (stryCov_9fa48("6037"), {
    code: stryMutAct_9fa48("6038") ? "" : (stryCov_9fa48("6038"), "159220"),
    name: stryMutAct_9fa48("6039") ? "" : (stryCov_9fa48("6039"), "Depreciación acumulada de equipo de computación y comunicación"),
    use: stryMutAct_9fa48("6040") ? "" : (stryCov_9fa48("6040"), "general"),
    normalSide: stryMutAct_9fa48("6041") ? "" : (stryCov_9fa48("6041"), "Credit")
  }), stryMutAct_9fa48("6042") ? {} : (stryCov_9fa48("6042"), {
    code: stryMutAct_9fa48("6043") ? "" : (stryCov_9fa48("6043"), "159235"),
    name: stryMutAct_9fa48("6044") ? "" : (stryCov_9fa48("6044"), "Depreciación acumulada de flota y equipo de transporte"),
    use: stryMutAct_9fa48("6045") ? "" : (stryCov_9fa48("6045"), "general"),
    normalSide: stryMutAct_9fa48("6046") ? "" : (stryCov_9fa48("6046"), "Credit")
  }), stryMutAct_9fa48("6047") ? {} : (stryCov_9fa48("6047"), {
    code: stryMutAct_9fa48("6048") ? "" : (stryCov_9fa48("6048"), "170520"),
    name: stryMutAct_9fa48("6049") ? "" : (stryCov_9fa48("6049"), "Seguros y fianzas pagados por anticipado"),
    use: stryMutAct_9fa48("6050") ? "" : (stryCov_9fa48("6050"), "general")
  }), stryMutAct_9fa48("6051") ? {} : (stryCov_9fa48("6051"), {
    code: stryMutAct_9fa48("6052") ? "" : (stryCov_9fa48("6052"), "170545"),
    name: stryMutAct_9fa48("6053") ? "" : (stryCov_9fa48("6053"), "Suscripciones pagadas por anticipado"),
    use: stryMutAct_9fa48("6054") ? "" : (stryCov_9fa48("6054"), "general")
  }), // 2 Pasivo
  stryMutAct_9fa48("6055") ? {} : (stryCov_9fa48("6055"), {
    code: stryMutAct_9fa48("6056") ? "" : (stryCov_9fa48("6056"), "219505"),
    name: stryMutAct_9fa48("6057") ? "" : (stryCov_9fa48("6057"), "Obligaciones con particulares"),
    use: stryMutAct_9fa48("6058") ? "" : (stryCov_9fa48("6058"), "general")
  }), stryMutAct_9fa48("6059") ? {} : (stryCov_9fa48("6059"), {
    code: stryMutAct_9fa48("6060") ? "" : (stryCov_9fa48("6060"), "233595"),
    name: stryMutAct_9fa48("6061") ? "" : (stryCov_9fa48("6061"), "Otros costos y gastos por pagar"),
    use: stryMutAct_9fa48("6062") ? "" : (stryCov_9fa48("6062"), "general")
  }), stryMutAct_9fa48("6063") ? {} : (stryCov_9fa48("6063"), {
    code: stryMutAct_9fa48("6064") ? "" : (stryCov_9fa48("6064"), "238020"),
    name: stryMutAct_9fa48("6065") ? "" : (stryCov_9fa48("6065"), "Reintegros por pagar"),
    use: stryMutAct_9fa48("6066") ? "" : (stryCov_9fa48("6066"), "general")
  }), stryMutAct_9fa48("6067") ? {} : (stryCov_9fa48("6067"), {
    code: stryMutAct_9fa48("6068") ? "" : (stryCov_9fa48("6068"), "240405"),
    name: stryMutAct_9fa48("6069") ? "" : (stryCov_9fa48("6069"), "Impuesto de renta por pagar, vigencia corriente"),
    use: stryMutAct_9fa48("6070") ? "" : (stryCov_9fa48("6070"), "general")
  }), stryMutAct_9fa48("6071") ? {} : (stryCov_9fa48("6071"), {
    code: stryMutAct_9fa48("6072") ? "" : (stryCov_9fa48("6072"), "270515"),
    name: stryMutAct_9fa48("6073") ? "" : (stryCov_9fa48("6073"), "Arrendamientos recibidos por anticipado"),
    use: stryMutAct_9fa48("6074") ? "" : (stryCov_9fa48("6074"), "general")
  }), stryMutAct_9fa48("6075") ? {} : (stryCov_9fa48("6075"), {
    code: stryMutAct_9fa48("6076") ? "" : (stryCov_9fa48("6076"), "280505"),
    name: stryMutAct_9fa48("6077") ? "" : (stryCov_9fa48("6077"), "Anticipos de clientes"),
    use: stryMutAct_9fa48("6078") ? "" : (stryCov_9fa48("6078"), "general")
  }), stryMutAct_9fa48("6079") ? {} : (stryCov_9fa48("6079"), {
    code: stryMutAct_9fa48("6080") ? "" : (stryCov_9fa48("6080"), "281020"),
    name: stryMutAct_9fa48("6081") ? "" : (stryCov_9fa48("6081"), "Depósitos recibidos en garantía de contratos"),
    use: stryMutAct_9fa48("6082") ? "" : (stryCov_9fa48("6082"), "general")
  }), // 3 Patrimonio
  stryMutAct_9fa48("6083") ? {} : (stryCov_9fa48("6083"), {
    code: stryMutAct_9fa48("6084") ? "" : (stryCov_9fa48("6084"), "313001"),
    name: stryMutAct_9fa48("6085") ? "" : (stryCov_9fa48("6085"), "Patrimonio de apertura"),
    use: stryMutAct_9fa48("6086") ? "" : (stryCov_9fa48("6086"), "openingBalance")
  }), // 4 Ingresos
  stryMutAct_9fa48("6087") ? {} : (stryCov_9fa48("6087"), {
    code: stryMutAct_9fa48("6088") ? "" : (stryCov_9fa48("6088"), "421005"),
    name: stryMutAct_9fa48("6089") ? "" : (stryCov_9fa48("6089"), "Intereses"),
    use: stryMutAct_9fa48("6090") ? "" : (stryCov_9fa48("6090"), "income")
  }), stryMutAct_9fa48("6091") ? {} : (stryCov_9fa48("6091"), {
    code: stryMutAct_9fa48("6092") ? "" : (stryCov_9fa48("6092"), "421020"),
    name: stryMutAct_9fa48("6093") ? "" : (stryCov_9fa48("6093"), "Diferencia en cambio (ingreso)"),
    use: stryMutAct_9fa48("6094") ? "" : (stryCov_9fa48("6094"), "general")
  }), stryMutAct_9fa48("6095") ? {} : (stryCov_9fa48("6095"), {
    code: stryMutAct_9fa48("6096") ? "" : (stryCov_9fa48("6096"), "421505"),
    name: stryMutAct_9fa48("6097") ? "" : (stryCov_9fa48("6097"), "Dividendos de sociedades anónimas"),
    use: stryMutAct_9fa48("6098") ? "" : (stryCov_9fa48("6098"), "income")
  }), stryMutAct_9fa48("6099") ? {} : (stryCov_9fa48("6099"), {
    code: stryMutAct_9fa48("6100") ? "" : (stryCov_9fa48("6100"), "42201001"),
    name: stryMutAct_9fa48("6101") ? "" : (stryCov_9fa48("6101"), "Arrendamientos de vivienda"),
    use: stryMutAct_9fa48("6102") ? "" : (stryCov_9fa48("6102"), "income")
  }), stryMutAct_9fa48("6103") ? {} : (stryCov_9fa48("6103"), {
    code: stryMutAct_9fa48("6104") ? "" : (stryCov_9fa48("6104"), "42201002"),
    name: stryMutAct_9fa48("6105") ? "" : (stryCov_9fa48("6105"), "Alojamiento de corta estancia"),
    use: stryMutAct_9fa48("6106") ? "" : (stryCov_9fa48("6106"), "income")
  }), stryMutAct_9fa48("6107") ? {} : (stryCov_9fa48("6107"), {
    code: stryMutAct_9fa48("6108") ? "" : (stryCov_9fa48("6108"), "423005"),
    name: stryMutAct_9fa48("6109") ? "" : (stryCov_9fa48("6109"), "Honorarios por asesorías"),
    use: stryMutAct_9fa48("6110") ? "" : (stryCov_9fa48("6110"), "income")
  }), stryMutAct_9fa48("6111") ? {} : (stryCov_9fa48("6111"), {
    code: stryMutAct_9fa48("6112") ? "" : (stryCov_9fa48("6112"), "424005"),
    name: stryMutAct_9fa48("6113") ? "" : (stryCov_9fa48("6113"), "Utilidad en venta de acciones"),
    use: stryMutAct_9fa48("6114") ? "" : (stryCov_9fa48("6114"), "general")
  }), stryMutAct_9fa48("6115") ? {} : (stryCov_9fa48("6115"), {
    code: stryMutAct_9fa48("6116") ? "" : (stryCov_9fa48("6116"), "429543"),
    name: stryMutAct_9fa48("6117") ? "" : (stryCov_9fa48("6117"), "Premios"),
    use: stryMutAct_9fa48("6118") ? "" : (stryCov_9fa48("6118"), "income")
  }), stryMutAct_9fa48("6119") ? {} : (stryCov_9fa48("6119"), {
    code: stryMutAct_9fa48("6120") ? "" : (stryCov_9fa48("6120"), "429545"),
    name: stryMutAct_9fa48("6121") ? "" : (stryCov_9fa48("6121"), "Bonificaciones"),
    use: stryMutAct_9fa48("6122") ? "" : (stryCov_9fa48("6122"), "income")
  }), stryMutAct_9fa48("6123") ? {} : (stryCov_9fa48("6123"), {
    code: stryMutAct_9fa48("6124") ? "" : (stryCov_9fa48("6124"), "42959501"),
    name: stryMutAct_9fa48("6125") ? "" : (stryCov_9fa48("6125"), "Salario"),
    use: stryMutAct_9fa48("6126") ? "" : (stryCov_9fa48("6126"), "income")
  }), stryMutAct_9fa48("6127") ? {} : (stryCov_9fa48("6127"), {
    code: stryMutAct_9fa48("6128") ? "" : (stryCov_9fa48("6128"), "42959502"),
    name: stryMutAct_9fa48("6129") ? "" : (stryCov_9fa48("6129"), "Regalos y apoyos recibidos"),
    use: stryMutAct_9fa48("6130") ? "" : (stryCov_9fa48("6130"), "income")
  }), stryMutAct_9fa48("6131") ? {} : (stryCov_9fa48("6131"), {
    code: stryMutAct_9fa48("6132") ? "" : (stryCov_9fa48("6132"), "42959595"),
    name: stryMutAct_9fa48("6133") ? "" : (stryCov_9fa48("6133"), "Otros ingresos"),
    use: stryMutAct_9fa48("6134") ? "" : (stryCov_9fa48("6134"), "income")
  }), // 5 Gastos
  stryMutAct_9fa48("6135") ? {} : (stryCov_9fa48("6135"), {
    code: stryMutAct_9fa48("6136") ? "" : (stryCov_9fa48("6136"), "511025"),
    name: stryMutAct_9fa48("6137") ? "" : (stryCov_9fa48("6137"), "Asesoría jurídica"),
    use: stryMutAct_9fa48("6138") ? "" : (stryCov_9fa48("6138"), "expense")
  }), stryMutAct_9fa48("6139") ? {} : (stryCov_9fa48("6139"), {
    code: stryMutAct_9fa48("6140") ? "" : (stryCov_9fa48("6140"), "511030"),
    name: stryMutAct_9fa48("6141") ? "" : (stryCov_9fa48("6141"), "Asesoría financiera"),
    use: stryMutAct_9fa48("6142") ? "" : (stryCov_9fa48("6142"), "expense")
  }), stryMutAct_9fa48("6143") ? {} : (stryCov_9fa48("6143"), {
    code: stryMutAct_9fa48("6144") ? "" : (stryCov_9fa48("6144"), "511515"),
    name: stryMutAct_9fa48("6145") ? "" : (stryCov_9fa48("6145"), "Impuesto predial"),
    use: stryMutAct_9fa48("6146") ? "" : (stryCov_9fa48("6146"), "expense")
  }), stryMutAct_9fa48("6147") ? {} : (stryCov_9fa48("6147"), {
    code: stryMutAct_9fa48("6148") ? "" : (stryCov_9fa48("6148"), "511540"),
    name: stryMutAct_9fa48("6149") ? "" : (stryCov_9fa48("6149"), "Impuesto de vehículos"),
    use: stryMutAct_9fa48("6150") ? "" : (stryCov_9fa48("6150"), "expense")
  }), stryMutAct_9fa48("6151") ? {} : (stryCov_9fa48("6151"), {
    code: stryMutAct_9fa48("6152") ? "" : (stryCov_9fa48("6152"), "51159501"),
    name: stryMutAct_9fa48("6153") ? "" : (stryCov_9fa48("6153"), "Gravamen a los movimientos financieros (4x1000)"),
    use: stryMutAct_9fa48("6154") ? "" : (stryCov_9fa48("6154"), "expense")
  }), stryMutAct_9fa48("6155") ? {} : (stryCov_9fa48("6155"), {
    code: stryMutAct_9fa48("6156") ? "" : (stryCov_9fa48("6156"), "512010"),
    name: stryMutAct_9fa48("6157") ? "" : (stryCov_9fa48("6157"), "Arrendamiento de vivienda"),
    use: stryMutAct_9fa48("6158") ? "" : (stryCov_9fa48("6158"), "expense")
  }), stryMutAct_9fa48("6159") ? {} : (stryCov_9fa48("6159"), {
    code: stryMutAct_9fa48("6160") ? "" : (stryCov_9fa48("6160"), "513020"),
    name: stryMutAct_9fa48("6161") ? "" : (stryCov_9fa48("6161"), "Seguro de vida"),
    use: stryMutAct_9fa48("6162") ? "" : (stryCov_9fa48("6162"), "expense")
  }), stryMutAct_9fa48("6163") ? {} : (stryCov_9fa48("6163"), {
    code: stryMutAct_9fa48("6164") ? "" : (stryCov_9fa48("6164"), "513040"),
    name: stryMutAct_9fa48("6165") ? "" : (stryCov_9fa48("6165"), "Seguro de vehículo"),
    use: stryMutAct_9fa48("6166") ? "" : (stryCov_9fa48("6166"), "expense")
  }), stryMutAct_9fa48("6167") ? {} : (stryCov_9fa48("6167"), {
    code: stryMutAct_9fa48("6168") ? "" : (stryCov_9fa48("6168"), "513075"),
    name: stryMutAct_9fa48("6169") ? "" : (stryCov_9fa48("6169"), "SOAT"),
    use: stryMutAct_9fa48("6170") ? "" : (stryCov_9fa48("6170"), "expense")
  }), stryMutAct_9fa48("6171") ? {} : (stryCov_9fa48("6171"), {
    code: stryMutAct_9fa48("6172") ? "" : (stryCov_9fa48("6172"), "513095"),
    name: stryMutAct_9fa48("6173") ? "" : (stryCov_9fa48("6173"), "Otros seguros"),
    use: stryMutAct_9fa48("6174") ? "" : (stryCov_9fa48("6174"), "expense")
  }), stryMutAct_9fa48("6175") ? {} : (stryCov_9fa48("6175"), {
    code: stryMutAct_9fa48("6176") ? "" : (stryCov_9fa48("6176"), "513505"),
    name: stryMutAct_9fa48("6177") ? "" : (stryCov_9fa48("6177"), "Aseo y vigilancia"),
    use: stryMutAct_9fa48("6178") ? "" : (stryCov_9fa48("6178"), "expense")
  }), stryMutAct_9fa48("6179") ? {} : (stryCov_9fa48("6179"), {
    code: stryMutAct_9fa48("6180") ? "" : (stryCov_9fa48("6180"), "513525"),
    name: stryMutAct_9fa48("6181") ? "" : (stryCov_9fa48("6181"), "Acueducto y alcantarillado"),
    use: stryMutAct_9fa48("6182") ? "" : (stryCov_9fa48("6182"), "expense")
  }), stryMutAct_9fa48("6183") ? {} : (stryCov_9fa48("6183"), {
    code: stryMutAct_9fa48("6184") ? "" : (stryCov_9fa48("6184"), "513530"),
    name: stryMutAct_9fa48("6185") ? "" : (stryCov_9fa48("6185"), "Energía eléctrica"),
    use: stryMutAct_9fa48("6186") ? "" : (stryCov_9fa48("6186"), "expense")
  }), stryMutAct_9fa48("6187") ? {} : (stryCov_9fa48("6187"), {
    code: stryMutAct_9fa48("6188") ? "" : (stryCov_9fa48("6188"), "513535"),
    name: stryMutAct_9fa48("6189") ? "" : (stryCov_9fa48("6189"), "Teléfono e internet"),
    use: stryMutAct_9fa48("6190") ? "" : (stryCov_9fa48("6190"), "expense")
  }), stryMutAct_9fa48("6191") ? {} : (stryCov_9fa48("6191"), {
    code: stryMutAct_9fa48("6192") ? "" : (stryCov_9fa48("6192"), "513550"),
    name: stryMutAct_9fa48("6193") ? "" : (stryCov_9fa48("6193"), "Transporte, fletes y acarreos"),
    use: stryMutAct_9fa48("6194") ? "" : (stryCov_9fa48("6194"), "expense")
  }), stryMutAct_9fa48("6195") ? {} : (stryCov_9fa48("6195"), {
    code: stryMutAct_9fa48("6196") ? "" : (stryCov_9fa48("6196"), "513555"),
    name: stryMutAct_9fa48("6197") ? "" : (stryCov_9fa48("6197"), "Gas"),
    use: stryMutAct_9fa48("6198") ? "" : (stryCov_9fa48("6198"), "expense")
  }), stryMutAct_9fa48("6199") ? {} : (stryCov_9fa48("6199"), {
    code: stryMutAct_9fa48("6200") ? "" : (stryCov_9fa48("6200"), "51359501"),
    name: stryMutAct_9fa48("6201") ? "" : (stryCov_9fa48("6201"), "Software y servicios digitales"),
    use: stryMutAct_9fa48("6202") ? "" : (stryCov_9fa48("6202"), "expense")
  }), stryMutAct_9fa48("6203") ? {} : (stryCov_9fa48("6203"), {
    code: stryMutAct_9fa48("6204") ? "" : (stryCov_9fa48("6204"), "514510"),
    name: stryMutAct_9fa48("6205") ? "" : (stryCov_9fa48("6205"), "Mantenimiento de vivienda"),
    use: stryMutAct_9fa48("6206") ? "" : (stryCov_9fa48("6206"), "expense")
  }), stryMutAct_9fa48("6207") ? {} : (stryCov_9fa48("6207"), {
    code: stryMutAct_9fa48("6208") ? "" : (stryCov_9fa48("6208"), "514525"),
    name: stryMutAct_9fa48("6209") ? "" : (stryCov_9fa48("6209"), "Mantenimiento de equipo de computación y comunicación"),
    use: stryMutAct_9fa48("6210") ? "" : (stryCov_9fa48("6210"), "expense")
  }), stryMutAct_9fa48("6211") ? {} : (stryCov_9fa48("6211"), {
    code: stryMutAct_9fa48("6212") ? "" : (stryCov_9fa48("6212"), "514540"),
    name: stryMutAct_9fa48("6213") ? "" : (stryCov_9fa48("6213"), "Mantenimiento de vehículos"),
    use: stryMutAct_9fa48("6214") ? "" : (stryCov_9fa48("6214"), "expense")
  }), stryMutAct_9fa48("6215") ? {} : (stryCov_9fa48("6215"), {
    code: stryMutAct_9fa48("6216") ? "" : (stryCov_9fa48("6216"), "515505"),
    name: stryMutAct_9fa48("6217") ? "" : (stryCov_9fa48("6217"), "Alojamiento y manutención en viajes"),
    use: stryMutAct_9fa48("6218") ? "" : (stryCov_9fa48("6218"), "expense")
  }), stryMutAct_9fa48("6219") ? {} : (stryCov_9fa48("6219"), {
    code: stryMutAct_9fa48("6220") ? "" : (stryCov_9fa48("6220"), "515515"),
    name: stryMutAct_9fa48("6221") ? "" : (stryCov_9fa48("6221"), "Pasajes aéreos"),
    use: stryMutAct_9fa48("6222") ? "" : (stryCov_9fa48("6222"), "expense")
  }), stryMutAct_9fa48("6223") ? {} : (stryCov_9fa48("6223"), {
    code: stryMutAct_9fa48("6224") ? "" : (stryCov_9fa48("6224"), "515520"),
    name: stryMutAct_9fa48("6225") ? "" : (stryCov_9fa48("6225"), "Pasajes terrestres"),
    use: stryMutAct_9fa48("6226") ? "" : (stryCov_9fa48("6226"), "expense")
  }), stryMutAct_9fa48("6227") ? {} : (stryCov_9fa48("6227"), {
    code: stryMutAct_9fa48("6228") ? "" : (stryCov_9fa48("6228"), "516005"),
    name: stryMutAct_9fa48("6229") ? "" : (stryCov_9fa48("6229"), "Depreciación de construcciones y edificaciones"),
    use: stryMutAct_9fa48("6230") ? "" : (stryCov_9fa48("6230"), "general")
  }), stryMutAct_9fa48("6231") ? {} : (stryCov_9fa48("6231"), {
    code: stryMutAct_9fa48("6232") ? "" : (stryCov_9fa48("6232"), "516015"),
    name: stryMutAct_9fa48("6233") ? "" : (stryCov_9fa48("6233"), "Depreciación de equipo de oficina"),
    use: stryMutAct_9fa48("6234") ? "" : (stryCov_9fa48("6234"), "general")
  }), stryMutAct_9fa48("6235") ? {} : (stryCov_9fa48("6235"), {
    code: stryMutAct_9fa48("6236") ? "" : (stryCov_9fa48("6236"), "516020"),
    name: stryMutAct_9fa48("6237") ? "" : (stryCov_9fa48("6237"), "Depreciación de equipo de computación y comunicación"),
    use: stryMutAct_9fa48("6238") ? "" : (stryCov_9fa48("6238"), "general")
  }), stryMutAct_9fa48("6239") ? {} : (stryCov_9fa48("6239"), {
    code: stryMutAct_9fa48("6240") ? "" : (stryCov_9fa48("6240"), "516035"),
    name: stryMutAct_9fa48("6241") ? "" : (stryCov_9fa48("6241"), "Depreciación de flota y equipo de transporte"),
    use: stryMutAct_9fa48("6242") ? "" : (stryCov_9fa48("6242"), "general")
  }), stryMutAct_9fa48("6243") ? {} : (stryCov_9fa48("6243"), {
    code: stryMutAct_9fa48("6244") ? "" : (stryCov_9fa48("6244"), "519510"),
    name: stryMutAct_9fa48("6245") ? "" : (stryCov_9fa48("6245"), "Libros, suscripciones, periódicos y revistas"),
    use: stryMutAct_9fa48("6246") ? "" : (stryCov_9fa48("6246"), "expense")
  }), stryMutAct_9fa48("6247") ? {} : (stryCov_9fa48("6247"), {
    code: stryMutAct_9fa48("6248") ? "" : (stryCov_9fa48("6248"), "519525"),
    name: stryMutAct_9fa48("6249") ? "" : (stryCov_9fa48("6249"), "Elementos de aseo y cafetería"),
    use: stryMutAct_9fa48("6250") ? "" : (stryCov_9fa48("6250"), "expense")
  }), stryMutAct_9fa48("6251") ? {} : (stryCov_9fa48("6251"), {
    code: stryMutAct_9fa48("6252") ? "" : (stryCov_9fa48("6252"), "519535"),
    name: stryMutAct_9fa48("6253") ? "" : (stryCov_9fa48("6253"), "Combustibles y lubricantes"),
    use: stryMutAct_9fa48("6254") ? "" : (stryCov_9fa48("6254"), "expense")
  }), stryMutAct_9fa48("6255") ? {} : (stryCov_9fa48("6255"), {
    code: stryMutAct_9fa48("6256") ? "" : (stryCov_9fa48("6256"), "519545"),
    name: stryMutAct_9fa48("6257") ? "" : (stryCov_9fa48("6257"), "Taxis y buses"),
    use: stryMutAct_9fa48("6258") ? "" : (stryCov_9fa48("6258"), "expense")
  }), stryMutAct_9fa48("6259") ? {} : (stryCov_9fa48("6259"), {
    code: stryMutAct_9fa48("6260") ? "" : (stryCov_9fa48("6260"), "519560"),
    name: stryMutAct_9fa48("6261") ? "" : (stryCov_9fa48("6261"), "Restaurantes y cafeterías"),
    use: stryMutAct_9fa48("6262") ? "" : (stryCov_9fa48("6262"), "expense")
  }), stryMutAct_9fa48("6263") ? {} : (stryCov_9fa48("6263"), {
    code: stryMutAct_9fa48("6264") ? "" : (stryCov_9fa48("6264"), "519565"),
    name: stryMutAct_9fa48("6265") ? "" : (stryCov_9fa48("6265"), "Parqueaderos"),
    use: stryMutAct_9fa48("6266") ? "" : (stryCov_9fa48("6266"), "expense")
  }), stryMutAct_9fa48("6267") ? {} : (stryCov_9fa48("6267"), {
    code: stryMutAct_9fa48("6268") ? "" : (stryCov_9fa48("6268"), "51959501"),
    name: stryMutAct_9fa48("6269") ? "" : (stryCov_9fa48("6269"), "Mercado y alimentos del hogar"),
    use: stryMutAct_9fa48("6270") ? "" : (stryCov_9fa48("6270"), "expense")
  }), stryMutAct_9fa48("6271") ? {} : (stryCov_9fa48("6271"), {
    code: stryMutAct_9fa48("6272") ? "" : (stryCov_9fa48("6272"), "51959502"),
    name: stryMutAct_9fa48("6273") ? "" : (stryCov_9fa48("6273"), "Salud y medicamentos"),
    use: stryMutAct_9fa48("6274") ? "" : (stryCov_9fa48("6274"), "expense")
  }), stryMutAct_9fa48("6275") ? {} : (stryCov_9fa48("6275"), {
    code: stryMutAct_9fa48("6276") ? "" : (stryCov_9fa48("6276"), "51959503"),
    name: stryMutAct_9fa48("6277") ? "" : (stryCov_9fa48("6277"), "Cuidado personal"),
    use: stryMutAct_9fa48("6278") ? "" : (stryCov_9fa48("6278"), "expense")
  }), stryMutAct_9fa48("6279") ? {} : (stryCov_9fa48("6279"), {
    code: stryMutAct_9fa48("6280") ? "" : (stryCov_9fa48("6280"), "51959504"),
    name: stryMutAct_9fa48("6281") ? "" : (stryCov_9fa48("6281"), "Ropa y calzado"),
    use: stryMutAct_9fa48("6282") ? "" : (stryCov_9fa48("6282"), "expense")
  }), stryMutAct_9fa48("6283") ? {} : (stryCov_9fa48("6283"), {
    code: stryMutAct_9fa48("6284") ? "" : (stryCov_9fa48("6284"), "51959505"),
    name: stryMutAct_9fa48("6285") ? "" : (stryCov_9fa48("6285"), "Educación"),
    use: stryMutAct_9fa48("6286") ? "" : (stryCov_9fa48("6286"), "expense")
  }), stryMutAct_9fa48("6287") ? {} : (stryCov_9fa48("6287"), {
    code: stryMutAct_9fa48("6288") ? "" : (stryCov_9fa48("6288"), "51959506"),
    name: stryMutAct_9fa48("6289") ? "" : (stryCov_9fa48("6289"), "Deporte y bienestar"),
    use: stryMutAct_9fa48("6290") ? "" : (stryCov_9fa48("6290"), "expense")
  }), stryMutAct_9fa48("6291") ? {} : (stryCov_9fa48("6291"), {
    code: stryMutAct_9fa48("6292") ? "" : (stryCov_9fa48("6292"), "51959507"),
    name: stryMutAct_9fa48("6293") ? "" : (stryCov_9fa48("6293"), "Entretenimiento y recreación"),
    use: stryMutAct_9fa48("6294") ? "" : (stryCov_9fa48("6294"), "expense")
  }), stryMutAct_9fa48("6295") ? {} : (stryCov_9fa48("6295"), {
    code: stryMutAct_9fa48("6296") ? "" : (stryCov_9fa48("6296"), "51959508"),
    name: stryMutAct_9fa48("6297") ? "" : (stryCov_9fa48("6297"), "Regalos y apoyo familiar"),
    use: stryMutAct_9fa48("6298") ? "" : (stryCov_9fa48("6298"), "expense")
  }), stryMutAct_9fa48("6299") ? {} : (stryCov_9fa48("6299"), {
    code: stryMutAct_9fa48("6300") ? "" : (stryCov_9fa48("6300"), "51959509"),
    name: stryMutAct_9fa48("6301") ? "" : (stryCov_9fa48("6301"), "Mascotas"),
    use: stryMutAct_9fa48("6302") ? "" : (stryCov_9fa48("6302"), "expense")
  }), stryMutAct_9fa48("6303") ? {} : (stryCov_9fa48("6303"), {
    code: stryMutAct_9fa48("6304") ? "" : (stryCov_9fa48("6304"), "51959510"),
    name: stryMutAct_9fa48("6305") ? "" : (stryCov_9fa48("6305"), "Tecnología y accesorios"),
    use: stryMutAct_9fa48("6306") ? "" : (stryCov_9fa48("6306"), "expense")
  }), stryMutAct_9fa48("6307") ? {} : (stryCov_9fa48("6307"), {
    code: stryMutAct_9fa48("6308") ? "" : (stryCov_9fa48("6308"), "51959595"),
    name: stryMutAct_9fa48("6309") ? "" : (stryCov_9fa48("6309"), "Otros gastos personales"),
    use: stryMutAct_9fa48("6310") ? "" : (stryCov_9fa48("6310"), "expense")
  }), stryMutAct_9fa48("6311") ? {} : (stryCov_9fa48("6311"), {
    code: stryMutAct_9fa48("6312") ? "" : (stryCov_9fa48("6312"), "530505"),
    name: stryMutAct_9fa48("6313") ? "" : (stryCov_9fa48("6313"), "Gastos bancarios"),
    use: stryMutAct_9fa48("6314") ? "" : (stryCov_9fa48("6314"), "expense")
  }), stryMutAct_9fa48("6315") ? {} : (stryCov_9fa48("6315"), {
    code: stryMutAct_9fa48("6316") ? "" : (stryCov_9fa48("6316"), "530515"),
    name: stryMutAct_9fa48("6317") ? "" : (stryCov_9fa48("6317"), "Comisiones financieras"),
    use: stryMutAct_9fa48("6318") ? "" : (stryCov_9fa48("6318"), "expense")
  }), stryMutAct_9fa48("6319") ? {} : (stryCov_9fa48("6319"), {
    code: stryMutAct_9fa48("6320") ? "" : (stryCov_9fa48("6320"), "530520"),
    name: stryMutAct_9fa48("6321") ? "" : (stryCov_9fa48("6321"), "Intereses"),
    use: stryMutAct_9fa48("6322") ? "" : (stryCov_9fa48("6322"), "expense")
  }), stryMutAct_9fa48("6323") ? {} : (stryCov_9fa48("6323"), {
    code: stryMutAct_9fa48("6324") ? "" : (stryCov_9fa48("6324"), "530525"),
    name: stryMutAct_9fa48("6325") ? "" : (stryCov_9fa48("6325"), "Diferencia en cambio (gasto)"),
    use: stryMutAct_9fa48("6326") ? "" : (stryCov_9fa48("6326"), "general")
  }), stryMutAct_9fa48("6327") ? {} : (stryCov_9fa48("6327"), {
    code: stryMutAct_9fa48("6328") ? "" : (stryCov_9fa48("6328"), "531005"),
    name: stryMutAct_9fa48("6329") ? "" : (stryCov_9fa48("6329"), "Pérdida en venta de inversiones"),
    use: stryMutAct_9fa48("6330") ? "" : (stryCov_9fa48("6330"), "general")
  }), stryMutAct_9fa48("6331") ? {} : (stryCov_9fa48("6331"), {
    code: stryMutAct_9fa48("6332") ? "" : (stryCov_9fa48("6332"), "531015"),
    name: stryMutAct_9fa48("6333") ? "" : (stryCov_9fa48("6333"), "Pérdida en venta de propiedades, planta y equipo"),
    use: stryMutAct_9fa48("6334") ? "" : (stryCov_9fa48("6334"), "general")
  }), stryMutAct_9fa48("6335") ? {} : (stryCov_9fa48("6335"), {
    code: stryMutAct_9fa48("6336") ? "" : (stryCov_9fa48("6336"), "539520"),
    name: stryMutAct_9fa48("6337") ? "" : (stryCov_9fa48("6337"), "Multas, sanciones y litigios"),
    use: stryMutAct_9fa48("6338") ? "" : (stryCov_9fa48("6338"), "expense")
  }), stryMutAct_9fa48("6339") ? {} : (stryCov_9fa48("6339"), {
    code: stryMutAct_9fa48("6340") ? "" : (stryCov_9fa48("6340"), "539525"),
    name: stryMutAct_9fa48("6341") ? "" : (stryCov_9fa48("6341"), "Donaciones"),
    use: stryMutAct_9fa48("6342") ? "" : (stryCov_9fa48("6342"), "expense")
  }), stryMutAct_9fa48("6343") ? {} : (stryCov_9fa48("6343"), {
    code: stryMutAct_9fa48("6344") ? "" : (stryCov_9fa48("6344"), "540505"),
    name: stryMutAct_9fa48("6345") ? "" : (stryCov_9fa48("6345"), "Impuesto de renta y complementarios"),
    use: stryMutAct_9fa48("6346") ? "" : (stryCov_9fa48("6346"), "expense")
  })]),
  summaryNames: stryMutAct_9fa48("6347") ? {} : (stryCov_9fa48("6347"), {
    "219505": stryMutAct_9fa48("6348") ? "" : (stryCov_9fa48("6348"), "Obligaciones con particulares"),
    "124505": stryMutAct_9fa48("6349") ? "" : (stryCov_9fa48("6349"), "Fideicomisos de inversión moneda nacional"),
    "122505": stryMutAct_9fa48("6350") ? "" : (stryCov_9fa48("6350"), "Certificados de depósito a término (CDT)"),
    "137010": stryMutAct_9fa48("6351") ? "" : (stryCov_9fa48("6351"), "Préstamos a particulares con garantía personal"),
    "137005": stryMutAct_9fa48("6352") ? "" : (stryCov_9fa48("6352"), "Préstamos a particulares con garantía real"),
    "1": stryMutAct_9fa48("6353") ? "" : (stryCov_9fa48("6353"), "Activo"),
    "11": stryMutAct_9fa48("6354") ? "" : (stryCov_9fa48("6354"), "Disponible"),
    "1105": stryMutAct_9fa48("6355") ? "" : (stryCov_9fa48("6355"), "Caja"),
    "110505": stryMutAct_9fa48("6356") ? "" : (stryCov_9fa48("6356"), "Caja general"),
    "1110": stryMutAct_9fa48("6357") ? "" : (stryCov_9fa48("6357"), "Bancos"),
    "111005": stryMutAct_9fa48("6358") ? "" : (stryCov_9fa48("6358"), "Moneda nacional"),
    "1120": stryMutAct_9fa48("6359") ? "" : (stryCov_9fa48("6359"), "Cuentas de ahorro"),
    "112005": stryMutAct_9fa48("6360") ? "" : (stryCov_9fa48("6360"), "Bancos"),
    "12": stryMutAct_9fa48("6361") ? "" : (stryCov_9fa48("6361"), "Inversiones"),
    "1225": stryMutAct_9fa48("6362") ? "" : (stryCov_9fa48("6362"), "Certificados"),
    "1245": stryMutAct_9fa48("6363") ? "" : (stryCov_9fa48("6363"), "Derechos fiduciarios"),
    "13": stryMutAct_9fa48("6364") ? "" : (stryCov_9fa48("6364"), "Deudores"),
    "1330": stryMutAct_9fa48("6365") ? "" : (stryCov_9fa48("6365"), "Anticipos y avances"),
    "1345": stryMutAct_9fa48("6366") ? "" : (stryCov_9fa48("6366"), "Ingresos por cobrar"),
    "1370": stryMutAct_9fa48("6367") ? "" : (stryCov_9fa48("6367"), "Préstamos a particulares"),
    "1380": stryMutAct_9fa48("6368") ? "" : (stryCov_9fa48("6368"), "Deudores varios"),
    "15": stryMutAct_9fa48("6369") ? "" : (stryCov_9fa48("6369"), "Propiedades, planta y equipo"),
    "1504": stryMutAct_9fa48("6370") ? "" : (stryCov_9fa48("6370"), "Terrenos"),
    "1516": stryMutAct_9fa48("6371") ? "" : (stryCov_9fa48("6371"), "Construcciones y edificaciones"),
    "1524": stryMutAct_9fa48("6372") ? "" : (stryCov_9fa48("6372"), "Equipo de oficina"),
    "1528": stryMutAct_9fa48("6373") ? "" : (stryCov_9fa48("6373"), "Equipo de computación y comunicación"),
    "1540": stryMutAct_9fa48("6374") ? "" : (stryCov_9fa48("6374"), "Flota y equipo de transporte"),
    "1592": stryMutAct_9fa48("6375") ? "" : (stryCov_9fa48("6375"), "Depreciación acumulada"),
    "17": stryMutAct_9fa48("6376") ? "" : (stryCov_9fa48("6376"), "Diferidos"),
    "1705": stryMutAct_9fa48("6377") ? "" : (stryCov_9fa48("6377"), "Gastos pagados por anticipado"),
    "2": stryMutAct_9fa48("6378") ? "" : (stryCov_9fa48("6378"), "Pasivo"),
    "21": stryMutAct_9fa48("6379") ? "" : (stryCov_9fa48("6379"), "Obligaciones financieras"),
    "2105": stryMutAct_9fa48("6380") ? "" : (stryCov_9fa48("6380"), "Bancos nacionales"),
    "210510": stryMutAct_9fa48("6381") ? "" : (stryCov_9fa48("6381"), "Pagarés"),
    "2195": stryMutAct_9fa48("6382") ? "" : (stryCov_9fa48("6382"), "Otras obligaciones"),
    "23": stryMutAct_9fa48("6383") ? "" : (stryCov_9fa48("6383"), "Cuentas por pagar"),
    "2335": stryMutAct_9fa48("6384") ? "" : (stryCov_9fa48("6384"), "Costos y gastos por pagar"),
    "2380": stryMutAct_9fa48("6385") ? "" : (stryCov_9fa48("6385"), "Acreedores varios"),
    "24": stryMutAct_9fa48("6386") ? "" : (stryCov_9fa48("6386"), "Impuestos, gravámenes y tasas"),
    "2404": stryMutAct_9fa48("6387") ? "" : (stryCov_9fa48("6387"), "De renta y complementarios"),
    "27": stryMutAct_9fa48("6388") ? "" : (stryCov_9fa48("6388"), "Diferidos"),
    "2705": stryMutAct_9fa48("6389") ? "" : (stryCov_9fa48("6389"), "Ingresos recibidos por anticipado"),
    "28": stryMutAct_9fa48("6390") ? "" : (stryCov_9fa48("6390"), "Otros pasivos"),
    "2805": stryMutAct_9fa48("6391") ? "" : (stryCov_9fa48("6391"), "Anticipos y avances recibidos"),
    "2810": stryMutAct_9fa48("6392") ? "" : (stryCov_9fa48("6392"), "Depósitos recibidos"),
    "3": stryMutAct_9fa48("6393") ? "" : (stryCov_9fa48("6393"), "Patrimonio"),
    "31": stryMutAct_9fa48("6394") ? "" : (stryCov_9fa48("6394"), "Capital social"),
    "3130": stryMutAct_9fa48("6395") ? "" : (stryCov_9fa48("6395"), "Capital de personas naturales"),
    "4": stryMutAct_9fa48("6396") ? "" : (stryCov_9fa48("6396"), "Ingresos"),
    "42": stryMutAct_9fa48("6397") ? "" : (stryCov_9fa48("6397"), "No operacionales"),
    "4210": stryMutAct_9fa48("6398") ? "" : (stryCov_9fa48("6398"), "Financieros"),
    "4215": stryMutAct_9fa48("6399") ? "" : (stryCov_9fa48("6399"), "Dividendos y participaciones"),
    "4220": stryMutAct_9fa48("6400") ? "" : (stryCov_9fa48("6400"), "Arrendamientos"),
    "422010": stryMutAct_9fa48("6401") ? "" : (stryCov_9fa48("6401"), "Construcciones y edificios"),
    "4230": stryMutAct_9fa48("6402") ? "" : (stryCov_9fa48("6402"), "Honorarios"),
    "4240": stryMutAct_9fa48("6403") ? "" : (stryCov_9fa48("6403"), "Utilidad en venta de inversiones"),
    "4295": stryMutAct_9fa48("6404") ? "" : (stryCov_9fa48("6404"), "Diversos"),
    "429595": stryMutAct_9fa48("6405") ? "" : (stryCov_9fa48("6405"), "Otros"),
    "5": stryMutAct_9fa48("6406") ? "" : (stryCov_9fa48("6406"), "Gastos"),
    "51": stryMutAct_9fa48("6407") ? "" : (stryCov_9fa48("6407"), "Operacionales de administración"),
    "5110": stryMutAct_9fa48("6408") ? "" : (stryCov_9fa48("6408"), "Honorarios"),
    "5115": stryMutAct_9fa48("6409") ? "" : (stryCov_9fa48("6409"), "Impuestos"),
    "511595": stryMutAct_9fa48("6410") ? "" : (stryCov_9fa48("6410"), "Otros"),
    "5120": stryMutAct_9fa48("6411") ? "" : (stryCov_9fa48("6411"), "Arrendamientos"),
    "5130": stryMutAct_9fa48("6412") ? "" : (stryCov_9fa48("6412"), "Seguros"),
    "5135": stryMutAct_9fa48("6413") ? "" : (stryCov_9fa48("6413"), "Servicios"),
    "513595": stryMutAct_9fa48("6414") ? "" : (stryCov_9fa48("6414"), "Otros"),
    "5145": stryMutAct_9fa48("6415") ? "" : (stryCov_9fa48("6415"), "Mantenimiento y reparaciones"),
    "5155": stryMutAct_9fa48("6416") ? "" : (stryCov_9fa48("6416"), "Gastos de viaje"),
    "5160": stryMutAct_9fa48("6417") ? "" : (stryCov_9fa48("6417"), "Depreciaciones"),
    "5195": stryMutAct_9fa48("6418") ? "" : (stryCov_9fa48("6418"), "Diversos"),
    "519595": stryMutAct_9fa48("6419") ? "" : (stryCov_9fa48("6419"), "Otros"),
    "53": stryMutAct_9fa48("6420") ? "" : (stryCov_9fa48("6420"), "No operacionales"),
    "5305": stryMutAct_9fa48("6421") ? "" : (stryCov_9fa48("6421"), "Financieros"),
    "5310": stryMutAct_9fa48("6422") ? "" : (stryCov_9fa48("6422"), "Pérdida en venta y retiro de bienes"),
    "5395": stryMutAct_9fa48("6423") ? "" : (stryCov_9fa48("6423"), "Gastos diversos"),
    "54": stryMutAct_9fa48("6424") ? "" : (stryCov_9fa48("6424"), "Impuesto de renta y complementarios"),
    "5405": stryMutAct_9fa48("6425") ? "" : (stryCov_9fa48("6425"), "Impuesto de renta y complementarios")
  })
})) satisfies ChartOfAccountsTemplate;