/*
 * COA Template for an English-language Personal Workspace, mirroring co-puc-personal@1.
 * US GAAP prescribes no chart of accounts, so codes are application-owned: the first
 * digit is the class, the second the group. Reporting concepts cite the FASB US GAAP
 * Taxonomy 2026 (https://xbrl.fasb.org/us-gaap/2026/elts/us-gaap-2026.xsd) only where an
 * element fits; personal concepts such as salary received or groceries have none,
 * because the taxonomy describes a reporting entity, not a household.
 * Cohesive data file: one template, one version; see ADR-0083.
 */
// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import type { ChartOfAccountsTemplate } from "../types";
export const usGaapPersonalTemplate = (stryMutAct_9fa48("6426") ? {} : (stryCov_9fa48("6426"), {
  version: stryMutAct_9fa48("6427") ? "" : (stryCov_9fa48("6427"), "us-gaap-personal@1"),
  applicableWorkspaceKinds: stryMutAct_9fa48("6428") ? [] : (stryCov_9fa48("6428"), [stryMutAct_9fa48("6429") ? "" : (stryCov_9fa48("6429"), "Personal"), stryMutAct_9fa48("6430") ? "" : (stryCov_9fa48("6430"), "Household")]),
  natureByClass: stryMutAct_9fa48("6431") ? {} : (stryCov_9fa48("6431"), {
    "1": stryMutAct_9fa48("6432") ? "" : (stryCov_9fa48("6432"), "Asset"),
    "2": stryMutAct_9fa48("6433") ? "" : (stryCov_9fa48("6433"), "Liability"),
    "3": stryMutAct_9fa48("6434") ? "" : (stryCov_9fa48("6434"), "Equity"),
    "4": stryMutAct_9fa48("6435") ? "" : (stryCov_9fa48("6435"), "Revenue"),
    "5": stryMutAct_9fa48("6436") ? "" : (stryCov_9fa48("6436"), "Expense"),
    "6": stryMutAct_9fa48("6437") ? "" : (stryCov_9fa48("6437"), "Expense")
  }),
  defaults: stryMutAct_9fa48("6438") ? {} : (stryCov_9fa48("6438"), {
    expense: stryMutAct_9fa48("6439") ? "" : (stryCov_9fa48("6439"), "5599"),
    income: stryMutAct_9fa48("6440") ? "" : (stryCov_9fa48("6440"), "4990"),
    openingBalance: stryMutAct_9fa48("6441") ? "" : (stryCov_9fa48("6441"), "3010")
  }),
  financialAccountParents: stryMutAct_9fa48("6442") ? {} : (stryCov_9fa48("6442"), {
    cash: stryMutAct_9fa48("6443") ? "" : (stryCov_9fa48("6443"), "1010"),
    bankAccount: stryMutAct_9fa48("6444") ? "" : (stryCov_9fa48("6444"), "1020"),
    savingsAccount: stryMutAct_9fa48("6445") ? "" : (stryCov_9fa48("6445"), "1030"),
    creditCard: stryMutAct_9fa48("6446") ? "" : (stryCov_9fa48("6446"), "2010"),
    loan: stryMutAct_9fa48("6447") ? "" : (stryCov_9fa48("6447"), "2110"),
    securedReceivable: stryMutAct_9fa48("6448") ? "" : (stryCov_9fa48("6448"), "1250"),
    unsecuredReceivable: stryMutAct_9fa48("6449") ? "" : (stryCov_9fa48("6449"), "1260"),
    termDeposit: stryMutAct_9fa48("6450") ? "" : (stryCov_9fa48("6450"), "1110"),
    investmentFund: stryMutAct_9fa48("6451") ? "" : (stryCov_9fa48("6451"), "1120"),
    personalDebt: stryMutAct_9fa48("6452") ? "" : (stryCov_9fa48("6452"), "2120")
  }),
  accounts: stryMutAct_9fa48("6453") ? [] : (stryCov_9fa48("6453"), [// 1 Assets
  stryMutAct_9fa48("6454") ? {} : (stryCov_9fa48("6454"), {
    code: stryMutAct_9fa48("6455") ? "" : (stryCov_9fa48("6455"), "1110"),
    name: stryMutAct_9fa48("6456") ? "" : (stryCov_9fa48("6456"), "Certificates of deposit"),
    use: stryMutAct_9fa48("6457") ? "" : (stryCov_9fa48("6457"), "general"),
    reportingConcept: stryMutAct_9fa48("6458") ? "" : (stryCov_9fa48("6458"), "us-gaap:CertificatesOfDepositAtCarryingValue")
  }), stryMutAct_9fa48("6459") ? {} : (stryCov_9fa48("6459"), {
    code: stryMutAct_9fa48("6460") ? "" : (stryCov_9fa48("6460"), "1120"),
    name: stryMutAct_9fa48("6461") ? "" : (stryCov_9fa48("6461"), "Investment fund units"),
    use: stryMutAct_9fa48("6462") ? "" : (stryCov_9fa48("6462"), "general"),
    reportingConcept: stryMutAct_9fa48("6463") ? "" : (stryCov_9fa48("6463"), "us-gaap:EquitySecuritiesFvNi")
  }), stryMutAct_9fa48("6464") ? {} : (stryCov_9fa48("6464"), {
    code: stryMutAct_9fa48("6465") ? "" : (stryCov_9fa48("6465"), "1210"),
    name: stryMutAct_9fa48("6466") ? "" : (stryCov_9fa48("6466"), "Advances to suppliers"),
    use: stryMutAct_9fa48("6467") ? "" : (stryCov_9fa48("6467"), "general")
  }), stryMutAct_9fa48("6468") ? {} : (stryCov_9fa48("6468"), {
    code: stryMutAct_9fa48("6469") ? "" : (stryCov_9fa48("6469"), "1220"),
    name: stryMutAct_9fa48("6470") ? "" : (stryCov_9fa48("6470"), "Dividends receivable"),
    use: stryMutAct_9fa48("6471") ? "" : (stryCov_9fa48("6471"), "general"),
    reportingConcept: stryMutAct_9fa48("6472") ? "" : (stryCov_9fa48("6472"), "us-gaap:DividendsReceivable")
  }), stryMutAct_9fa48("6473") ? {} : (stryCov_9fa48("6473"), {
    code: stryMutAct_9fa48("6474") ? "" : (stryCov_9fa48("6474"), "1230"),
    name: stryMutAct_9fa48("6475") ? "" : (stryCov_9fa48("6475"), "Interest receivable"),
    use: stryMutAct_9fa48("6476") ? "" : (stryCov_9fa48("6476"), "general"),
    reportingConcept: stryMutAct_9fa48("6477") ? "" : (stryCov_9fa48("6477"), "us-gaap:InterestReceivable")
  }), stryMutAct_9fa48("6478") ? {} : (stryCov_9fa48("6478"), {
    code: stryMutAct_9fa48("6479") ? "" : (stryCov_9fa48("6479"), "1240"),
    name: stryMutAct_9fa48("6480") ? "" : (stryCov_9fa48("6480"), "Rent receivable"),
    use: stryMutAct_9fa48("6481") ? "" : (stryCov_9fa48("6481"), "general")
  }), stryMutAct_9fa48("6482") ? {} : (stryCov_9fa48("6482"), {
    code: stryMutAct_9fa48("6483") ? "" : (stryCov_9fa48("6483"), "1250"),
    name: stryMutAct_9fa48("6484") ? "" : (stryCov_9fa48("6484"), "Loans to individuals, secured"),
    use: stryMutAct_9fa48("6485") ? "" : (stryCov_9fa48("6485"), "general"),
    reportingConcept: stryMutAct_9fa48("6486") ? "" : (stryCov_9fa48("6486"), "us-gaap:NotesReceivableGross")
  }), stryMutAct_9fa48("6487") ? {} : (stryCov_9fa48("6487"), {
    code: stryMutAct_9fa48("6488") ? "" : (stryCov_9fa48("6488"), "1260"),
    name: stryMutAct_9fa48("6489") ? "" : (stryCov_9fa48("6489"), "Loans to individuals, unsecured"),
    use: stryMutAct_9fa48("6490") ? "" : (stryCov_9fa48("6490"), "general"),
    reportingConcept: stryMutAct_9fa48("6491") ? "" : (stryCov_9fa48("6491"), "us-gaap:NotesReceivableGross")
  }), stryMutAct_9fa48("6492") ? {} : (stryCov_9fa48("6492"), {
    code: stryMutAct_9fa48("6493") ? "" : (stryCov_9fa48("6493"), "1270"),
    name: stryMutAct_9fa48("6494") ? "" : (stryCov_9fa48("6494"), "Payments made on behalf of others"),
    use: stryMutAct_9fa48("6495") ? "" : (stryCov_9fa48("6495"), "general"),
    reportingConcept: stryMutAct_9fa48("6496") ? "" : (stryCov_9fa48("6496"), "us-gaap:OtherReceivables")
  }), stryMutAct_9fa48("6497") ? {} : (stryCov_9fa48("6497"), {
    code: stryMutAct_9fa48("6498") ? "" : (stryCov_9fa48("6498"), "1310"),
    name: stryMutAct_9fa48("6499") ? "" : (stryCov_9fa48("6499"), "Prepaid insurance"),
    use: stryMutAct_9fa48("6500") ? "" : (stryCov_9fa48("6500"), "general"),
    reportingConcept: stryMutAct_9fa48("6501") ? "" : (stryCov_9fa48("6501"), "us-gaap:PrepaidInsurance")
  }), stryMutAct_9fa48("6502") ? {} : (stryCov_9fa48("6502"), {
    code: stryMutAct_9fa48("6503") ? "" : (stryCov_9fa48("6503"), "1320"),
    name: stryMutAct_9fa48("6504") ? "" : (stryCov_9fa48("6504"), "Prepaid subscriptions"),
    use: stryMutAct_9fa48("6505") ? "" : (stryCov_9fa48("6505"), "general"),
    reportingConcept: stryMutAct_9fa48("6506") ? "" : (stryCov_9fa48("6506"), "us-gaap:OtherPrepaidExpenseCurrent")
  }), stryMutAct_9fa48("6507") ? {} : (stryCov_9fa48("6507"), {
    code: stryMutAct_9fa48("6508") ? "" : (stryCov_9fa48("6508"), "1510"),
    name: stryMutAct_9fa48("6509") ? "" : (stryCov_9fa48("6509"), "Land"),
    use: stryMutAct_9fa48("6510") ? "" : (stryCov_9fa48("6510"), "general"),
    reportingConcept: stryMutAct_9fa48("6511") ? "" : (stryCov_9fa48("6511"), "us-gaap:Land")
  }), stryMutAct_9fa48("6512") ? {} : (stryCov_9fa48("6512"), {
    code: stryMutAct_9fa48("6513") ? "" : (stryCov_9fa48("6513"), "1520"),
    name: stryMutAct_9fa48("6514") ? "" : (stryCov_9fa48("6514"), "Buildings"),
    use: stryMutAct_9fa48("6515") ? "" : (stryCov_9fa48("6515"), "general"),
    reportingConcept: stryMutAct_9fa48("6516") ? "" : (stryCov_9fa48("6516"), "us-gaap:BuildingsAndImprovementsGross")
  }), stryMutAct_9fa48("6517") ? {} : (stryCov_9fa48("6517"), {
    code: stryMutAct_9fa48("6518") ? "" : (stryCov_9fa48("6518"), "1530"),
    name: stryMutAct_9fa48("6519") ? "" : (stryCov_9fa48("6519"), "Furniture and fixtures"),
    use: stryMutAct_9fa48("6520") ? "" : (stryCov_9fa48("6520"), "general"),
    reportingConcept: stryMutAct_9fa48("6521") ? "" : (stryCov_9fa48("6521"), "us-gaap:FurnitureAndFixturesGross")
  }), stryMutAct_9fa48("6522") ? {} : (stryCov_9fa48("6522"), {
    code: stryMutAct_9fa48("6523") ? "" : (stryCov_9fa48("6523"), "1540"),
    name: stryMutAct_9fa48("6524") ? "" : (stryCov_9fa48("6524"), "Computer equipment"),
    use: stryMutAct_9fa48("6525") ? "" : (stryCov_9fa48("6525"), "general"),
    reportingConcept: stryMutAct_9fa48("6526") ? "" : (stryCov_9fa48("6526"), "us-gaap:PropertyPlantAndEquipmentGross")
  }), stryMutAct_9fa48("6527") ? {} : (stryCov_9fa48("6527"), {
    code: stryMutAct_9fa48("6528") ? "" : (stryCov_9fa48("6528"), "1550"),
    name: stryMutAct_9fa48("6529") ? "" : (stryCov_9fa48("6529"), "Vehicles"),
    use: stryMutAct_9fa48("6530") ? "" : (stryCov_9fa48("6530"), "general"),
    reportingConcept: stryMutAct_9fa48("6531") ? "" : (stryCov_9fa48("6531"), "us-gaap:PropertyPlantAndEquipmentGross")
  }), stryMutAct_9fa48("6532") ? {} : (stryCov_9fa48("6532"), {
    code: stryMutAct_9fa48("6533") ? "" : (stryCov_9fa48("6533"), "1560"),
    name: stryMutAct_9fa48("6534") ? "" : (stryCov_9fa48("6534"), "Motorcycles"),
    use: stryMutAct_9fa48("6535") ? "" : (stryCov_9fa48("6535"), "general"),
    reportingConcept: stryMutAct_9fa48("6536") ? "" : (stryCov_9fa48("6536"), "us-gaap:PropertyPlantAndEquipmentGross")
  }), stryMutAct_9fa48("6537") ? {} : (stryCov_9fa48("6537"), {
    code: stryMutAct_9fa48("6538") ? "" : (stryCov_9fa48("6538"), "1591"),
    name: stryMutAct_9fa48("6539") ? "" : (stryCov_9fa48("6539"), "Accumulated depreciation, buildings"),
    use: stryMutAct_9fa48("6540") ? "" : (stryCov_9fa48("6540"), "general"),
    normalSide: stryMutAct_9fa48("6541") ? "" : (stryCov_9fa48("6541"), "Credit"),
    reportingConcept: stryMutAct_9fa48("6542") ? "" : (stryCov_9fa48("6542"), "us-gaap:AccumulatedDepreciationDepletionAndAmortizationPropertyPlantAndEquipment")
  }), stryMutAct_9fa48("6543") ? {} : (stryCov_9fa48("6543"), {
    code: stryMutAct_9fa48("6544") ? "" : (stryCov_9fa48("6544"), "1592"),
    name: stryMutAct_9fa48("6545") ? "" : (stryCov_9fa48("6545"), "Accumulated depreciation, furniture and fixtures"),
    use: stryMutAct_9fa48("6546") ? "" : (stryCov_9fa48("6546"), "general"),
    normalSide: stryMutAct_9fa48("6547") ? "" : (stryCov_9fa48("6547"), "Credit"),
    reportingConcept: stryMutAct_9fa48("6548") ? "" : (stryCov_9fa48("6548"), "us-gaap:AccumulatedDepreciationDepletionAndAmortizationPropertyPlantAndEquipment")
  }), stryMutAct_9fa48("6549") ? {} : (stryCov_9fa48("6549"), {
    code: stryMutAct_9fa48("6550") ? "" : (stryCov_9fa48("6550"), "1593"),
    name: stryMutAct_9fa48("6551") ? "" : (stryCov_9fa48("6551"), "Accumulated depreciation, computer equipment"),
    use: stryMutAct_9fa48("6552") ? "" : (stryCov_9fa48("6552"), "general"),
    normalSide: stryMutAct_9fa48("6553") ? "" : (stryCov_9fa48("6553"), "Credit"),
    reportingConcept: stryMutAct_9fa48("6554") ? "" : (stryCov_9fa48("6554"), "us-gaap:AccumulatedDepreciationDepletionAndAmortizationPropertyPlantAndEquipment")
  }), stryMutAct_9fa48("6555") ? {} : (stryCov_9fa48("6555"), {
    code: stryMutAct_9fa48("6556") ? "" : (stryCov_9fa48("6556"), "1594"),
    name: stryMutAct_9fa48("6557") ? "" : (stryCov_9fa48("6557"), "Accumulated depreciation, vehicles"),
    use: stryMutAct_9fa48("6558") ? "" : (stryCov_9fa48("6558"), "general"),
    normalSide: stryMutAct_9fa48("6559") ? "" : (stryCov_9fa48("6559"), "Credit"),
    reportingConcept: stryMutAct_9fa48("6560") ? "" : (stryCov_9fa48("6560"), "us-gaap:AccumulatedDepreciationDepletionAndAmortizationPropertyPlantAndEquipment")
  }), // 2 Liabilities
  stryMutAct_9fa48("6561") ? {} : (stryCov_9fa48("6561"), {
    code: stryMutAct_9fa48("6562") ? "" : (stryCov_9fa48("6562"), "2120"),
    name: stryMutAct_9fa48("6563") ? "" : (stryCov_9fa48("6563"), "Loans from individuals"),
    use: stryMutAct_9fa48("6564") ? "" : (stryCov_9fa48("6564"), "general"),
    reportingConcept: stryMutAct_9fa48("6565") ? "" : (stryCov_9fa48("6565"), "us-gaap:OtherNotesPayable")
  }), stryMutAct_9fa48("6566") ? {} : (stryCov_9fa48("6566"), {
    code: stryMutAct_9fa48("6567") ? "" : (stryCov_9fa48("6567"), "2210"),
    name: stryMutAct_9fa48("6568") ? "" : (stryCov_9fa48("6568"), "Accrued expenses"),
    use: stryMutAct_9fa48("6569") ? "" : (stryCov_9fa48("6569"), "general"),
    reportingConcept: stryMutAct_9fa48("6570") ? "" : (stryCov_9fa48("6570"), "us-gaap:AccruedLiabilitiesCurrent")
  }), stryMutAct_9fa48("6571") ? {} : (stryCov_9fa48("6571"), {
    code: stryMutAct_9fa48("6572") ? "" : (stryCov_9fa48("6572"), "2220"),
    name: stryMutAct_9fa48("6573") ? "" : (stryCov_9fa48("6573"), "Reimbursements payable"),
    use: stryMutAct_9fa48("6574") ? "" : (stryCov_9fa48("6574"), "general"),
    reportingConcept: stryMutAct_9fa48("6575") ? "" : (stryCov_9fa48("6575"), "us-gaap:AccountsPayableOtherCurrent")
  }), stryMutAct_9fa48("6576") ? {} : (stryCov_9fa48("6576"), {
    code: stryMutAct_9fa48("6577") ? "" : (stryCov_9fa48("6577"), "2230"),
    name: stryMutAct_9fa48("6578") ? "" : (stryCov_9fa48("6578"), "Income taxes payable"),
    use: stryMutAct_9fa48("6579") ? "" : (stryCov_9fa48("6579"), "general"),
    reportingConcept: stryMutAct_9fa48("6580") ? "" : (stryCov_9fa48("6580"), "us-gaap:AccruedIncomeTaxesCurrent")
  }), stryMutAct_9fa48("6581") ? {} : (stryCov_9fa48("6581"), {
    code: stryMutAct_9fa48("6582") ? "" : (stryCov_9fa48("6582"), "2310"),
    name: stryMutAct_9fa48("6583") ? "" : (stryCov_9fa48("6583"), "Rent received in advance"),
    use: stryMutAct_9fa48("6584") ? "" : (stryCov_9fa48("6584"), "general"),
    reportingConcept: stryMutAct_9fa48("6585") ? "" : (stryCov_9fa48("6585"), "us-gaap:DeferredRevenueCurrent")
  }), stryMutAct_9fa48("6586") ? {} : (stryCov_9fa48("6586"), {
    code: stryMutAct_9fa48("6587") ? "" : (stryCov_9fa48("6587"), "2320"),
    name: stryMutAct_9fa48("6588") ? "" : (stryCov_9fa48("6588"), "Customer advances"),
    use: stryMutAct_9fa48("6589") ? "" : (stryCov_9fa48("6589"), "general"),
    reportingConcept: stryMutAct_9fa48("6590") ? "" : (stryCov_9fa48("6590"), "us-gaap:ContractWithCustomerLiabilityCurrent")
  }), stryMutAct_9fa48("6591") ? {} : (stryCov_9fa48("6591"), {
    code: stryMutAct_9fa48("6592") ? "" : (stryCov_9fa48("6592"), "2330"),
    name: stryMutAct_9fa48("6593") ? "" : (stryCov_9fa48("6593"), "Security deposits received"),
    use: stryMutAct_9fa48("6594") ? "" : (stryCov_9fa48("6594"), "general"),
    reportingConcept: stryMutAct_9fa48("6595") ? "" : (stryCov_9fa48("6595"), "us-gaap:SecurityDepositLiability")
  }), // 3 Net worth
  stryMutAct_9fa48("6596") ? {} : (stryCov_9fa48("6596"), {
    code: stryMutAct_9fa48("6597") ? "" : (stryCov_9fa48("6597"), "3010"),
    name: stryMutAct_9fa48("6598") ? "" : (stryCov_9fa48("6598"), "Opening balance equity"),
    use: stryMutAct_9fa48("6599") ? "" : (stryCov_9fa48("6599"), "openingBalance")
  }), // 4 Revenue
  stryMutAct_9fa48("6600") ? {} : (stryCov_9fa48("6600"), {
    code: stryMutAct_9fa48("6601") ? "" : (stryCov_9fa48("6601"), "4010"),
    name: stryMutAct_9fa48("6602") ? "" : (stryCov_9fa48("6602"), "Salary and wages"),
    use: stryMutAct_9fa48("6603") ? "" : (stryCov_9fa48("6603"), "income")
  }), stryMutAct_9fa48("6604") ? {} : (stryCov_9fa48("6604"), {
    code: stryMutAct_9fa48("6605") ? "" : (stryCov_9fa48("6605"), "4020"),
    name: stryMutAct_9fa48("6606") ? "" : (stryCov_9fa48("6606"), "Bonuses"),
    use: stryMutAct_9fa48("6607") ? "" : (stryCov_9fa48("6607"), "income")
  }), stryMutAct_9fa48("6608") ? {} : (stryCov_9fa48("6608"), {
    code: stryMutAct_9fa48("6609") ? "" : (stryCov_9fa48("6609"), "4030"),
    name: stryMutAct_9fa48("6610") ? "" : (stryCov_9fa48("6610"), "Consulting fees"),
    use: stryMutAct_9fa48("6611") ? "" : (stryCov_9fa48("6611"), "income"),
    reportingConcept: stryMutAct_9fa48("6612") ? "" : (stryCov_9fa48("6612"), "us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax")
  }), stryMutAct_9fa48("6613") ? {} : (stryCov_9fa48("6613"), {
    code: stryMutAct_9fa48("6614") ? "" : (stryCov_9fa48("6614"), "4110"),
    name: stryMutAct_9fa48("6615") ? "" : (stryCov_9fa48("6615"), "Interest income"),
    use: stryMutAct_9fa48("6616") ? "" : (stryCov_9fa48("6616"), "income"),
    reportingConcept: stryMutAct_9fa48("6617") ? "" : (stryCov_9fa48("6617"), "us-gaap:InvestmentIncomeInterest")
  }), stryMutAct_9fa48("6618") ? {} : (stryCov_9fa48("6618"), {
    code: stryMutAct_9fa48("6619") ? "" : (stryCov_9fa48("6619"), "4120"),
    name: stryMutAct_9fa48("6620") ? "" : (stryCov_9fa48("6620"), "Dividend income"),
    use: stryMutAct_9fa48("6621") ? "" : (stryCov_9fa48("6621"), "income"),
    reportingConcept: stryMutAct_9fa48("6622") ? "" : (stryCov_9fa48("6622"), "us-gaap:InvestmentIncomeDividend")
  }), stryMutAct_9fa48("6623") ? {} : (stryCov_9fa48("6623"), {
    code: stryMutAct_9fa48("6624") ? "" : (stryCov_9fa48("6624"), "4130"),
    name: stryMutAct_9fa48("6625") ? "" : (stryCov_9fa48("6625"), "Gain on sale of investments"),
    use: stryMutAct_9fa48("6626") ? "" : (stryCov_9fa48("6626"), "general"),
    reportingConcept: stryMutAct_9fa48("6627") ? "" : (stryCov_9fa48("6627"), "us-gaap:GainLossOnInvestments")
  }), stryMutAct_9fa48("6628") ? {} : (stryCov_9fa48("6628"), {
    code: stryMutAct_9fa48("6629") ? "" : (stryCov_9fa48("6629"), "4140"),
    name: stryMutAct_9fa48("6630") ? "" : (stryCov_9fa48("6630"), "Foreign exchange gains"),
    use: stryMutAct_9fa48("6631") ? "" : (stryCov_9fa48("6631"), "general"),
    reportingConcept: stryMutAct_9fa48("6632") ? "" : (stryCov_9fa48("6632"), "us-gaap:ForeignCurrencyTransactionGainBeforeTax")
  }), stryMutAct_9fa48("6633") ? {} : (stryCov_9fa48("6633"), {
    code: stryMutAct_9fa48("6634") ? "" : (stryCov_9fa48("6634"), "4210"),
    name: stryMutAct_9fa48("6635") ? "" : (stryCov_9fa48("6635"), "Long-term rental income"),
    use: stryMutAct_9fa48("6636") ? "" : (stryCov_9fa48("6636"), "income"),
    reportingConcept: stryMutAct_9fa48("6637") ? "" : (stryCov_9fa48("6637"), "us-gaap:RentalIncomeNonoperating")
  }), stryMutAct_9fa48("6638") ? {} : (stryCov_9fa48("6638"), {
    code: stryMutAct_9fa48("6639") ? "" : (stryCov_9fa48("6639"), "4220"),
    name: stryMutAct_9fa48("6640") ? "" : (stryCov_9fa48("6640"), "Short-stay accommodation income"),
    use: stryMutAct_9fa48("6641") ? "" : (stryCov_9fa48("6641"), "income"),
    reportingConcept: stryMutAct_9fa48("6642") ? "" : (stryCov_9fa48("6642"), "us-gaap:OccupancyNet")
  }), stryMutAct_9fa48("6643") ? {} : (stryCov_9fa48("6643"), {
    code: stryMutAct_9fa48("6644") ? "" : (stryCov_9fa48("6644"), "4910"),
    name: stryMutAct_9fa48("6645") ? "" : (stryCov_9fa48("6645"), "Prizes"),
    use: stryMutAct_9fa48("6646") ? "" : (stryCov_9fa48("6646"), "income"),
    reportingConcept: stryMutAct_9fa48("6647") ? "" : (stryCov_9fa48("6647"), "us-gaap:OtherNonoperatingIncome")
  }), stryMutAct_9fa48("6648") ? {} : (stryCov_9fa48("6648"), {
    code: stryMutAct_9fa48("6649") ? "" : (stryCov_9fa48("6649"), "4920"),
    name: stryMutAct_9fa48("6650") ? "" : (stryCov_9fa48("6650"), "Gifts and support received"),
    use: stryMutAct_9fa48("6651") ? "" : (stryCov_9fa48("6651"), "income")
  }), stryMutAct_9fa48("6652") ? {} : (stryCov_9fa48("6652"), {
    code: stryMutAct_9fa48("6653") ? "" : (stryCov_9fa48("6653"), "4990"),
    name: stryMutAct_9fa48("6654") ? "" : (stryCov_9fa48("6654"), "Other income"),
    use: stryMutAct_9fa48("6655") ? "" : (stryCov_9fa48("6655"), "income"),
    reportingConcept: stryMutAct_9fa48("6656") ? "" : (stryCov_9fa48("6656"), "us-gaap:OtherNonoperatingIncome")
  }), // 5 Living expenses
  stryMutAct_9fa48("6657") ? {} : (stryCov_9fa48("6657"), {
    code: stryMutAct_9fa48("6658") ? "" : (stryCov_9fa48("6658"), "5010"),
    name: stryMutAct_9fa48("6659") ? "" : (stryCov_9fa48("6659"), "Rent"),
    use: stryMutAct_9fa48("6660") ? "" : (stryCov_9fa48("6660"), "expense"),
    reportingConcept: stryMutAct_9fa48("6661") ? "" : (stryCov_9fa48("6661"), "us-gaap:OperatingLeaseCost")
  }), stryMutAct_9fa48("6662") ? {} : (stryCov_9fa48("6662"), {
    code: stryMutAct_9fa48("6663") ? "" : (stryCov_9fa48("6663"), "5020"),
    name: stryMutAct_9fa48("6664") ? "" : (stryCov_9fa48("6664"), "Home repairs and maintenance"),
    use: stryMutAct_9fa48("6665") ? "" : (stryCov_9fa48("6665"), "expense"),
    reportingConcept: stryMutAct_9fa48("6666") ? "" : (stryCov_9fa48("6666"), "us-gaap:CostOfPropertyRepairsAndMaintenance")
  }), stryMutAct_9fa48("6667") ? {} : (stryCov_9fa48("6667"), {
    code: stryMutAct_9fa48("6668") ? "" : (stryCov_9fa48("6668"), "5030"),
    name: stryMutAct_9fa48("6669") ? "" : (stryCov_9fa48("6669"), "Property tax"),
    use: stryMutAct_9fa48("6670") ? "" : (stryCov_9fa48("6670"), "expense"),
    reportingConcept: stryMutAct_9fa48("6671") ? "" : (stryCov_9fa48("6671"), "us-gaap:RealEstateTaxExpense")
  }), stryMutAct_9fa48("6672") ? {} : (stryCov_9fa48("6672"), {
    code: stryMutAct_9fa48("6673") ? "" : (stryCov_9fa48("6673"), "5040"),
    name: stryMutAct_9fa48("6674") ? "" : (stryCov_9fa48("6674"), "Cleaning and security services"),
    use: stryMutAct_9fa48("6675") ? "" : (stryCov_9fa48("6675"), "expense")
  }), stryMutAct_9fa48("6676") ? {} : (stryCov_9fa48("6676"), {
    code: stryMutAct_9fa48("6677") ? "" : (stryCov_9fa48("6677"), "5110"),
    name: stryMutAct_9fa48("6678") ? "" : (stryCov_9fa48("6678"), "Water and sewer"),
    use: stryMutAct_9fa48("6679") ? "" : (stryCov_9fa48("6679"), "expense")
  }), stryMutAct_9fa48("6680") ? {} : (stryCov_9fa48("6680"), {
    code: stryMutAct_9fa48("6681") ? "" : (stryCov_9fa48("6681"), "5120"),
    name: stryMutAct_9fa48("6682") ? "" : (stryCov_9fa48("6682"), "Electricity"),
    use: stryMutAct_9fa48("6683") ? "" : (stryCov_9fa48("6683"), "expense")
  }), stryMutAct_9fa48("6684") ? {} : (stryCov_9fa48("6684"), {
    code: stryMutAct_9fa48("6685") ? "" : (stryCov_9fa48("6685"), "5130"),
    name: stryMutAct_9fa48("6686") ? "" : (stryCov_9fa48("6686"), "Gas"),
    use: stryMutAct_9fa48("6687") ? "" : (stryCov_9fa48("6687"), "expense")
  }), stryMutAct_9fa48("6688") ? {} : (stryCov_9fa48("6688"), {
    code: stryMutAct_9fa48("6689") ? "" : (stryCov_9fa48("6689"), "5140"),
    name: stryMutAct_9fa48("6690") ? "" : (stryCov_9fa48("6690"), "Phone and internet"),
    use: stryMutAct_9fa48("6691") ? "" : (stryCov_9fa48("6691"), "expense"),
    reportingConcept: stryMutAct_9fa48("6692") ? "" : (stryCov_9fa48("6692"), "us-gaap:Communication")
  }), stryMutAct_9fa48("6693") ? {} : (stryCov_9fa48("6693"), {
    code: stryMutAct_9fa48("6694") ? "" : (stryCov_9fa48("6694"), "5150"),
    name: stryMutAct_9fa48("6695") ? "" : (stryCov_9fa48("6695"), "Software and digital services"),
    use: stryMutAct_9fa48("6696") ? "" : (stryCov_9fa48("6696"), "expense"),
    reportingConcept: stryMutAct_9fa48("6697") ? "" : (stryCov_9fa48("6697"), "us-gaap:InformationTechnologyAndDataProcessing")
  }), stryMutAct_9fa48("6698") ? {} : (stryCov_9fa48("6698"), {
    code: stryMutAct_9fa48("6699") ? "" : (stryCov_9fa48("6699"), "5160"),
    name: stryMutAct_9fa48("6700") ? "" : (stryCov_9fa48("6700"), "Books and subscriptions"),
    use: stryMutAct_9fa48("6701") ? "" : (stryCov_9fa48("6701"), "expense")
  }), stryMutAct_9fa48("6702") ? {} : (stryCov_9fa48("6702"), {
    code: stryMutAct_9fa48("6703") ? "" : (stryCov_9fa48("6703"), "5210"),
    name: stryMutAct_9fa48("6704") ? "" : (stryCov_9fa48("6704"), "Fuel"),
    use: stryMutAct_9fa48("6705") ? "" : (stryCov_9fa48("6705"), "expense"),
    reportingConcept: stryMutAct_9fa48("6706") ? "" : (stryCov_9fa48("6706"), "us-gaap:FuelCosts")
  }), stryMutAct_9fa48("6707") ? {} : (stryCov_9fa48("6707"), {
    code: stryMutAct_9fa48("6708") ? "" : (stryCov_9fa48("6708"), "5220"),
    name: stryMutAct_9fa48("6709") ? "" : (stryCov_9fa48("6709"), "Taxis and public transit"),
    use: stryMutAct_9fa48("6710") ? "" : (stryCov_9fa48("6710"), "expense")
  }), stryMutAct_9fa48("6711") ? {} : (stryCov_9fa48("6711"), {
    code: stryMutAct_9fa48("6712") ? "" : (stryCov_9fa48("6712"), "5230"),
    name: stryMutAct_9fa48("6713") ? "" : (stryCov_9fa48("6713"), "Parking"),
    use: stryMutAct_9fa48("6714") ? "" : (stryCov_9fa48("6714"), "expense")
  }), stryMutAct_9fa48("6715") ? {} : (stryCov_9fa48("6715"), {
    code: stryMutAct_9fa48("6716") ? "" : (stryCov_9fa48("6716"), "5240"),
    name: stryMutAct_9fa48("6717") ? "" : (stryCov_9fa48("6717"), "Vehicle repairs and maintenance"),
    use: stryMutAct_9fa48("6718") ? "" : (stryCov_9fa48("6718"), "expense")
  }), stryMutAct_9fa48("6719") ? {} : (stryCov_9fa48("6719"), {
    code: stryMutAct_9fa48("6720") ? "" : (stryCov_9fa48("6720"), "5250"),
    name: stryMutAct_9fa48("6721") ? "" : (stryCov_9fa48("6721"), "Vehicle tax"),
    use: stryMutAct_9fa48("6722") ? "" : (stryCov_9fa48("6722"), "expense"),
    reportingConcept: stryMutAct_9fa48("6723") ? "" : (stryCov_9fa48("6723"), "us-gaap:TaxesOther")
  }), stryMutAct_9fa48("6724") ? {} : (stryCov_9fa48("6724"), {
    code: stryMutAct_9fa48("6725") ? "" : (stryCov_9fa48("6725"), "5260"),
    name: stryMutAct_9fa48("6726") ? "" : (stryCov_9fa48("6726"), "Shipping and moving"),
    use: stryMutAct_9fa48("6727") ? "" : (stryCov_9fa48("6727"), "expense")
  }), stryMutAct_9fa48("6728") ? {} : (stryCov_9fa48("6728"), {
    code: stryMutAct_9fa48("6729") ? "" : (stryCov_9fa48("6729"), "5310"),
    name: stryMutAct_9fa48("6730") ? "" : (stryCov_9fa48("6730"), "Groceries"),
    use: stryMutAct_9fa48("6731") ? "" : (stryCov_9fa48("6731"), "expense")
  }), stryMutAct_9fa48("6732") ? {} : (stryCov_9fa48("6732"), {
    code: stryMutAct_9fa48("6733") ? "" : (stryCov_9fa48("6733"), "5320"),
    name: stryMutAct_9fa48("6734") ? "" : (stryCov_9fa48("6734"), "Restaurants and cafés"),
    use: stryMutAct_9fa48("6735") ? "" : (stryCov_9fa48("6735"), "expense")
  }), stryMutAct_9fa48("6736") ? {} : (stryCov_9fa48("6736"), {
    code: stryMutAct_9fa48("6737") ? "" : (stryCov_9fa48("6737"), "5330"),
    name: stryMutAct_9fa48("6738") ? "" : (stryCov_9fa48("6738"), "Household supplies"),
    use: stryMutAct_9fa48("6739") ? "" : (stryCov_9fa48("6739"), "expense"),
    reportingConcept: stryMutAct_9fa48("6740") ? "" : (stryCov_9fa48("6740"), "us-gaap:SuppliesExpense")
  }), stryMutAct_9fa48("6741") ? {} : (stryCov_9fa48("6741"), {
    code: stryMutAct_9fa48("6742") ? "" : (stryCov_9fa48("6742"), "5410"),
    name: stryMutAct_9fa48("6743") ? "" : (stryCov_9fa48("6743"), "Life insurance"),
    use: stryMutAct_9fa48("6744") ? "" : (stryCov_9fa48("6744"), "expense"),
    reportingConcept: stryMutAct_9fa48("6745") ? "" : (stryCov_9fa48("6745"), "us-gaap:GeneralInsuranceExpense")
  }), stryMutAct_9fa48("6746") ? {} : (stryCov_9fa48("6746"), {
    code: stryMutAct_9fa48("6747") ? "" : (stryCov_9fa48("6747"), "5420"),
    name: stryMutAct_9fa48("6748") ? "" : (stryCov_9fa48("6748"), "Vehicle insurance"),
    use: stryMutAct_9fa48("6749") ? "" : (stryCov_9fa48("6749"), "expense"),
    reportingConcept: stryMutAct_9fa48("6750") ? "" : (stryCov_9fa48("6750"), "us-gaap:GeneralInsuranceExpense")
  }), stryMutAct_9fa48("6751") ? {} : (stryCov_9fa48("6751"), {
    code: stryMutAct_9fa48("6752") ? "" : (stryCov_9fa48("6752"), "5430"),
    name: stryMutAct_9fa48("6753") ? "" : (stryCov_9fa48("6753"), "Compulsory traffic accident insurance"),
    use: stryMutAct_9fa48("6754") ? "" : (stryCov_9fa48("6754"), "expense"),
    reportingConcept: stryMutAct_9fa48("6755") ? "" : (stryCov_9fa48("6755"), "us-gaap:GeneralInsuranceExpense")
  }), stryMutAct_9fa48("6756") ? {} : (stryCov_9fa48("6756"), {
    code: stryMutAct_9fa48("6757") ? "" : (stryCov_9fa48("6757"), "5440"),
    name: stryMutAct_9fa48("6758") ? "" : (stryCov_9fa48("6758"), "Other insurance"),
    use: stryMutAct_9fa48("6759") ? "" : (stryCov_9fa48("6759"), "expense"),
    reportingConcept: stryMutAct_9fa48("6760") ? "" : (stryCov_9fa48("6760"), "us-gaap:GeneralInsuranceExpense")
  }), stryMutAct_9fa48("6761") ? {} : (stryCov_9fa48("6761"), {
    code: stryMutAct_9fa48("6762") ? "" : (stryCov_9fa48("6762"), "5510"),
    name: stryMutAct_9fa48("6763") ? "" : (stryCov_9fa48("6763"), "Health and medicine"),
    use: stryMutAct_9fa48("6764") ? "" : (stryCov_9fa48("6764"), "expense")
  }), stryMutAct_9fa48("6765") ? {} : (stryCov_9fa48("6765"), {
    code: stryMutAct_9fa48("6766") ? "" : (stryCov_9fa48("6766"), "5520"),
    name: stryMutAct_9fa48("6767") ? "" : (stryCov_9fa48("6767"), "Personal care"),
    use: stryMutAct_9fa48("6768") ? "" : (stryCov_9fa48("6768"), "expense")
  }), stryMutAct_9fa48("6769") ? {} : (stryCov_9fa48("6769"), {
    code: stryMutAct_9fa48("6770") ? "" : (stryCov_9fa48("6770"), "5530"),
    name: stryMutAct_9fa48("6771") ? "" : (stryCov_9fa48("6771"), "Clothing and footwear"),
    use: stryMutAct_9fa48("6772") ? "" : (stryCov_9fa48("6772"), "expense")
  }), stryMutAct_9fa48("6773") ? {} : (stryCov_9fa48("6773"), {
    code: stryMutAct_9fa48("6774") ? "" : (stryCov_9fa48("6774"), "5540"),
    name: stryMutAct_9fa48("6775") ? "" : (stryCov_9fa48("6775"), "Education"),
    use: stryMutAct_9fa48("6776") ? "" : (stryCov_9fa48("6776"), "expense")
  }), stryMutAct_9fa48("6777") ? {} : (stryCov_9fa48("6777"), {
    code: stryMutAct_9fa48("6778") ? "" : (stryCov_9fa48("6778"), "5550"),
    name: stryMutAct_9fa48("6779") ? "" : (stryCov_9fa48("6779"), "Sports and wellness"),
    use: stryMutAct_9fa48("6780") ? "" : (stryCov_9fa48("6780"), "expense")
  }), stryMutAct_9fa48("6781") ? {} : (stryCov_9fa48("6781"), {
    code: stryMutAct_9fa48("6782") ? "" : (stryCov_9fa48("6782"), "5560"),
    name: stryMutAct_9fa48("6783") ? "" : (stryCov_9fa48("6783"), "Entertainment and recreation"),
    use: stryMutAct_9fa48("6784") ? "" : (stryCov_9fa48("6784"), "expense")
  }), stryMutAct_9fa48("6785") ? {} : (stryCov_9fa48("6785"), {
    code: stryMutAct_9fa48("6786") ? "" : (stryCov_9fa48("6786"), "5570"),
    name: stryMutAct_9fa48("6787") ? "" : (stryCov_9fa48("6787"), "Gifts and family support"),
    use: stryMutAct_9fa48("6788") ? "" : (stryCov_9fa48("6788"), "expense")
  }), stryMutAct_9fa48("6789") ? {} : (stryCov_9fa48("6789"), {
    code: stryMutAct_9fa48("6790") ? "" : (stryCov_9fa48("6790"), "5580"),
    name: stryMutAct_9fa48("6791") ? "" : (stryCov_9fa48("6791"), "Pets"),
    use: stryMutAct_9fa48("6792") ? "" : (stryCov_9fa48("6792"), "expense")
  }), stryMutAct_9fa48("6793") ? {} : (stryCov_9fa48("6793"), {
    code: stryMutAct_9fa48("6794") ? "" : (stryCov_9fa48("6794"), "5590"),
    name: stryMutAct_9fa48("6795") ? "" : (stryCov_9fa48("6795"), "Technology and accessories"),
    use: stryMutAct_9fa48("6796") ? "" : (stryCov_9fa48("6796"), "expense")
  }), stryMutAct_9fa48("6797") ? {} : (stryCov_9fa48("6797"), {
    code: stryMutAct_9fa48("6798") ? "" : (stryCov_9fa48("6798"), "5599"),
    name: stryMutAct_9fa48("6799") ? "" : (stryCov_9fa48("6799"), "Other personal expenses"),
    use: stryMutAct_9fa48("6800") ? "" : (stryCov_9fa48("6800"), "expense")
  }), stryMutAct_9fa48("6801") ? {} : (stryCov_9fa48("6801"), {
    code: stryMutAct_9fa48("6802") ? "" : (stryCov_9fa48("6802"), "5610"),
    name: stryMutAct_9fa48("6803") ? "" : (stryCov_9fa48("6803"), "Legal fees"),
    use: stryMutAct_9fa48("6804") ? "" : (stryCov_9fa48("6804"), "expense"),
    reportingConcept: stryMutAct_9fa48("6805") ? "" : (stryCov_9fa48("6805"), "us-gaap:LegalFees")
  }), stryMutAct_9fa48("6806") ? {} : (stryCov_9fa48("6806"), {
    code: stryMutAct_9fa48("6807") ? "" : (stryCov_9fa48("6807"), "5620"),
    name: stryMutAct_9fa48("6808") ? "" : (stryCov_9fa48("6808"), "Financial advisory fees"),
    use: stryMutAct_9fa48("6809") ? "" : (stryCov_9fa48("6809"), "expense"),
    reportingConcept: stryMutAct_9fa48("6810") ? "" : (stryCov_9fa48("6810"), "us-gaap:ProfessionalFees")
  }), stryMutAct_9fa48("6811") ? {} : (stryCov_9fa48("6811"), {
    code: stryMutAct_9fa48("6812") ? "" : (stryCov_9fa48("6812"), "5630"),
    name: stryMutAct_9fa48("6813") ? "" : (stryCov_9fa48("6813"), "Financial transaction tax"),
    use: stryMutAct_9fa48("6814") ? "" : (stryCov_9fa48("6814"), "expense"),
    reportingConcept: stryMutAct_9fa48("6815") ? "" : (stryCov_9fa48("6815"), "us-gaap:TaxesOther")
  }), stryMutAct_9fa48("6816") ? {} : (stryCov_9fa48("6816"), {
    code: stryMutAct_9fa48("6817") ? "" : (stryCov_9fa48("6817"), "5640"),
    name: stryMutAct_9fa48("6818") ? "" : (stryCov_9fa48("6818"), "Income tax"),
    use: stryMutAct_9fa48("6819") ? "" : (stryCov_9fa48("6819"), "expense"),
    reportingConcept: stryMutAct_9fa48("6820") ? "" : (stryCov_9fa48("6820"), "us-gaap:IncomeTaxExpenseBenefit")
  }), stryMutAct_9fa48("6821") ? {} : (stryCov_9fa48("6821"), {
    code: stryMutAct_9fa48("6822") ? "" : (stryCov_9fa48("6822"), "5650"),
    name: stryMutAct_9fa48("6823") ? "" : (stryCov_9fa48("6823"), "Fines and penalties"),
    use: stryMutAct_9fa48("6824") ? "" : (stryCov_9fa48("6824"), "expense")
  }), stryMutAct_9fa48("6825") ? {} : (stryCov_9fa48("6825"), {
    code: stryMutAct_9fa48("6826") ? "" : (stryCov_9fa48("6826"), "5660"),
    name: stryMutAct_9fa48("6827") ? "" : (stryCov_9fa48("6827"), "Donations"),
    use: stryMutAct_9fa48("6828") ? "" : (stryCov_9fa48("6828"), "expense")
  }), stryMutAct_9fa48("6829") ? {} : (stryCov_9fa48("6829"), {
    code: stryMutAct_9fa48("6830") ? "" : (stryCov_9fa48("6830"), "5710"),
    name: stryMutAct_9fa48("6831") ? "" : (stryCov_9fa48("6831"), "Travel lodging and meals"),
    use: stryMutAct_9fa48("6832") ? "" : (stryCov_9fa48("6832"), "expense"),
    reportingConcept: stryMutAct_9fa48("6833") ? "" : (stryCov_9fa48("6833"), "us-gaap:TravelAndEntertainmentExpense")
  }), stryMutAct_9fa48("6834") ? {} : (stryCov_9fa48("6834"), {
    code: stryMutAct_9fa48("6835") ? "" : (stryCov_9fa48("6835"), "5720"),
    name: stryMutAct_9fa48("6836") ? "" : (stryCov_9fa48("6836"), "Airfare"),
    use: stryMutAct_9fa48("6837") ? "" : (stryCov_9fa48("6837"), "expense"),
    reportingConcept: stryMutAct_9fa48("6838") ? "" : (stryCov_9fa48("6838"), "us-gaap:TravelAndEntertainmentExpense")
  }), stryMutAct_9fa48("6839") ? {} : (stryCov_9fa48("6839"), {
    code: stryMutAct_9fa48("6840") ? "" : (stryCov_9fa48("6840"), "5730"),
    name: stryMutAct_9fa48("6841") ? "" : (stryCov_9fa48("6841"), "Intercity ground fares"),
    use: stryMutAct_9fa48("6842") ? "" : (stryCov_9fa48("6842"), "expense"),
    reportingConcept: stryMutAct_9fa48("6843") ? "" : (stryCov_9fa48("6843"), "us-gaap:TravelAndEntertainmentExpense")
  }), // 6 Financial costs, depreciation, and losses
  stryMutAct_9fa48("6844") ? {} : (stryCov_9fa48("6844"), {
    code: stryMutAct_9fa48("6845") ? "" : (stryCov_9fa48("6845"), "6010"),
    name: stryMutAct_9fa48("6846") ? "" : (stryCov_9fa48("6846"), "Bank fees"),
    use: stryMutAct_9fa48("6847") ? "" : (stryCov_9fa48("6847"), "expense")
  }), stryMutAct_9fa48("6848") ? {} : (stryCov_9fa48("6848"), {
    code: stryMutAct_9fa48("6849") ? "" : (stryCov_9fa48("6849"), "6020"),
    name: stryMutAct_9fa48("6850") ? "" : (stryCov_9fa48("6850"), "Financial commissions"),
    use: stryMutAct_9fa48("6851") ? "" : (stryCov_9fa48("6851"), "expense")
  }), stryMutAct_9fa48("6852") ? {} : (stryCov_9fa48("6852"), {
    code: stryMutAct_9fa48("6853") ? "" : (stryCov_9fa48("6853"), "6030"),
    name: stryMutAct_9fa48("6854") ? "" : (stryCov_9fa48("6854"), "Interest expense"),
    use: stryMutAct_9fa48("6855") ? "" : (stryCov_9fa48("6855"), "expense"),
    reportingConcept: stryMutAct_9fa48("6856") ? "" : (stryCov_9fa48("6856"), "us-gaap:InterestExpense")
  }), stryMutAct_9fa48("6857") ? {} : (stryCov_9fa48("6857"), {
    code: stryMutAct_9fa48("6858") ? "" : (stryCov_9fa48("6858"), "6040"),
    name: stryMutAct_9fa48("6859") ? "" : (stryCov_9fa48("6859"), "Foreign exchange losses"),
    use: stryMutAct_9fa48("6860") ? "" : (stryCov_9fa48("6860"), "general"),
    reportingConcept: stryMutAct_9fa48("6861") ? "" : (stryCov_9fa48("6861"), "us-gaap:ForeignCurrencyTransactionLossBeforeTax")
  }), stryMutAct_9fa48("6862") ? {} : (stryCov_9fa48("6862"), {
    code: stryMutAct_9fa48("6863") ? "" : (stryCov_9fa48("6863"), "6110"),
    name: stryMutAct_9fa48("6864") ? "" : (stryCov_9fa48("6864"), "Depreciation, buildings"),
    use: stryMutAct_9fa48("6865") ? "" : (stryCov_9fa48("6865"), "general"),
    reportingConcept: stryMutAct_9fa48("6866") ? "" : (stryCov_9fa48("6866"), "us-gaap:Depreciation")
  }), stryMutAct_9fa48("6867") ? {} : (stryCov_9fa48("6867"), {
    code: stryMutAct_9fa48("6868") ? "" : (stryCov_9fa48("6868"), "6120"),
    name: stryMutAct_9fa48("6869") ? "" : (stryCov_9fa48("6869"), "Depreciation, furniture and fixtures"),
    use: stryMutAct_9fa48("6870") ? "" : (stryCov_9fa48("6870"), "general"),
    reportingConcept: stryMutAct_9fa48("6871") ? "" : (stryCov_9fa48("6871"), "us-gaap:Depreciation")
  }), stryMutAct_9fa48("6872") ? {} : (stryCov_9fa48("6872"), {
    code: stryMutAct_9fa48("6873") ? "" : (stryCov_9fa48("6873"), "6130"),
    name: stryMutAct_9fa48("6874") ? "" : (stryCov_9fa48("6874"), "Depreciation, computer equipment"),
    use: stryMutAct_9fa48("6875") ? "" : (stryCov_9fa48("6875"), "general"),
    reportingConcept: stryMutAct_9fa48("6876") ? "" : (stryCov_9fa48("6876"), "us-gaap:Depreciation")
  }), stryMutAct_9fa48("6877") ? {} : (stryCov_9fa48("6877"), {
    code: stryMutAct_9fa48("6878") ? "" : (stryCov_9fa48("6878"), "6140"),
    name: stryMutAct_9fa48("6879") ? "" : (stryCov_9fa48("6879"), "Depreciation, vehicles"),
    use: stryMutAct_9fa48("6880") ? "" : (stryCov_9fa48("6880"), "general"),
    reportingConcept: stryMutAct_9fa48("6881") ? "" : (stryCov_9fa48("6881"), "us-gaap:Depreciation")
  }), stryMutAct_9fa48("6882") ? {} : (stryCov_9fa48("6882"), {
    code: stryMutAct_9fa48("6883") ? "" : (stryCov_9fa48("6883"), "6150"),
    name: stryMutAct_9fa48("6884") ? "" : (stryCov_9fa48("6884"), "Loss on sale of investments"),
    use: stryMutAct_9fa48("6885") ? "" : (stryCov_9fa48("6885"), "general"),
    reportingConcept: stryMutAct_9fa48("6886") ? "" : (stryCov_9fa48("6886"), "us-gaap:GainLossOnInvestments")
  }), stryMutAct_9fa48("6887") ? {} : (stryCov_9fa48("6887"), {
    code: stryMutAct_9fa48("6888") ? "" : (stryCov_9fa48("6888"), "6160"),
    name: stryMutAct_9fa48("6889") ? "" : (stryCov_9fa48("6889"), "Loss on disposal of property and equipment"),
    use: stryMutAct_9fa48("6890") ? "" : (stryCov_9fa48("6890"), "general"),
    reportingConcept: stryMutAct_9fa48("6891") ? "" : (stryCov_9fa48("6891"), "us-gaap:GainLossOnDispositionOfAssets")
  })]),
  summaryNames: stryMutAct_9fa48("6892") ? {} : (stryCov_9fa48("6892"), {
    "2120": stryMutAct_9fa48("6893") ? "" : (stryCov_9fa48("6893"), "Loans from individuals"),
    "1120": stryMutAct_9fa48("6894") ? "" : (stryCov_9fa48("6894"), "Investment fund units"),
    "1110": stryMutAct_9fa48("6895") ? "" : (stryCov_9fa48("6895"), "Certificates of deposit"),
    "1260": stryMutAct_9fa48("6896") ? "" : (stryCov_9fa48("6896"), "Loans to individuals, unsecured"),
    "1250": stryMutAct_9fa48("6897") ? "" : (stryCov_9fa48("6897"), "Loans to individuals, secured"),
    "1": stryMutAct_9fa48("6898") ? "" : (stryCov_9fa48("6898"), "Assets"),
    "10": stryMutAct_9fa48("6899") ? "" : (stryCov_9fa48("6899"), "Cash and cash equivalents"),
    "1010": stryMutAct_9fa48("6900") ? "" : (stryCov_9fa48("6900"), "Cash on hand"),
    "1020": stryMutAct_9fa48("6901") ? "" : (stryCov_9fa48("6901"), "Checking accounts"),
    "1030": stryMutAct_9fa48("6902") ? "" : (stryCov_9fa48("6902"), "Savings accounts"),
    "11": stryMutAct_9fa48("6903") ? "" : (stryCov_9fa48("6903"), "Investments"),
    "12": stryMutAct_9fa48("6904") ? "" : (stryCov_9fa48("6904"), "Receivables"),
    "13": stryMutAct_9fa48("6905") ? "" : (stryCov_9fa48("6905"), "Prepaid expenses"),
    "15": stryMutAct_9fa48("6906") ? "" : (stryCov_9fa48("6906"), "Property and equipment"),
    "2": stryMutAct_9fa48("6907") ? "" : (stryCov_9fa48("6907"), "Liabilities"),
    "20": stryMutAct_9fa48("6908") ? "" : (stryCov_9fa48("6908"), "Credit cards"),
    "2010": stryMutAct_9fa48("6909") ? "" : (stryCov_9fa48("6909"), "Credit cards payable"),
    "21": stryMutAct_9fa48("6910") ? "" : (stryCov_9fa48("6910"), "Borrowings"),
    "2110": stryMutAct_9fa48("6911") ? "" : (stryCov_9fa48("6911"), "Loans payable"),
    "22": stryMutAct_9fa48("6912") ? "" : (stryCov_9fa48("6912"), "Payables and accrued liabilities"),
    "23": stryMutAct_9fa48("6913") ? "" : (stryCov_9fa48("6913"), "Deferred revenue and deposits"),
    "3": stryMutAct_9fa48("6914") ? "" : (stryCov_9fa48("6914"), "Net worth"),
    "30": stryMutAct_9fa48("6915") ? "" : (stryCov_9fa48("6915"), "Net worth"),
    "4": stryMutAct_9fa48("6916") ? "" : (stryCov_9fa48("6916"), "Revenue"),
    "40": stryMutAct_9fa48("6917") ? "" : (stryCov_9fa48("6917"), "Earned income"),
    "41": stryMutAct_9fa48("6918") ? "" : (stryCov_9fa48("6918"), "Investment income"),
    "42": stryMutAct_9fa48("6919") ? "" : (stryCov_9fa48("6919"), "Rental income"),
    "49": stryMutAct_9fa48("6920") ? "" : (stryCov_9fa48("6920"), "Other income"),
    "5": stryMutAct_9fa48("6921") ? "" : (stryCov_9fa48("6921"), "Living expenses"),
    "50": stryMutAct_9fa48("6922") ? "" : (stryCov_9fa48("6922"), "Housing"),
    "51": stryMutAct_9fa48("6923") ? "" : (stryCov_9fa48("6923"), "Utilities and communication"),
    "52": stryMutAct_9fa48("6924") ? "" : (stryCov_9fa48("6924"), "Transportation"),
    "53": stryMutAct_9fa48("6925") ? "" : (stryCov_9fa48("6925"), "Food and household"),
    "54": stryMutAct_9fa48("6926") ? "" : (stryCov_9fa48("6926"), "Insurance"),
    "55": stryMutAct_9fa48("6927") ? "" : (stryCov_9fa48("6927"), "Personal and family"),
    "56": stryMutAct_9fa48("6928") ? "" : (stryCov_9fa48("6928"), "Professional services and taxes"),
    "57": stryMutAct_9fa48("6929") ? "" : (stryCov_9fa48("6929"), "Travel"),
    "6": stryMutAct_9fa48("6930") ? "" : (stryCov_9fa48("6930"), "Financial and other expenses"),
    "60": stryMutAct_9fa48("6931") ? "" : (stryCov_9fa48("6931"), "Financial costs"),
    "61": stryMutAct_9fa48("6932") ? "" : (stryCov_9fa48("6932"), "Depreciation and losses")
  })
})) satisfies ChartOfAccountsTemplate;