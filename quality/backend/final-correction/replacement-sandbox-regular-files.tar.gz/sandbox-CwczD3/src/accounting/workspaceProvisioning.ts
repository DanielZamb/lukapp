// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { chartTemplate, personalChartTemplate, provisionChartOfAccounts } from "./chartOfAccounts";
import { AccountingError } from "./errors";
import { requireFunctionalCurrencyCode } from "./money";
import { clockMonth } from "./period";
import type { AccountingClock, AccountingStore, Actor, Workspace, WorkspaceKind } from "./types";
import { toWorkspace } from "./views";
export function workspaceConfiguration(input: {
  kind: WorkspaceKind;
  functionalCurrency: string;
  chartOfAccountsTemplate?: string;
}) {
  if (stryMutAct_9fa48("7032")) {
    {}
  } else {
    stryCov_9fa48("7032");
    const functionalCurrency = requireFunctionalCurrencyCode(input.functionalCurrency);
    const template = chartTemplate(stryMutAct_9fa48("7033") ? input.chartOfAccountsTemplate && personalChartTemplate.version : (stryCov_9fa48("7033"), input.chartOfAccountsTemplate ?? personalChartTemplate.version));
    if (stryMutAct_9fa48("7036") ? false : stryMutAct_9fa48("7035") ? true : stryMutAct_9fa48("7034") ? template.applicableWorkspaceKinds.includes(input.kind) : (stryCov_9fa48("7034", "7035", "7036"), !template.applicableWorkspaceKinds.includes(input.kind))) {
      if (stryMutAct_9fa48("7037")) {
        {}
      } else {
        stryCov_9fa48("7037");
        throw new AccountingError(stryMutAct_9fa48("7039") ? "" : (stryCov_9fa48("7039"), "chart_of_accounts_template_not_applicable"));
      }
    }
    return stryMutAct_9fa48("7040") ? {} : (stryCov_9fa48("7040"), {
      functionalCurrency,
      template
    });
  }
}
export async function provisionWorkspace(store: AccountingStore, clock: AccountingClock, input: {
  actor: Actor;
  kind: WorkspaceKind;
  functionalCurrency: string;
  chartOfAccountsTemplate?: string;
}): Promise<Workspace> {
  if (stryMutAct_9fa48("7041")) {
    {}
  } else {
    stryCov_9fa48("7041");
    const {
      functionalCurrency,
      template
    } = workspaceConfiguration(input);
    const month = clockMonth(clock.now());
    const workspace = await store.insertWorkspace(stryMutAct_9fa48("7042") ? {} : (stryCov_9fa48("7042"), {
      kind: input.kind,
      functionalCurrency,
      chartOfAccountsTemplate: template.version
    }), input.actor.userId);
    await provisionChartOfAccounts(store, workspace.id, template);
    const period = await store.insertAccountingPeriod(workspace.id, stryMutAct_9fa48("7043") ? {} : (stryCov_9fa48("7043"), {
      ...month,
      status: stryMutAct_9fa48("7044") ? "" : (stryCov_9fa48("7044"), "open")
    }));
    return toWorkspace(workspace, period);
  }
}