// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { requireProfile } from "../financialAccountProfiles";
import { requireWorkspace } from "../membership";
import type { AccountingStore, Actor, PostedJournalEntry } from "../types";
import { journalContext, toPostedJournalEntry } from "../views";

/** Every Posted Journal Entry, reversals included, with links between each pair. */
export async function listJournalEntries(store: AccountingStore, input: {
  actor: Actor;
  workspaceId: string;
  financialAccountProfileId?: string;
}): Promise<PostedJournalEntry[]> {
  if (stryMutAct_9fa48("5462")) {
    {}
  } else {
    stryCov_9fa48("5462");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor);
    const profile = (stryMutAct_9fa48("5465") ? input.financialAccountProfileId === undefined : stryMutAct_9fa48("5464") ? false : stryMutAct_9fa48("5463") ? true : (stryCov_9fa48("5463", "5464", "5465"), input.financialAccountProfileId !== undefined)) ? await requireProfile(store, input.workspaceId, input.financialAccountProfileId) : undefined;
    const [entries, context] = await Promise.all(stryMutAct_9fa48("5466") ? [] : (stryCov_9fa48("5466"), [store.listJournalEntries(input.workspaceId), journalContext(store, workspace)]));
    const reversedBy = new Map(entries.flatMap(stryMutAct_9fa48("5467") ? () => undefined : (stryCov_9fa48("5467"), entry => entry.reversesEntryId ? stryMutAct_9fa48("5468") ? [] : (stryCov_9fa48("5468"), [[entry.reversesEntryId, entry.id] as const]) : stryMutAct_9fa48("5469") ? ["Stryker was here"] : (stryCov_9fa48("5469"), []))));
    return Promise.all(stryMutAct_9fa48("5470") ? entries.map(entry => {
      const reversedByEntryId = reversedBy.get(entry.id);
      return toPostedJournalEntry(store, context, entry, {
        replay: false,
        ...(reversedByEntryId ? {
          reversedByEntryId
        } : {})
      });
    }) : (stryCov_9fa48("5470"), entries.filter(stryMutAct_9fa48("5471") ? () => undefined : (stryCov_9fa48("5471"), entry => stryMutAct_9fa48("5474") ? !profile && entry.lines.some(line => line.ledgerAccountId === profile.postingAccountId) : stryMutAct_9fa48("5473") ? false : stryMutAct_9fa48("5472") ? true : (stryCov_9fa48("5472", "5473", "5474"), (stryMutAct_9fa48("5475") ? profile : (stryCov_9fa48("5475"), !profile)) || (stryMutAct_9fa48("5476") ? entry.lines.every(line => line.ledgerAccountId === profile.postingAccountId) : (stryCov_9fa48("5476"), entry.lines.some(stryMutAct_9fa48("5477") ? () => undefined : (stryCov_9fa48("5477"), line => stryMutAct_9fa48("5480") ? line.ledgerAccountId !== profile.postingAccountId : stryMutAct_9fa48("5479") ? false : stryMutAct_9fa48("5478") ? true : (stryCov_9fa48("5478", "5479", "5480"), line.ledgerAccountId === profile.postingAccountId)))))))).map(entry => {
      if (stryMutAct_9fa48("5481")) {
        {}
      } else {
        stryCov_9fa48("5481");
        const reversedByEntryId = reversedBy.get(entry.id);
        return toPostedJournalEntry(store, context, entry, stryMutAct_9fa48("5482") ? {} : (stryCov_9fa48("5482"), {
          replay: stryMutAct_9fa48("5483") ? true : (stryCov_9fa48("5483"), false),
          ...(reversedByEntryId ? stryMutAct_9fa48("5484") ? {} : (stryCov_9fa48("5484"), {
            reversedByEntryId
          }) : {})
        }));
      }
    })));
  }
}