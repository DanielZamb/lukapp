// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { totalsByAccount } from "../ledgerTotals";
import { requireWorkspace } from "../membership";
import type { AccountingStore, Actor, TrialBalanceRow } from "../types";
import { byCode } from "../views";

/** Every Ledger Account with Posted activity, in code order; debits and credits sum to equal totals. */
export async function trialBalance(store: AccountingStore, input: {
  actor: Actor;
  workspaceId: string;
}): Promise<TrialBalanceRow[]> {
  if (stryMutAct_9fa48("5542")) {
    {}
  } else {
    stryCov_9fa48("5542");
    await requireWorkspace(store, input.workspaceId, input.actor);
    const [accounts, entries] = await Promise.all(stryMutAct_9fa48("5543") ? [] : (stryCov_9fa48("5543"), [store.listLedgerAccounts(input.workspaceId), store.listJournalEntries(input.workspaceId)]));
    const totals = totalsByAccount(entries);
    return stryMutAct_9fa48("5544") ? accounts.flatMap(account => {
      const row = totals.get(account.id);
      return row ? [{
        ledgerAccountId: account.id,
        code: account.code,
        name: account.name,
        nature: account.nature,
        debitMinorUnits: row.debitMinorUnits,
        creditMinorUnits: row.creditMinorUnits
      }] : [];
    }) : (stryCov_9fa48("5544"), accounts.sort(byCode).flatMap(account => {
      if (stryMutAct_9fa48("5545")) {
        {}
      } else {
        stryCov_9fa48("5545");
        const row = totals.get(account.id);
        return row ? stryMutAct_9fa48("5546") ? [] : (stryCov_9fa48("5546"), [stryMutAct_9fa48("5547") ? {} : (stryCov_9fa48("5547"), {
          ledgerAccountId: account.id,
          code: account.code,
          name: account.name,
          nature: account.nature,
          debitMinorUnits: row.debitMinorUnits,
          creditMinorUnits: row.creditMinorUnits
        })]) : stryMutAct_9fa48("5548") ? ["Stryker was here"] : (stryCov_9fa48("5548"), []);
      }
    }));
  }
}