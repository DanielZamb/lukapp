// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { expenseEligibility } from "./expenseEligibility";
import { AccountingError } from "../errors";
import { requireWorkspace } from "../membership";
import { periodFromAccountingDate } from "../period";
import type { AccountingStore, Actor, PostedExpense } from "../types";
export type ExpenseReadStore = Pick<AccountingStore, "getWorkspace" | "membershipRole" | "listExpenseEntriesInRange" | "getLedgerAccount" | "findReversalOf" | "listJournalSourceEffects" | "getJournalEntry">;
export async function listPostedExpenses(store: ExpenseReadStore, input: {
  actor: Actor;
  workspaceId: string;
  from: string;
  through: string;
}): Promise<PostedExpense[]> {
  if (stryMutAct_9fa48("5500")) {
    {}
  } else {
    stryCov_9fa48("5500");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor);
    if (stryMutAct_9fa48("5501")) {
      ;
    } else {
      stryCov_9fa48("5501");
      periodFromAccountingDate(input.from);
    }
    if (stryMutAct_9fa48("5502")) {
      ;
    } else {
      stryCov_9fa48("5502");
      periodFromAccountingDate(input.through);
    }
    if (stryMutAct_9fa48("5506") ? input.from <= input.through : stryMutAct_9fa48("5505") ? input.from >= input.through : stryMutAct_9fa48("5504") ? false : stryMutAct_9fa48("5503") ? true : (stryCov_9fa48("5503", "5504", "5505", "5506"), input.from > input.through)) throw new AccountingError(stryMutAct_9fa48("5508") ? "" : (stryCov_9fa48("5508"), "accounting_date_required"));
    const entries = await store.listExpenseEntriesInRange(input.workspaceId, input.from, input.through);
    return Promise.all(entries.map(async entry => {
      if (stryMutAct_9fa48("5509")) {
        {}
      } else {
        stryCov_9fa48("5509");
        const expenseLines: PostedExpense["expenseLines"] = stryMutAct_9fa48("5510") ? ["Stryker was here"] : (stryCov_9fa48("5510"), []);
        for (const line of entry.lines) {
          if (stryMutAct_9fa48("5511")) {
            {}
          } else {
            stryCov_9fa48("5511");
            const account = await store.getLedgerAccount(line.ledgerAccountId);
            if (stryMutAct_9fa48("5514") ? account?.nature === "Expense" || line.debitMinorUnits > 0 : stryMutAct_9fa48("5513") ? false : stryMutAct_9fa48("5512") ? true : (stryCov_9fa48("5512", "5513", "5514"), (stryMutAct_9fa48("5516") ? account?.nature !== "Expense" : stryMutAct_9fa48("5515") ? true : (stryCov_9fa48("5515", "5516"), (stryMutAct_9fa48("5517") ? account.nature : (stryCov_9fa48("5517"), account?.nature)) === (stryMutAct_9fa48("5518") ? "" : (stryCov_9fa48("5518"), "Expense")))) && (stryMutAct_9fa48("5521") ? line.debitMinorUnits <= 0 : stryMutAct_9fa48("5520") ? line.debitMinorUnits >= 0 : stryMutAct_9fa48("5519") ? true : (stryCov_9fa48("5519", "5520", "5521"), line.debitMinorUnits > 0)))) {
              if (stryMutAct_9fa48("5522")) {
                {}
              } else {
                stryCov_9fa48("5522");
                expenseLines.push(stryMutAct_9fa48("5524") ? {} : (stryCov_9fa48("5524"), {
                  ledgerAccountId: account.id,
                  amount: stryMutAct_9fa48("5525") ? {} : (stryCov_9fa48("5525"), {
                    currency: workspace.functionalCurrency,
                    minorUnits: line.debitMinorUnits
                  })
                }));
              }
            }
          }
        }
        const reversal = await store.findReversalOf(entry.id);
        const eligibility = await expenseEligibility(store, stryMutAct_9fa48("5526") ? {} : (stryCov_9fa48("5526"), {
          workspaceId: input.workspaceId,
          sourceEntryId: entry.id,
          originalMinorUnits: expenseLines.reduce(stryMutAct_9fa48("5527") ? () => undefined : (stryCov_9fa48("5527"), (sum, line) => stryMutAct_9fa48("5528") ? sum - line.amount.minorUnits : (stryCov_9fa48("5528"), sum + line.amount.minorUnits)), 0)
        }));
        return stryMutAct_9fa48("5529") ? {} : (stryCov_9fa48("5529"), {
          entryId: entry.id,
          accountingDate: entry.accountingDate,
          description: entry.description,
          expenseLines,
          currentEligibleAmount: stryMutAct_9fa48("5530") ? {} : (stryCov_9fa48("5530"), {
            currency: workspace.functionalCurrency,
            minorUnits: reversal ? 0 : eligibility.minorUnits
          }),
          sourceEffects: eligibility.effects,
          amount: stryMutAct_9fa48("5531") ? {} : (stryCov_9fa48("5531"), {
            currency: workspace.functionalCurrency,
            minorUnits: expenseLines.reduce(stryMutAct_9fa48("5532") ? () => undefined : (stryCov_9fa48("5532"), (sum, line) => stryMutAct_9fa48("5533") ? sum - line.amount.minorUnits : (stryCov_9fa48("5533"), sum + line.amount.minorUnits)), 0)
          }),
          reversal: reversal ? stryMutAct_9fa48("5534") ? {} : (stryCov_9fa48("5534"), {
            entryId: reversal.id,
            accountingDate: reversal.accountingDate,
            recordedAt: reversal.postedAt
          }) : null
        });
      }
    }));
  }
}