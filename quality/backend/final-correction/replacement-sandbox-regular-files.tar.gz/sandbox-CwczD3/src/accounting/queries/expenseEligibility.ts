// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "../errors";
import type { AccountingStore } from "../types";
export async function expenseEligibility(store: Pick<AccountingStore, "listJournalSourceEffects" | "getJournalEntry" | "findReversalOf">, input: {
  workspaceId: string;
  sourceEntryId: string;
  originalMinorUnits: number;
  asKnownAt?: number;
}) {
  if (stryMutAct_9fa48("5389")) {
    {}
  } else {
    stryCov_9fa48("5389");
    const facts = await store.listJournalSourceEffects(input.workspaceId, input.sourceEntryId);
    const effects = stryMutAct_9fa48("5390") ? ["Stryker was here"] : (stryCov_9fa48("5390"), []);
    const prefixes = stryMutAct_9fa48("5391") ? ["Stryker was here"] : (stryCov_9fa48("5391"), []);
    let eligible = BigInt(input.originalMinorUnits);
    for (const [index, fact] of stryMutAct_9fa48("5392") ? [...facts].entries() : (stryCov_9fa48("5392"), (stryMutAct_9fa48("5393") ? [] : (stryCov_9fa48("5393"), [...facts])).sort(stryMutAct_9fa48("5394") ? () => undefined : (stryCov_9fa48("5394"), (a, b) => stryMutAct_9fa48("5395") ? a.sourceSequence + b.sourceSequence : (stryCov_9fa48("5395"), a.sourceSequence - b.sourceSequence))).entries())) {
      if (stryMutAct_9fa48("5396")) {
        {}
      } else {
        stryCov_9fa48("5396");
        if (stryMutAct_9fa48("5399") ? !Number.isSafeInteger(fact.sourceSequence) && fact.sourceSequence !== index + 1 : stryMutAct_9fa48("5398") ? false : stryMutAct_9fa48("5397") ? true : (stryCov_9fa48("5397", "5398", "5399"), (stryMutAct_9fa48("5400") ? Number.isSafeInteger(fact.sourceSequence) : (stryCov_9fa48("5400"), !Number.isSafeInteger(fact.sourceSequence))) || (stryMutAct_9fa48("5402") ? fact.sourceSequence === index + 1 : stryMutAct_9fa48("5401") ? false : (stryCov_9fa48("5401", "5402"), fact.sourceSequence !== (stryMutAct_9fa48("5403") ? index - 1 : (stryCov_9fa48("5403"), index + 1)))))) throw new AccountingError(stryMutAct_9fa48("5405") ? "" : (stryCov_9fa48("5405"), "journal_source_effect_invalid"));
        const entry = await store.getJournalEntry(fact.journalEntryId);
        if (stryMutAct_9fa48("5408") ? (!entry || entry.workspaceId !== input.workspaceId) && !Number.isSafeInteger(fact.expenseDeltaMinorUnits) : stryMutAct_9fa48("5407") ? false : stryMutAct_9fa48("5406") ? true : (stryCov_9fa48("5406", "5407", "5408"), (stryMutAct_9fa48("5410") ? !entry && entry.workspaceId !== input.workspaceId : stryMutAct_9fa48("5409") ? false : (stryCov_9fa48("5409", "5410"), (stryMutAct_9fa48("5411") ? entry : (stryCov_9fa48("5411"), !entry)) || (stryMutAct_9fa48("5413") ? entry.workspaceId === input.workspaceId : stryMutAct_9fa48("5412") ? false : (stryCov_9fa48("5412", "5413"), entry.workspaceId !== input.workspaceId)))) || (stryMutAct_9fa48("5414") ? Number.isSafeInteger(fact.expenseDeltaMinorUnits) : (stryCov_9fa48("5414"), !Number.isSafeInteger(fact.expenseDeltaMinorUnits))))) throw new AccountingError(stryMutAct_9fa48("5416") ? "" : (stryCov_9fa48("5416"), "journal_source_effect_invalid"));
        if (stryMutAct_9fa48("5419") ? input.asKnownAt !== undefined || entry.postedAt > input.asKnownAt : stryMutAct_9fa48("5418") ? false : stryMutAct_9fa48("5417") ? true : (stryCov_9fa48("5417", "5418", "5419"), (stryMutAct_9fa48("5421") ? input.asKnownAt === undefined : stryMutAct_9fa48("5420") ? true : (stryCov_9fa48("5420", "5421"), input.asKnownAt !== undefined)) && (stryMutAct_9fa48("5424") ? entry.postedAt <= input.asKnownAt : stryMutAct_9fa48("5423") ? entry.postedAt >= input.asKnownAt : stryMutAct_9fa48("5422") ? true : (stryCov_9fa48("5422", "5423", "5424"), entry.postedAt > input.asKnownAt)))) continue;
        stryMutAct_9fa48("5425") ? eligible -= BigInt(fact.expenseDeltaMinorUnits) : (stryCov_9fa48("5425"), eligible += BigInt(fact.expenseDeltaMinorUnits));
        const prefixMinor = Number((stryMutAct_9fa48("5429") ? eligible <= 0n : stryMutAct_9fa48("5428") ? eligible >= 0n : stryMutAct_9fa48("5427") ? false : stryMutAct_9fa48("5426") ? true : (stryCov_9fa48("5426", "5427", "5428", "5429"), eligible > 0n)) ? eligible : 0n);
        if (stryMutAct_9fa48("5432") ? false : stryMutAct_9fa48("5431") ? true : stryMutAct_9fa48("5430") ? Number.isSafeInteger(prefixMinor) : (stryCov_9fa48("5430", "5431", "5432"), !Number.isSafeInteger(prefixMinor))) throw new AccountingError(stryMutAct_9fa48("5434") ? "" : (stryCov_9fa48("5434"), "journal_source_effect_invalid"));
        prefixes.push(stryMutAct_9fa48("5436") ? {} : (stryCov_9fa48("5436"), {
          sourceSequence: fact.sourceSequence,
          recordedAt: entry.postedAt,
          eligibleMinorUnits: prefixMinor
        }));
        const reversal = await store.findReversalOf(entry.id);
        effects.push(stryMutAct_9fa48("5438") ? {} : (stryCov_9fa48("5438"), {
          ...fact,
          accountingDate: entry.accountingDate,
          recordedAt: entry.postedAt,
          reversedByEntryId: (stryMutAct_9fa48("5441") ? reversal || input.asKnownAt === undefined || reversal.postedAt <= input.asKnownAt : stryMutAct_9fa48("5440") ? false : stryMutAct_9fa48("5439") ? true : (stryCov_9fa48("5439", "5440", "5441"), reversal && (stryMutAct_9fa48("5443") ? input.asKnownAt === undefined && reversal.postedAt <= input.asKnownAt : stryMutAct_9fa48("5442") ? true : (stryCov_9fa48("5442", "5443"), (stryMutAct_9fa48("5445") ? input.asKnownAt !== undefined : stryMutAct_9fa48("5444") ? false : (stryCov_9fa48("5444", "5445"), input.asKnownAt === undefined)) || (stryMutAct_9fa48("5448") ? reversal.postedAt > input.asKnownAt : stryMutAct_9fa48("5447") ? reversal.postedAt < input.asKnownAt : stryMutAct_9fa48("5446") ? false : (stryCov_9fa48("5446", "5447", "5448"), reversal.postedAt <= input.asKnownAt)))))) ? reversal.id : null
        }));
      }
    }
    const minorUnits = Number((stryMutAct_9fa48("5452") ? eligible <= 0n : stryMutAct_9fa48("5451") ? eligible >= 0n : stryMutAct_9fa48("5450") ? false : stryMutAct_9fa48("5449") ? true : (stryCov_9fa48("5449", "5450", "5451", "5452"), eligible > 0n)) ? eligible : 0n);
    if (stryMutAct_9fa48("5455") ? false : stryMutAct_9fa48("5454") ? true : stryMutAct_9fa48("5453") ? Number.isSafeInteger(minorUnits) : (stryCov_9fa48("5453", "5454", "5455"), !Number.isSafeInteger(minorUnits))) throw new AccountingError(stryMutAct_9fa48("5457") ? "" : (stryCov_9fa48("5457"), "journal_source_effect_invalid"));
    return stryMutAct_9fa48("5458") ? {} : (stryCov_9fa48("5458"), {
      minorUnits,
      effects,
      prefixes
    });
  }
}