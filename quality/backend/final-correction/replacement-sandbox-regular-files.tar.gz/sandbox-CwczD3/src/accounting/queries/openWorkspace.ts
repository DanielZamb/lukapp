// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { requireWorkspace } from "../membership";
import { clockMonth, dateFromTimestamp } from "../period";
import type { AccountingClock, AccountingStore, Actor, Workspace } from "../types";
import { toWorkspace } from "../views";
export async function openWorkspace(store: AccountingStore, clock: AccountingClock, input: {
  actor: Actor;
  workspaceId: string;
  now?: number;
}): Promise<Workspace> {
  if (stryMutAct_9fa48("5535")) {
    {}
  } else {
    stryCov_9fa48("5535");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor);
    const month = clockMonth((stryMutAct_9fa48("5538") ? input.now !== undefined : stryMutAct_9fa48("5537") ? false : stryMutAct_9fa48("5536") ? true : (stryCov_9fa48("5536", "5537", "5538"), input.now === undefined)) ? clock.now() : dateFromTimestamp(input.now));
    const stored = await store.getAccountingPeriod(input.workspaceId, month);
    return toWorkspace(workspace, stryMutAct_9fa48("5539") ? stored && {
      ...month,
      status: "not_opened"
    } : (stryCov_9fa48("5539"), stored ?? (stryMutAct_9fa48("5540") ? {} : (stryCov_9fa48("5540"), {
      ...month,
      status: stryMutAct_9fa48("5541") ? "" : (stryCov_9fa48("5541"), "not_opened")
    }))));
  }
}