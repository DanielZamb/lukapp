// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { chartTemplate, requireTemplateAccount } from "./chartOfAccounts";
import { classifyFinancialAccountProfile } from "./classification";
import { commandIdentity } from "./commandIdentity";
import { categorySnapshot, requireCategory } from "./categories";
import { assertCategoryAccount } from "./categoryPolicy";
import { setupFinancialAccount } from "./commands/setupFinancialAccount";
import { AccountingError } from "./errors";
import { requireWorkspace } from "./membership";
import { periodFromAccountingDate } from "./period";
import { postJournalEntry } from "./posting";
import type { AccountingClock, AccountingPeriod, AccountingStore, DraftJournalLine, JournalEntryDraft, StoredJournalEntry, StoredWorkspace } from "./types";
import type { CategoryNature, CategorySnapshot, ConfirmReclassificationInput, CorrectionSource, ReclassificationInput, ReclassificationBucket, ReclassificationPreview, UserCategory } from "./categoryTypes";
type ResolvedTarget = {
  kind: "category";
  accountId: string | undefined;
  nature: CategoryNature;
} | {
  kind: "profile";
};
type CorrectionHistory = {
  buckets: Map<string, ReclassificationBucket>;
  periods: Map<string, string>;
  lockedIds: Set<string>;
};
type CorrectionDestination = {
  category: UserCategory;
  ledgerAccountId: string;
} & ({
  kind: "category";
} | {
  kind: "profile";
  financialAccountProfileId: string;
});
export async function previewCategoryReclassification(store: AccountingStore, input: ReclassificationInput): Promise<ReclassificationPreview> {
  if (stryMutAct_9fa48("5549")) {
    {}
  } else {
    stryCov_9fa48("5549");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("5550") ? "" : (stryCov_9fa48("5550"), "correct"));
    const category = await requireCategory(store, input.workspaceId, input.categoryId);
    if (stryMutAct_9fa48("5553") ? category.classification.kind === "resolved" : stryMutAct_9fa48("5552") ? false : stryMutAct_9fa48("5551") ? true : (stryCov_9fa48("5551", "5552", "5553"), category.classification.kind !== (stryMutAct_9fa48("5554") ? "" : (stryCov_9fa48("5554"), "resolved")))) throw new AccountingError(stryMutAct_9fa48("5556") ? "" : (stryCov_9fa48("5556"), "category_unresolved"));
    if (stryMutAct_9fa48("5559") ? category.status === "active" : stryMutAct_9fa48("5558") ? false : stryMutAct_9fa48("5557") ? true : (stryCov_9fa48("5557", "5558", "5559"), category.status !== (stryMutAct_9fa48("5560") ? "" : (stryCov_9fa48("5560"), "active")))) throw new AccountingError(stryMutAct_9fa48("5562") ? "" : (stryCov_9fa48("5562"), "category_inactive"));
    const currentPeriod = periodFromAccountingDate(input.currentDate);
    const target = await resolveReclassificationTarget(store, workspace, input);
    const entries = stryMutAct_9fa48("5563") ? await store.listJournalEntries(input.workspaceId) : (stryCov_9fa48("5563"), (await store.listJournalEntries(input.workspaceId)).sort(stryMutAct_9fa48("5564") ? () => undefined : (stryCov_9fa48("5564"), (a, b) => a.id.localeCompare(b.id))));
    const history = await readCorrectionHistory(store, stryMutAct_9fa48("5565") ? {} : (stryCov_9fa48("5565"), {
      input,
      target,
      entries,
      categoryId: category.id
    }));
    const currentStatus = await store.getAccountingPeriod(input.workspaceId, currentPeriod);
    const outstanding = stryMutAct_9fa48("5567") ? [...history.buckets.values()].sort((a, b) => commandIdentity(a).localeCompare(commandIdentity(b))) : stryMutAct_9fa48("5566") ? [...history.buckets.values()].filter(bucket => bucket.rootSources.some(root => root.signedMinorUnits !== 0)) : (stryCov_9fa48("5566", "5567"), (stryMutAct_9fa48("5568") ? [] : (stryCov_9fa48("5568"), [...history.buckets.values()])).filter(stryMutAct_9fa48("5569") ? () => undefined : (stryCov_9fa48("5569"), bucket => stryMutAct_9fa48("5570") ? bucket.rootSources.every(root => root.signedMinorUnits !== 0) : (stryCov_9fa48("5570"), bucket.rootSources.some(stryMutAct_9fa48("5571") ? () => undefined : (stryCov_9fa48("5571"), root => stryMutAct_9fa48("5574") ? root.signedMinorUnits === 0 : stryMutAct_9fa48("5573") ? false : stryMutAct_9fa48("5572") ? true : (stryCov_9fa48("5572", "5573", "5574"), root.signedMinorUnits !== 0)))))).sort(stryMutAct_9fa48("5575") ? () => undefined : (stryCov_9fa48("5575"), (a, b) => commandIdentity(a).localeCompare(commandIdentity(b)))));
    const selectedSources = outstanding.flatMap(stryMutAct_9fa48("5576") ? () => undefined : (stryCov_9fa48("5576"), bucket => bucket.sources));
    const lockedEntryIds = new Set(stryMutAct_9fa48("5577") ? selectedSources.map(source => source.entryId) : (stryCov_9fa48("5577"), selectedSources.filter(stryMutAct_9fa48("5578") ? () => undefined : (stryCov_9fa48("5578"), source => history.lockedIds.has(source.entryId))).map(stryMutAct_9fa48("5579") ? () => undefined : (stryCov_9fa48("5579"), source => source.entryId))));
    validateCorrectionDates(stryMutAct_9fa48("5581") ? {} : (stryCov_9fa48("5581"), {
      input,
      entries,
      outstanding,
      lockedEntryIds,
      currentStatus
    }));
    const impact = correctionImpact(stryMutAct_9fa48("5582") ? {} : (stryCov_9fa48("5582"), {
      outstanding,
      selectedSources,
      lockedEntryIds
    }));
    const revisionToken = commandIdentity(stryMutAct_9fa48("5583") ? {} : (stryCov_9fa48("5583"), {
      policy: stryMutAct_9fa48("5584") ? "" : (stryCov_9fa48("5584"), "category-reclassification@1"),
      category,
      target: input.target,
      currentDate: input.currentDate,
      template: workspace.chartOfAccountsTemplate,
      periods: stryMutAct_9fa48("5585") ? [...history.periods.entries()] : (stryCov_9fa48("5585"), (stryMutAct_9fa48("5586") ? [] : (stryCov_9fa48("5586"), [...history.periods.entries()])).sort()),
      currentStatus,
      history: stryMutAct_9fa48("5587") ? entries : (stryCov_9fa48("5587"), entries.filter(stryMutAct_9fa48("5588") ? () => undefined : (stryCov_9fa48("5588"), entry => stryMutAct_9fa48("5589") ? entry.lines.every(line => line.category?.categoryId === category.id) : (stryCov_9fa48("5589"), entry.lines.some(stryMutAct_9fa48("5590") ? () => undefined : (stryCov_9fa48("5590"), line => stryMutAct_9fa48("5593") ? line.category?.categoryId !== category.id : stryMutAct_9fa48("5592") ? false : stryMutAct_9fa48("5591") ? true : (stryCov_9fa48("5591", "5592", "5593"), (stryMutAct_9fa48("5594") ? line.category.categoryId : (stryCov_9fa48("5594"), line.category?.categoryId)) === category.id)))))))
    }));
    return stryMutAct_9fa48("5595") ? {} : (stryCov_9fa48("5595"), {
      categoryId: category.id,
      categoryRevision: category.revision,
      revisionToken,
      entryCount: impact.entryCount,
      lineCount: impact.lineCount,
      amount: stryMutAct_9fa48("5596") ? {} : (stryCov_9fa48("5596"), {
        currency: workspace.functionalCurrency,
        minorUnits: impact.total
      }),
      lockedEntryCount: impact.lockedEntryCount,
      lockedAmount: stryMutAct_9fa48("5597") ? {} : (stryCov_9fa48("5597"), {
        currency: workspace.functionalCurrency,
        minorUnits: impact.lockedTotal
      }),
      correctionDates: impact.correctionDates,
      buckets: outstanding
    });
  }
}
async function resolveReclassificationTarget(store: AccountingStore, workspace: StoredWorkspace, input: ReclassificationInput): Promise<ResolvedTarget> {
  if (stryMutAct_9fa48("5598")) {
    {}
  } else {
    stryCov_9fa48("5598");
    const target = input.target;
    if (stryMutAct_9fa48("5601") ? target.kind !== "category" : stryMutAct_9fa48("5600") ? false : stryMutAct_9fa48("5599") ? true : (stryCov_9fa48("5599", "5600", "5601"), target.kind === (stryMutAct_9fa48("5602") ? "" : (stryCov_9fa48("5602"), "category")))) {
      if (stryMutAct_9fa48("5603")) {
        {}
      } else {
        stryCov_9fa48("5603");
        if (stryMutAct_9fa48("5604")) {
          ;
        } else {
          stryCov_9fa48("5604");
          assertCategoryAccount(workspace.chartOfAccountsTemplate, target.nature, target.accountCode);
        }
        const account = await store.findLedgerAccountByCode(input.workspaceId, target.accountCode);
        return stryMutAct_9fa48("5605") ? {} : (stryCov_9fa48("5605"), {
          kind: stryMutAct_9fa48("5606") ? "" : (stryCov_9fa48("5606"), "category"),
          accountId: stryMutAct_9fa48("5607") ? account.id : (stryCov_9fa48("5607"), account?.id),
          nature: target.nature
        });
      }
    }
    if (stryMutAct_9fa48("5608")) {
      ;
    } else {
      stryCov_9fa48("5608");
      classifyFinancialAccountProfile(chartTemplate(workspace.chartOfAccountsTemplate), target.setup.productKind, target.setup.classificationAnswers);
    }
    return stryMutAct_9fa48("5609") ? {} : (stryCov_9fa48("5609"), {
      kind: stryMutAct_9fa48("5610") ? "" : (stryCov_9fa48("5610"), "profile")
    });
  }
}
async function readCorrectionHistory(store: AccountingStore, args: {
  input: ReclassificationInput;
  target: ResolvedTarget;
  entries: StoredJournalEntry[];
  categoryId: string;
}): Promise<CorrectionHistory> {
  if (stryMutAct_9fa48("5611")) {
    {}
  } else {
    stryCov_9fa48("5611");
    const {
      input,
      target,
      entries,
      categoryId
    } = args;
    const history: CorrectionHistory = stryMutAct_9fa48("5612") ? {} : (stryCov_9fa48("5612"), {
      buckets: new Map(),
      periods: new Map(),
      lockedIds: new Set()
    });
    for (const entry of entries) for (const [lineNumber, line] of entry.lines.entries()) {
      if (stryMutAct_9fa48("5613")) {
        {}
      } else {
        stryCov_9fa48("5613");
        if (stryMutAct_9fa48("5616") ? line.category?.categoryId === categoryId : stryMutAct_9fa48("5615") ? false : stryMutAct_9fa48("5614") ? true : (stryCov_9fa48("5614", "5615", "5616"), (stryMutAct_9fa48("5617") ? line.category.categoryId : (stryCov_9fa48("5617"), line.category?.categoryId)) !== categoryId)) continue;
        if (stryMutAct_9fa48("5620") ? target.kind === "category" && line.ledgerAccountId === target.accountId || line.category.nature === target.nature : stryMutAct_9fa48("5619") ? false : stryMutAct_9fa48("5618") ? true : (stryCov_9fa48("5618", "5619", "5620"), (stryMutAct_9fa48("5622") ? target.kind === "category" || line.ledgerAccountId === target.accountId : stryMutAct_9fa48("5621") ? true : (stryCov_9fa48("5621", "5622"), (stryMutAct_9fa48("5624") ? target.kind !== "category" : stryMutAct_9fa48("5623") ? true : (stryCov_9fa48("5623", "5624"), target.kind === (stryMutAct_9fa48("5625") ? "" : (stryCov_9fa48("5625"), "category")))) && (stryMutAct_9fa48("5627") ? line.ledgerAccountId !== target.accountId : stryMutAct_9fa48("5626") ? true : (stryCov_9fa48("5626", "5627"), line.ledgerAccountId === target.accountId)))) && (stryMutAct_9fa48("5629") ? line.category.nature !== target.nature : stryMutAct_9fa48("5628") ? true : (stryCov_9fa48("5628", "5629"), line.category.nature === target.nature)))) continue;
        const periodKey = stryMutAct_9fa48("5630") ? `` : (stryCov_9fa48("5630"), `${entry.period.year}-${String(entry.period.month).padStart(2, stryMutAct_9fa48("5631") ? "" : (stryCov_9fa48("5631"), "0"))}`);
        const status = await readCorrectionPeriod(store, input.workspaceId, entry, periodKey, history.periods);
        const locked = stryMutAct_9fa48("5634") ? status !== "locked" : stryMutAct_9fa48("5633") ? false : stryMutAct_9fa48("5632") ? true : (stryCov_9fa48("5632", "5633", "5634"), status === (stryMutAct_9fa48("5635") ? "" : (stryCov_9fa48("5635"), "locked")));
        accumulateCorrectionBucket(history.buckets, stryMutAct_9fa48("5637") ? {} : (stryCov_9fa48("5637"), {
          entry,
          line,
          category: line.category,
          lineNumber,
          periodKey,
          locked,
          currentDate: input.currentDate
        }));
        if (stryMutAct_9fa48("5639") ? false : stryMutAct_9fa48("5638") ? true : (stryCov_9fa48("5638", "5639"), locked)) if (stryMutAct_9fa48("5640")) {
          ;
        } else {
          stryCov_9fa48("5640");
          history.lockedIds.add(entry.id);
        }
      }
    }
    return history;
  }
}
async function readCorrectionPeriod(store: AccountingStore, workspaceId: string, entry: StoredJournalEntry, periodKey: string, periods: Map<string, string>): Promise<string> {
  if (stryMutAct_9fa48("5641")) {
    {}
  } else {
    stryCov_9fa48("5641");
    let status = periods.get(periodKey);
    if (stryMutAct_9fa48("5644") ? false : stryMutAct_9fa48("5643") ? true : stryMutAct_9fa48("5642") ? status : (stryCov_9fa48("5642", "5643", "5644"), !status)) {
      if (stryMutAct_9fa48("5645")) {
        {}
      } else {
        stryCov_9fa48("5645");
        status = stryMutAct_9fa48("5646") ? (await store.getAccountingPeriod(workspaceId, entry.period)).status : (stryCov_9fa48("5646"), (await store.getAccountingPeriod(workspaceId, entry.period))?.status);
        if (stryMutAct_9fa48("5649") ? false : stryMutAct_9fa48("5648") ? true : stryMutAct_9fa48("5647") ? status : (stryCov_9fa48("5647", "5648", "5649"), !status)) throw new AccountingError(stryMutAct_9fa48("5651") ? "" : (stryCov_9fa48("5651"), "accounting_period_not_found"));
        if (stryMutAct_9fa48("5652")) {
          ;
        } else {
          stryCov_9fa48("5652");
          periods.set(periodKey, status);
        }
      }
    }
    return status;
  }
}
function accumulateCorrectionBucket(buckets: Map<string, ReclassificationBucket>, input: {
  entry: StoredJournalEntry;
  line: DraftJournalLine;
  category: CategorySnapshot;
  lineNumber: number;
  periodKey: string;
  locked: boolean;
  currentDate: string;
}): void {
  if (stryMutAct_9fa48("5653")) {
    {}
  } else {
    stryCov_9fa48("5653");
    const {
      entry,
      line,
      category,
      lineNumber,
      periodKey,
      locked
    } = input;
    const date = locked ? input.currentDate : entry.accountingDate;
    const destinationPeriod = locked ? stryMutAct_9fa48("5654") ? "" : (stryCov_9fa48("5654"), "catch-up") : periodKey;
    const key = stryMutAct_9fa48("5655") ? `` : (stryCov_9fa48("5655"), `${destinationPeriod}:${line.ledgerAccountId}:${commandIdentity(category)}`);
    const bucket = stryMutAct_9fa48("5656") ? buckets.get(key) && {
      accountingDate: date,
      ledgerAccountId: line.ledgerAccountId,
      signedMinorUnits: 0,
      sources: [],
      rootSources: [],
      priorLockedPeriods: [],
      snapshot: category
    } : (stryCov_9fa48("5656"), buckets.get(key) ?? (stryMutAct_9fa48("5657") ? {} : (stryCov_9fa48("5657"), {
      accountingDate: date,
      ledgerAccountId: line.ledgerAccountId,
      signedMinorUnits: 0,
      sources: stryMutAct_9fa48("5658") ? ["Stryker was here"] : (stryCov_9fa48("5658"), []),
      rootSources: stryMutAct_9fa48("5659") ? ["Stryker was here"] : (stryCov_9fa48("5659"), []),
      priorLockedPeriods: stryMutAct_9fa48("5660") ? ["Stryker was here"] : (stryCov_9fa48("5660"), []),
      snapshot: category
    })));
    bucket.accountingDate = (stryMutAct_9fa48("5664") ? date <= bucket.accountingDate : stryMutAct_9fa48("5663") ? date >= bucket.accountingDate : stryMutAct_9fa48("5662") ? false : stryMutAct_9fa48("5661") ? true : (stryCov_9fa48("5661", "5662", "5663", "5664"), date > bucket.accountingDate)) ? date : bucket.accountingDate;
    const signedMinorUnits = stryMutAct_9fa48("5665") ? line.debitMinorUnits + line.creditMinorUnits : (stryCov_9fa48("5665"), line.debitMinorUnits - line.creditMinorUnits);
    stryMutAct_9fa48("5666") ? bucket.signedMinorUnits -= signedMinorUnits : (stryCov_9fa48("5666"), bucket.signedMinorUnits += signedMinorUnits);
    if (stryMutAct_9fa48("5669") ? false : stryMutAct_9fa48("5668") ? true : stryMutAct_9fa48("5667") ? Number.isSafeInteger(bucket.signedMinorUnits) : (stryCov_9fa48("5667", "5668", "5669"), !Number.isSafeInteger(bucket.signedMinorUnits))) throw new AccountingError(stryMutAct_9fa48("5671") ? "" : (stryCov_9fa48("5671"), "journal_line_invalid"));
    bucket.sources.push(stryMutAct_9fa48("5673") ? {} : (stryCov_9fa48("5673"), {
      entryId: entry.id,
      lineNumber,
      signedMinorUnits
    }));
    if (stryMutAct_9fa48("5674")) {
      ;
    } else {
      stryCov_9fa48("5674");
      accumulateOriginalSources(bucket.rootSources, originalSources(entry, line, lineNumber, signedMinorUnits));
    }
    if (stryMutAct_9fa48("5677") ? locked || !bucket.priorLockedPeriods.includes(periodKey) : stryMutAct_9fa48("5676") ? false : stryMutAct_9fa48("5675") ? true : (stryCov_9fa48("5675", "5676", "5677"), locked && (stryMutAct_9fa48("5678") ? bucket.priorLockedPeriods.includes(periodKey) : (stryCov_9fa48("5678"), !bucket.priorLockedPeriods.includes(periodKey))))) if (stryMutAct_9fa48("5679")) {
      ;
    } else {
      stryCov_9fa48("5679");
      bucket.priorLockedPeriods.push(periodKey);
    }
    if (stryMutAct_9fa48("5680")) {
      ;
    } else {
      stryCov_9fa48("5680");
      buckets.set(key, bucket);
    }
  }
}
function originalSources(entry: StoredJournalEntry, line: DraftJournalLine, lineNumber: number, signedMinorUnits: number): CorrectionSource[] {
  if (stryMutAct_9fa48("5681")) {
    {}
  } else {
    stryCov_9fa48("5681");
    const correction = line.categoryCorrection;
    if (stryMutAct_9fa48("5684") ? false : stryMutAct_9fa48("5683") ? true : stryMutAct_9fa48("5682") ? correction : (stryCov_9fa48("5682", "5683", "5684"), !correction)) return stryMutAct_9fa48("5685") ? [] : (stryCov_9fa48("5685"), [stryMutAct_9fa48("5686") ? {} : (stryCov_9fa48("5686"), {
      entryId: stryMutAct_9fa48("5687") ? entry.reversesEntryId && entry.id : (stryCov_9fa48("5687"), entry.reversesEntryId ?? entry.id),
      lineNumber,
      signedMinorUnits
    })]);
    const correctionSign = (stryMutAct_9fa48("5690") ? correction.side !== "reversing" : stryMutAct_9fa48("5689") ? false : stryMutAct_9fa48("5688") ? true : (stryCov_9fa48("5688", "5689", "5690"), correction.side === (stryMutAct_9fa48("5691") ? "" : (stryCov_9fa48("5691"), "reversing")))) ? stryMutAct_9fa48("5692") ? +1 : (stryCov_9fa48("5692"), -1) : 1;
    const reversalSign = entry.reversesEntryId ? stryMutAct_9fa48("5693") ? +1 : (stryCov_9fa48("5693"), -1) : 1;
    return correction.rootSources.map(stryMutAct_9fa48("5694") ? () => undefined : (stryCov_9fa48("5694"), ref => stryMutAct_9fa48("5695") ? {} : (stryCov_9fa48("5695"), {
      ...ref,
      signedMinorUnits: stryMutAct_9fa48("5696") ? ref.signedMinorUnits * correctionSign / reversalSign : (stryCov_9fa48("5696"), (stryMutAct_9fa48("5697") ? ref.signedMinorUnits / correctionSign : (stryCov_9fa48("5697"), ref.signedMinorUnits * correctionSign)) * reversalSign)
    })));
  }
}
function accumulateOriginalSources(savedSources: CorrectionSource[], sources: CorrectionSource[]): void {
  if (stryMutAct_9fa48("5698")) {
    {}
  } else {
    stryCov_9fa48("5698");
    for (const root of sources) {
      if (stryMutAct_9fa48("5699")) {
        {}
      } else {
        stryCov_9fa48("5699");
        const saved = savedSources.find(stryMutAct_9fa48("5700") ? () => undefined : (stryCov_9fa48("5700"), ref => stryMutAct_9fa48("5703") ? ref.entryId === root.entryId || ref.lineNumber === root.lineNumber : stryMutAct_9fa48("5702") ? false : stryMutAct_9fa48("5701") ? true : (stryCov_9fa48("5701", "5702", "5703"), (stryMutAct_9fa48("5705") ? ref.entryId !== root.entryId : stryMutAct_9fa48("5704") ? true : (stryCov_9fa48("5704", "5705"), ref.entryId === root.entryId)) && (stryMutAct_9fa48("5707") ? ref.lineNumber !== root.lineNumber : stryMutAct_9fa48("5706") ? true : (stryCov_9fa48("5706", "5707"), ref.lineNumber === root.lineNumber)))));
        if (stryMutAct_9fa48("5709") ? false : stryMutAct_9fa48("5708") ? true : (stryCov_9fa48("5708", "5709"), saved)) {
          if (stryMutAct_9fa48("5710")) {
            {}
          } else {
            stryCov_9fa48("5710");
            stryMutAct_9fa48("5711") ? saved.signedMinorUnits -= root.signedMinorUnits : (stryCov_9fa48("5711"), saved.signedMinorUnits += root.signedMinorUnits);
            if (stryMutAct_9fa48("5714") ? false : stryMutAct_9fa48("5713") ? true : stryMutAct_9fa48("5712") ? Number.isSafeInteger(saved.signedMinorUnits) : (stryCov_9fa48("5712", "5713", "5714"), !Number.isSafeInteger(saved.signedMinorUnits))) throw new AccountingError(stryMutAct_9fa48("5716") ? "" : (stryCov_9fa48("5716"), "journal_line_invalid"));
          }
        } else savedSources.push(stryMutAct_9fa48("5718") ? {} : (stryCov_9fa48("5718"), {
          ...root
        }));
      }
    }
  }
}
function validateCorrectionDates(input: {
  input: ReclassificationInput;
  entries: StoredJournalEntry[];
  outstanding: ReclassificationBucket[];
  lockedEntryIds: Set<string>;
  currentStatus: AccountingPeriod | undefined;
}): void {
  if (stryMutAct_9fa48("5719")) {
    {}
  } else {
    stryCov_9fa48("5719");
    const {
      input: request,
      entries,
      outstanding,
      lockedEntryIds,
      currentStatus
    } = input;
    if (stryMutAct_9fa48("5722") ? entries.every(entry => lockedEntryIds.has(entry.id) && request.currentDate < entry.accountingDate) : stryMutAct_9fa48("5721") ? false : stryMutAct_9fa48("5720") ? true : (stryCov_9fa48("5720", "5721", "5722"), entries.some(stryMutAct_9fa48("5723") ? () => undefined : (stryCov_9fa48("5723"), entry => stryMutAct_9fa48("5726") ? lockedEntryIds.has(entry.id) || request.currentDate < entry.accountingDate : stryMutAct_9fa48("5725") ? false : stryMutAct_9fa48("5724") ? true : (stryCov_9fa48("5724", "5725", "5726"), lockedEntryIds.has(entry.id) && (stryMutAct_9fa48("5729") ? request.currentDate >= entry.accountingDate : stryMutAct_9fa48("5728") ? request.currentDate <= entry.accountingDate : stryMutAct_9fa48("5727") ? true : (stryCov_9fa48("5727", "5728", "5729"), request.currentDate < entry.accountingDate))))))) throw new AccountingError(stryMutAct_9fa48("5731") ? "" : (stryCov_9fa48("5731"), "reclassification_date_before_source"));
    if (stryMutAct_9fa48("5734") ? outstanding.some(bucket => bucket.priorLockedPeriods.length) || currentStatus?.status !== "open" : stryMutAct_9fa48("5733") ? false : stryMutAct_9fa48("5732") ? true : (stryCov_9fa48("5732", "5733", "5734"), (stryMutAct_9fa48("5735") ? outstanding.every(bucket => bucket.priorLockedPeriods.length) : (stryCov_9fa48("5735"), outstanding.some(stryMutAct_9fa48("5736") ? () => undefined : (stryCov_9fa48("5736"), bucket => bucket.priorLockedPeriods.length)))) && (stryMutAct_9fa48("5738") ? currentStatus?.status === "open" : stryMutAct_9fa48("5737") ? true : (stryCov_9fa48("5737", "5738"), (stryMutAct_9fa48("5739") ? currentStatus.status : (stryCov_9fa48("5739"), currentStatus?.status)) !== (stryMutAct_9fa48("5740") ? "" : (stryCov_9fa48("5740"), "open")))))) throw new AccountingError(stryMutAct_9fa48("5742") ? "" : (stryCov_9fa48("5742"), "reclassification_current_period_required"));
    if (stryMutAct_9fa48("5745") ? request.target.kind !== "profile" : stryMutAct_9fa48("5744") ? false : stryMutAct_9fa48("5743") ? true : (stryCov_9fa48("5743", "5744", "5745"), request.target.kind === (stryMutAct_9fa48("5746") ? "" : (stryCov_9fa48("5746"), "profile")))) {
      if (stryMutAct_9fa48("5747")) {
        {}
      } else {
        stryCov_9fa48("5747");
        const openingDate = request.target.setup.accountingDate;
        if (stryMutAct_9fa48("5750") ? outstanding.every(bucket => bucket.accountingDate < openingDate) : stryMutAct_9fa48("5749") ? false : stryMutAct_9fa48("5748") ? true : (stryCov_9fa48("5748", "5749", "5750"), outstanding.some(stryMutAct_9fa48("5751") ? () => undefined : (stryCov_9fa48("5751"), bucket => stryMutAct_9fa48("5755") ? bucket.accountingDate >= openingDate : stryMutAct_9fa48("5754") ? bucket.accountingDate <= openingDate : stryMutAct_9fa48("5753") ? false : stryMutAct_9fa48("5752") ? true : (stryCov_9fa48("5752", "5753", "5754", "5755"), bucket.accountingDate < openingDate))))) throw new AccountingError(stryMutAct_9fa48("5757") ? "" : (stryCov_9fa48("5757"), "activity_before_opening"));
      }
    }
  }
}
function grossOriginalAmount(bucket: ReclassificationBucket): number {
  if (stryMutAct_9fa48("5758")) {
    {}
  } else {
    stryCov_9fa48("5758");
    return bucket.rootSources.reduce(stryMutAct_9fa48("5759") ? () => undefined : (stryCov_9fa48("5759"), (sum, root) => stryMutAct_9fa48("5760") ? sum - Math.abs(root.signedMinorUnits) : (stryCov_9fa48("5760"), sum + Math.abs(root.signedMinorUnits))), 0);
  }
}
function correctionImpact(input: {
  outstanding: ReclassificationBucket[];
  selectedSources: CorrectionSource[];
  lockedEntryIds: Set<string>;
}) {
  if (stryMutAct_9fa48("5761")) {
    {}
  } else {
    stryCov_9fa48("5761");
    const {
      outstanding,
      selectedSources,
      lockedEntryIds
    } = input;
    const entryIds = new Set(selectedSources.map(stryMutAct_9fa48("5762") ? () => undefined : (stryCov_9fa48("5762"), source => source.entryId)));
    const total = outstanding.reduce(stryMutAct_9fa48("5763") ? () => undefined : (stryCov_9fa48("5763"), (sum, bucket) => stryMutAct_9fa48("5764") ? sum - grossOriginalAmount(bucket) : (stryCov_9fa48("5764"), sum + grossOriginalAmount(bucket))), 0);
    const lockedTotal = stryMutAct_9fa48("5765") ? outstanding.reduce((sum, bucket) => sum + grossOriginalAmount(bucket), 0) : (stryCov_9fa48("5765"), outstanding.filter(stryMutAct_9fa48("5766") ? () => undefined : (stryCov_9fa48("5766"), bucket => bucket.priorLockedPeriods.length)).reduce(stryMutAct_9fa48("5767") ? () => undefined : (stryCov_9fa48("5767"), (sum, bucket) => stryMutAct_9fa48("5768") ? sum - grossOriginalAmount(bucket) : (stryCov_9fa48("5768"), sum + grossOriginalAmount(bucket))), 0));
    if (stryMutAct_9fa48("5771") ? false : stryMutAct_9fa48("5770") ? true : stryMutAct_9fa48("5769") ? Number.isSafeInteger(total) : (stryCov_9fa48("5769", "5770", "5771"), !Number.isSafeInteger(total))) throw new AccountingError(stryMutAct_9fa48("5773") ? "" : (stryCov_9fa48("5773"), "journal_line_invalid"));
    const correctionDates = stryMutAct_9fa48("5774") ? [...new Set(outstanding.map(bucket => bucket.accountingDate.slice(0, 7)))].map(month => outstanding.filter(bucket => bucket.accountingDate.startsWith(month)).reduce((date, bucket) => bucket.accountingDate > date ? bucket.accountingDate : date, "")) : (stryCov_9fa48("5774"), (stryMutAct_9fa48("5775") ? [] : (stryCov_9fa48("5775"), [...new Set(outstanding.map(stryMutAct_9fa48("5776") ? () => undefined : (stryCov_9fa48("5776"), bucket => stryMutAct_9fa48("5777") ? bucket.accountingDate : (stryCov_9fa48("5777"), bucket.accountingDate.slice(0, 7)))))])).sort().map(stryMutAct_9fa48("5778") ? () => undefined : (stryCov_9fa48("5778"), month => stryMutAct_9fa48("5779") ? outstanding.reduce((date, bucket) => bucket.accountingDate > date ? bucket.accountingDate : date, "") : (stryCov_9fa48("5779"), outstanding.filter(stryMutAct_9fa48("5780") ? () => undefined : (stryCov_9fa48("5780"), bucket => stryMutAct_9fa48("5781") ? bucket.accountingDate.endsWith(month) : (stryCov_9fa48("5781"), bucket.accountingDate.startsWith(month)))).reduce(stryMutAct_9fa48("5782") ? () => undefined : (stryCov_9fa48("5782"), (date, bucket) => (stryMutAct_9fa48("5786") ? bucket.accountingDate <= date : stryMutAct_9fa48("5785") ? bucket.accountingDate >= date : stryMutAct_9fa48("5784") ? false : stryMutAct_9fa48("5783") ? true : (stryCov_9fa48("5783", "5784", "5785", "5786"), bucket.accountingDate > date)) ? bucket.accountingDate : date), stryMutAct_9fa48("5787") ? "Stryker was here!" : (stryCov_9fa48("5787"), ""))))));
    return stryMutAct_9fa48("5788") ? {} : (stryCov_9fa48("5788"), {
      entryCount: entryIds.size,
      lineCount: selectedSources.length,
      lockedEntryCount: lockedEntryIds.size,
      total,
      lockedTotal,
      correctionDates
    });
  }
}
export async function confirmCategoryReclassification(store: AccountingStore, clock: AccountingClock, input: ConfirmReclassificationInput) {
  if (stryMutAct_9fa48("5789")) {
    {}
  } else {
    stryCov_9fa48("5789");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("5790") ? "" : (stryCov_9fa48("5790"), "correct"));
    await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("5791") ? "" : (stryCov_9fa48("5791"), "post"));
    if (stryMutAct_9fa48("5794") ? false : stryMutAct_9fa48("5793") ? true : stryMutAct_9fa48("5792") ? input.confirmed : (stryCov_9fa48("5792", "5793", "5794"), !input.confirmed)) throw new AccountingError(stryMutAct_9fa48("5796") ? "" : (stryCov_9fa48("5796"), "category_confirmation_required"));
    if (stryMutAct_9fa48("5799") ? false : stryMutAct_9fa48("5798") ? true : stryMutAct_9fa48("5797") ? input.idempotencyKey : (stryCov_9fa48("5797", "5798", "5799"), !input.idempotencyKey)) throw new AccountingError(stryMutAct_9fa48("5801") ? "" : (stryCov_9fa48("5801"), "idempotency_key_required"));
    const request = commandIdentity(stryMutAct_9fa48("5802") ? {} : (stryCov_9fa48("5802"), {
      command: stryMutAct_9fa48("5803") ? "" : (stryCov_9fa48("5803"), "reclassify"),
      categoryId: input.categoryId,
      target: input.target,
      currentDate: input.currentDate,
      revisionToken: input.revisionToken
    }));
    const receipt = await store.getCategoryReceipt(input.workspaceId, input.idempotencyKey);
    if (stryMutAct_9fa48("5805") ? false : stryMutAct_9fa48("5804") ? true : (stryCov_9fa48("5804", "5805"), receipt)) {
      if (stryMutAct_9fa48("5806")) {
        {}
      } else {
        stryCov_9fa48("5806");
        if (stryMutAct_9fa48("5809") ? receipt.request === request : stryMutAct_9fa48("5808") ? false : stryMutAct_9fa48("5807") ? true : (stryCov_9fa48("5807", "5808", "5809"), receipt.request !== request)) throw new AccountingError(stryMutAct_9fa48("5811") ? "" : (stryCov_9fa48("5811"), "idempotency_key_conflict"));
        return stryMutAct_9fa48("5812") ? {} : (stryCov_9fa48("5812"), {
          category: receipt.category,
          correctionEntryIds: receipt.correctionEntryIds,
          ...(receipt.financialAccountProfileId ? stryMutAct_9fa48("5813") ? {} : (stryCov_9fa48("5813"), {
            financialAccountProfileId: receipt.financialAccountProfileId
          }) : {}),
          replay: stryMutAct_9fa48("5814") ? false : (stryCov_9fa48("5814"), true)
        });
      }
    }
    const preview = await previewCategoryReclassification(store, input);
    if (stryMutAct_9fa48("5817") ? preview.revisionToken === input.revisionToken : stryMutAct_9fa48("5816") ? false : stryMutAct_9fa48("5815") ? true : (stryCov_9fa48("5815", "5816", "5817"), preview.revisionToken !== input.revisionToken)) throw new AccountingError(stryMutAct_9fa48("5819") ? "" : (stryCov_9fa48("5819"), "reclassification_stale"));
    const category = await requireCategory(store, input.workspaceId, input.categoryId);
    const destination = await resolveCorrectionDestination(store, clock, workspace, category, input);
    const profileId = (stryMutAct_9fa48("5822") ? destination.kind !== "profile" : stryMutAct_9fa48("5821") ? false : stryMutAct_9fa48("5820") ? true : (stryCov_9fa48("5820", "5821", "5822"), destination.kind === (stryMutAct_9fa48("5823") ? "" : (stryCov_9fa48("5823"), "profile")))) ? destination.financialAccountProfileId : undefined;
    const correctionEntryIds: string[] = stryMutAct_9fa48("5824") ? ["Stryker was here"] : (stryCov_9fa48("5824"), []);
    for (const date of preview.correctionDates) {
      if (stryMutAct_9fa48("5825")) {
        {}
      } else {
        stryCov_9fa48("5825");
        const draft = draftCategoryCorrection(stryMutAct_9fa48("5826") ? {} : (stryCov_9fa48("5826"), {
          date,
          preview,
          destination,
          input,
          categoryName: category.name
        }));
        if (stryMutAct_9fa48("5829") ? false : stryMutAct_9fa48("5828") ? true : stryMutAct_9fa48("5827") ? draft.lines.length : (stryCov_9fa48("5827", "5828", "5829"), !draft.lines.length)) continue;
        const {
          entry
        } = await postJournalEntry(store, clock, stryMutAct_9fa48("5830") ? {} : (stryCov_9fa48("5830"), {
          actor: input.actor,
          workspaceId: input.workspaceId,
          draft
        }));
        if (stryMutAct_9fa48("5831")) {
          ;
        } else {
          stryCov_9fa48("5831");
          correctionEntryIds.push(entry.id);
        }
      }
    }
    await store.saveCategory(destination.category);
    await store.saveCategoryReceipt(stryMutAct_9fa48("5832") ? {} : (stryCov_9fa48("5832"), {
      workspaceId: input.workspaceId,
      idempotencyKey: input.idempotencyKey,
      request,
      category: destination.category,
      correctionEntryIds,
      ...(profileId ? stryMutAct_9fa48("5833") ? {} : (stryCov_9fa48("5833"), {
        financialAccountProfileId: profileId
      }) : {})
    }));
    return stryMutAct_9fa48("5834") ? {} : (stryCov_9fa48("5834"), {
      category: destination.category,
      correctionEntryIds,
      ...(profileId ? stryMutAct_9fa48("5835") ? {} : (stryCov_9fa48("5835"), {
        financialAccountProfileId: profileId
      }) : {}),
      replay: stryMutAct_9fa48("5836") ? true : (stryCov_9fa48("5836"), false)
    });
  }
}
async function resolveCorrectionDestination(store: AccountingStore, clock: AccountingClock, workspace: StoredWorkspace, category: UserCategory, input: ConfirmReclassificationInput): Promise<CorrectionDestination> {
  if (stryMutAct_9fa48("5837")) {
    {}
  } else {
    stryCov_9fa48("5837");
    const updated = stryMutAct_9fa48("5838") ? {} : (stryCov_9fa48("5838"), {
      ...category,
      revision: stryMutAct_9fa48("5839") ? category.revision - 1 : (stryCov_9fa48("5839"), category.revision + 1)
    });
    const target = input.target;
    if (stryMutAct_9fa48("5842") ? target.kind !== "category" : stryMutAct_9fa48("5841") ? false : stryMutAct_9fa48("5840") ? true : (stryCov_9fa48("5840", "5841", "5842"), target.kind === (stryMutAct_9fa48("5843") ? "" : (stryCov_9fa48("5843"), "category")))) {
      if (stryMutAct_9fa48("5844")) {
        {}
      } else {
        stryCov_9fa48("5844");
        const account = await requireTemplateAccount(store, workspace, (stryMutAct_9fa48("5847") ? target.nature !== "Expense" : stryMutAct_9fa48("5846") ? false : stryMutAct_9fa48("5845") ? true : (stryCov_9fa48("5845", "5846", "5847"), target.nature === (stryMutAct_9fa48("5848") ? "" : (stryCov_9fa48("5848"), "Expense")))) ? stryMutAct_9fa48("5849") ? "" : (stryCov_9fa48("5849"), "expense") : stryMutAct_9fa48("5850") ? "" : (stryCov_9fa48("5850"), "income"), target.accountCode);
        updated.classification = stryMutAct_9fa48("5851") ? {} : (stryCov_9fa48("5851"), {
          kind: stryMutAct_9fa48("5852") ? "" : (stryCov_9fa48("5852"), "resolved"),
          nature: target.nature,
          natureProvenance: stryMutAct_9fa48("5853") ? {} : (stryCov_9fa48("5853"), {
            kind: stryMutAct_9fa48("5854") ? "" : (stryCov_9fa48("5854"), "answered")
          }),
          account: stryMutAct_9fa48("5855") ? {} : (stryCov_9fa48("5855"), {
            kind: stryMutAct_9fa48("5856") ? "" : (stryCov_9fa48("5856"), "advanced"),
            accountCode: target.accountCode
          })
        });
        return stryMutAct_9fa48("5857") ? {} : (stryCov_9fa48("5857"), {
          kind: stryMutAct_9fa48("5858") ? "" : (stryCov_9fa48("5858"), "category"),
          category: updated,
          ledgerAccountId: account.id
        });
      }
    }
    const result = await setupFinancialAccount(store, clock, stryMutAct_9fa48("5859") ? {} : (stryCov_9fa48("5859"), {
      ...target.setup,
      actor: input.actor,
      workspaceId: input.workspaceId,
      idempotencyKey: stryMutAct_9fa48("5860") ? `` : (stryCov_9fa48("5860"), `${input.idempotencyKey}:profile`)
    }));
    updated.classification = stryMutAct_9fa48("5861") ? {} : (stryCov_9fa48("5861"), {
      kind: stryMutAct_9fa48("5862") ? "" : (stryCov_9fa48("5862"), "converted"),
      financialAccountProfileId: result.profile.id
    });
    updated.status = stryMutAct_9fa48("5863") ? "" : (stryCov_9fa48("5863"), "archived");
    return stryMutAct_9fa48("5864") ? {} : (stryCov_9fa48("5864"), {
      kind: stryMutAct_9fa48("5865") ? "" : (stryCov_9fa48("5865"), "profile"),
      category: updated,
      ledgerAccountId: result.profile.ledgerAccountId,
      financialAccountProfileId: result.profile.id
    });
  }
}
function draftCategoryCorrection(args: {
  date: string;
  preview: ReclassificationPreview;
  destination: CorrectionDestination;
  input: ConfirmReclassificationInput;
  categoryName: string;
}): JournalEntryDraft {
  if (stryMutAct_9fa48("5866")) {
    {}
  } else {
    stryCov_9fa48("5866");
    const {
      date,
      preview,
      destination,
      input,
      categoryName
    } = args;
    const lines: DraftJournalLine[] = stryMutAct_9fa48("5867") ? ["Stryker was here"] : (stryCov_9fa48("5867"), []);
    const expenseEffects = new Map<string, number>();
    for (const bucket of stryMutAct_9fa48("5868") ? preview.buckets : (stryCov_9fa48("5868"), preview.buckets.filter(stryMutAct_9fa48("5869") ? () => undefined : (stryCov_9fa48("5869"), bucket => stryMutAct_9fa48("5872") ? bucket.accountingDate.slice(0, 7) !== date.slice(0, 7) : stryMutAct_9fa48("5871") ? false : stryMutAct_9fa48("5870") ? true : (stryCov_9fa48("5870", "5871", "5872"), (stryMutAct_9fa48("5873") ? bucket.accountingDate : (stryCov_9fa48("5873"), bucket.accountingDate.slice(0, 7))) === (stryMutAct_9fa48("5874") ? date : (stryCov_9fa48("5874"), date.slice(0, 7)))))))) {
      if (stryMutAct_9fa48("5875")) {
        {}
      } else {
        stryCov_9fa48("5875");
        const expenseFactor = stryMutAct_9fa48("5876") ? (input.target.kind === "category" && input.target.nature === "Expense" ? 1 : 0) + (bucket.snapshot.nature === "Expense" ? 1 : 0) : (stryCov_9fa48("5876"), ((stryMutAct_9fa48("5879") ? input.target.kind === "category" || input.target.nature === "Expense" : stryMutAct_9fa48("5878") ? false : stryMutAct_9fa48("5877") ? true : (stryCov_9fa48("5877", "5878", "5879"), (stryMutAct_9fa48("5881") ? input.target.kind !== "category" : stryMutAct_9fa48("5880") ? true : (stryCov_9fa48("5880", "5881"), input.target.kind === (stryMutAct_9fa48("5882") ? "" : (stryCov_9fa48("5882"), "category")))) && (stryMutAct_9fa48("5884") ? input.target.nature !== "Expense" : stryMutAct_9fa48("5883") ? true : (stryCov_9fa48("5883", "5884"), input.target.nature === (stryMutAct_9fa48("5885") ? "" : (stryCov_9fa48("5885"), "Expense")))))) ? 1 : 0) - ((stryMutAct_9fa48("5888") ? bucket.snapshot.nature !== "Expense" : stryMutAct_9fa48("5887") ? false : stryMutAct_9fa48("5886") ? true : (stryCov_9fa48("5886", "5887", "5888"), bucket.snapshot.nature === (stryMutAct_9fa48("5889") ? "" : (stryCov_9fa48("5889"), "Expense")))) ? 1 : 0));
        for (const root of stryMutAct_9fa48("5890") ? bucket.rootSources : (stryCov_9fa48("5890"), bucket.rootSources.filter(stryMutAct_9fa48("5891") ? () => undefined : (stryCov_9fa48("5891"), root => stryMutAct_9fa48("5894") ? root.signedMinorUnits === 0 : stryMutAct_9fa48("5893") ? false : stryMutAct_9fa48("5892") ? true : (stryCov_9fa48("5892", "5893", "5894"), root.signedMinorUnits !== 0))))) {
          if (stryMutAct_9fa48("5895")) {
            {}
          } else {
            stryCov_9fa48("5895");
            const amount = Math.abs(root.signedMinorUnits);
            const positive = stryMutAct_9fa48("5899") ? root.signedMinorUnits <= 0 : stryMutAct_9fa48("5898") ? root.signedMinorUnits >= 0 : stryMutAct_9fa48("5897") ? false : stryMutAct_9fa48("5896") ? true : (stryCov_9fa48("5896", "5897", "5898", "5899"), root.signedMinorUnits > 0);
            const correction = stryMutAct_9fa48("5900") ? {} : (stryCov_9fa48("5900"), {
              reclassificationKey: input.idempotencyKey,
              sources: bucket.sources,
              rootSources: stryMutAct_9fa48("5901") ? [] : (stryCov_9fa48("5901"), [root]),
              priorLockedPeriods: stryMutAct_9fa48("5902") ? bucket.priorLockedPeriods : (stryCov_9fa48("5902"), bucket.priorLockedPeriods.sort())
            });
            expenseEffects.set(root.entryId, stryMutAct_9fa48("5904") ? (expenseEffects.get(root.entryId) ?? 0) - expenseFactor * root.signedMinorUnits : (stryCov_9fa48("5904"), (stryMutAct_9fa48("5905") ? expenseEffects.get(root.entryId) && 0 : (stryCov_9fa48("5905"), expenseEffects.get(root.entryId) ?? 0)) + (stryMutAct_9fa48("5906") ? expenseFactor / root.signedMinorUnits : (stryCov_9fa48("5906"), expenseFactor * root.signedMinorUnits))));
            lines.push(stryMutAct_9fa48("5908") ? {} : (stryCov_9fa48("5908"), {
              ledgerAccountId: bucket.ledgerAccountId,
              debitMinorUnits: positive ? 0 : amount,
              creditMinorUnits: positive ? amount : 0,
              category: bucket.snapshot,
              categoryCorrection: stryMutAct_9fa48("5909") ? {} : (stryCov_9fa48("5909"), {
                ...correction,
                side: stryMutAct_9fa48("5910") ? "" : (stryCov_9fa48("5910"), "reversing")
              })
            }));
            lines.push(stryMutAct_9fa48("5912") ? {} : (stryCov_9fa48("5912"), {
              ledgerAccountId: destination.ledgerAccountId,
              debitMinorUnits: positive ? amount : 0,
              creditMinorUnits: positive ? 0 : amount,
              ...((stryMutAct_9fa48("5915") ? input.target.kind !== "category" : stryMutAct_9fa48("5914") ? false : stryMutAct_9fa48("5913") ? true : (stryCov_9fa48("5913", "5914", "5915"), input.target.kind === (stryMutAct_9fa48("5916") ? "" : (stryCov_9fa48("5916"), "category")))) ? stryMutAct_9fa48("5917") ? {} : (stryCov_9fa48("5917"), {
                category: categorySnapshot(destination.category)
              }) : {}),
              categoryCorrection: stryMutAct_9fa48("5918") ? {} : (stryCov_9fa48("5918"), {
                ...correction,
                side: stryMutAct_9fa48("5919") ? "" : (stryCov_9fa48("5919"), "replacement")
              })
            }));
          }
        }
      }
    }
    const catchUp = stryMutAct_9fa48("5920") ? lines.every(line => line.categoryCorrection?.priorLockedPeriods.length) : (stryCov_9fa48("5920"), lines.some(stryMutAct_9fa48("5921") ? () => undefined : (stryCov_9fa48("5921"), line => stryMutAct_9fa48("5922") ? line.categoryCorrection.priorLockedPeriods.length : (stryCov_9fa48("5922"), line.categoryCorrection?.priorLockedPeriods.length))));
    return stryMutAct_9fa48("5923") ? {} : (stryCov_9fa48("5923"), {
      accountingDate: date,
      description: stryMutAct_9fa48("5924") ? `` : (stryCov_9fa48("5924"), `${catchUp ? stryMutAct_9fa48("5925") ? "" : (stryCov_9fa48("5925"), "Prior-period category correction") : stryMutAct_9fa48("5926") ? "" : (stryCov_9fa48("5926"), "Category correction")}: ${categoryName}`),
      idempotencyKey: stryMutAct_9fa48("5927") ? `` : (stryCov_9fa48("5927"), `${input.idempotencyKey}:correction:${stryMutAct_9fa48("5928") ? date : (stryCov_9fa48("5928"), date.slice(0, 7))}`),
      policy: stryMutAct_9fa48("5929") ? "" : (stryCov_9fa48("5929"), "category-reclassification@1"),
      lines,
      sourceExpenseEffects: stryMutAct_9fa48("5931") ? [...expenseEffects.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([sourceEntryId, expenseDeltaMinorUnits]) => ({
        sourceEntryId,
        expenseDeltaMinorUnits
      })) : stryMutAct_9fa48("5930") ? [...expenseEffects.entries()].filter(([, delta]) => delta !== 0).map(([sourceEntryId, expenseDeltaMinorUnits]) => ({
        sourceEntryId,
        expenseDeltaMinorUnits
      })) : (stryCov_9fa48("5930", "5931"), (stryMutAct_9fa48("5932") ? [] : (stryCov_9fa48("5932"), [...expenseEffects.entries()])).filter(stryMutAct_9fa48("5933") ? () => undefined : (stryCov_9fa48("5933"), ([, delta]) => stryMutAct_9fa48("5936") ? delta === 0 : stryMutAct_9fa48("5935") ? false : stryMutAct_9fa48("5934") ? true : (stryCov_9fa48("5934", "5935", "5936"), delta !== 0))).sort(stryMutAct_9fa48("5937") ? () => undefined : (stryCov_9fa48("5937"), ([a], [b]) => a.localeCompare(b))).map(stryMutAct_9fa48("5938") ? () => undefined : (stryCov_9fa48("5938"), ([sourceEntryId, expenseDeltaMinorUnits]) => stryMutAct_9fa48("5939") ? {} : (stryCov_9fa48("5939"), {
        sourceEntryId,
        expenseDeltaMinorUnits
      }))))
    });
  }
}