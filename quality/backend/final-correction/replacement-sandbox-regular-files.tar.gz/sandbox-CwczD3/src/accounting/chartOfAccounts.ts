// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError, type AccountingErrorCode } from "./errors";
import { coPucPersonalTemplate } from "./templates/coPucPersonal";
import { usGaapPersonalTemplate } from "./templates/usGaapPersonal";
import type { AccountNature, AccountingStore, CatalogAccount, CatalogAccountView, CatalogUse, ChartOfAccountsTemplate, LedgerAccount, NormalSide, StoredWorkspace } from "./types";

/** The template a new Personal or Household Workspace starts from unless it asks for another. */
export const personalChartTemplate: ChartOfAccountsTemplate = coPucPersonalTemplate;
const templates = new Map<string, ChartOfAccountsTemplate>((stryMutAct_9fa48("4065") ? [] : (stryCov_9fa48("4065"), [coPucPersonalTemplate, usGaapPersonalTemplate])).map(stryMutAct_9fa48("4066") ? () => undefined : (stryCov_9fa48("4066"), template => stryMutAct_9fa48("4067") ? [] : (stryCov_9fa48("4067"), [template.version, template]))));
type RecordingUse = Extract<CatalogUse, "expense" | "income" | "openingBalance">;
const wrongUse: Record<RecordingUse, AccountingErrorCode> = stryMutAct_9fa48("4068") ? {} : (stryCov_9fa48("4068"), {
  expense: stryMutAct_9fa48("4069") ? "" : (stryCov_9fa48("4069"), "cash_expense_account_invalid"),
  income: stryMutAct_9fa48("4070") ? "" : (stryCov_9fa48("4070"), "cash_income_account_invalid"),
  openingBalance: stryMutAct_9fa48("4071") ? "" : (stryCov_9fa48("4071"), "opening_balance_account_invalid")
});
export function chartTemplate(version: string): ChartOfAccountsTemplate {
  if (stryMutAct_9fa48("4072")) {
    {}
  } else {
    stryCov_9fa48("4072");
    const template = templates.get(version);
    if (stryMutAct_9fa48("4075") ? false : stryMutAct_9fa48("4074") ? true : stryMutAct_9fa48("4073") ? template : (stryCov_9fa48("4073", "4074", "4075"), !template)) {
      if (stryMutAct_9fa48("4076")) {
        {}
      } else {
        stryCov_9fa48("4076");
        throw new AccountingError(stryMutAct_9fa48("4078") ? "" : (stryCov_9fa48("4078"), "chart_of_accounts_template_unknown"));
      }
    }
    return template;
  }
}

/** The first digit of a code is its class, and the class locks the nature. */
export function natureOfCode(template: ChartOfAccountsTemplate, code: string): AccountNature {
  if (stryMutAct_9fa48("4079")) {
    {}
  } else {
    stryCov_9fa48("4079");
    const nature = template.natureByClass[stryMutAct_9fa48("4080") ? code : (stryCov_9fa48("4080"), code.charAt(0))];
    if (stryMutAct_9fa48("4083") ? false : stryMutAct_9fa48("4082") ? true : stryMutAct_9fa48("4081") ? nature : (stryCov_9fa48("4081", "4082", "4083"), !nature)) {
      if (stryMutAct_9fa48("4084")) {
        {}
      } else {
        stryCov_9fa48("4084");
        throw new AccountingError(stryMutAct_9fa48("4086") ? "" : (stryCov_9fa48("4086"), "ledger_account_code_unknown"));
      }
    }
    return nature;
  }
}

/** Assets and Expenses grow with debits; Liabilities, Equity, and Revenue grow with credits. */
export function increasesWithDebit(nature: AccountNature): boolean {
  if (stryMutAct_9fa48("4087")) {
    {}
  } else {
    stryCov_9fa48("4087");
    return stryMutAct_9fa48("4090") ? nature === "Asset" && nature === "Expense" : stryMutAct_9fa48("4089") ? false : stryMutAct_9fa48("4088") ? true : (stryCov_9fa48("4088", "4089", "4090"), (stryMutAct_9fa48("4092") ? nature !== "Asset" : stryMutAct_9fa48("4091") ? false : (stryCov_9fa48("4091", "4092"), nature === (stryMutAct_9fa48("4093") ? "" : (stryCov_9fa48("4093"), "Asset")))) || (stryMutAct_9fa48("4095") ? nature !== "Expense" : stryMutAct_9fa48("4094") ? false : (stryCov_9fa48("4094", "4095"), nature === (stryMutAct_9fa48("4096") ? "" : (stryCov_9fa48("4096"), "Expense")))));
  }
}
export function normalSideOf(nature: AccountNature): NormalSide {
  if (stryMutAct_9fa48("4097")) {
    {}
  } else {
    stryCov_9fa48("4097");
    return increasesWithDebit(nature) ? stryMutAct_9fa48("4098") ? "" : (stryCov_9fa48("4098"), "Debit") : stryMutAct_9fa48("4099") ? "" : (stryCov_9fa48("4099"), "Credit");
  }
}

/** Balance on the account's normal side, so an Asset shows money held and a Liability money owed. */
export function normalBalance(normalSide: NormalSide, totals: {
  debitMinorUnits: number;
  creditMinorUnits: number;
}): number {
  if (stryMutAct_9fa48("4100")) {
    {}
  } else {
    stryCov_9fa48("4100");
    return (stryMutAct_9fa48("4103") ? normalSide !== "Debit" : stryMutAct_9fa48("4102") ? false : stryMutAct_9fa48("4101") ? true : (stryCov_9fa48("4101", "4102", "4103"), normalSide === (stryMutAct_9fa48("4104") ? "" : (stryCov_9fa48("4104"), "Debit")))) ? stryMutAct_9fa48("4105") ? totals.debitMinorUnits + totals.creditMinorUnits : (stryCov_9fa48("4105"), totals.debitMinorUnits - totals.creditMinorUnits) : stryMutAct_9fa48("4106") ? totals.creditMinorUnits + totals.debitMinorUnits : (stryCov_9fa48("4106"), totals.creditMinorUnits - totals.debitMinorUnits);
  }
}
function classify(template: ChartOfAccountsTemplate, account: CatalogAccount) {
  if (stryMutAct_9fa48("4107")) {
    {}
  } else {
    stryCov_9fa48("4107");
    const nature = natureOfCode(template, account.code);
    return stryMutAct_9fa48("4108") ? {} : (stryCov_9fa48("4108"), {
      nature,
      normalSide: stryMutAct_9fa48("4109") ? account.normalSide && normalSideOf(nature) : (stryCov_9fa48("4109"), account.normalSide ?? normalSideOf(nature))
    });
  }
}
function catalogAccount(template: ChartOfAccountsTemplate, code: string): CatalogAccount {
  if (stryMutAct_9fa48("4110")) {
    {}
  } else {
    stryCov_9fa48("4110");
    const account = template.accounts.find(stryMutAct_9fa48("4111") ? () => undefined : (stryCov_9fa48("4111"), candidate => stryMutAct_9fa48("4114") ? candidate.code !== code : stryMutAct_9fa48("4113") ? false : stryMutAct_9fa48("4112") ? true : (stryCov_9fa48("4112", "4113", "4114"), candidate.code === code)));
    if (stryMutAct_9fa48("4117") ? false : stryMutAct_9fa48("4116") ? true : stryMutAct_9fa48("4115") ? account : (stryCov_9fa48("4115", "4116", "4117"), !account)) {
      if (stryMutAct_9fa48("4118")) {
        {}
      } else {
        stryCov_9fa48("4118");
        throw new AccountingError(stryMutAct_9fa48("4120") ? "" : (stryCov_9fa48("4120"), "ledger_account_code_unknown"));
      }
    }
    return account;
  }
}
async function activate(store: AccountingStore, workspaceId: string, template: ChartOfAccountsTemplate, account: CatalogAccount): Promise<LedgerAccount> {
  if (stryMutAct_9fa48("4121")) {
    {}
  } else {
    stryCov_9fa48("4121");
    const existing = await store.findLedgerAccountByCode(workspaceId, account.code);
    if (stryMutAct_9fa48("4123") ? false : stryMutAct_9fa48("4122") ? true : (stryCov_9fa48("4122", "4123"), existing)) {
      if (stryMutAct_9fa48("4124")) {
        {}
      } else {
        stryCov_9fa48("4124");
        return existing;
      }
    }
    return store.insertLedgerAccount(stryMutAct_9fa48("4125") ? {} : (stryCov_9fa48("4125"), {
      workspaceId,
      code: account.code,
      name: account.name,
      ...classify(template, account),
      role: stryMutAct_9fa48("4126") ? "" : (stryCov_9fa48("4126"), "Posting")
    }));
  }
}
export async function provisionChartOfAccounts(store: AccountingStore, workspaceId: string, template: ChartOfAccountsTemplate): Promise<void> {
  if (stryMutAct_9fa48("4127")) {
    {}
  } else {
    stryCov_9fa48("4127");
    const {
      expense,
      income,
      openingBalance
    } = template.defaults;
    for (const code of stryMutAct_9fa48("4128") ? [] : (stryCov_9fa48("4128"), [openingBalance, income, expense])) {
      if (stryMutAct_9fa48("4129")) {
        {}
      } else {
        stryCov_9fa48("4129");
        await activate(store, workspaceId, template, catalogAccount(template, code));
      }
    }
  }
}

/**
 * The Workspace's Posting Account for a template code, activated on first use.
 * The template's use for the code must match the recording flow asking for it.
 */
export async function requireTemplateAccount(store: AccountingStore, workspace: StoredWorkspace, use: RecordingUse, code?: string): Promise<LedgerAccount> {
  if (stryMutAct_9fa48("4130")) {
    {}
  } else {
    stryCov_9fa48("4130");
    const account = resolveTemplateAccount(workspace, use, code);
    return activate(store, workspace.id, chartTemplate(workspace.chartOfAccountsTemplate), account);
  }
}

/** Next auxiliary code under a profile parent: 111005 → 11100501, 11100502, … up to 99. Template accounts never sit under a profile parent. */
export async function nextAuxiliaryCode(store: AccountingStore, workspaceId: string, parentCode: string): Promise<string> {
  if (stryMutAct_9fa48("4131")) {
    {}
  } else {
    stryCov_9fa48("4131");
    const accounts = await store.listLedgerAccounts(workspaceId);
    const used = stryMutAct_9fa48("4132") ? accounts.map(account => Number(account.code.slice(parentCode.length))) : (stryCov_9fa48("4132"), accounts.filter(stryMutAct_9fa48("4133") ? () => undefined : (stryCov_9fa48("4133"), account => stryMutAct_9fa48("4134") ? account.code.endsWith(parentCode) : (stryCov_9fa48("4134"), account.code.startsWith(parentCode)))).map(stryMutAct_9fa48("4135") ? () => undefined : (stryCov_9fa48("4135"), account => Number(stryMutAct_9fa48("4136") ? account.code : (stryCov_9fa48("4136"), account.code.slice(parentCode.length))))));
    const next = stryMutAct_9fa48("4137") ? Math.max(0, ...used) - 1 : (stryCov_9fa48("4137"), (stryMutAct_9fa48("4138") ? Math.min(0, ...used) : (stryCov_9fa48("4138"), Math.max(0, ...used))) + 1);
    if (stryMutAct_9fa48("4142") ? next <= 99 : stryMutAct_9fa48("4141") ? next >= 99 : stryMutAct_9fa48("4140") ? false : stryMutAct_9fa48("4139") ? true : (stryCov_9fa48("4139", "4140", "4141", "4142"), next > 99)) {
      if (stryMutAct_9fa48("4143")) {
        {}
      } else {
        stryCov_9fa48("4143");
        throw new AccountingError(stryMutAct_9fa48("4145") ? "" : (stryCov_9fa48("4145"), "auxiliary_accounts_exhausted"));
      }
    }
    return stryMutAct_9fa48("4146") ? `` : (stryCov_9fa48("4146"), `${parentCode}${String(next).padStart(2, stryMutAct_9fa48("4147") ? "" : (stryCov_9fa48("4147"), "0"))}`);
  }
}

/** Every Posting Account the template offers, each with its summary levels and activation. */
export function catalogView(template: ChartOfAccountsTemplate, activated: LedgerAccount[]): CatalogAccountView[] {
  if (stryMutAct_9fa48("4148")) {
    {}
  } else {
    stryCov_9fa48("4148");
    const byCode = new Map(activated.map(stryMutAct_9fa48("4149") ? () => undefined : (stryCov_9fa48("4149"), account => stryMutAct_9fa48("4150") ? [] : (stryCov_9fa48("4150"), [account.code, account.id]))));
    return template.accounts.map(account => {
      if (stryMutAct_9fa48("4151")) {
        {}
      } else {
        stryCov_9fa48("4151");
        const view: CatalogAccountView = stryMutAct_9fa48("4152") ? {} : (stryCov_9fa48("4152"), {
          code: account.code,
          name: account.name,
          ...classify(template, account),
          use: account.use,
          ...(account.reportingConcept ? stryMutAct_9fa48("4153") ? {} : (stryCov_9fa48("4153"), {
            reportingConcept: account.reportingConcept
          }) : {}),
          ancestors: ancestorCodes(account.code).map(stryMutAct_9fa48("4154") ? () => undefined : (stryCov_9fa48("4154"), code => stryMutAct_9fa48("4155") ? {} : (stryCov_9fa48("4155"), {
            code,
            name: stryMutAct_9fa48("4156") ? template.summaryNames[code] && "" : (stryCov_9fa48("4156"), template.summaryNames[code] ?? (stryMutAct_9fa48("4157") ? "Stryker was here!" : (stryCov_9fa48("4157"), "")))
          })))
        });
        const ledgerAccountId = byCode.get(account.code);
        if (stryMutAct_9fa48("4159") ? false : stryMutAct_9fa48("4158") ? true : (stryCov_9fa48("4158", "4159"), ledgerAccountId)) {
          if (stryMutAct_9fa48("4160")) {
            {}
          } else {
            stryCov_9fa48("4160");
            view.ledgerAccountId = ledgerAccountId;
          }
        }
        return view;
      }
    });
  }
}

/** Clase, grupo, cuenta, and subcuenta above a code: 51959595 → 5, 51, 5195, 519595. */
export function ancestorCodes(code: string): string[] {
  if (stryMutAct_9fa48("4161")) {
    {}
  } else {
    stryCov_9fa48("4161");
    return stryMutAct_9fa48("4162") ? [1, 2, 4, 6].map(length => code.slice(0, length)) : (stryCov_9fa48("4162"), (stryMutAct_9fa48("4163") ? [] : (stryCov_9fa48("4163"), [1, 2, 4, 6])).filter(stryMutAct_9fa48("4164") ? () => undefined : (stryCov_9fa48("4164"), length => stryMutAct_9fa48("4168") ? length >= code.length : stryMutAct_9fa48("4167") ? length <= code.length : stryMutAct_9fa48("4166") ? false : stryMutAct_9fa48("4165") ? true : (stryCov_9fa48("4165", "4166", "4167", "4168"), length < code.length))).map(stryMutAct_9fa48("4169") ? () => undefined : (stryCov_9fa48("4169"), length => stryMutAct_9fa48("4170") ? code : (stryCov_9fa48("4170"), code.slice(0, length)))));
  }
}
export function resolveTemplateAccount(workspace: StoredWorkspace, use: RecordingUse, code?: string) {
  if (stryMutAct_9fa48("4171")) {
    {}
  } else {
    stryCov_9fa48("4171");
    const template = chartTemplate(workspace.chartOfAccountsTemplate);
    const account = catalogAccount(template, stryMutAct_9fa48("4172") ? code && template.defaults[use] : (stryCov_9fa48("4172"), code ?? template.defaults[use]));
    if (stryMutAct_9fa48("4175") ? account.use === use : stryMutAct_9fa48("4174") ? false : stryMutAct_9fa48("4173") ? true : (stryCov_9fa48("4173", "4174", "4175"), account.use !== use)) if (stryMutAct_9fa48("4176")) {
      ;
    } else {
      stryCov_9fa48("4176");
      throw new AccountingError(wrongUse[use]);
    }
    return stryMutAct_9fa48("4177") ? {} : (stryCov_9fa48("4177"), {
      ...account,
      ...classify(template, account)
    });
  }
}