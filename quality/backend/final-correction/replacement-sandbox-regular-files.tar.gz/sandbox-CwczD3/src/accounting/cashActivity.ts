// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { commandIdentity } from "./commandIdentity";
import { resolveCashCategory } from "./cashCategory";
import { requireTemplateAccount } from "./chartOfAccounts";
import { AccountingError } from "./errors";
import { requireWorkspace } from "./membership";
import { requireFunctionalAmount } from "./money";
import { postJournalEntry } from "./posting";
import type { AccountingClock, AccountingStore, CashActivityInput, PostedJournalEntry, PostingPolicy } from "./types";
import { journalContext, toPostedJournalEntry } from "./views";

/**
 * Cash-style activity between a Financial Account Profile and one Chart of Accounts
 * counterpart. Money out credits the profile; money in debits it. The profile's
 * nature decides what that does to its balance, so a card purchase grows a Liability.
 * The counterpart is the template account for `ledgerAccountCode`, or the template
 * default, and its template use must match the flow: an expense for money out,
 * income for money in.
 */
export async function recordCashActivity(store: AccountingStore, clock: AccountingClock, input: CashActivityInput, treatment: {
  policy: PostingPolicy;
  direction: "out" | "in";
  counterpart: "expense" | "income";
}): Promise<PostedJournalEntry> {
  if (stryMutAct_9fa48("3378")) {
    {}
  } else {
    stryCov_9fa48("3378");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("3379") ? "" : (stryCov_9fa48("3379"), "post"));
    const amount = requireFunctionalAmount(workspace, input.amount);
    const profile = await store.getProfile(input.financialAccountProfileId);
    if (stryMutAct_9fa48("3382") ? !profile && profile.workspaceId !== input.workspaceId : stryMutAct_9fa48("3381") ? false : stryMutAct_9fa48("3380") ? true : (stryCov_9fa48("3380", "3381", "3382"), (stryMutAct_9fa48("3383") ? profile : (stryCov_9fa48("3383"), !profile)) || (stryMutAct_9fa48("3385") ? profile.workspaceId === input.workspaceId : stryMutAct_9fa48("3384") ? false : (stryCov_9fa48("3384", "3385"), profile.workspaceId !== input.workspaceId)))) {
      if (stryMutAct_9fa48("3386")) {
        {}
      } else {
        stryCov_9fa48("3386");
        throw new AccountingError(stryMutAct_9fa48("3388") ? "" : (stryCov_9fa48("3388"), "financial_account_profile_not_found"));
      }
    }
    const cashCategoryInput = (stryMutAct_9fa48("3391") ? input.userCategoryId !== undefined : stryMutAct_9fa48("3390") ? false : stryMutAct_9fa48("3389") ? true : (stryCov_9fa48("3389", "3390", "3391"), input.userCategoryId === undefined)) ? undefined : stryMutAct_9fa48("3392") ? {} : (stryCov_9fa48("3392"), {
      userCategoryId: input.userCategoryId,
      ...((stryMutAct_9fa48("3395") ? input.categoryRevision === undefined : stryMutAct_9fa48("3394") ? false : stryMutAct_9fa48("3393") ? true : (stryCov_9fa48("3393", "3394", "3395"), input.categoryRevision !== undefined)) ? stryMutAct_9fa48("3396") ? {} : (stryCov_9fa48("3396"), {
        categoryRevision: input.categoryRevision
      }) : {}),
      ...((stryMutAct_9fa48("3399") ? input.ledgerAccountCode === undefined : stryMutAct_9fa48("3398") ? false : stryMutAct_9fa48("3397") ? true : (stryCov_9fa48("3397", "3398", "3399"), input.ledgerAccountCode !== undefined)) ? stryMutAct_9fa48("3400") ? {} : (stryCov_9fa48("3400"), {
        ledgerAccountCode: input.ledgerAccountCode
      }) : {})
    });
    const existing = await store.findJournalEntryByIdempotencyKey(input.workspaceId, input.idempotencyKey);
    if (stryMutAct_9fa48("3403") ? existing || commandIdentity(existing.cashCategoryInput) !== commandIdentity(cashCategoryInput) : stryMutAct_9fa48("3402") ? false : stryMutAct_9fa48("3401") ? true : (stryCov_9fa48("3401", "3402", "3403"), existing && (stryMutAct_9fa48("3405") ? commandIdentity(existing.cashCategoryInput) === commandIdentity(cashCategoryInput) : stryMutAct_9fa48("3404") ? true : (stryCov_9fa48("3404", "3405"), commandIdentity(existing.cashCategoryInput) !== commandIdentity(cashCategoryInput))))) throw new AccountingError(stryMutAct_9fa48("3407") ? "" : (stryCov_9fa48("3407"), "idempotency_key_conflict"));
    const saved = stryMutAct_9fa48("3409") ? existing.lines.find(line => line.category)?.category : stryMutAct_9fa48("3408") ? existing?.lines.find(line => line.category).category : (stryCov_9fa48("3408", "3409"), existing?.lines.find(stryMutAct_9fa48("3410") ? () => undefined : (stryCov_9fa48("3410"), line => line.category))?.category);
    if (stryMutAct_9fa48("3413") ? existing && input.userCategoryId !== undefined || !saved || saved.categoryId !== input.userCategoryId : stryMutAct_9fa48("3412") ? false : stryMutAct_9fa48("3411") ? true : (stryCov_9fa48("3411", "3412", "3413"), (stryMutAct_9fa48("3415") ? existing || input.userCategoryId !== undefined : stryMutAct_9fa48("3414") ? true : (stryCov_9fa48("3414", "3415"), existing && (stryMutAct_9fa48("3417") ? input.userCategoryId === undefined : stryMutAct_9fa48("3416") ? true : (stryCov_9fa48("3416", "3417"), input.userCategoryId !== undefined)))) && (stryMutAct_9fa48("3419") ? !saved && saved.categoryId !== input.userCategoryId : stryMutAct_9fa48("3418") ? true : (stryCov_9fa48("3418", "3419"), (stryMutAct_9fa48("3420") ? saved : (stryCov_9fa48("3420"), !saved)) || (stryMutAct_9fa48("3422") ? saved.categoryId === input.userCategoryId : stryMutAct_9fa48("3421") ? false : (stryCov_9fa48("3421", "3422"), saved.categoryId !== input.userCategoryId)))))) throw new AccountingError(stryMutAct_9fa48("3424") ? "" : (stryCov_9fa48("3424"), "idempotency_key_conflict"));
    const category = await resolveCashCategory(store, input, treatment.counterpart, saved);
    const counterpart = await requireTemplateAccount(store, workspace, treatment.counterpart, stryMutAct_9fa48("3425") ? input.ledgerAccountCode && category?.account.accountCode : (stryCov_9fa48("3425"), input.ledgerAccountCode ?? (stryMutAct_9fa48("3426") ? category.account.accountCode : (stryCov_9fa48("3426"), category?.account.accountCode))));
    const debitAccountId = (stryMutAct_9fa48("3429") ? treatment.direction !== "out" : stryMutAct_9fa48("3428") ? false : stryMutAct_9fa48("3427") ? true : (stryCov_9fa48("3427", "3428", "3429"), treatment.direction === (stryMutAct_9fa48("3430") ? "" : (stryCov_9fa48("3430"), "out")))) ? counterpart.id : profile.postingAccountId;
    const creditAccountId = (stryMutAct_9fa48("3433") ? treatment.direction !== "out" : stryMutAct_9fa48("3432") ? false : stryMutAct_9fa48("3431") ? true : (stryCov_9fa48("3431", "3432", "3433"), treatment.direction === (stryMutAct_9fa48("3434") ? "" : (stryCov_9fa48("3434"), "out")))) ? profile.postingAccountId : counterpart.id;
    const {
      entry,
      replay
    } = await postJournalEntry(store, clock, stryMutAct_9fa48("3435") ? {} : (stryCov_9fa48("3435"), {
      actor: input.actor,
      workspaceId: input.workspaceId,
      draft: stryMutAct_9fa48("3436") ? {} : (stryCov_9fa48("3436"), {
        accountingDate: input.accountingDate,
        description: input.description,
        idempotencyKey: input.idempotencyKey,
        policy: treatment.policy,
        ...(cashCategoryInput ? stryMutAct_9fa48("3437") ? {} : (stryCov_9fa48("3437"), {
          cashCategoryInput
        }) : {}),
        financialAccountProfileId: profile.id,
        lines: stryMutAct_9fa48("3438") ? [] : (stryCov_9fa48("3438"), [stryMutAct_9fa48("3439") ? {} : (stryCov_9fa48("3439"), {
          ledgerAccountId: debitAccountId,
          debitMinorUnits: amount,
          creditMinorUnits: 0,
          ...((stryMutAct_9fa48("3442") ? category || treatment.direction === "out" : stryMutAct_9fa48("3441") ? false : stryMutAct_9fa48("3440") ? true : (stryCov_9fa48("3440", "3441", "3442"), category && (stryMutAct_9fa48("3444") ? treatment.direction !== "out" : stryMutAct_9fa48("3443") ? true : (stryCov_9fa48("3443", "3444"), treatment.direction === (stryMutAct_9fa48("3445") ? "" : (stryCov_9fa48("3445"), "out")))))) ? stryMutAct_9fa48("3446") ? {} : (stryCov_9fa48("3446"), {
            category
          }) : {})
        }), stryMutAct_9fa48("3447") ? {} : (stryCov_9fa48("3447"), {
          ledgerAccountId: creditAccountId,
          debitMinorUnits: 0,
          creditMinorUnits: amount,
          ...((stryMutAct_9fa48("3450") ? category || treatment.direction === "in" : stryMutAct_9fa48("3449") ? false : stryMutAct_9fa48("3448") ? true : (stryCov_9fa48("3448", "3449", "3450"), category && (stryMutAct_9fa48("3452") ? treatment.direction !== "in" : stryMutAct_9fa48("3451") ? true : (stryCov_9fa48("3451", "3452"), treatment.direction === (stryMutAct_9fa48("3453") ? "" : (stryCov_9fa48("3453"), "in")))))) ? stryMutAct_9fa48("3454") ? {} : (stryCov_9fa48("3454"), {
            category
          }) : {})
        })])
      })
    }));
    const reversal = await store.findReversalOf(entry.id);
    return toPostedJournalEntry(store, await journalContext(store, workspace), entry, stryMutAct_9fa48("3455") ? {} : (stryCov_9fa48("3455"), {
      replay,
      ...(reversal ? stryMutAct_9fa48("3456") ? {} : (stryCov_9fa48("3456"), {
        reversedByEntryId: reversal.id
      }) : {})
    }));
  }
}