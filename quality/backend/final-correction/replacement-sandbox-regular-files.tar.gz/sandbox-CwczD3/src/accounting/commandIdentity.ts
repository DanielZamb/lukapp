// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
export function commandIdentity(value: unknown): string {
  if (stryMutAct_9fa48("4285")) {
    {}
  } else {
    stryCov_9fa48("4285");
    return JSON.stringify(value, (_, item: unknown) => {
      if (stryMutAct_9fa48("4286")) {
        {}
      } else {
        stryCov_9fa48("4286");
        if (stryMutAct_9fa48("4289") ? item !== null && typeof item === "object" || !Array.isArray(item) : stryMutAct_9fa48("4288") ? false : stryMutAct_9fa48("4287") ? true : (stryCov_9fa48("4287", "4288", "4289"), (stryMutAct_9fa48("4291") ? item !== null || typeof item === "object" : stryMutAct_9fa48("4290") ? true : (stryCov_9fa48("4290", "4291"), (stryMutAct_9fa48("4293") ? item === null : stryMutAct_9fa48("4292") ? true : (stryCov_9fa48("4292", "4293"), item !== null)) && (stryMutAct_9fa48("4295") ? typeof item !== "object" : stryMutAct_9fa48("4294") ? true : (stryCov_9fa48("4294", "4295"), typeof item === (stryMutAct_9fa48("4296") ? "" : (stryCov_9fa48("4296"), "object")))))) && (stryMutAct_9fa48("4297") ? Array.isArray(item) : (stryCov_9fa48("4297"), !Array.isArray(item))))) return Object.fromEntries(stryMutAct_9fa48("4298") ? Object.entries(item) : (stryCov_9fa48("4298"), Object.entries(item).sort(stryMutAct_9fa48("4299") ? () => undefined : (stryCov_9fa48("4299"), ([a], [b]) => a.localeCompare(b)))));
        return item;
      }
    });
  }
}