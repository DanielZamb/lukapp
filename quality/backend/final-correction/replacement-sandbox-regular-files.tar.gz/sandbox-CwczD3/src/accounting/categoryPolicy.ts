// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { chartTemplate } from "./chartOfAccounts";
import { AccountingError } from "./errors";
import type { AccountResolution, CategoryNature, NatureAnswer } from "./categoryTypes";
export const categoryPolicy = stryMutAct_9fa48("3745") ? "" : (stryCov_9fa48("3745"), "category-es-en@1");
export const categoryPresets = (stryMutAct_9fa48("3746") ? [] : (stryCov_9fa48("3746"), [stryMutAct_9fa48("3747") ? {} : (stryCov_9fa48("3747"), {
  concept: stryMutAct_9fa48("3748") ? "" : (stryCov_9fa48("3748"), "groceries"),
  nature: stryMutAct_9fa48("3749") ? "" : (stryCov_9fa48("3749"), "Expense"),
  aliases: stryMutAct_9fa48("3750") ? [] : (stryCov_9fa48("3750"), [stryMutAct_9fa48("3751") ? "" : (stryCov_9fa48("3751"), "mercado"), stryMutAct_9fa48("3752") ? "" : (stryCov_9fa48("3752"), "groceries"), stryMutAct_9fa48("3753") ? "" : (stryCov_9fa48("3753"), "supermercado")]),
  co: stryMutAct_9fa48("3754") ? "" : (stryCov_9fa48("3754"), "51959501"),
  us: stryMutAct_9fa48("3755") ? "" : (stryCov_9fa48("3755"), "5310")
}), stryMutAct_9fa48("3756") ? {} : (stryCov_9fa48("3756"), {
  concept: stryMutAct_9fa48("3757") ? "" : (stryCov_9fa48("3757"), "restaurants"),
  nature: stryMutAct_9fa48("3758") ? "" : (stryCov_9fa48("3758"), "Expense"),
  aliases: stryMutAct_9fa48("3759") ? [] : (stryCov_9fa48("3759"), [stryMutAct_9fa48("3760") ? "" : (stryCov_9fa48("3760"), "restaurante"), stryMutAct_9fa48("3761") ? "" : (stryCov_9fa48("3761"), "restaurant"), stryMutAct_9fa48("3762") ? "" : (stryCov_9fa48("3762"), "cafe"), stryMutAct_9fa48("3763") ? "" : (stryCov_9fa48("3763"), "coffee")]),
  co: stryMutAct_9fa48("3764") ? "" : (stryCov_9fa48("3764"), "519560"),
  us: stryMutAct_9fa48("3765") ? "" : (stryCov_9fa48("3765"), "5320")
}), stryMutAct_9fa48("3766") ? {} : (stryCov_9fa48("3766"), {
  concept: stryMutAct_9fa48("3767") ? "" : (stryCov_9fa48("3767"), "fuel"),
  nature: stryMutAct_9fa48("3768") ? "" : (stryCov_9fa48("3768"), "Expense"),
  aliases: stryMutAct_9fa48("3769") ? [] : (stryCov_9fa48("3769"), [stryMutAct_9fa48("3770") ? "" : (stryCov_9fa48("3770"), "gasolina"), stryMutAct_9fa48("3771") ? "" : (stryCov_9fa48("3771"), "fuel"), stryMutAct_9fa48("3772") ? "" : (stryCov_9fa48("3772"), "gasoline")]),
  co: stryMutAct_9fa48("3773") ? "" : (stryCov_9fa48("3773"), "519535"),
  us: stryMutAct_9fa48("3774") ? "" : (stryCov_9fa48("3774"), "5210")
}), stryMutAct_9fa48("3775") ? {} : (stryCov_9fa48("3775"), {
  concept: stryMutAct_9fa48("3776") ? "" : (stryCov_9fa48("3776"), "rentPaid"),
  nature: stryMutAct_9fa48("3777") ? "" : (stryCov_9fa48("3777"), "Expense"),
  aliases: stryMutAct_9fa48("3778") ? [] : (stryCov_9fa48("3778"), [stryMutAct_9fa48("3779") ? "" : (stryCov_9fa48("3779"), "arriendo"), stryMutAct_9fa48("3780") ? "" : (stryCov_9fa48("3780"), "rent"), stryMutAct_9fa48("3781") ? "" : (stryCov_9fa48("3781"), "alquiler")]),
  co: stryMutAct_9fa48("3782") ? "" : (stryCov_9fa48("3782"), "512010"),
  us: stryMutAct_9fa48("3783") ? "" : (stryCov_9fa48("3783"), "5010")
}), stryMutAct_9fa48("3784") ? {} : (stryCov_9fa48("3784"), {
  concept: stryMutAct_9fa48("3785") ? "" : (stryCov_9fa48("3785"), "rentReceived"),
  nature: stryMutAct_9fa48("3786") ? "" : (stryCov_9fa48("3786"), "Income"),
  aliases: stryMutAct_9fa48("3787") ? [] : (stryCov_9fa48("3787"), [stryMutAct_9fa48("3788") ? "" : (stryCov_9fa48("3788"), "arriendo"), stryMutAct_9fa48("3789") ? "" : (stryCov_9fa48("3789"), "rent"), stryMutAct_9fa48("3790") ? "" : (stryCov_9fa48("3790"), "alquiler")]),
  co: stryMutAct_9fa48("3791") ? "" : (stryCov_9fa48("3791"), "42201001"),
  us: stryMutAct_9fa48("3792") ? "" : (stryCov_9fa48("3792"), "4210")
}), stryMutAct_9fa48("3793") ? {} : (stryCov_9fa48("3793"), {
  concept: stryMutAct_9fa48("3794") ? "" : (stryCov_9fa48("3794"), "salary"),
  nature: stryMutAct_9fa48("3795") ? "" : (stryCov_9fa48("3795"), "Income"),
  aliases: stryMutAct_9fa48("3796") ? [] : (stryCov_9fa48("3796"), [stryMutAct_9fa48("3797") ? "" : (stryCov_9fa48("3797"), "salario"), stryMutAct_9fa48("3798") ? "" : (stryCov_9fa48("3798"), "sueldo"), stryMutAct_9fa48("3799") ? "" : (stryCov_9fa48("3799"), "salary"), stryMutAct_9fa48("3800") ? "" : (stryCov_9fa48("3800"), "wages")]),
  co: stryMutAct_9fa48("3801") ? "" : (stryCov_9fa48("3801"), "42959501"),
  us: stryMutAct_9fa48("3802") ? "" : (stryCov_9fa48("3802"), "4010")
}), stryMutAct_9fa48("3803") ? {} : (stryCov_9fa48("3803"), {
  concept: stryMutAct_9fa48("3804") ? "" : (stryCov_9fa48("3804"), "interestPaid"),
  nature: stryMutAct_9fa48("3805") ? "" : (stryCov_9fa48("3805"), "Expense"),
  aliases: stryMutAct_9fa48("3806") ? [] : (stryCov_9fa48("3806"), [stryMutAct_9fa48("3807") ? "" : (stryCov_9fa48("3807"), "intereses"), stryMutAct_9fa48("3808") ? "" : (stryCov_9fa48("3808"), "interest")]),
  co: stryMutAct_9fa48("3809") ? "" : (stryCov_9fa48("3809"), "530520"),
  us: stryMutAct_9fa48("3810") ? "" : (stryCov_9fa48("3810"), "6030")
}), stryMutAct_9fa48("3811") ? {} : (stryCov_9fa48("3811"), {
  concept: stryMutAct_9fa48("3812") ? "" : (stryCov_9fa48("3812"), "interestReceived"),
  nature: stryMutAct_9fa48("3813") ? "" : (stryCov_9fa48("3813"), "Income"),
  aliases: stryMutAct_9fa48("3814") ? [] : (stryCov_9fa48("3814"), [stryMutAct_9fa48("3815") ? "" : (stryCov_9fa48("3815"), "intereses"), stryMutAct_9fa48("3816") ? "" : (stryCov_9fa48("3816"), "interest")]),
  co: stryMutAct_9fa48("3817") ? "" : (stryCov_9fa48("3817"), "421005"),
  us: stryMutAct_9fa48("3818") ? "" : (stryCov_9fa48("3818"), "4110")
}), stryMutAct_9fa48("3819") ? {} : (stryCov_9fa48("3819"), {
  concept: stryMutAct_9fa48("3820") ? "" : (stryCov_9fa48("3820"), "lifeInsurance"),
  nature: stryMutAct_9fa48("3821") ? "" : (stryCov_9fa48("3821"), "Expense"),
  aliases: stryMutAct_9fa48("3822") ? [] : (stryCov_9fa48("3822"), [stryMutAct_9fa48("3823") ? "" : (stryCov_9fa48("3823"), "seguro"), stryMutAct_9fa48("3824") ? "" : (stryCov_9fa48("3824"), "seguro de vida"), stryMutAct_9fa48("3825") ? "" : (stryCov_9fa48("3825"), "life insurance")]),
  co: stryMutAct_9fa48("3826") ? "" : (stryCov_9fa48("3826"), "513020"),
  us: stryMutAct_9fa48("3827") ? "" : (stryCov_9fa48("3827"), "5410")
}), stryMutAct_9fa48("3828") ? {} : (stryCov_9fa48("3828"), {
  concept: stryMutAct_9fa48("3829") ? "" : (stryCov_9fa48("3829"), "vehicleInsurance"),
  nature: stryMutAct_9fa48("3830") ? "" : (stryCov_9fa48("3830"), "Expense"),
  aliases: stryMutAct_9fa48("3831") ? [] : (stryCov_9fa48("3831"), [stryMutAct_9fa48("3832") ? "" : (stryCov_9fa48("3832"), "seguro"), stryMutAct_9fa48("3833") ? "" : (stryCov_9fa48("3833"), "seguro de vehiculo"), stryMutAct_9fa48("3834") ? "" : (stryCov_9fa48("3834"), "car insurance")]),
  co: stryMutAct_9fa48("3835") ? "" : (stryCov_9fa48("3835"), "513040"),
  us: stryMutAct_9fa48("3836") ? "" : (stryCov_9fa48("3836"), "5420")
}), stryMutAct_9fa48("3837") ? {} : (stryCov_9fa48("3837"), {
  concept: stryMutAct_9fa48("3838") ? "" : (stryCov_9fa48("3838"), "health"),
  nature: stryMutAct_9fa48("3839") ? "" : (stryCov_9fa48("3839"), "Expense"),
  aliases: stryMutAct_9fa48("3840") ? [] : (stryCov_9fa48("3840"), [stryMutAct_9fa48("3841") ? "" : (stryCov_9fa48("3841"), "salud"), stryMutAct_9fa48("3842") ? "" : (stryCov_9fa48("3842"), "health"), stryMutAct_9fa48("3843") ? "" : (stryCov_9fa48("3843"), "medicina")]),
  co: stryMutAct_9fa48("3844") ? "" : (stryCov_9fa48("3844"), "51959502"),
  us: stryMutAct_9fa48("3845") ? "" : (stryCov_9fa48("3845"), "5510")
}), stryMutAct_9fa48("3846") ? {} : (stryCov_9fa48("3846"), {
  concept: stryMutAct_9fa48("3847") ? "" : (stryCov_9fa48("3847"), "transport"),
  nature: stryMutAct_9fa48("3848") ? "" : (stryCov_9fa48("3848"), "Expense"),
  aliases: stryMutAct_9fa48("3849") ? [] : (stryCov_9fa48("3849"), [stryMutAct_9fa48("3850") ? "" : (stryCov_9fa48("3850"), "taxi"), stryMutAct_9fa48("3851") ? "" : (stryCov_9fa48("3851"), "bus"), stryMutAct_9fa48("3852") ? "" : (stryCov_9fa48("3852"), "transporte"), stryMutAct_9fa48("3853") ? "" : (stryCov_9fa48("3853"), "transit")]),
  co: stryMutAct_9fa48("3854") ? "" : (stryCov_9fa48("3854"), "519545"),
  us: stryMutAct_9fa48("3855") ? "" : (stryCov_9fa48("3855"), "5220")
}), stryMutAct_9fa48("3856") ? {} : (stryCov_9fa48("3856"), {
  concept: stryMutAct_9fa48("3857") ? "" : (stryCov_9fa48("3857"), "education"),
  nature: stryMutAct_9fa48("3858") ? "" : (stryCov_9fa48("3858"), "Expense"),
  aliases: stryMutAct_9fa48("3859") ? [] : (stryCov_9fa48("3859"), [stryMutAct_9fa48("3860") ? "" : (stryCov_9fa48("3860"), "educacion"), stryMutAct_9fa48("3861") ? "" : (stryCov_9fa48("3861"), "education")]),
  co: stryMutAct_9fa48("3862") ? "" : (stryCov_9fa48("3862"), "51959505"),
  us: stryMutAct_9fa48("3863") ? "" : (stryCov_9fa48("3863"), "5540")
}), stryMutAct_9fa48("3864") ? {} : (stryCov_9fa48("3864"), {
  concept: stryMutAct_9fa48("3865") ? "" : (stryCov_9fa48("3865"), "entertainment"),
  nature: stryMutAct_9fa48("3866") ? "" : (stryCov_9fa48("3866"), "Expense"),
  aliases: stryMutAct_9fa48("3867") ? [] : (stryCov_9fa48("3867"), [stryMutAct_9fa48("3868") ? "" : (stryCov_9fa48("3868"), "entretenimiento"), stryMutAct_9fa48("3869") ? "" : (stryCov_9fa48("3869"), "entertainment"), stryMutAct_9fa48("3870") ? "" : (stryCov_9fa48("3870"), "ocio")]),
  co: stryMutAct_9fa48("3871") ? "" : (stryCov_9fa48("3871"), "51959507"),
  us: stryMutAct_9fa48("3872") ? "" : (stryCov_9fa48("3872"), "5560")
})])) satisfies Array<{
  concept: string;
  nature: CategoryNature;
  aliases: string[];
  co: string;
  us: string;
}>;
export function normalizeCategoryName(name: string): string {
  if (stryMutAct_9fa48("3873")) {
    {}
  } else {
    stryCov_9fa48("3873");
    return stryMutAct_9fa48("3875") ? name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().trim().replace(/\s+/g, " ") : stryMutAct_9fa48("3874") ? name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\s+/g, " ") : (stryCov_9fa48("3874", "3875"), name.normalize(stryMutAct_9fa48("3876") ? "" : (stryCov_9fa48("3876"), "NFD")).replace(stryMutAct_9fa48("3877") ? /[^\u0300-\u036f]/g : (stryCov_9fa48("3877"), /[\u0300-\u036f]/g), stryMutAct_9fa48("3878") ? "Stryker was here!" : (stryCov_9fa48("3878"), "")).toLowerCase().trim().replace(stryMutAct_9fa48("3880") ? /\S+/g : stryMutAct_9fa48("3879") ? /\s/g : (stryCov_9fa48("3879", "3880"), /\s+/g), stryMutAct_9fa48("3881") ? "" : (stryCov_9fa48("3881"), " ")));
  }
}
function distance(a: string, b: string): number {
  if (stryMutAct_9fa48("3882")) {
    {}
  } else {
    stryCov_9fa48("3882");
    let previous = Array.from(stryMutAct_9fa48("3883") ? {} : (stryCov_9fa48("3883"), {
      length: stryMutAct_9fa48("3884") ? b.length - 1 : (stryCov_9fa48("3884"), b.length + 1)
    }), stryMutAct_9fa48("3885") ? () => undefined : (stryCov_9fa48("3885"), (_, i) => i));
    for (let i = 1; stryMutAct_9fa48("3888") ? i > a.length : stryMutAct_9fa48("3887") ? i < a.length : stryMutAct_9fa48("3886") ? false : (stryCov_9fa48("3886", "3887", "3888"), i <= a.length); stryMutAct_9fa48("3889") ? i-- : (stryCov_9fa48("3889"), i++)) {
      if (stryMutAct_9fa48("3890")) {
        {}
      } else {
        stryCov_9fa48("3890");
        const next = stryMutAct_9fa48("3891") ? [] : (stryCov_9fa48("3891"), [i]);
        for (let j = 1; stryMutAct_9fa48("3894") ? j > b.length : stryMutAct_9fa48("3893") ? j < b.length : stryMutAct_9fa48("3892") ? false : (stryCov_9fa48("3892", "3893", "3894"), j <= b.length); stryMutAct_9fa48("3895") ? j-- : (stryCov_9fa48("3895"), j++)) next[j] = stryMutAct_9fa48("3896") ? Math.max((next[j - 1] ?? 0) + 1, (previous[j] ?? 0) + 1, (previous[j - 1] ?? 0) + (a[i - 1] === b[j - 1] ? 0 : 1)) : (stryCov_9fa48("3896"), Math.min(stryMutAct_9fa48("3897") ? (next[j - 1] ?? 0) - 1 : (stryCov_9fa48("3897"), (stryMutAct_9fa48("3898") ? next[j - 1] && 0 : (stryCov_9fa48("3898"), next[stryMutAct_9fa48("3899") ? j + 1 : (stryCov_9fa48("3899"), j - 1)] ?? 0)) + 1), stryMutAct_9fa48("3900") ? (previous[j] ?? 0) - 1 : (stryCov_9fa48("3900"), (stryMutAct_9fa48("3901") ? previous[j] && 0 : (stryCov_9fa48("3901"), previous[j] ?? 0)) + 1), stryMutAct_9fa48("3902") ? (previous[j - 1] ?? 0) - (a[i - 1] === b[j - 1] ? 0 : 1) : (stryCov_9fa48("3902"), (stryMutAct_9fa48("3903") ? previous[j - 1] && 0 : (stryCov_9fa48("3903"), previous[stryMutAct_9fa48("3904") ? j + 1 : (stryCov_9fa48("3904"), j - 1)] ?? 0)) + ((stryMutAct_9fa48("3907") ? a[i - 1] !== b[j - 1] : stryMutAct_9fa48("3906") ? false : stryMutAct_9fa48("3905") ? true : (stryCov_9fa48("3905", "3906", "3907"), a[stryMutAct_9fa48("3908") ? i + 1 : (stryCov_9fa48("3908"), i - 1)] === b[stryMutAct_9fa48("3909") ? j + 1 : (stryCov_9fa48("3909"), j - 1)])) ? 0 : 1))));
        previous = next;
      }
    }
    return stryMutAct_9fa48("3910") ? previous[b.length] && a.length : (stryCov_9fa48("3910"), previous[b.length] ?? a.length);
  }
}
function matches(name: string, aliases: string[]): number {
  if (stryMutAct_9fa48("3911")) {
    {}
  } else {
    stryCov_9fa48("3911");
    const normalized = normalizeCategoryName(name);
    return stryMutAct_9fa48("3912") ? Math.max(...aliases.map(alias => {
      const d = distance(normalized, alias);
      return d === 0 || normalized.length >= 4 && alias.length >= 4 && d <= 1 ? d : Infinity;
    })) : (stryCov_9fa48("3912"), Math.min(...aliases.map(alias => {
      if (stryMutAct_9fa48("3913")) {
        {}
      } else {
        stryCov_9fa48("3913");
        const d = distance(normalized, alias);
        return (stryMutAct_9fa48("3916") ? d === 0 && normalized.length >= 4 && alias.length >= 4 && d <= 1 : stryMutAct_9fa48("3915") ? false : stryMutAct_9fa48("3914") ? true : (stryCov_9fa48("3914", "3915", "3916"), (stryMutAct_9fa48("3918") ? d !== 0 : stryMutAct_9fa48("3917") ? false : (stryCov_9fa48("3917", "3918"), d === 0)) || (stryMutAct_9fa48("3920") ? normalized.length >= 4 && alias.length >= 4 || d <= 1 : stryMutAct_9fa48("3919") ? false : (stryCov_9fa48("3919", "3920"), (stryMutAct_9fa48("3922") ? normalized.length >= 4 || alias.length >= 4 : stryMutAct_9fa48("3921") ? true : (stryCov_9fa48("3921", "3922"), (stryMutAct_9fa48("3925") ? normalized.length < 4 : stryMutAct_9fa48("3924") ? normalized.length > 4 : stryMutAct_9fa48("3923") ? true : (stryCov_9fa48("3923", "3924", "3925"), normalized.length >= 4)) && (stryMutAct_9fa48("3928") ? alias.length < 4 : stryMutAct_9fa48("3927") ? alias.length > 4 : stryMutAct_9fa48("3926") ? true : (stryCov_9fa48("3926", "3927", "3928"), alias.length >= 4)))) && (stryMutAct_9fa48("3931") ? d > 1 : stryMutAct_9fa48("3930") ? d < 1 : stryMutAct_9fa48("3929") ? true : (stryCov_9fa48("3929", "3930", "3931"), d <= 1)))))) ? d : Infinity;
      }
    })));
  }
}
export function suggestCategoryNature(name: string) {
  if (stryMutAct_9fa48("3932")) {
    {}
  } else {
    stryCov_9fa48("3932");
    const candidates: Array<{
      answer: NatureAnswer;
      distance: number;
    }> = categoryPresets.map(stryMutAct_9fa48("3933") ? () => undefined : (stryCov_9fa48("3933"), p => stryMutAct_9fa48("3934") ? {} : (stryCov_9fa48("3934"), {
      answer: p.nature,
      distance: matches(name, p.aliases)
    })));
    candidates.push(stryMutAct_9fa48("3936") ? {} : (stryCov_9fa48("3936"), {
      answer: stryMutAct_9fa48("3937") ? "" : (stryCov_9fa48("3937"), "stillMine"),
      distance: matches(name, stryMutAct_9fa48("3938") ? [] : (stryCov_9fa48("3938"), [stryMutAct_9fa48("3939") ? "" : (stryCov_9fa48("3939"), "ahorro"), stryMutAct_9fa48("3940") ? "" : (stryCov_9fa48("3940"), "savings"), stryMutAct_9fa48("3941") ? "" : (stryCov_9fa48("3941"), "inversion"), stryMutAct_9fa48("3942") ? "" : (stryCov_9fa48("3942"), "investment"), stryMutAct_9fa48("3943") ? "" : (stryCov_9fa48("3943"), "prestamo a una persona")]))
    }), stryMutAct_9fa48("3944") ? {} : (stryCov_9fa48("3944"), {
      answer: stryMutAct_9fa48("3945") ? "" : (stryCov_9fa48("3945"), "payingDebt"),
      distance: matches(name, stryMutAct_9fa48("3946") ? [] : (stryCov_9fa48("3946"), [stryMutAct_9fa48("3947") ? "" : (stryCov_9fa48("3947"), "pago tarjeta"), stryMutAct_9fa48("3948") ? "" : (stryCov_9fa48("3948"), "card payment"), stryMutAct_9fa48("3949") ? "" : (stryCov_9fa48("3949"), "deuda"), stryMutAct_9fa48("3950") ? "" : (stryCov_9fa48("3950"), "debt payment")]))
    }));
    const normalized = normalizeCategoryName(name);
    if (stryMutAct_9fa48("3952") ? false : stryMutAct_9fa48("3951") ? true : (stryCov_9fa48("3951", "3952"), (stryMutAct_9fa48("3953") ? /(prestamo a |loan to )/ : (stryCov_9fa48("3953"), /^(prestamo a |loan to )/)).test(normalized))) candidates.push(stryMutAct_9fa48("3955") ? {} : (stryCov_9fa48("3955"), {
      answer: stryMutAct_9fa48("3956") ? "" : (stryCov_9fa48("3956"), "stillMine"),
      distance: 0
    }));
    if (stryMutAct_9fa48("3958") ? false : stryMutAct_9fa48("3957") ? true : (stryCov_9fa48("3957", "3958"), (stryMutAct_9fa48("3959") ? /(deuda con |debt to )/ : (stryCov_9fa48("3959"), /^(deuda con |debt to )/)).test(normalized))) candidates.push(stryMutAct_9fa48("3961") ? {} : (stryCov_9fa48("3961"), {
      answer: stryMutAct_9fa48("3962") ? "" : (stryCov_9fa48("3962"), "payingDebt"),
      distance: 0
    }));
    const best = stryMutAct_9fa48("3963") ? Math.max(...candidates.map(c => c.distance)) : (stryCov_9fa48("3963"), Math.min(...candidates.map(stryMutAct_9fa48("3964") ? () => undefined : (stryCov_9fa48("3964"), c => c.distance))));
    return stryMutAct_9fa48("3965") ? {} : (stryCov_9fa48("3965"), {
      policy: categoryPolicy,
      suggestions: Number.isFinite(best) ? stryMutAct_9fa48("3966") ? [...new Set(candidates.filter(c => c.distance === best).map(c => c.answer))] : (stryCov_9fa48("3966"), (stryMutAct_9fa48("3967") ? [] : (stryCov_9fa48("3967"), [...new Set(stryMutAct_9fa48("3968") ? candidates.map(c => c.answer) : (stryCov_9fa48("3968"), candidates.filter(stryMutAct_9fa48("3969") ? () => undefined : (stryCov_9fa48("3969"), c => stryMutAct_9fa48("3972") ? c.distance !== best : stryMutAct_9fa48("3971") ? false : stryMutAct_9fa48("3970") ? true : (stryCov_9fa48("3970", "3971", "3972"), c.distance === best))).map(stryMutAct_9fa48("3973") ? () => undefined : (stryCov_9fa48("3973"), c => c.answer))))])).sort()) : stryMutAct_9fa48("3974") ? ["Stryker was here"] : (stryCov_9fa48("3974"), []),
      requiresConfirmation: true as const
    });
  }
}
export function assertCategoryAccount(templateVersion: string, nature: CategoryNature, code: string): void {
  if (stryMutAct_9fa48("3975")) {
    {}
  } else {
    stryCov_9fa48("3975");
    const account = chartTemplate(templateVersion).accounts.find(stryMutAct_9fa48("3976") ? () => undefined : (stryCov_9fa48("3976"), a => stryMutAct_9fa48("3979") ? a.code !== code : stryMutAct_9fa48("3978") ? false : stryMutAct_9fa48("3977") ? true : (stryCov_9fa48("3977", "3978", "3979"), a.code === code)));
    if (stryMutAct_9fa48("3982") ? false : stryMutAct_9fa48("3981") ? true : stryMutAct_9fa48("3980") ? account : (stryCov_9fa48("3980", "3981", "3982"), !account)) throw new AccountingError(stryMutAct_9fa48("3984") ? "" : (stryCov_9fa48("3984"), "ledger_account_code_unknown"));
    if (stryMutAct_9fa48("3987") ? account.use === (nature === "Expense" ? "expense" : "income") : stryMutAct_9fa48("3986") ? false : stryMutAct_9fa48("3985") ? true : (stryCov_9fa48("3985", "3986", "3987"), account.use !== ((stryMutAct_9fa48("3990") ? nature !== "Expense" : stryMutAct_9fa48("3989") ? false : stryMutAct_9fa48("3988") ? true : (stryCov_9fa48("3988", "3989", "3990"), nature === (stryMutAct_9fa48("3991") ? "" : (stryCov_9fa48("3991"), "Expense")))) ? stryMutAct_9fa48("3992") ? "" : (stryCov_9fa48("3992"), "expense") : stryMutAct_9fa48("3993") ? "" : (stryCov_9fa48("3993"), "income")))) throw new AccountingError((stryMutAct_9fa48("3997") ? nature !== "Expense" : stryMutAct_9fa48("3996") ? false : stryMutAct_9fa48("3995") ? true : (stryCov_9fa48("3995", "3996", "3997"), nature === (stryMutAct_9fa48("3998") ? "" : (stryCov_9fa48("3998"), "Expense")))) ? stryMutAct_9fa48("3999") ? "" : (stryCov_9fa48("3999"), "cash_expense_account_invalid") : stryMutAct_9fa48("4000") ? "" : (stryCov_9fa48("4000"), "cash_income_account_invalid"));
  }
}
function presetAccount(templateVersion: string, preset: typeof categoryPresets[number]): string {
  if (stryMutAct_9fa48("4001")) {
    {}
  } else {
    stryCov_9fa48("4001");
    const code = (stryMutAct_9fa48("4004") ? templateVersion !== "co-puc-personal@1" : stryMutAct_9fa48("4003") ? false : stryMutAct_9fa48("4002") ? true : (stryCov_9fa48("4002", "4003", "4004"), templateVersion === (stryMutAct_9fa48("4005") ? "" : (stryCov_9fa48("4005"), "co-puc-personal@1")))) ? preset.co : (stryMutAct_9fa48("4008") ? templateVersion !== "us-gaap-personal@1" : stryMutAct_9fa48("4007") ? false : stryMutAct_9fa48("4006") ? true : (stryCov_9fa48("4006", "4007", "4008"), templateVersion === (stryMutAct_9fa48("4009") ? "" : (stryCov_9fa48("4009"), "us-gaap-personal@1")))) ? preset.us : undefined;
    if (stryMutAct_9fa48("4012") ? false : stryMutAct_9fa48("4011") ? true : stryMutAct_9fa48("4010") ? code : (stryCov_9fa48("4010", "4011", "4012"), !code)) throw new AccountingError(stryMutAct_9fa48("4014") ? "" : (stryCov_9fa48("4014"), "chart_of_accounts_template_unknown"));
    if (stryMutAct_9fa48("4015")) {
      ;
    } else {
      stryCov_9fa48("4015");
      assertCategoryAccount(templateVersion, preset.nature, code);
    }
    return code;
  }
}
export function resolveCategoryAccount(templateVersion: string, name: string, nature: CategoryNature): AccountResolution {
  if (stryMutAct_9fa48("4016")) {
    {}
  } else {
    stryCov_9fa48("4016");
    const candidates = stryMutAct_9fa48("4017") ? categoryPresets.map(p => ({
      preset: p,
      distance: matches(name, p.aliases)
    })) : (stryCov_9fa48("4017"), categoryPresets.filter(stryMutAct_9fa48("4018") ? () => undefined : (stryCov_9fa48("4018"), p => stryMutAct_9fa48("4021") ? p.nature !== nature : stryMutAct_9fa48("4020") ? false : stryMutAct_9fa48("4019") ? true : (stryCov_9fa48("4019", "4020", "4021"), p.nature === nature))).map(stryMutAct_9fa48("4022") ? () => undefined : (stryCov_9fa48("4022"), p => stryMutAct_9fa48("4023") ? {} : (stryCov_9fa48("4023"), {
      preset: p,
      distance: matches(name, p.aliases)
    }))));
    const best = stryMutAct_9fa48("4024") ? Math.max(...candidates.map(c => c.distance)) : (stryCov_9fa48("4024"), Math.min(...candidates.map(stryMutAct_9fa48("4025") ? () => undefined : (stryCov_9fa48("4025"), c => c.distance))));
    const winners = stryMutAct_9fa48("4027") ? candidates.map(c => c.preset).sort((a, b) => a.concept.localeCompare(b.concept)) : stryMutAct_9fa48("4026") ? candidates.filter(c => Number.isFinite(best) && c.distance === best).map(c => c.preset) : (stryCov_9fa48("4026", "4027"), candidates.filter(stryMutAct_9fa48("4028") ? () => undefined : (stryCov_9fa48("4028"), c => stryMutAct_9fa48("4031") ? Number.isFinite(best) || c.distance === best : stryMutAct_9fa48("4030") ? false : stryMutAct_9fa48("4029") ? true : (stryCov_9fa48("4029", "4030", "4031"), Number.isFinite(best) && (stryMutAct_9fa48("4033") ? c.distance !== best : stryMutAct_9fa48("4032") ? true : (stryCov_9fa48("4032", "4033"), c.distance === best))))).map(stryMutAct_9fa48("4034") ? () => undefined : (stryCov_9fa48("4034"), c => c.preset)).sort(stryMutAct_9fa48("4035") ? () => undefined : (stryCov_9fa48("4035"), (a, b) => a.concept.localeCompare(b.concept))));
    const winner = (stryMutAct_9fa48("4038") ? winners.length !== 1 : stryMutAct_9fa48("4037") ? false : stryMutAct_9fa48("4036") ? true : (stryCov_9fa48("4036", "4037", "4038"), winners.length === 1)) ? winners[0] : undefined;
    if (stryMutAct_9fa48("4040") ? false : stryMutAct_9fa48("4039") ? true : (stryCov_9fa48("4039", "4040"), winner)) return stryMutAct_9fa48("4041") ? {} : (stryCov_9fa48("4041"), {
      kind: stryMutAct_9fa48("4042") ? "" : (stryCov_9fa48("4042"), "lexicon"),
      concept: winner.concept,
      policy: categoryPolicy,
      accountCode: presetAccount(templateVersion, winner)
    });
    const template = chartTemplate(templateVersion);
    return stryMutAct_9fa48("4043") ? {} : (stryCov_9fa48("4043"), {
      kind: stryMutAct_9fa48("4044") ? "" : (stryCov_9fa48("4044"), "fallback"),
      policy: categoryPolicy,
      accountCode: template.defaults[(stryMutAct_9fa48("4047") ? nature !== "Expense" : stryMutAct_9fa48("4046") ? false : stryMutAct_9fa48("4045") ? true : (stryCov_9fa48("4045", "4046", "4047"), nature === (stryMutAct_9fa48("4048") ? "" : (stryCov_9fa48("4048"), "Expense")))) ? stryMutAct_9fa48("4049") ? "" : (stryCov_9fa48("4049"), "expense") : stryMutAct_9fa48("4050") ? "" : (stryCov_9fa48("4050"), "income")],
      candidates: winners.map(stryMutAct_9fa48("4051") ? () => undefined : (stryCov_9fa48("4051"), p => p.concept))
    });
  }
}
export function resolvePreset(templateVersion: string, concept: string) {
  if (stryMutAct_9fa48("4052")) {
    {}
  } else {
    stryCov_9fa48("4052");
    const preset = categoryPresets.find(stryMutAct_9fa48("4053") ? () => undefined : (stryCov_9fa48("4053"), p => stryMutAct_9fa48("4056") ? p.concept !== concept : stryMutAct_9fa48("4055") ? false : stryMutAct_9fa48("4054") ? true : (stryCov_9fa48("4054", "4055", "4056"), p.concept === concept)));
    if (stryMutAct_9fa48("4059") ? false : stryMutAct_9fa48("4058") ? true : stryMutAct_9fa48("4057") ? preset : (stryCov_9fa48("4057", "4058", "4059"), !preset)) throw new AccountingError(stryMutAct_9fa48("4061") ? "" : (stryCov_9fa48("4061"), "category_preset_unknown"));
    return stryMutAct_9fa48("4062") ? {} : (stryCov_9fa48("4062"), {
      kind: "resolved" as const,
      nature: preset.nature,
      natureProvenance: stryMutAct_9fa48("4063") ? {} : (stryCov_9fa48("4063"), {
        kind: "preset" as const,
        concept
      }),
      account: stryMutAct_9fa48("4064") ? {} : (stryCov_9fa48("4064"), {
        kind: "preset" as const,
        concept,
        policy: categoryPolicy,
        accountCode: presetAccount(templateVersion, preset)
      })
    });
  }
}