// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { natureOfCode } from "./chartOfAccounts";
import { AccountingError } from "./errors";
import type { ChartOfAccountsTemplate, FinancialAccountProductKind, FinancialAccountParentKind, ProfileClassificationAnswers } from "./types";
export const profileClassificationPolicy = stryMutAct_9fa48("4178") ? "" : (stryCov_9fa48("4178"), "financial-account-profile@3");
export function classifyFinancialAccountProfile(template: ChartOfAccountsTemplate, productKind: string, answers?: ProfileClassificationAnswers) {
  if (stryMutAct_9fa48("4179")) {
    {}
  } else {
    stryCov_9fa48("4179");
    let parent: FinancialAccountParentKind;
    let normalized: ProfileClassificationAnswers | undefined;
    switch (productKind) {
      case stryMutAct_9fa48("4181") ? "" : (stryCov_9fa48("4181"), "receivable"):
        if (stryMutAct_9fa48("4180")) {} else {
          stryCov_9fa48("4180");
          if (stryMutAct_9fa48("4184") ? answers?.kind !== "receivable" && !answers.counterpartyName.trim() : stryMutAct_9fa48("4183") ? false : stryMutAct_9fa48("4182") ? true : (stryCov_9fa48("4182", "4183", "4184"), (stryMutAct_9fa48("4186") ? answers?.kind === "receivable" : stryMutAct_9fa48("4185") ? false : (stryCov_9fa48("4185", "4186"), (stryMutAct_9fa48("4187") ? answers.kind : (stryCov_9fa48("4187"), answers?.kind)) !== (stryMutAct_9fa48("4188") ? "" : (stryCov_9fa48("4188"), "receivable")))) || (stryMutAct_9fa48("4189") ? answers.counterpartyName.trim() : (stryCov_9fa48("4189"), !(stryMutAct_9fa48("4190") ? answers.counterpartyName : (stryCov_9fa48("4190"), answers.counterpartyName.trim())))))) throw new AccountingError(stryMutAct_9fa48("4192") ? "" : (stryCov_9fa48("4192"), "profile_classification_answers_required"));
          parent = (stryMutAct_9fa48("4195") ? answers.security !== "secured" : stryMutAct_9fa48("4194") ? false : stryMutAct_9fa48("4193") ? true : (stryCov_9fa48("4193", "4194", "4195"), answers.security === (stryMutAct_9fa48("4196") ? "" : (stryCov_9fa48("4196"), "secured")))) ? stryMutAct_9fa48("4197") ? "" : (stryCov_9fa48("4197"), "securedReceivable") : stryMutAct_9fa48("4198") ? "" : (stryCov_9fa48("4198"), "unsecuredReceivable");
          normalized = stryMutAct_9fa48("4199") ? {} : (stryCov_9fa48("4199"), {
            kind: stryMutAct_9fa48("4200") ? "" : (stryCov_9fa48("4200"), "receivable"),
            security: answers.security,
            counterpartyName: stryMutAct_9fa48("4201") ? answers.counterpartyName : (stryCov_9fa48("4201"), answers.counterpartyName.trim())
          });
          break;
        }
      case stryMutAct_9fa48("4203") ? "" : (stryCov_9fa48("4203"), "investment"):
        if (stryMutAct_9fa48("4202")) {} else {
          stryCov_9fa48("4202");
          if (stryMutAct_9fa48("4206") ? answers?.kind === "investment" : stryMutAct_9fa48("4205") ? false : stryMutAct_9fa48("4204") ? true : (stryCov_9fa48("4204", "4205", "4206"), (stryMutAct_9fa48("4207") ? answers.kind : (stryCov_9fa48("4207"), answers?.kind)) !== (stryMutAct_9fa48("4208") ? "" : (stryCov_9fa48("4208"), "investment")))) throw new AccountingError(stryMutAct_9fa48("4210") ? "" : (stryCov_9fa48("4210"), "profile_classification_answers_required"));
          parent = (stryMutAct_9fa48("4213") ? answers.form !== "termDeposit" : stryMutAct_9fa48("4212") ? false : stryMutAct_9fa48("4211") ? true : (stryCov_9fa48("4211", "4212", "4213"), answers.form === (stryMutAct_9fa48("4214") ? "" : (stryCov_9fa48("4214"), "termDeposit")))) ? stryMutAct_9fa48("4215") ? "" : (stryCov_9fa48("4215"), "termDeposit") : stryMutAct_9fa48("4216") ? "" : (stryCov_9fa48("4216"), "investmentFund");
          normalized = stryMutAct_9fa48("4217") ? {} : (stryCov_9fa48("4217"), {
            kind: stryMutAct_9fa48("4218") ? "" : (stryCov_9fa48("4218"), "investment"),
            form: answers.form,
            ...((stryMutAct_9fa48("4220") ? answers.counterpartyName.trim() : stryMutAct_9fa48("4219") ? answers.counterpartyName : (stryCov_9fa48("4219", "4220"), answers.counterpartyName?.trim())) ? stryMutAct_9fa48("4221") ? {} : (stryCov_9fa48("4221"), {
              counterpartyName: stryMutAct_9fa48("4222") ? answers.counterpartyName : (stryCov_9fa48("4222"), answers.counterpartyName.trim())
            }) : {})
          });
          break;
        }
      case stryMutAct_9fa48("4224") ? "" : (stryCov_9fa48("4224"), "personalDebt"):
        if (stryMutAct_9fa48("4223")) {} else {
          stryCov_9fa48("4223");
          if (stryMutAct_9fa48("4227") ? answers?.kind !== "personalDebt" && !answers.counterpartyName.trim() : stryMutAct_9fa48("4226") ? false : stryMutAct_9fa48("4225") ? true : (stryCov_9fa48("4225", "4226", "4227"), (stryMutAct_9fa48("4229") ? answers?.kind === "personalDebt" : stryMutAct_9fa48("4228") ? false : (stryCov_9fa48("4228", "4229"), (stryMutAct_9fa48("4230") ? answers.kind : (stryCov_9fa48("4230"), answers?.kind)) !== (stryMutAct_9fa48("4231") ? "" : (stryCov_9fa48("4231"), "personalDebt")))) || (stryMutAct_9fa48("4232") ? answers.counterpartyName.trim() : (stryCov_9fa48("4232"), !(stryMutAct_9fa48("4233") ? answers.counterpartyName : (stryCov_9fa48("4233"), answers.counterpartyName.trim())))))) throw new AccountingError(stryMutAct_9fa48("4235") ? "" : (stryCov_9fa48("4235"), "profile_classification_answers_required"));
          parent = stryMutAct_9fa48("4236") ? "" : (stryCov_9fa48("4236"), "personalDebt");
          normalized = stryMutAct_9fa48("4237") ? {} : (stryCov_9fa48("4237"), {
            kind: stryMutAct_9fa48("4238") ? "" : (stryCov_9fa48("4238"), "personalDebt"),
            counterpartyName: stryMutAct_9fa48("4239") ? answers.counterpartyName : (stryCov_9fa48("4239"), answers.counterpartyName.trim())
          });
          break;
        }
      case stryMutAct_9fa48("4240") ? "" : (stryCov_9fa48("4240"), "cash"):
      case stryMutAct_9fa48("4241") ? "" : (stryCov_9fa48("4241"), "bankAccount"):
      case stryMutAct_9fa48("4242") ? "" : (stryCov_9fa48("4242"), "savingsAccount"):
      case stryMutAct_9fa48("4243") ? "" : (stryCov_9fa48("4243"), "creditCard"):
      case stryMutAct_9fa48("4245") ? "" : (stryCov_9fa48("4245"), "loan"):
        if (stryMutAct_9fa48("4244")) {} else {
          stryCov_9fa48("4244");
          if (stryMutAct_9fa48("4247") ? false : stryMutAct_9fa48("4246") ? true : (stryCov_9fa48("4246", "4247"), answers)) throw new AccountingError(stryMutAct_9fa48("4249") ? "" : (stryCov_9fa48("4249"), "profile_classification_answers_required"));
          parent = productKind;
          break;
        }
      default:
        if (stryMutAct_9fa48("4250")) {} else {
          stryCov_9fa48("4250");
          {
            if (stryMutAct_9fa48("4251")) {
              {}
            } else {
              stryCov_9fa48("4251");
              throw new AccountingError(stryMutAct_9fa48("4253") ? "" : (stryCov_9fa48("4253"), "financial_account_product_kind_unknown"));
            }
          }
        }
    }
    const parentCode = template.financialAccountParents[parent];
    if (stryMutAct_9fa48("4256") ? productKind === "receivable" || productKind === "investment" || productKind === "personalDebt" || !template.accounts.some(account => account.code === parentCode && account.use === "general") : stryMutAct_9fa48("4255") ? false : stryMutAct_9fa48("4254") ? true : (stryCov_9fa48("4254", "4255", "4256"), (stryMutAct_9fa48("4258") ? (productKind === "receivable" || productKind === "investment") && productKind === "personalDebt" : stryMutAct_9fa48("4257") ? true : (stryCov_9fa48("4257", "4258"), (stryMutAct_9fa48("4260") ? productKind === "receivable" && productKind === "investment" : stryMutAct_9fa48("4259") ? false : (stryCov_9fa48("4259", "4260"), (stryMutAct_9fa48("4262") ? productKind !== "receivable" : stryMutAct_9fa48("4261") ? false : (stryCov_9fa48("4261", "4262"), productKind === (stryMutAct_9fa48("4263") ? "" : (stryCov_9fa48("4263"), "receivable")))) || (stryMutAct_9fa48("4265") ? productKind !== "investment" : stryMutAct_9fa48("4264") ? false : (stryCov_9fa48("4264", "4265"), productKind === (stryMutAct_9fa48("4266") ? "" : (stryCov_9fa48("4266"), "investment")))))) || (stryMutAct_9fa48("4268") ? productKind !== "personalDebt" : stryMutAct_9fa48("4267") ? false : (stryCov_9fa48("4267", "4268"), productKind === (stryMutAct_9fa48("4269") ? "" : (stryCov_9fa48("4269"), "personalDebt")))))) && (stryMutAct_9fa48("4270") ? template.accounts.some(account => account.code === parentCode && account.use === "general") : (stryCov_9fa48("4270"), !(stryMutAct_9fa48("4271") ? template.accounts.every(account => account.code === parentCode && account.use === "general") : (stryCov_9fa48("4271"), template.accounts.some(stryMutAct_9fa48("4272") ? () => undefined : (stryCov_9fa48("4272"), account => stryMutAct_9fa48("4275") ? account.code === parentCode || account.use === "general" : stryMutAct_9fa48("4274") ? false : stryMutAct_9fa48("4273") ? true : (stryCov_9fa48("4273", "4274", "4275"), (stryMutAct_9fa48("4277") ? account.code !== parentCode : stryMutAct_9fa48("4276") ? true : (stryCov_9fa48("4276", "4277"), account.code === parentCode)) && (stryMutAct_9fa48("4279") ? account.use !== "general" : stryMutAct_9fa48("4278") ? true : (stryCov_9fa48("4278", "4279"), account.use === (stryMutAct_9fa48("4280") ? "" : (stryCov_9fa48("4280"), "general"))))))))))))) throw new AccountingError(stryMutAct_9fa48("4282") ? "" : (stryCov_9fa48("4282"), "ledger_account_code_unknown"));
    return stryMutAct_9fa48("4283") ? {} : (stryCov_9fa48("4283"), {
      productKind,
      parentCode,
      nature: natureOfCode(template, parentCode),
      policy: profileClassificationPolicy,
      ...(normalized ? stryMutAct_9fa48("4284") ? {} : (stryCov_9fa48("4284"), {
        answers: normalized
      }) : {})
    });
  }
}