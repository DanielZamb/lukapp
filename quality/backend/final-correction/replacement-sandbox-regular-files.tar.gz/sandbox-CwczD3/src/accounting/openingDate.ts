// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "./errors";
import type { AccountingStore, JournalEntryDraft, StoredProfile } from "./types";
export async function assertOpeningDates(store: AccountingStore, workspaceId: string, draft: JournalEntryDraft): Promise<void> {
  if (stryMutAct_9fa48("4932")) {
    {}
  } else {
    stryCov_9fa48("4932");
    const accountIds = new Set(draft.lines.map(stryMutAct_9fa48("4933") ? () => undefined : (stryCov_9fa48("4933"), line => line.ledgerAccountId)));
    const profiles = await store.listProfiles(workspaceId);
    for (const profile of profiles) {
      if (stryMutAct_9fa48("4934")) {
        {}
      } else {
        stryCov_9fa48("4934");
        if (stryMutAct_9fa48("4937") ? (accountIds.has(profile.postingAccountId) || profile.id === draft.financialAccountProfileId) && profile.opening || draft.accountingDate < profile.opening.accountingDate : stryMutAct_9fa48("4936") ? false : stryMutAct_9fa48("4935") ? true : (stryCov_9fa48("4935", "4936", "4937"), (stryMutAct_9fa48("4939") ? accountIds.has(profile.postingAccountId) || profile.id === draft.financialAccountProfileId || profile.opening : stryMutAct_9fa48("4938") ? true : (stryCov_9fa48("4938", "4939"), (stryMutAct_9fa48("4941") ? accountIds.has(profile.postingAccountId) && profile.id === draft.financialAccountProfileId : stryMutAct_9fa48("4940") ? true : (stryCov_9fa48("4940", "4941"), accountIds.has(profile.postingAccountId) || (stryMutAct_9fa48("4943") ? profile.id !== draft.financialAccountProfileId : stryMutAct_9fa48("4942") ? false : (stryCov_9fa48("4942", "4943"), profile.id === draft.financialAccountProfileId)))) && profile.opening)) && (stryMutAct_9fa48("4946") ? draft.accountingDate >= profile.opening.accountingDate : stryMutAct_9fa48("4945") ? draft.accountingDate <= profile.opening.accountingDate : stryMutAct_9fa48("4944") ? true : (stryCov_9fa48("4944", "4945", "4946"), draft.accountingDate < profile.opening.accountingDate)))) {
          if (stryMutAct_9fa48("4947")) {
            {}
          } else {
            stryCov_9fa48("4947");
            throw new AccountingError(stryMutAct_9fa48("4949") ? "" : (stryCov_9fa48("4949"), "activity_before_opening"));
          }
        }
      }
    }
  }
}
export async function assertOpeningCutover(store: AccountingStore, profile: StoredProfile, accountingDate: string): Promise<void> {
  if (stryMutAct_9fa48("4950")) {
    {}
  } else {
    stryCov_9fa48("4950");
    const entries = await store.listJournalEntries(profile.workspaceId);
    const reversals = new Map(stryMutAct_9fa48("4951") ? entries.map(entry => [entry.reversesEntryId, entry]) : (stryCov_9fa48("4951"), entries.filter(stryMutAct_9fa48("4952") ? () => undefined : (stryCov_9fa48("4952"), entry => stryMutAct_9fa48("4955") ? entry.policy === "reversal@1" || entry.reversesEntryId : stryMutAct_9fa48("4954") ? false : stryMutAct_9fa48("4953") ? true : (stryCov_9fa48("4953", "4954", "4955"), (stryMutAct_9fa48("4957") ? entry.policy !== "reversal@1" : stryMutAct_9fa48("4956") ? true : (stryCov_9fa48("4956", "4957"), entry.policy === (stryMutAct_9fa48("4958") ? "" : (stryCov_9fa48("4958"), "reversal@1")))) && entry.reversesEntryId))).map(stryMutAct_9fa48("4959") ? () => undefined : (stryCov_9fa48("4959"), entry => stryMutAct_9fa48("4960") ? [] : (stryCov_9fa48("4960"), [entry.reversesEntryId, entry])))));
    const retiredEntryIds = new Set<string>();
    for (const entry of entries) {
      if (stryMutAct_9fa48("4961")) {
        {}
      } else {
        stryCov_9fa48("4961");
        if (stryMutAct_9fa48("4964") ? entry.policy === "opening-position@1" || entry.financialAccountProfileId === profile.id : stryMutAct_9fa48("4963") ? false : stryMutAct_9fa48("4962") ? true : (stryCov_9fa48("4962", "4963", "4964"), (stryMutAct_9fa48("4966") ? entry.policy !== "opening-position@1" : stryMutAct_9fa48("4965") ? true : (stryCov_9fa48("4965", "4966"), entry.policy === (stryMutAct_9fa48("4967") ? "" : (stryCov_9fa48("4967"), "opening-position@1")))) && (stryMutAct_9fa48("4969") ? entry.financialAccountProfileId !== profile.id : stryMutAct_9fa48("4968") ? true : (stryCov_9fa48("4968", "4969"), entry.financialAccountProfileId === profile.id)))) {
          if (stryMutAct_9fa48("4970")) {
            {}
          } else {
            stryCov_9fa48("4970");
            const reversal = reversals.get(entry.id);
            if (stryMutAct_9fa48("4972") ? false : stryMutAct_9fa48("4971") ? true : (stryCov_9fa48("4971", "4972"), reversal)) {
              if (stryMutAct_9fa48("4973")) {
                {}
              } else {
                stryCov_9fa48("4973");
                if (stryMutAct_9fa48("4974")) {
                  ;
                } else {
                  stryCov_9fa48("4974");
                  retiredEntryIds.add(entry.id);
                }
                if (stryMutAct_9fa48("4975")) {
                  ;
                } else {
                  stryCov_9fa48("4975");
                  retiredEntryIds.add(reversal.id);
                }
              }
            }
          }
        }
      }
    }
    if (stryMutAct_9fa48("4978") ? entries.every(entry => !retiredEntryIds.has(entry.id) && entry.accountingDate < accountingDate && (entry.financialAccountProfileId === profile.id || entry.lines.some(line => line.ledgerAccountId === profile.postingAccountId))) : stryMutAct_9fa48("4977") ? false : stryMutAct_9fa48("4976") ? true : (stryCov_9fa48("4976", "4977", "4978"), entries.some(stryMutAct_9fa48("4979") ? () => undefined : (stryCov_9fa48("4979"), entry => stryMutAct_9fa48("4982") ? !retiredEntryIds.has(entry.id) && entry.accountingDate < accountingDate || entry.financialAccountProfileId === profile.id || entry.lines.some(line => line.ledgerAccountId === profile.postingAccountId) : stryMutAct_9fa48("4981") ? false : stryMutAct_9fa48("4980") ? true : (stryCov_9fa48("4980", "4981", "4982"), (stryMutAct_9fa48("4984") ? !retiredEntryIds.has(entry.id) || entry.accountingDate < accountingDate : stryMutAct_9fa48("4983") ? true : (stryCov_9fa48("4983", "4984"), (stryMutAct_9fa48("4985") ? retiredEntryIds.has(entry.id) : (stryCov_9fa48("4985"), !retiredEntryIds.has(entry.id))) && (stryMutAct_9fa48("4988") ? entry.accountingDate >= accountingDate : stryMutAct_9fa48("4987") ? entry.accountingDate <= accountingDate : stryMutAct_9fa48("4986") ? true : (stryCov_9fa48("4986", "4987", "4988"), entry.accountingDate < accountingDate)))) && (stryMutAct_9fa48("4990") ? entry.financialAccountProfileId === profile.id && entry.lines.some(line => line.ledgerAccountId === profile.postingAccountId) : stryMutAct_9fa48("4989") ? true : (stryCov_9fa48("4989", "4990"), (stryMutAct_9fa48("4992") ? entry.financialAccountProfileId !== profile.id : stryMutAct_9fa48("4991") ? false : (stryCov_9fa48("4991", "4992"), entry.financialAccountProfileId === profile.id)) || (stryMutAct_9fa48("4993") ? entry.lines.every(line => line.ledgerAccountId === profile.postingAccountId) : (stryCov_9fa48("4993"), entry.lines.some(stryMutAct_9fa48("4994") ? () => undefined : (stryCov_9fa48("4994"), line => stryMutAct_9fa48("4997") ? line.ledgerAccountId !== profile.postingAccountId : stryMutAct_9fa48("4996") ? false : stryMutAct_9fa48("4995") ? true : (stryCov_9fa48("4995", "4996", "4997"), line.ledgerAccountId === profile.postingAccountId)))))))))))) {
      if (stryMutAct_9fa48("4998")) {
        {}
      } else {
        stryCov_9fa48("4998");
        throw new AccountingError(stryMutAct_9fa48("5000") ? "" : (stryCov_9fa48("5000"), "activity_before_opening"));
      }
    }
  }
}