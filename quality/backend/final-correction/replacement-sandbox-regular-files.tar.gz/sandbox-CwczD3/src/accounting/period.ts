// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "./errors";
export function dateFromTimestamp(now: number): Date {
  if (stryMutAct_9fa48("5001")) {
    {}
  } else {
    stryCov_9fa48("5001");
    if (stryMutAct_9fa48("5004") ? false : stryMutAct_9fa48("5003") ? true : stryMutAct_9fa48("5002") ? Number.isFinite(now) : (stryCov_9fa48("5002", "5003", "5004"), !Number.isFinite(now))) {
      if (stryMutAct_9fa48("5005")) {
        {}
      } else {
        stryCov_9fa48("5005");
        throw new AccountingError(stryMutAct_9fa48("5007") ? "" : (stryCov_9fa48("5007"), "clock_required"));
      }
    }
    const date = new Date(now);
    if (stryMutAct_9fa48("5009") ? false : stryMutAct_9fa48("5008") ? true : (stryCov_9fa48("5008", "5009"), Number.isNaN(date.getTime()))) {
      if (stryMutAct_9fa48("5010")) {
        {}
      } else {
        stryCov_9fa48("5010");
        throw new AccountingError(stryMutAct_9fa48("5012") ? "" : (stryCov_9fa48("5012"), "clock_required"));
      }
    }
    return date;
  }
}
export function clockMonth(now: Date): {
  year: number;
  month: number;
} {
  if (stryMutAct_9fa48("5013")) {
    {}
  } else {
    stryCov_9fa48("5013");
    if (stryMutAct_9fa48("5015") ? false : stryMutAct_9fa48("5014") ? true : (stryCov_9fa48("5014", "5015"), Number.isNaN(now.getTime()))) {
      if (stryMutAct_9fa48("5016")) {
        {}
      } else {
        stryCov_9fa48("5016");
        throw new AccountingError(stryMutAct_9fa48("5018") ? "" : (stryCov_9fa48("5018"), "clock_required"));
      }
    }
    return stryMutAct_9fa48("5019") ? {} : (stryCov_9fa48("5019"), {
      year: now.getUTCFullYear(),
      month: stryMutAct_9fa48("5020") ? now.getUTCMonth() - 1 : (stryCov_9fa48("5020"), now.getUTCMonth() + 1)
    });
  }
}
export function periodFromAccountingDate(accountingDate: string): {
  year: number;
  month: number;
} {
  if (stryMutAct_9fa48("5021")) {
    {}
  } else {
    stryCov_9fa48("5021");
    const match = (stryMutAct_9fa48("5029") ? /^(\d{4})-(\d{2})-(\D{2})$/ : stryMutAct_9fa48("5028") ? /^(\d{4})-(\d{2})-(\d)$/ : stryMutAct_9fa48("5027") ? /^(\d{4})-(\D{2})-(\d{2})$/ : stryMutAct_9fa48("5026") ? /^(\d{4})-(\d)-(\d{2})$/ : stryMutAct_9fa48("5025") ? /^(\D{4})-(\d{2})-(\d{2})$/ : stryMutAct_9fa48("5024") ? /^(\d)-(\d{2})-(\d{2})$/ : stryMutAct_9fa48("5023") ? /^(\d{4})-(\d{2})-(\d{2})/ : stryMutAct_9fa48("5022") ? /(\d{4})-(\d{2})-(\d{2})$/ : (stryCov_9fa48("5022", "5023", "5024", "5025", "5026", "5027", "5028", "5029"), /^(\d{4})-(\d{2})-(\d{2})$/)).exec(accountingDate);
    if (stryMutAct_9fa48("5032") ? false : stryMutAct_9fa48("5031") ? true : stryMutAct_9fa48("5030") ? match : (stryCov_9fa48("5030", "5031", "5032"), !match)) {
      if (stryMutAct_9fa48("5033")) {
        {}
      } else {
        stryCov_9fa48("5033");
        throw new AccountingError(stryMutAct_9fa48("5035") ? "" : (stryCov_9fa48("5035"), "accounting_date_required"));
      }
    }
    const year = Number(match[1]);
    const month = Number(match[2]);
    const day = Number(match[3]);
    const utc = new Date(Date.UTC(year, stryMutAct_9fa48("5036") ? month + 1 : (stryCov_9fa48("5036"), month - 1), day));
    if (stryMutAct_9fa48("5039") ? (utc.getUTCFullYear() !== year || utc.getUTCMonth() + 1 !== month) && utc.getUTCDate() !== day : stryMutAct_9fa48("5038") ? false : stryMutAct_9fa48("5037") ? true : (stryCov_9fa48("5037", "5038", "5039"), (stryMutAct_9fa48("5041") ? utc.getUTCFullYear() !== year && utc.getUTCMonth() + 1 !== month : stryMutAct_9fa48("5040") ? false : (stryCov_9fa48("5040", "5041"), (stryMutAct_9fa48("5043") ? utc.getUTCFullYear() === year : stryMutAct_9fa48("5042") ? false : (stryCov_9fa48("5042", "5043"), utc.getUTCFullYear() !== year)) || (stryMutAct_9fa48("5045") ? utc.getUTCMonth() + 1 === month : stryMutAct_9fa48("5044") ? false : (stryCov_9fa48("5044", "5045"), (stryMutAct_9fa48("5046") ? utc.getUTCMonth() - 1 : (stryCov_9fa48("5046"), utc.getUTCMonth() + 1)) !== month)))) || (stryMutAct_9fa48("5048") ? utc.getUTCDate() === day : stryMutAct_9fa48("5047") ? false : (stryCov_9fa48("5047", "5048"), utc.getUTCDate() !== day)))) {
      if (stryMutAct_9fa48("5049")) {
        {}
      } else {
        stryCov_9fa48("5049");
        throw new AccountingError(stryMutAct_9fa48("5051") ? "" : (stryCov_9fa48("5051"), "accounting_date_required"));
      }
    }
    return stryMutAct_9fa48("5052") ? {} : (stryCov_9fa48("5052"), {
      year,
      month
    });
  }
}
export function requirePeriodKey(period: {
  year: number;
  month: number;
}): {
  year: number;
  month: number;
} {
  if (stryMutAct_9fa48("5053")) {
    {}
  } else {
    stryCov_9fa48("5053");
    if (stryMutAct_9fa48("5056") ? (!Number.isInteger(period.year) || period.year < 1 || period.year > 9999 || !Number.isInteger(period.month) || period.month < 1) && period.month > 12 : stryMutAct_9fa48("5055") ? false : stryMutAct_9fa48("5054") ? true : (stryCov_9fa48("5054", "5055", "5056"), (stryMutAct_9fa48("5058") ? (!Number.isInteger(period.year) || period.year < 1 || period.year > 9999 || !Number.isInteger(period.month)) && period.month < 1 : stryMutAct_9fa48("5057") ? false : (stryCov_9fa48("5057", "5058"), (stryMutAct_9fa48("5060") ? (!Number.isInteger(period.year) || period.year < 1 || period.year > 9999) && !Number.isInteger(period.month) : stryMutAct_9fa48("5059") ? false : (stryCov_9fa48("5059", "5060"), (stryMutAct_9fa48("5062") ? (!Number.isInteger(period.year) || period.year < 1) && period.year > 9999 : stryMutAct_9fa48("5061") ? false : (stryCov_9fa48("5061", "5062"), (stryMutAct_9fa48("5064") ? !Number.isInteger(period.year) && period.year < 1 : stryMutAct_9fa48("5063") ? false : (stryCov_9fa48("5063", "5064"), (stryMutAct_9fa48("5065") ? Number.isInteger(period.year) : (stryCov_9fa48("5065"), !Number.isInteger(period.year))) || (stryMutAct_9fa48("5068") ? period.year >= 1 : stryMutAct_9fa48("5067") ? period.year <= 1 : stryMutAct_9fa48("5066") ? false : (stryCov_9fa48("5066", "5067", "5068"), period.year < 1)))) || (stryMutAct_9fa48("5071") ? period.year <= 9999 : stryMutAct_9fa48("5070") ? period.year >= 9999 : stryMutAct_9fa48("5069") ? false : (stryCov_9fa48("5069", "5070", "5071"), period.year > 9999)))) || (stryMutAct_9fa48("5072") ? Number.isInteger(period.month) : (stryCov_9fa48("5072"), !Number.isInteger(period.month))))) || (stryMutAct_9fa48("5075") ? period.month >= 1 : stryMutAct_9fa48("5074") ? period.month <= 1 : stryMutAct_9fa48("5073") ? false : (stryCov_9fa48("5073", "5074", "5075"), period.month < 1)))) || (stryMutAct_9fa48("5078") ? period.month <= 12 : stryMutAct_9fa48("5077") ? period.month >= 12 : stryMutAct_9fa48("5076") ? false : (stryCov_9fa48("5076", "5077", "5078"), period.month > 12)))) {
      if (stryMutAct_9fa48("5079")) {
        {}
      } else {
        stryCov_9fa48("5079");
        throw new AccountingError(stryMutAct_9fa48("5081") ? "" : (stryCov_9fa48("5081"), "accounting_period_invalid"));
      }
    }
    return stryMutAct_9fa48("5082") ? {} : (stryCov_9fa48("5082"), {
      year: period.year,
      month: period.month
    });
  }
}
export function nextPeriod(period: {
  year: number;
  month: number;
}): {
  year: number;
  month: number;
} {
  if (stryMutAct_9fa48("5083")) {
    {}
  } else {
    stryCov_9fa48("5083");
    return (stryMutAct_9fa48("5086") ? period.month !== 12 : stryMutAct_9fa48("5085") ? false : stryMutAct_9fa48("5084") ? true : (stryCov_9fa48("5084", "5085", "5086"), period.month === 12)) ? stryMutAct_9fa48("5087") ? {} : (stryCov_9fa48("5087"), {
      year: stryMutAct_9fa48("5088") ? period.year - 1 : (stryCov_9fa48("5088"), period.year + 1),
      month: 1
    }) : stryMutAct_9fa48("5089") ? {} : (stryCov_9fa48("5089"), {
      year: period.year,
      month: stryMutAct_9fa48("5090") ? period.month - 1 : (stryCov_9fa48("5090"), period.month + 1)
    });
  }
}
export function firstDayOf(period: {
  year: number;
  month: number;
}): string {
  if (stryMutAct_9fa48("5091")) {
    {}
  } else {
    stryCov_9fa48("5091");
    return stryMutAct_9fa48("5092") ? `` : (stryCov_9fa48("5092"), `${String(period.year).padStart(4, stryMutAct_9fa48("5093") ? "" : (stryCov_9fa48("5093"), "0"))}-${String(period.month).padStart(2, stryMutAct_9fa48("5094") ? "" : (stryCov_9fa48("5094"), "0"))}-01`);
  }
}