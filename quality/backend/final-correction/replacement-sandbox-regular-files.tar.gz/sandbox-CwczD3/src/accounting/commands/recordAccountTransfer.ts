// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "../errors";
import { requireWorkspace } from "../membership";
import { requireFunctionalAmount } from "../money";
import { requireProfile } from "../financialAccountProfiles";
import { postJournalEntry } from "../posting";
import type { AccountingClock, AccountingStore, AccountTransferInput, PostedJournalEntry } from "../types";
import { journalContext, toPostedJournalEntry } from "../views";
export async function recordAccountTransfer(store: AccountingStore, clock: AccountingClock, input: AccountTransferInput): Promise<PostedJournalEntry> {
  if (stryMutAct_9fa48("4394")) {
    {}
  } else {
    stryCov_9fa48("4394");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("4395") ? "" : (stryCov_9fa48("4395"), "post"));
    const amount = requireFunctionalAmount(workspace, input.amount);
    if (stryMutAct_9fa48("4398") ? input.sourceFinancialAccountProfileId !== input.destinationFinancialAccountProfileId : stryMutAct_9fa48("4397") ? false : stryMutAct_9fa48("4396") ? true : (stryCov_9fa48("4396", "4397", "4398"), input.sourceFinancialAccountProfileId === input.destinationFinancialAccountProfileId)) throw new AccountingError(stryMutAct_9fa48("4400") ? "" : (stryCov_9fa48("4400"), "account_transfer_same_profile"));
    const source = await requireProfile(store, input.workspaceId, input.sourceFinancialAccountProfileId);
    const destination = await requireProfile(store, input.workspaceId, input.destinationFinancialAccountProfileId);
    const {
      entry,
      replay
    } = await postJournalEntry(store, clock, stryMutAct_9fa48("4401") ? {} : (stryCov_9fa48("4401"), {
      actor: input.actor,
      workspaceId: input.workspaceId,
      draft: stryMutAct_9fa48("4402") ? {} : (stryCov_9fa48("4402"), {
        policy: stryMutAct_9fa48("4403") ? "" : (stryCov_9fa48("4403"), "account-transfer@1"),
        financialAccountProfileId: source.id,
        accountingDate: input.accountingDate,
        description: input.description,
        idempotencyKey: input.idempotencyKey,
        lines: stryMutAct_9fa48("4404") ? [] : (stryCov_9fa48("4404"), [stryMutAct_9fa48("4405") ? {} : (stryCov_9fa48("4405"), {
          ledgerAccountId: destination.postingAccountId,
          debitMinorUnits: amount,
          creditMinorUnits: 0
        }), stryMutAct_9fa48("4406") ? {} : (stryCov_9fa48("4406"), {
          ledgerAccountId: source.postingAccountId,
          debitMinorUnits: 0,
          creditMinorUnits: amount
        })])
      })
    }));
    const reversal = await store.findReversalOf(entry.id);
    return toPostedJournalEntry(store, await journalContext(store, workspace), entry, stryMutAct_9fa48("4407") ? {} : (stryCov_9fa48("4407"), {
      replay,
      ...(reversal ? stryMutAct_9fa48("4408") ? {} : (stryCov_9fa48("4408"), {
        reversedByEntryId: reversal.id
      }) : {})
    }));
  }
}