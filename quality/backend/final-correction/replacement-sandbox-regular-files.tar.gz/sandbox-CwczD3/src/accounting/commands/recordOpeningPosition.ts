// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { requireTemplateAccount } from "../chartOfAccounts";
import { AccountingError } from "../errors";
import { requireWorkspace } from "../membership";
import { requireProfile } from "../financialAccountProfiles";
import { periodFromAccountingDate } from "../period";
import { assertOpeningCutover } from "../openingDate";
import { requirePostablePeriod } from "../periodControl";
import { postJournalEntry } from "../posting";
import type { AccountingClock, AccountingStore, OpeningPositionInput, OpeningPositionResult, StoredOpening, StoredWorkspace } from "../types";
import { journalContext, toPostedJournalEntry, toProfile } from "../views";
export async function recordOpeningPosition(store: AccountingStore, clock: AccountingClock, input: OpeningPositionInput): Promise<OpeningPositionResult> {
  if (stryMutAct_9fa48("4419")) {
    {}
  } else {
    stryCov_9fa48("4419");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("4420") ? "" : (stryCov_9fa48("4420"), "post"));
    if (stryMutAct_9fa48("4423") ? !Number.isSafeInteger(input.amount.minorUnits) && input.amount.minorUnits < 0 : stryMutAct_9fa48("4422") ? false : stryMutAct_9fa48("4421") ? true : (stryCov_9fa48("4421", "4422", "4423"), (stryMutAct_9fa48("4424") ? Number.isSafeInteger(input.amount.minorUnits) : (stryCov_9fa48("4424"), !Number.isSafeInteger(input.amount.minorUnits))) || (stryMutAct_9fa48("4427") ? input.amount.minorUnits >= 0 : stryMutAct_9fa48("4426") ? input.amount.minorUnits <= 0 : stryMutAct_9fa48("4425") ? false : (stryCov_9fa48("4425", "4426", "4427"), input.amount.minorUnits < 0)))) throw new AccountingError(stryMutAct_9fa48("4429") ? "" : (stryCov_9fa48("4429"), "opening_amount_invalid"));
    if (stryMutAct_9fa48("4432") ? input.amount.currency === workspace.functionalCurrency : stryMutAct_9fa48("4431") ? false : stryMutAct_9fa48("4430") ? true : (stryCov_9fa48("4430", "4431", "4432"), input.amount.currency !== workspace.functionalCurrency)) throw new AccountingError(stryMutAct_9fa48("4434") ? "" : (stryCov_9fa48("4434"), "currency_mismatch"));
    if (stryMutAct_9fa48("4435")) {
      ;
    } else {
      stryCov_9fa48("4435");
      periodFromAccountingDate(input.accountingDate);
    }
    if (stryMutAct_9fa48("4438") ? false : stryMutAct_9fa48("4437") ? true : stryMutAct_9fa48("4436") ? input.idempotencyKey : (stryCov_9fa48("4436", "4437", "4438"), !input.idempotencyKey)) throw new AccountingError(stryMutAct_9fa48("4440") ? "" : (stryCov_9fa48("4440"), "idempotency_key_required"));
    const profile = await requireProfile(store, input.workspaceId, input.financialAccountProfileId);
    const previous = await store.findOpeningPositionByKey(input.workspaceId, input.idempotencyKey);
    if (stryMutAct_9fa48("4442") ? false : stryMutAct_9fa48("4441") ? true : (stryCov_9fa48("4441", "4442"), previous)) {
      if (stryMutAct_9fa48("4443")) {
        {}
      } else {
        stryCov_9fa48("4443");
        if (stryMutAct_9fa48("4446") ? (previous.financialAccountProfileId !== profile.id || previous.description !== input.description || previous.replacesOpeningKey !== input.replacesOpeningKey || previous.opening.accountingDate !== input.accountingDate || previous.opening.amount.minorUnits !== input.amount.minorUnits) && previous.opening.amount.currency !== input.amount.currency : stryMutAct_9fa48("4445") ? false : stryMutAct_9fa48("4444") ? true : (stryCov_9fa48("4444", "4445", "4446"), (stryMutAct_9fa48("4448") ? (previous.financialAccountProfileId !== profile.id || previous.description !== input.description || previous.replacesOpeningKey !== input.replacesOpeningKey || previous.opening.accountingDate !== input.accountingDate) && previous.opening.amount.minorUnits !== input.amount.minorUnits : stryMutAct_9fa48("4447") ? false : (stryCov_9fa48("4447", "4448"), (stryMutAct_9fa48("4450") ? (previous.financialAccountProfileId !== profile.id || previous.description !== input.description || previous.replacesOpeningKey !== input.replacesOpeningKey) && previous.opening.accountingDate !== input.accountingDate : stryMutAct_9fa48("4449") ? false : (stryCov_9fa48("4449", "4450"), (stryMutAct_9fa48("4452") ? (previous.financialAccountProfileId !== profile.id || previous.description !== input.description) && previous.replacesOpeningKey !== input.replacesOpeningKey : stryMutAct_9fa48("4451") ? false : (stryCov_9fa48("4451", "4452"), (stryMutAct_9fa48("4454") ? previous.financialAccountProfileId !== profile.id && previous.description !== input.description : stryMutAct_9fa48("4453") ? false : (stryCov_9fa48("4453", "4454"), (stryMutAct_9fa48("4456") ? previous.financialAccountProfileId === profile.id : stryMutAct_9fa48("4455") ? false : (stryCov_9fa48("4455", "4456"), previous.financialAccountProfileId !== profile.id)) || (stryMutAct_9fa48("4458") ? previous.description === input.description : stryMutAct_9fa48("4457") ? false : (stryCov_9fa48("4457", "4458"), previous.description !== input.description)))) || (stryMutAct_9fa48("4460") ? previous.replacesOpeningKey === input.replacesOpeningKey : stryMutAct_9fa48("4459") ? false : (stryCov_9fa48("4459", "4460"), previous.replacesOpeningKey !== input.replacesOpeningKey)))) || (stryMutAct_9fa48("4462") ? previous.opening.accountingDate === input.accountingDate : stryMutAct_9fa48("4461") ? false : (stryCov_9fa48("4461", "4462"), previous.opening.accountingDate !== input.accountingDate)))) || (stryMutAct_9fa48("4464") ? previous.opening.amount.minorUnits === input.amount.minorUnits : stryMutAct_9fa48("4463") ? false : (stryCov_9fa48("4463", "4464"), previous.opening.amount.minorUnits !== input.amount.minorUnits)))) || (stryMutAct_9fa48("4466") ? previous.opening.amount.currency === input.amount.currency : stryMutAct_9fa48("4465") ? false : (stryCov_9fa48("4465", "4466"), previous.opening.amount.currency !== input.amount.currency)))) {
          if (stryMutAct_9fa48("4467")) {
            {}
          } else {
            stryCov_9fa48("4467");
            throw new AccountingError(stryMutAct_9fa48("4469") ? "" : (stryCov_9fa48("4469"), "idempotency_key_conflict"));
          }
        }
        return openingResult(store, workspace, profile.id, previous.opening, stryMutAct_9fa48("4470") ? false : (stryCov_9fa48("4470"), true));
      }
    }
    if (stryMutAct_9fa48("4472") ? false : stryMutAct_9fa48("4471") ? true : (stryCov_9fa48("4471", "4472"), await store.findJournalEntryByIdempotencyKey(input.workspaceId, input.idempotencyKey))) throw new AccountingError(stryMutAct_9fa48("4474") ? "" : (stryCov_9fa48("4474"), "idempotency_key_conflict"));
    if (stryMutAct_9fa48("4476") ? false : stryMutAct_9fa48("4475") ? true : (stryCov_9fa48("4475", "4476"), profile.opening)) {
      if (stryMutAct_9fa48("4477")) {
        {}
      } else {
        stryCov_9fa48("4477");
        await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("4478") ? "" : (stryCov_9fa48("4478"), "correct"));
        if (stryMutAct_9fa48("4481") ? input.replacesOpeningKey !== undefined || input.replacesOpeningKey !== profile.opening.idempotencyKey : stryMutAct_9fa48("4480") ? false : stryMutAct_9fa48("4479") ? true : (stryCov_9fa48("4479", "4480", "4481"), (stryMutAct_9fa48("4483") ? input.replacesOpeningKey === undefined : stryMutAct_9fa48("4482") ? true : (stryCov_9fa48("4482", "4483"), input.replacesOpeningKey !== undefined)) && (stryMutAct_9fa48("4485") ? input.replacesOpeningKey === profile.opening.idempotencyKey : stryMutAct_9fa48("4484") ? true : (stryCov_9fa48("4484", "4485"), input.replacesOpeningKey !== profile.opening.idempotencyKey)))) throw new AccountingError(stryMutAct_9fa48("4487") ? "" : (stryCov_9fa48("4487"), "opening_replacement_conflict"));
        if (stryMutAct_9fa48("4489") ? false : stryMutAct_9fa48("4488") ? true : (stryCov_9fa48("4488", "4489"), (stryMutAct_9fa48("4492") ? profile.opening.kind !== "zero" : stryMutAct_9fa48("4491") ? false : stryMutAct_9fa48("4490") ? true : (stryCov_9fa48("4490", "4491", "4492"), profile.opening.kind === (stryMutAct_9fa48("4493") ? "" : (stryCov_9fa48("4493"), "zero")))) ? stryMutAct_9fa48("4496") ? input.replacesOpeningKey === profile.opening.idempotencyKey : stryMutAct_9fa48("4495") ? false : stryMutAct_9fa48("4494") ? true : (stryCov_9fa48("4494", "4495", "4496"), input.replacesOpeningKey !== profile.opening.idempotencyKey) : stryMutAct_9fa48("4497") ? await store.findReversalOf(profile.opening.journalEntryId) : (stryCov_9fa48("4497"), !(await store.findReversalOf(profile.opening.journalEntryId))))) {
          if (stryMutAct_9fa48("4498")) {
            {}
          } else {
            stryCov_9fa48("4498");
            throw new AccountingError(stryMutAct_9fa48("4500") ? "" : (stryCov_9fa48("4500"), "opening_already_recorded"));
          }
        }
      }
    } else {
      if (stryMutAct_9fa48("4501")) {
        {}
      } else {
        stryCov_9fa48("4501");
        if (stryMutAct_9fa48("4504") ? input.replacesOpeningKey === undefined : stryMutAct_9fa48("4503") ? false : stryMutAct_9fa48("4502") ? true : (stryCov_9fa48("4502", "4503", "4504"), input.replacesOpeningKey !== undefined)) throw new AccountingError(stryMutAct_9fa48("4506") ? "" : (stryCov_9fa48("4506"), "opening_replacement_conflict"));
      }
    }
    await assertOpeningCutover(store, profile, input.accountingDate);
    if (stryMutAct_9fa48("4508") ? false : stryMutAct_9fa48("4507") ? true : (stryCov_9fa48("4507", "4508"), profile.opening)) await store.clearProfileOpening(profile.id);
    let opening: StoredOpening;
    const common = stryMutAct_9fa48("4509") ? {} : (stryCov_9fa48("4509"), {
      accountingDate: input.accountingDate,
      idempotencyKey: input.idempotencyKey,
      amount: input.amount
    });
    if (stryMutAct_9fa48("4512") ? input.amount.minorUnits !== 0 : stryMutAct_9fa48("4511") ? false : stryMutAct_9fa48("4510") ? true : (stryCov_9fa48("4510", "4511", "4512"), input.amount.minorUnits === 0)) {
      if (stryMutAct_9fa48("4513")) {
        {}
      } else {
        stryCov_9fa48("4513");
        await requirePostablePeriod(store, input.workspaceId, input.accountingDate);
        opening = stryMutAct_9fa48("4514") ? {} : (stryCov_9fa48("4514"), {
          ...common,
          kind: stryMutAct_9fa48("4515") ? "" : (stryCov_9fa48("4515"), "zero")
        });
      }
    } else {
      if (stryMutAct_9fa48("4516")) {
        {}
      } else {
        stryCov_9fa48("4516");
        const account = await store.getLedgerAccount(profile.postingAccountId);
        if (stryMutAct_9fa48("4519") ? !account && account.workspaceId !== input.workspaceId : stryMutAct_9fa48("4518") ? false : stryMutAct_9fa48("4517") ? true : (stryCov_9fa48("4517", "4518", "4519"), (stryMutAct_9fa48("4520") ? account : (stryCov_9fa48("4520"), !account)) || (stryMutAct_9fa48("4522") ? account.workspaceId === input.workspaceId : stryMutAct_9fa48("4521") ? false : (stryCov_9fa48("4521", "4522"), account.workspaceId !== input.workspaceId)))) throw new AccountingError(stryMutAct_9fa48("4524") ? "" : (stryCov_9fa48("4524"), "ledger_account_not_found"));
        const equity = await requireTemplateAccount(store, workspace, stryMutAct_9fa48("4525") ? "" : (stryCov_9fa48("4525"), "openingBalance"));
        const debitId = (stryMutAct_9fa48("4528") ? account.normalSide !== "Debit" : stryMutAct_9fa48("4527") ? false : stryMutAct_9fa48("4526") ? true : (stryCov_9fa48("4526", "4527", "4528"), account.normalSide === (stryMutAct_9fa48("4529") ? "" : (stryCov_9fa48("4529"), "Debit")))) ? account.id : equity.id;
        const creditId = (stryMutAct_9fa48("4532") ? account.normalSide !== "Debit" : stryMutAct_9fa48("4531") ? false : stryMutAct_9fa48("4530") ? true : (stryCov_9fa48("4530", "4531", "4532"), account.normalSide === (stryMutAct_9fa48("4533") ? "" : (stryCov_9fa48("4533"), "Debit")))) ? equity.id : account.id;
        const {
          entry
        } = await postJournalEntry(store, clock, stryMutAct_9fa48("4534") ? {} : (stryCov_9fa48("4534"), {
          actor: input.actor,
          workspaceId: input.workspaceId,
          draft: stryMutAct_9fa48("4535") ? {} : (stryCov_9fa48("4535"), {
            policy: stryMutAct_9fa48("4536") ? "" : (stryCov_9fa48("4536"), "opening-position@1"),
            financialAccountProfileId: profile.id,
            accountingDate: input.accountingDate,
            description: input.description,
            idempotencyKey: input.idempotencyKey,
            lines: stryMutAct_9fa48("4537") ? [] : (stryCov_9fa48("4537"), [stryMutAct_9fa48("4538") ? {} : (stryCov_9fa48("4538"), {
              ledgerAccountId: debitId,
              debitMinorUnits: input.amount.minorUnits,
              creditMinorUnits: 0
            }), stryMutAct_9fa48("4539") ? {} : (stryCov_9fa48("4539"), {
              ledgerAccountId: creditId,
              debitMinorUnits: 0,
              creditMinorUnits: input.amount.minorUnits
            })])
          })
        }));
        opening = stryMutAct_9fa48("4540") ? {} : (stryCov_9fa48("4540"), {
          ...common,
          kind: stryMutAct_9fa48("4541") ? "" : (stryCov_9fa48("4541"), "posted"),
          journalEntryId: entry.id
        });
      }
    }
    await store.saveOpeningPosition(stryMutAct_9fa48("4542") ? {} : (stryCov_9fa48("4542"), {
      workspaceId: input.workspaceId,
      financialAccountProfileId: profile.id,
      description: input.description,
      opening,
      ...((stryMutAct_9fa48("4545") ? input.replacesOpeningKey === undefined : stryMutAct_9fa48("4544") ? false : stryMutAct_9fa48("4543") ? true : (stryCov_9fa48("4543", "4544", "4545"), input.replacesOpeningKey !== undefined)) ? stryMutAct_9fa48("4546") ? {} : (stryCov_9fa48("4546"), {
        replacesOpeningKey: input.replacesOpeningKey
      }) : {})
    }));
    return openingResult(store, workspace, profile.id, opening, stryMutAct_9fa48("4547") ? true : (stryCov_9fa48("4547"), false));
  }
}
async function openingResult(store: AccountingStore, workspace: StoredWorkspace, profileId: string, opening: StoredOpening, replay: boolean): Promise<OpeningPositionResult> {
  if (stryMutAct_9fa48("4548")) {
    {}
  } else {
    stryCov_9fa48("4548");
    const profile = await requireProfile(store, workspace.id, profileId);
    let journalEntry = null;
    if (stryMutAct_9fa48("4551") ? opening.kind !== "posted" : stryMutAct_9fa48("4550") ? false : stryMutAct_9fa48("4549") ? true : (stryCov_9fa48("4549", "4550", "4551"), opening.kind === (stryMutAct_9fa48("4552") ? "" : (stryCov_9fa48("4552"), "posted")))) {
      if (stryMutAct_9fa48("4553")) {
        {}
      } else {
        stryCov_9fa48("4553");
        const entry = await store.getJournalEntry(opening.journalEntryId);
        if (stryMutAct_9fa48("4556") ? false : stryMutAct_9fa48("4555") ? true : stryMutAct_9fa48("4554") ? entry : (stryCov_9fa48("4554", "4555", "4556"), !entry)) throw new AccountingError(stryMutAct_9fa48("4558") ? "" : (stryCov_9fa48("4558"), "journal_entry_not_found"));
        const reversal = await store.findReversalOf(entry.id);
        journalEntry = await toPostedJournalEntry(store, await journalContext(store, workspace), entry, stryMutAct_9fa48("4559") ? {} : (stryCov_9fa48("4559"), {
          replay,
          ...(reversal ? stryMutAct_9fa48("4560") ? {} : (stryCov_9fa48("4560"), {
            reversedByEntryId: reversal.id
          }) : {})
        }));
      }
    }
    return stryMutAct_9fa48("4561") ? {} : (stryCov_9fa48("4561"), {
      profile: await toProfile(store, profile),
      journalEntry,
      replay
    });
  }
}