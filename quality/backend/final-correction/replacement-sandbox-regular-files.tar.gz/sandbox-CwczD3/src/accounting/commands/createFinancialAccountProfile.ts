// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { commandIdentity } from "../commandIdentity";
import { chartTemplate, nextAuxiliaryCode, normalSideOf } from "../chartOfAccounts";
import { classifyFinancialAccountProfile } from "../classification";
import { AccountingError } from "../errors";
import { requireWorkspace } from "../membership";
import type { AccountingStore, Actor, FinancialAccountProfile, FinancialAccountProductKind, ProfileClassificationAnswers } from "../types";
import { toProfile } from "../views";

/** Each profile gets its own auxiliary Posting Account, as a bookkeeper opens one per bank account. */
export async function createFinancialAccountProfile(store: AccountingStore, input: {
  actor: Actor;
  workspaceId: string;
  name: string;
  productKind: FinancialAccountProductKind;
  classificationAnswers?: ProfileClassificationAnswers;
  idempotencyKey?: string;
}): Promise<FinancialAccountProfile> {
  if (stryMutAct_9fa48("4300")) {
    {}
  } else {
    stryCov_9fa48("4300");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("4301") ? "" : (stryCov_9fa48("4301"), "prepare"));
    const name = stryMutAct_9fa48("4302") ? input.name : (stryCov_9fa48("4302"), input.name.trim());
    if (stryMutAct_9fa48("4305") ? false : stryMutAct_9fa48("4304") ? true : stryMutAct_9fa48("4303") ? name : (stryCov_9fa48("4303", "4304", "4305"), !name)) {
      if (stryMutAct_9fa48("4306")) {
        {}
      } else {
        stryCov_9fa48("4306");
        throw new AccountingError(stryMutAct_9fa48("4308") ? "" : (stryCov_9fa48("4308"), "name_required"));
      }
    }
    const classified = classifyFinancialAccountProfile(chartTemplate(workspace.chartOfAccountsTemplate), input.productKind, input.classificationAnswers);
    if (stryMutAct_9fa48("4311") ? input.idempotencyKey === undefined : stryMutAct_9fa48("4310") ? false : stryMutAct_9fa48("4309") ? true : (stryCov_9fa48("4309", "4310", "4311"), input.idempotencyKey !== undefined)) {
      if (stryMutAct_9fa48("4312")) {
        {}
      } else {
        stryCov_9fa48("4312");
        if (stryMutAct_9fa48("4315") ? false : stryMutAct_9fa48("4314") ? true : stryMutAct_9fa48("4313") ? input.idempotencyKey : (stryCov_9fa48("4313", "4314", "4315"), !input.idempotencyKey)) throw new AccountingError(stryMutAct_9fa48("4317") ? "" : (stryCov_9fa48("4317"), "idempotency_key_required"));
        const existing = await store.findProfileBySetupKey(input.workspaceId, input.idempotencyKey);
        if (stryMutAct_9fa48("4319") ? false : stryMutAct_9fa48("4318") ? true : (stryCov_9fa48("4318", "4319"), existing)) {
          if (stryMutAct_9fa48("4320")) {
            {}
          } else {
            stryCov_9fa48("4320");
            if (stryMutAct_9fa48("4323") ? (existing.name !== name || existing.productKind !== input.productKind) && commandIdentity(existing.classificationAnswers) !== commandIdentity(classified.answers) : stryMutAct_9fa48("4322") ? false : stryMutAct_9fa48("4321") ? true : (stryCov_9fa48("4321", "4322", "4323"), (stryMutAct_9fa48("4325") ? existing.name !== name && existing.productKind !== input.productKind : stryMutAct_9fa48("4324") ? false : (stryCov_9fa48("4324", "4325"), (stryMutAct_9fa48("4327") ? existing.name === name : stryMutAct_9fa48("4326") ? false : (stryCov_9fa48("4326", "4327"), existing.name !== name)) || (stryMutAct_9fa48("4329") ? existing.productKind === input.productKind : stryMutAct_9fa48("4328") ? false : (stryCov_9fa48("4328", "4329"), existing.productKind !== input.productKind)))) || (stryMutAct_9fa48("4331") ? commandIdentity(existing.classificationAnswers) === commandIdentity(classified.answers) : stryMutAct_9fa48("4330") ? false : (stryCov_9fa48("4330", "4331"), commandIdentity(existing.classificationAnswers) !== commandIdentity(classified.answers))))) throw new AccountingError(stryMutAct_9fa48("4333") ? "" : (stryCov_9fa48("4333"), "idempotency_key_conflict"));
            return toProfile(store, existing);
          }
        }
      }
    }
    const postingAccount = await store.insertLedgerAccount(stryMutAct_9fa48("4334") ? {} : (stryCov_9fa48("4334"), {
      workspaceId: input.workspaceId,
      code: await nextAuxiliaryCode(store, input.workspaceId, classified.parentCode),
      name,
      nature: classified.nature,
      normalSide: normalSideOf(classified.nature),
      role: stryMutAct_9fa48("4335") ? "" : (stryCov_9fa48("4335"), "Posting")
    }));
    const profile = await store.insertProfile(stryMutAct_9fa48("4336") ? {} : (stryCov_9fa48("4336"), {
      workspaceId: input.workspaceId,
      name,
      productKind: classified.productKind,
      classificationPolicy: classified.policy,
      ...(classified.answers ? stryMutAct_9fa48("4337") ? {} : (stryCov_9fa48("4337"), {
        classificationAnswers: classified.answers
      }) : {}),
      postingAccountId: postingAccount.id,
      ...((stryMutAct_9fa48("4340") ? input.idempotencyKey === undefined : stryMutAct_9fa48("4339") ? false : stryMutAct_9fa48("4338") ? true : (stryCov_9fa48("4338", "4339", "4340"), input.idempotencyKey !== undefined)) ? stryMutAct_9fa48("4341") ? {} : (stryCov_9fa48("4341"), {
        setupIdempotencyKey: input.idempotencyKey
      }) : {})
    }));
    return toProfile(store, profile);
  }
}