// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { recordCashActivity } from "../cashActivity";
import type { AccountingClock, AccountingStore, CashActivityInput, PostedJournalEntry } from "../types";

/** Dr the profile's Posting Account, Cr an income account (the template default unless chosen). */
export function recordCashIncome(store: AccountingStore, clock: AccountingClock, input: CashActivityInput): Promise<PostedJournalEntry> {
  if (stryMutAct_9fa48("4414")) {
    {}
  } else {
    stryCov_9fa48("4414");
    return recordCashActivity(store, clock, input, stryMutAct_9fa48("4415") ? {} : (stryCov_9fa48("4415"), {
      policy: stryMutAct_9fa48("4416") ? "" : (stryCov_9fa48("4416"), "cash-income@1"),
      direction: stryMutAct_9fa48("4417") ? "" : (stryCov_9fa48("4417"), "in"),
      counterpart: stryMutAct_9fa48("4418") ? "" : (stryCov_9fa48("4418"), "income")
    }));
  }
}