// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { requireWorkspace } from "../membership";
import { requirePeriodKey } from "../period";
import type { AccountingClock, AccountingPeriod, AccountingStore, Actor, PeriodKey } from "../types";

/**
 * Locks one calendar month, even one with no activity yet, and appends an immutable
 * Period Control Decision naming who locked it, when, and why.
 */
export async function lockAccountingPeriod(store: AccountingStore, clock: AccountingClock, input: {
  actor: Actor;
  workspaceId: string;
  period: PeriodKey;
  reason?: string;
}): Promise<AccountingPeriod> {
  if (stryMutAct_9fa48("4378")) {
    {}
  } else {
    stryCov_9fa48("4378");
    await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("4379") ? "" : (stryCov_9fa48("4379"), "managePeriods"));
    const period = requirePeriodKey(input.period);
    const stored = await store.getAccountingPeriod(input.workspaceId, period);
    if (stryMutAct_9fa48("4382") ? stored?.status !== "locked" : stryMutAct_9fa48("4381") ? false : stryMutAct_9fa48("4380") ? true : (stryCov_9fa48("4380", "4381", "4382"), (stryMutAct_9fa48("4383") ? stored.status : (stryCov_9fa48("4383"), stored?.status)) === (stryMutAct_9fa48("4384") ? "" : (stryCov_9fa48("4384"), "locked")))) {
      if (stryMutAct_9fa48("4385")) {
        {}
      } else {
        stryCov_9fa48("4385");
        return stored;
      }
    }
    const locked = stored ? await store.setAccountingPeriodStatus(input.workspaceId, period, stryMutAct_9fa48("4386") ? "" : (stryCov_9fa48("4386"), "locked")) : await store.insertAccountingPeriod(input.workspaceId, stryMutAct_9fa48("4387") ? {} : (stryCov_9fa48("4387"), {
      ...period,
      status: stryMutAct_9fa48("4388") ? "" : (stryCov_9fa48("4388"), "locked")
    }));
    const reason = stryMutAct_9fa48("4390") ? input.reason.trim() : stryMutAct_9fa48("4389") ? input.reason : (stryCov_9fa48("4389", "4390"), input.reason?.trim());
    await store.insertPeriodControlDecision(input.workspaceId, stryMutAct_9fa48("4391") ? {} : (stryCov_9fa48("4391"), {
      period,
      action: stryMutAct_9fa48("4392") ? "" : (stryCov_9fa48("4392"), "Lock"),
      decidedBy: input.actor.userId,
      decidedAt: clock.now().getTime(),
      ...(reason ? stryMutAct_9fa48("4393") ? {} : (stryCov_9fa48("4393"), {
        reason
      }) : {})
    }));
    return locked;
  }
}