// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "../errors";
import { requireWorkspace } from "../membership";
import { periodFromAccountingDate } from "../period";
import { earliestPermittedDate } from "../periodControl";
import { postJournalEntry } from "../posting";
import type { AccountingClock, AccountingStore, Actor, PostedJournalEntry } from "../types";
import { journalContext, toPostedJournalEntry } from "../views";

/**
 * Append-only correction: a new Posted entry that mirrors every line of the original,
 * so the pair nets to zero and the original stays untouched. Record a Replacement
 * Entry afterwards when the correct treatment is a different amount or account.
 *
 * Without an explicit date the reversal takes the original Accounting Date, or the
 * first day of the next unlocked period when the original's period is Locked.
 */
export async function reversePostedEntry(store: AccountingStore, clock: AccountingClock, input: {
  actor: Actor;
  workspaceId: string;
  journalEntryId: string;
  accountingDate?: string;
  description?: string;
  idempotencyKey: string;
}): Promise<PostedJournalEntry> {
  if (stryMutAct_9fa48("4562")) {
    {}
  } else {
    stryCov_9fa48("4562");
    const workspace = await requireWorkspace(store, input.workspaceId, input.actor, stryMutAct_9fa48("4563") ? "" : (stryCov_9fa48("4563"), "correct"));
    const original = await store.getJournalEntry(input.journalEntryId);
    if (stryMutAct_9fa48("4566") ? !original && original.workspaceId !== input.workspaceId : stryMutAct_9fa48("4565") ? false : stryMutAct_9fa48("4564") ? true : (stryCov_9fa48("4564", "4565", "4566"), (stryMutAct_9fa48("4567") ? original : (stryCov_9fa48("4567"), !original)) || (stryMutAct_9fa48("4569") ? original.workspaceId === input.workspaceId : stryMutAct_9fa48("4568") ? false : (stryCov_9fa48("4568", "4569"), original.workspaceId !== input.workspaceId)))) {
      if (stryMutAct_9fa48("4570")) {
        {}
      } else {
        stryCov_9fa48("4570");
        throw new AccountingError(stryMutAct_9fa48("4572") ? "" : (stryCov_9fa48("4572"), "journal_entry_not_found"));
      }
    }
    if (stryMutAct_9fa48("4574") ? false : stryMutAct_9fa48("4573") ? true : (stryCov_9fa48("4573", "4574"), original.reversesEntryId)) {
      if (stryMutAct_9fa48("4575")) {
        {}
      } else {
        stryCov_9fa48("4575");
        throw new AccountingError(stryMutAct_9fa48("4577") ? "" : (stryCov_9fa48("4577"), "reversal_cannot_be_reversed"));
      }
    }
    const earlier = await store.findReversalOf(original.id);
    if (stryMutAct_9fa48("4580") ? earlier || earlier.idempotencyKey !== input.idempotencyKey : stryMutAct_9fa48("4579") ? false : stryMutAct_9fa48("4578") ? true : (stryCov_9fa48("4578", "4579", "4580"), earlier && (stryMutAct_9fa48("4582") ? earlier.idempotencyKey === input.idempotencyKey : stryMutAct_9fa48("4581") ? true : (stryCov_9fa48("4581", "4582"), earlier.idempotencyKey !== input.idempotencyKey)))) {
      if (stryMutAct_9fa48("4583")) {
        {}
      } else {
        stryCov_9fa48("4583");
        throw new AccountingError(stryMutAct_9fa48("4585") ? "" : (stryCov_9fa48("4585"), "journal_entry_already_reversed"));
      }
    }
    const accountingDate = stryMutAct_9fa48("4586") ? (input.accountingDate ?? earlier?.accountingDate) && (await earliestPermittedDate(store, input.workspaceId, original.accountingDate)) : (stryCov_9fa48("4586"), (stryMutAct_9fa48("4587") ? input.accountingDate && earlier?.accountingDate : (stryCov_9fa48("4587"), input.accountingDate ?? (stryMutAct_9fa48("4588") ? earlier.accountingDate : (stryCov_9fa48("4588"), earlier?.accountingDate)))) ?? (await earliestPermittedDate(store, input.workspaceId, original.accountingDate)));
    if (stryMutAct_9fa48("4589")) {
      ;
    } else {
      stryCov_9fa48("4589");
      periodFromAccountingDate(accountingDate);
    }
    if (stryMutAct_9fa48("4593") ? accountingDate >= original.accountingDate : stryMutAct_9fa48("4592") ? accountingDate <= original.accountingDate : stryMutAct_9fa48("4591") ? false : stryMutAct_9fa48("4590") ? true : (stryCov_9fa48("4590", "4591", "4592", "4593"), accountingDate < original.accountingDate)) {
      if (stryMutAct_9fa48("4594")) {
        {}
      } else {
        stryCov_9fa48("4594");
        throw new AccountingError(stryMutAct_9fa48("4596") ? "" : (stryCov_9fa48("4596"), "reversal_date_before_original"));
      }
    }
    const draft = stryMutAct_9fa48("4597") ? {} : (stryCov_9fa48("4597"), {
      accountingDate,
      description: stryMutAct_9fa48("4598") ? input.description && `Reversal: ${original.description}` : (stryCov_9fa48("4598"), input.description ?? (stryMutAct_9fa48("4599") ? `` : (stryCov_9fa48("4599"), `Reversal: ${original.description}`))),
      idempotencyKey: input.idempotencyKey,
      policy: "reversal@1" as const,
      ...(original.cashCategoryInput ? stryMutAct_9fa48("4600") ? {} : (stryCov_9fa48("4600"), {
        cashCategoryInput: original.cashCategoryInput
      }) : {}),
      reversesEntryId: original.id,
      ...(original.sourceExpenseEffects ? stryMutAct_9fa48("4601") ? {} : (stryCov_9fa48("4601"), {
        sourceExpenseEffects: original.sourceExpenseEffects.map(stryMutAct_9fa48("4602") ? () => undefined : (stryCov_9fa48("4602"), e => stryMutAct_9fa48("4603") ? {} : (stryCov_9fa48("4603"), {
          sourceEntryId: e.sourceEntryId,
          expenseDeltaMinorUnits: stryMutAct_9fa48("4604") ? +e.expenseDeltaMinorUnits : (stryCov_9fa48("4604"), -e.expenseDeltaMinorUnits)
        })))
      }) : {}),
      lines: original.lines.map(stryMutAct_9fa48("4605") ? () => undefined : (stryCov_9fa48("4605"), line => stryMutAct_9fa48("4606") ? {} : (stryCov_9fa48("4606"), {
        ...(line.category ? stryMutAct_9fa48("4607") ? {} : (stryCov_9fa48("4607"), {
          category: line.category
        }) : {}),
        ...(line.categoryCorrection ? stryMutAct_9fa48("4608") ? {} : (stryCov_9fa48("4608"), {
          categoryCorrection: line.categoryCorrection
        }) : {}),
        ledgerAccountId: line.ledgerAccountId,
        debitMinorUnits: line.creditMinorUnits,
        creditMinorUnits: line.debitMinorUnits
      })))
    });
    const {
      entry,
      replay
    } = await postJournalEntry(store, clock, stryMutAct_9fa48("4609") ? {} : (stryCov_9fa48("4609"), {
      actor: input.actor,
      workspaceId: input.workspaceId,
      draft: original.financialAccountProfileId ? stryMutAct_9fa48("4610") ? {} : (stryCov_9fa48("4610"), {
        ...draft,
        financialAccountProfileId: original.financialAccountProfileId
      }) : draft
    }));
    return toPostedJournalEntry(store, await journalContext(store, workspace), entry, stryMutAct_9fa48("4611") ? {} : (stryCov_9fa48("4611"), {
      replay
    }));
  }
}