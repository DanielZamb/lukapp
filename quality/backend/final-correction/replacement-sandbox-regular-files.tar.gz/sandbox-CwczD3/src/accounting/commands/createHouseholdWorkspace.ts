// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "../errors";
import { requireWorkspace } from "../membership";
import { openWorkspace } from "../queries/openWorkspace";
import type { AccountingClock, AccountingStore, Actor, Workspace } from "../types";
import { provisionWorkspace, workspaceConfiguration } from "../workspaceProvisioning";
export async function createHouseholdWorkspace(store: AccountingStore, clock: AccountingClock, input: {
  actor: Actor;
  functionalCurrency: string;
  chartOfAccountsTemplate?: string;
  idempotencyKey: string;
}): Promise<Workspace> {
  if (stryMutAct_9fa48("4342")) {
    {}
  } else {
    stryCov_9fa48("4342");
    if (stryMutAct_9fa48("4345") ? false : stryMutAct_9fa48("4344") ? true : stryMutAct_9fa48("4343") ? input.idempotencyKey.trim() : (stryCov_9fa48("4343", "4344", "4345"), !(stryMutAct_9fa48("4346") ? input.idempotencyKey : (stryCov_9fa48("4346"), input.idempotencyKey.trim())))) {
      if (stryMutAct_9fa48("4347")) {
        {}
      } else {
        stryCov_9fa48("4347");
        throw new AccountingError(stryMutAct_9fa48("4349") ? "" : (stryCov_9fa48("4349"), "idempotency_key_required"));
      }
    }
    const existingId = await store.findHouseholdWorkspaceByKey(input.actor.userId, input.idempotencyKey);
    if (stryMutAct_9fa48("4351") ? false : stryMutAct_9fa48("4350") ? true : (stryCov_9fa48("4350", "4351"), existingId)) {
      if (stryMutAct_9fa48("4352")) {
        {}
      } else {
        stryCov_9fa48("4352");
        const workspace = await requireWorkspace(store, existingId, input.actor, stryMutAct_9fa48("4353") ? "" : (stryCov_9fa48("4353"), "administerMembership"));
        const {
          functionalCurrency,
          template
        } = workspaceConfiguration(stryMutAct_9fa48("4354") ? {} : (stryCov_9fa48("4354"), {
          ...input,
          kind: stryMutAct_9fa48("4355") ? "" : (stryCov_9fa48("4355"), "Household")
        }));
        if (stryMutAct_9fa48("4358") ? (workspace.kind !== "Household" || workspace.functionalCurrency !== functionalCurrency) && workspace.chartOfAccountsTemplate !== template.version : stryMutAct_9fa48("4357") ? false : stryMutAct_9fa48("4356") ? true : (stryCov_9fa48("4356", "4357", "4358"), (stryMutAct_9fa48("4360") ? workspace.kind !== "Household" && workspace.functionalCurrency !== functionalCurrency : stryMutAct_9fa48("4359") ? false : (stryCov_9fa48("4359", "4360"), (stryMutAct_9fa48("4362") ? workspace.kind === "Household" : stryMutAct_9fa48("4361") ? false : (stryCov_9fa48("4361", "4362"), workspace.kind !== (stryMutAct_9fa48("4363") ? "" : (stryCov_9fa48("4363"), "Household")))) || (stryMutAct_9fa48("4365") ? workspace.functionalCurrency === functionalCurrency : stryMutAct_9fa48("4364") ? false : (stryCov_9fa48("4364", "4365"), workspace.functionalCurrency !== functionalCurrency)))) || (stryMutAct_9fa48("4367") ? workspace.chartOfAccountsTemplate === template.version : stryMutAct_9fa48("4366") ? false : (stryCov_9fa48("4366", "4367"), workspace.chartOfAccountsTemplate !== template.version)))) {
          if (stryMutAct_9fa48("4368")) {
            {}
          } else {
            stryCov_9fa48("4368");
            throw new AccountingError(stryMutAct_9fa48("4370") ? "" : (stryCov_9fa48("4370"), "idempotency_key_conflict"));
          }
        }
        return openWorkspace(store, clock, stryMutAct_9fa48("4371") ? {} : (stryCov_9fa48("4371"), {
          actor: input.actor,
          workspaceId: existingId
        }));
      }
    }
    const workspace = await provisionWorkspace(store, clock, stryMutAct_9fa48("4372") ? {} : (stryCov_9fa48("4372"), {
      ...input,
      kind: stryMutAct_9fa48("4373") ? "" : (stryCov_9fa48("4373"), "Household")
    }));
    await store.saveHouseholdWorkspaceCreation(stryMutAct_9fa48("4374") ? {} : (stryCov_9fa48("4374"), {
      ownerUserId: input.actor.userId,
      idempotencyKey: input.idempotencyKey,
      workspaceId: workspace.id
    }));
    return workspace;
  }
}