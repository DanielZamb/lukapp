// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
export const accessPolicy = {
  version: "lukapp-device-access@1",
  challengeLifetimeMs: 60_000,
  inactivityLifetimeMs: 30 * 24 * 60 * 60 * 1000,
  maximumLifetimeMs: 90 * 24 * 60 * 60 * 1000,
  localInputLifetimeMs: 15 * 24 * 60 * 60 * 1000,
  ordinaryLockMs: 2 * 60 * 1000,
  monthCloseLockMs: 10 * 60 * 1000
} as const;
export const operations = ["accounting.completeFirstRun", "accounting.firstRunStatus", "accounting.phoneSummary", "budget.createBudget", "budget.updateBudget", "budget.retireBudget", "budget.listBudgets", "budget.evaluateBudgets", "budget.budgetImpactWarning", "accounting.createUserCategory", "accounting.suggestCategoryNature", "accounting.listUserCategories", "accounting.categoryTotals", "accounting.changeUserCategory", "accounting.previewCategoryReclassification", "accounting.confirmCategoryReclassification", "devices.register", "devices.revoke", "devices.heartbeat", "devices.approveRegistration", "accounting.createPersonalWorkspace", "accounting.personalWorkspace", "accounting.openWorkspace", "accounting.createHouseholdWorkspace", "accounting.listOwnedWorkspaces", "accounting.localInputAuthority", "accounting.setupFinancialAccount", "accounting.recordOpeningPosition", "accounting.recordAccountTransfer", "accounting.createFinancialAccountProfile", "accounting.listFinancialAccountProfiles", "accounting.listLedgerAccounts", "accounting.listCatalogAccounts", "accounting.lockAccountingPeriod", "accounting.recordCashExpense", "accounting.recordCashIncome", "accounting.reversePostedEntry", "accounting.listPostedExpenses", "savingsRecovery.saveDraft", "savingsRecovery.activatePlan", "savingsRecovery.cancelPlan", "savingsRecovery.replacePlan", "savingsRecovery.reconcilePlans", "savingsRecovery.decideCandidate", "savingsRecovery.recordContribution", "savingsRecovery.reverseContribution", "savingsRecovery.proposeAllocation", "savingsRecovery.decideProposal", "savingsRecovery.declareOpeningProgress", "savingsRecovery.listCandidates", "savingsRecovery.progress", "savingsRecovery.monthlyWaterfall", "accounting.listJournalEntries", "accounting.balances", "accounting.trialBalance"] as const;
export type AccessOperation = typeof operations[number];
export type FinancialOperation = Exclude<AccessOperation, `devices.${string}`>;
export type DeviceProof = {
  challengeId: string;
  signature: string;
};
export type DevicePlatform = "ios" | "android";
export const accessDenials = ["session_id_required", "session_id_invalid", "session_state_unverified", "session_not_active", "session_revoked", "device_unregistered", "device_unknown", "device_revoked", "session_device_mismatch", "session_inactive", "session_maximum_lifetime", "recovery_registration_blocked", "device_proof_required", "device_proof_invalid", "device_challenge_expired", "device_challenge_replayed", "device_request_mismatch", "device_slot_occupied", "device_registration_conflict", "device_key_invalid"] as const;
export type AccessDenial = typeof accessDenials[number];
export type ContactDirective = "register-device" | "wipe-local-input-and-sign-out" | "unlock-online";
const directives = (stryMutAct_9fa48("3149") ? {} : (stryCov_9fa48("3149"), {
  session_id_required: stryMutAct_9fa48("3150") ? "" : (stryCov_9fa48("3150"), "wipe-local-input-and-sign-out"),
  session_id_invalid: stryMutAct_9fa48("3151") ? "" : (stryCov_9fa48("3151"), "wipe-local-input-and-sign-out"),
  session_state_unverified: stryMutAct_9fa48("3152") ? "" : (stryCov_9fa48("3152"), "wipe-local-input-and-sign-out"),
  session_not_active: stryMutAct_9fa48("3153") ? "" : (stryCov_9fa48("3153"), "wipe-local-input-and-sign-out"),
  session_revoked: stryMutAct_9fa48("3154") ? "" : (stryCov_9fa48("3154"), "wipe-local-input-and-sign-out"),
  device_unregistered: stryMutAct_9fa48("3155") ? "" : (stryCov_9fa48("3155"), "register-device"),
  device_unknown: stryMutAct_9fa48("3156") ? "" : (stryCov_9fa48("3156"), "register-device"),
  device_revoked: stryMutAct_9fa48("3157") ? "" : (stryCov_9fa48("3157"), "wipe-local-input-and-sign-out"),
  session_device_mismatch: stryMutAct_9fa48("3158") ? "" : (stryCov_9fa48("3158"), "unlock-online"),
  session_inactive: stryMutAct_9fa48("3159") ? "" : (stryCov_9fa48("3159"), "wipe-local-input-and-sign-out"),
  session_maximum_lifetime: stryMutAct_9fa48("3160") ? "" : (stryCov_9fa48("3160"), "wipe-local-input-and-sign-out"),
  recovery_registration_blocked: stryMutAct_9fa48("3161") ? "" : (stryCov_9fa48("3161"), "wipe-local-input-and-sign-out"),
  device_proof_required: stryMutAct_9fa48("3162") ? "" : (stryCov_9fa48("3162"), "unlock-online"),
  device_proof_invalid: stryMutAct_9fa48("3163") ? "" : (stryCov_9fa48("3163"), "unlock-online"),
  device_challenge_expired: stryMutAct_9fa48("3164") ? "" : (stryCov_9fa48("3164"), "unlock-online"),
  device_challenge_replayed: stryMutAct_9fa48("3165") ? "" : (stryCov_9fa48("3165"), "unlock-online"),
  device_request_mismatch: stryMutAct_9fa48("3166") ? "" : (stryCov_9fa48("3166"), "unlock-online"),
  device_slot_occupied: stryMutAct_9fa48("3167") ? "" : (stryCov_9fa48("3167"), "unlock-online"),
  device_registration_conflict: stryMutAct_9fa48("3168") ? "" : (stryCov_9fa48("3168"), "unlock-online"),
  device_key_invalid: stryMutAct_9fa48("3169") ? "" : (stryCov_9fa48("3169"), "unlock-online")
})) satisfies Record<AccessDenial, ContactDirective>;
export function directiveFor(code: AccessDenial): ContactDirective {
  if (stryMutAct_9fa48("3170")) {
    {}
  } else {
    stryCov_9fa48("3170");
    return directives[code];
  }
}
export function bindingExpiry(binding: {
  createdAt: number;
  lastSeenAt: number;
}, now: number): AccessDenial | null {
  if (stryMutAct_9fa48("3171")) {
    {}
  } else {
    stryCov_9fa48("3171");
    if (stryMutAct_9fa48("3175") ? now < binding.createdAt + accessPolicy.maximumLifetimeMs : stryMutAct_9fa48("3174") ? now > binding.createdAt + accessPolicy.maximumLifetimeMs : stryMutAct_9fa48("3173") ? false : stryMutAct_9fa48("3172") ? true : (stryCov_9fa48("3172", "3173", "3174", "3175"), now >= (stryMutAct_9fa48("3176") ? binding.createdAt - accessPolicy.maximumLifetimeMs : (stryCov_9fa48("3176"), binding.createdAt + accessPolicy.maximumLifetimeMs)))) return stryMutAct_9fa48("3177") ? "" : (stryCov_9fa48("3177"), "session_maximum_lifetime");
    if (stryMutAct_9fa48("3181") ? now < binding.lastSeenAt + accessPolicy.inactivityLifetimeMs : stryMutAct_9fa48("3180") ? now > binding.lastSeenAt + accessPolicy.inactivityLifetimeMs : stryMutAct_9fa48("3179") ? false : stryMutAct_9fa48("3178") ? true : (stryCov_9fa48("3178", "3179", "3180", "3181"), now >= (stryMutAct_9fa48("3182") ? binding.lastSeenAt - accessPolicy.inactivityLifetimeMs : (stryCov_9fa48("3182"), binding.lastSeenAt + accessPolicy.inactivityLifetimeMs)))) return stryMutAct_9fa48("3183") ? "" : (stryCov_9fa48("3183"), "session_inactive");
    return null;
  }
}
export function lockRequired(facts: {
  coldLaunch: boolean;
  foregroundIdleMs: number;
  backgroundMs: number;
  screen: "ordinary" | "month-close" | "security";
}) {
  if (stryMutAct_9fa48("3184")) {
    {}
  } else {
    stryCov_9fa48("3184");
    return stryMutAct_9fa48("3187") ? (facts.coldLaunch || facts.screen === "security" || facts.backgroundMs >= accessPolicy.ordinaryLockMs) && facts.foregroundIdleMs >= (facts.screen === "month-close" ? accessPolicy.monthCloseLockMs : accessPolicy.ordinaryLockMs) : stryMutAct_9fa48("3186") ? false : stryMutAct_9fa48("3185") ? true : (stryCov_9fa48("3185", "3186", "3187"), (stryMutAct_9fa48("3189") ? (facts.coldLaunch || facts.screen === "security") && facts.backgroundMs >= accessPolicy.ordinaryLockMs : stryMutAct_9fa48("3188") ? false : (stryCov_9fa48("3188", "3189"), (stryMutAct_9fa48("3191") ? facts.coldLaunch && facts.screen === "security" : stryMutAct_9fa48("3190") ? false : (stryCov_9fa48("3190", "3191"), facts.coldLaunch || (stryMutAct_9fa48("3193") ? facts.screen !== "security" : stryMutAct_9fa48("3192") ? false : (stryCov_9fa48("3192", "3193"), facts.screen === (stryMutAct_9fa48("3194") ? "" : (stryCov_9fa48("3194"), "security")))))) || (stryMutAct_9fa48("3197") ? facts.backgroundMs < accessPolicy.ordinaryLockMs : stryMutAct_9fa48("3196") ? facts.backgroundMs > accessPolicy.ordinaryLockMs : stryMutAct_9fa48("3195") ? false : (stryCov_9fa48("3195", "3196", "3197"), facts.backgroundMs >= accessPolicy.ordinaryLockMs)))) || (stryMutAct_9fa48("3200") ? facts.foregroundIdleMs < (facts.screen === "month-close" ? accessPolicy.monthCloseLockMs : accessPolicy.ordinaryLockMs) : stryMutAct_9fa48("3199") ? facts.foregroundIdleMs > (facts.screen === "month-close" ? accessPolicy.monthCloseLockMs : accessPolicy.ordinaryLockMs) : stryMutAct_9fa48("3198") ? false : (stryCov_9fa48("3198", "3199", "3200"), facts.foregroundIdleMs >= ((stryMutAct_9fa48("3203") ? facts.screen !== "month-close" : stryMutAct_9fa48("3202") ? false : stryMutAct_9fa48("3201") ? true : (stryCov_9fa48("3201", "3202", "3203"), facts.screen === (stryMutAct_9fa48("3204") ? "" : (stryCov_9fa48("3204"), "month-close")))) ? accessPolicy.monthCloseLockMs : accessPolicy.ordinaryLockMs))));
  }
}
export interface NativeDeviceKey {
  publicKey(): Promise<string>;
  sign(message: string): Promise<string>;
  delete(): Promise<void>;
}
export function canonicalJson(value: unknown): string {
  if (stryMutAct_9fa48("3205")) {
    {}
  } else {
    stryCov_9fa48("3205");
    if (stryMutAct_9fa48("3208") ? value !== null : stryMutAct_9fa48("3207") ? false : stryMutAct_9fa48("3206") ? true : (stryCov_9fa48("3206", "3207", "3208"), value === null)) return stryMutAct_9fa48("3209") ? "" : (stryCov_9fa48("3209"), '["null"]');
    if (stryMutAct_9fa48("3212") ? typeof value !== "string" : stryMutAct_9fa48("3211") ? false : stryMutAct_9fa48("3210") ? true : (stryCov_9fa48("3210", "3211", "3212"), typeof value === (stryMutAct_9fa48("3213") ? "" : (stryCov_9fa48("3213"), "string")))) return JSON.stringify(stryMutAct_9fa48("3214") ? [] : (stryCov_9fa48("3214"), [stryMutAct_9fa48("3215") ? "" : (stryCov_9fa48("3215"), "string"), value]));
    if (stryMutAct_9fa48("3218") ? typeof value !== "boolean" : stryMutAct_9fa48("3217") ? false : stryMutAct_9fa48("3216") ? true : (stryCov_9fa48("3216", "3217", "3218"), typeof value === (stryMutAct_9fa48("3219") ? "" : (stryCov_9fa48("3219"), "boolean")))) return JSON.stringify(stryMutAct_9fa48("3220") ? [] : (stryCov_9fa48("3220"), [stryMutAct_9fa48("3221") ? "" : (stryCov_9fa48("3221"), "boolean"), value]));
    if (stryMutAct_9fa48("3224") ? typeof value !== "number" : stryMutAct_9fa48("3223") ? false : stryMutAct_9fa48("3222") ? true : (stryCov_9fa48("3222", "3223", "3224"), typeof value === (stryMutAct_9fa48("3225") ? "" : (stryCov_9fa48("3225"), "number")))) return JSON.stringify(stryMutAct_9fa48("3226") ? [] : (stryCov_9fa48("3226"), [stryMutAct_9fa48("3227") ? "" : (stryCov_9fa48("3227"), "number"), Object.is(value, stryMutAct_9fa48("3228") ? +0 : (stryCov_9fa48("3228"), -0)) ? stryMutAct_9fa48("3229") ? "" : (stryCov_9fa48("3229"), "-0") : String(value)]));
    if (stryMutAct_9fa48("3231") ? false : stryMutAct_9fa48("3230") ? true : (stryCov_9fa48("3230", "3231"), Array.isArray(value))) return stryMutAct_9fa48("3232") ? `` : (stryCov_9fa48("3232"), `["array",[${value.map(canonicalJson).join(stryMutAct_9fa48("3233") ? "" : (stryCov_9fa48("3233"), ","))}]]`);
    if (stryMutAct_9fa48("3236") ? typeof value === "object" || value !== null : stryMutAct_9fa48("3235") ? false : stryMutAct_9fa48("3234") ? true : (stryCov_9fa48("3234", "3235", "3236"), (stryMutAct_9fa48("3238") ? typeof value !== "object" : stryMutAct_9fa48("3237") ? true : (stryCov_9fa48("3237", "3238"), typeof value === (stryMutAct_9fa48("3239") ? "" : (stryCov_9fa48("3239"), "object")))) && (stryMutAct_9fa48("3241") ? value === null : stryMutAct_9fa48("3240") ? true : (stryCov_9fa48("3240", "3241"), value !== null)))) {
      if (stryMutAct_9fa48("3242")) {
        {}
      } else {
        stryCov_9fa48("3242");
        const pairs = stryMutAct_9fa48("3244") ? Object.entries(value).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0) : stryMutAct_9fa48("3243") ? Object.entries(value).filter(([, v]) => v !== undefined) : (stryCov_9fa48("3243", "3244"), Object.entries(value).filter(stryMutAct_9fa48("3245") ? () => undefined : (stryCov_9fa48("3245"), ([, v]) => stryMutAct_9fa48("3248") ? v === undefined : stryMutAct_9fa48("3247") ? false : stryMutAct_9fa48("3246") ? true : (stryCov_9fa48("3246", "3247", "3248"), v !== undefined))).sort(stryMutAct_9fa48("3249") ? () => undefined : (stryCov_9fa48("3249"), ([a], [b]) => (stryMutAct_9fa48("3253") ? a >= b : stryMutAct_9fa48("3252") ? a <= b : stryMutAct_9fa48("3251") ? false : stryMutAct_9fa48("3250") ? true : (stryCov_9fa48("3250", "3251", "3252", "3253"), a < b)) ? stryMutAct_9fa48("3254") ? +1 : (stryCov_9fa48("3254"), -1) : (stryMutAct_9fa48("3258") ? a <= b : stryMutAct_9fa48("3257") ? a >= b : stryMutAct_9fa48("3256") ? false : stryMutAct_9fa48("3255") ? true : (stryCov_9fa48("3255", "3256", "3257", "3258"), a > b)) ? 1 : 0)));
        return stryMutAct_9fa48("3259") ? `` : (stryCov_9fa48("3259"), `["object",[${pairs.map(stryMutAct_9fa48("3260") ? () => undefined : (stryCov_9fa48("3260"), ([key, v]) => stryMutAct_9fa48("3261") ? `` : (stryCov_9fa48("3261"), `[${JSON.stringify(key)},${canonicalJson(v)}]`))).join(stryMutAct_9fa48("3262") ? "" : (stryCov_9fa48("3262"), ","))}]]`);
      }
    }
    throw new Error(stryMutAct_9fa48("3264") ? "" : (stryCov_9fa48("3264"), "Request is not a supported Convex argument"));
  }
}
export function bytesToHex(bytes: Uint8Array): string {
  if (stryMutAct_9fa48("3265")) {
    {}
  } else {
    stryCov_9fa48("3265");
    return Array.from(bytes, stryMutAct_9fa48("3266") ? () => undefined : (stryCov_9fa48("3266"), byte => byte.toString(16).padStart(2, stryMutAct_9fa48("3267") ? "" : (stryCov_9fa48("3267"), "0")))).join(stryMutAct_9fa48("3268") ? "Stryker was here!" : (stryCov_9fa48("3268"), ""));
  }
}
export function hexToBytes(hex: string): Uint8Array<ArrayBuffer> {
  if (stryMutAct_9fa48("3269")) {
    {}
  } else {
    stryCov_9fa48("3269");
    if (stryMutAct_9fa48("3272") ? false : stryMutAct_9fa48("3271") ? true : stryMutAct_9fa48("3270") ? /^(?:[0-9a-f]{2})+$/.test(hex) : (stryCov_9fa48("3270", "3271", "3272"), !(stryMutAct_9fa48("3277") ? /^(?:[^0-9a-f]{2})+$/ : stryMutAct_9fa48("3276") ? /^(?:[0-9a-f])+$/ : stryMutAct_9fa48("3275") ? /^(?:[0-9a-f]{2})$/ : stryMutAct_9fa48("3274") ? /^(?:[0-9a-f]{2})+/ : stryMutAct_9fa48("3273") ? /(?:[0-9a-f]{2})+$/ : (stryCov_9fa48("3273", "3274", "3275", "3276", "3277"), /^(?:[0-9a-f]{2})+$/)).test(hex))) throw new Error(stryMutAct_9fa48("3279") ? "" : (stryCov_9fa48("3279"), "Invalid lowercase hex"));
    return Uint8Array.from(stryMutAct_9fa48("3280") ? hex.match(/../g) && [] : (stryCov_9fa48("3280"), hex.match(/../g) ?? (stryMutAct_9fa48("3281") ? ["Stryker was here"] : (stryCov_9fa48("3281"), []))), stryMutAct_9fa48("3282") ? () => undefined : (stryCov_9fa48("3282"), byte => parseInt(byte, 16)));
  }
}
export async function requestHash(args: unknown): Promise<string> {
  if (stryMutAct_9fa48("3283")) {
    {}
  } else {
    stryCov_9fa48("3283");
    return bytesToHex(new Uint8Array(await crypto.subtle.digest(stryMutAct_9fa48("3284") ? "" : (stryCov_9fa48("3284"), "SHA-256"), new TextEncoder().encode(canonicalJson(args)))));
  }
}
export function challengeMessage(facts: {
  challengeId: string;
  nonce: string;
  tokenIdentifier: string;
  sid: string;
  operation: AccessOperation;
  payloadHash: string;
  expiresAt: number;
}) {
  if (stryMutAct_9fa48("3285")) {
    {}
  } else {
    stryCov_9fa48("3285");
    return canonicalJson(stryMutAct_9fa48("3286") ? {} : (stryCov_9fa48("3286"), {
      protocol: accessPolicy.version,
      ...facts
    }));
  }
}
export function derSignatureToP1363(derHex: string): string {
  if (stryMutAct_9fa48("3287")) {
    {}
  } else {
    stryCov_9fa48("3287");
    const der = hexToBytes(derHex);
    if (stryMutAct_9fa48("3290") ? (der.length < 8 || der[0] !== 0x30) && der[1] !== der.length - 2 : stryMutAct_9fa48("3289") ? false : stryMutAct_9fa48("3288") ? true : (stryCov_9fa48("3288", "3289", "3290"), (stryMutAct_9fa48("3292") ? der.length < 8 && der[0] !== 0x30 : stryMutAct_9fa48("3291") ? false : (stryCov_9fa48("3291", "3292"), (stryMutAct_9fa48("3295") ? der.length >= 8 : stryMutAct_9fa48("3294") ? der.length <= 8 : stryMutAct_9fa48("3293") ? false : (stryCov_9fa48("3293", "3294", "3295"), der.length < 8)) || (stryMutAct_9fa48("3297") ? der[0] === 0x30 : stryMutAct_9fa48("3296") ? false : (stryCov_9fa48("3296", "3297"), der[0] !== 0x30)))) || (stryMutAct_9fa48("3299") ? der[1] === der.length - 2 : stryMutAct_9fa48("3298") ? false : (stryCov_9fa48("3298", "3299"), der[1] !== (stryMutAct_9fa48("3300") ? der.length + 2 : (stryCov_9fa48("3300"), der.length - 2)))))) throw new Error(stryMutAct_9fa48("3302") ? "" : (stryCov_9fa48("3302"), "Invalid P-256 DER signature"));
    let offset = 2;
    function integer(): Uint8Array<ArrayBuffer> {
      if (stryMutAct_9fa48("3303")) {
        {}
      } else {
        stryCov_9fa48("3303");
        if (stryMutAct_9fa48("3306") ? der[offset++] === 0x02 : stryMutAct_9fa48("3305") ? false : stryMutAct_9fa48("3304") ? true : (stryCov_9fa48("3304", "3305", "3306"), der[stryMutAct_9fa48("3307") ? offset-- : (stryCov_9fa48("3307"), offset++)] !== 0x02)) throw new Error(stryMutAct_9fa48("3309") ? "" : (stryCov_9fa48("3309"), "Invalid DER integer"));
        const length = der[stryMutAct_9fa48("3310") ? offset-- : (stryCov_9fa48("3310"), offset++)];
        if (stryMutAct_9fa48("3313") ? (length === undefined || length < 1 || length > 33) && offset + length > der.length : stryMutAct_9fa48("3312") ? false : stryMutAct_9fa48("3311") ? true : (stryCov_9fa48("3311", "3312", "3313"), (stryMutAct_9fa48("3315") ? (length === undefined || length < 1) && length > 33 : stryMutAct_9fa48("3314") ? false : (stryCov_9fa48("3314", "3315"), (stryMutAct_9fa48("3317") ? length === undefined && length < 1 : stryMutAct_9fa48("3316") ? false : (stryCov_9fa48("3316", "3317"), (stryMutAct_9fa48("3319") ? length !== undefined : stryMutAct_9fa48("3318") ? false : (stryCov_9fa48("3318", "3319"), length === undefined)) || (stryMutAct_9fa48("3322") ? length >= 1 : stryMutAct_9fa48("3321") ? length <= 1 : stryMutAct_9fa48("3320") ? false : (stryCov_9fa48("3320", "3321", "3322"), length < 1)))) || (stryMutAct_9fa48("3325") ? length <= 33 : stryMutAct_9fa48("3324") ? length >= 33 : stryMutAct_9fa48("3323") ? false : (stryCov_9fa48("3323", "3324", "3325"), length > 33)))) || (stryMutAct_9fa48("3328") ? offset + length <= der.length : stryMutAct_9fa48("3327") ? offset + length >= der.length : stryMutAct_9fa48("3326") ? false : (stryCov_9fa48("3326", "3327", "3328"), (stryMutAct_9fa48("3329") ? offset - length : (stryCov_9fa48("3329"), offset + length)) > der.length)))) throw new Error(stryMutAct_9fa48("3331") ? "" : (stryCov_9fa48("3331"), "Invalid P-256 integer size"));
        const bytes = stryMutAct_9fa48("3332") ? der : (stryCov_9fa48("3332"), der.slice(offset, stryMutAct_9fa48("3333") ? offset - length : (stryCov_9fa48("3333"), offset + length)));
        stryMutAct_9fa48("3334") ? offset -= length : (stryCov_9fa48("3334"), offset += length);
        const first = bytes[0];
        if (stryMutAct_9fa48("3337") ? (first === undefined || first >= 0x80) && bytes.length > 1 && first === 0 && (bytes[1] ?? 0) < 0x80 : stryMutAct_9fa48("3336") ? false : stryMutAct_9fa48("3335") ? true : (stryCov_9fa48("3335", "3336", "3337"), (stryMutAct_9fa48("3339") ? first === undefined && first >= 0x80 : stryMutAct_9fa48("3338") ? false : (stryCov_9fa48("3338", "3339"), (stryMutAct_9fa48("3341") ? first !== undefined : stryMutAct_9fa48("3340") ? false : (stryCov_9fa48("3340", "3341"), first === undefined)) || (stryMutAct_9fa48("3344") ? first < 0x80 : stryMutAct_9fa48("3343") ? first > 0x80 : stryMutAct_9fa48("3342") ? false : (stryCov_9fa48("3342", "3343", "3344"), first >= 0x80)))) || (stryMutAct_9fa48("3346") ? bytes.length > 1 && first === 0 || (bytes[1] ?? 0) < 0x80 : stryMutAct_9fa48("3345") ? false : (stryCov_9fa48("3345", "3346"), (stryMutAct_9fa48("3348") ? bytes.length > 1 || first === 0 : stryMutAct_9fa48("3347") ? true : (stryCov_9fa48("3347", "3348"), (stryMutAct_9fa48("3351") ? bytes.length <= 1 : stryMutAct_9fa48("3350") ? bytes.length >= 1 : stryMutAct_9fa48("3349") ? true : (stryCov_9fa48("3349", "3350", "3351"), bytes.length > 1)) && (stryMutAct_9fa48("3353") ? first !== 0 : stryMutAct_9fa48("3352") ? true : (stryCov_9fa48("3352", "3353"), first === 0)))) && (stryMutAct_9fa48("3356") ? (bytes[1] ?? 0) >= 0x80 : stryMutAct_9fa48("3355") ? (bytes[1] ?? 0) <= 0x80 : stryMutAct_9fa48("3354") ? true : (stryCov_9fa48("3354", "3355", "3356"), (stryMutAct_9fa48("3357") ? bytes[1] && 0 : (stryCov_9fa48("3357"), bytes[1] ?? 0)) < 0x80)))))) throw new Error(stryMutAct_9fa48("3359") ? "" : (stryCov_9fa48("3359"), "Non-canonical DER integer"));
        const magnitude = (stryMutAct_9fa48("3362") ? first !== 0 : stryMutAct_9fa48("3361") ? false : stryMutAct_9fa48("3360") ? true : (stryCov_9fa48("3360", "3361", "3362"), first === 0)) ? stryMutAct_9fa48("3363") ? bytes : (stryCov_9fa48("3363"), bytes.slice(1)) : bytes;
        if (stryMutAct_9fa48("3367") ? magnitude.length <= 32 : stryMutAct_9fa48("3366") ? magnitude.length >= 32 : stryMutAct_9fa48("3365") ? false : stryMutAct_9fa48("3364") ? true : (stryCov_9fa48("3364", "3365", "3366", "3367"), magnitude.length > 32)) throw new Error(stryMutAct_9fa48("3369") ? "" : (stryCov_9fa48("3369"), "Oversized P-256 integer"));
        const padded = new Uint8Array(32);
        padded.set(magnitude, stryMutAct_9fa48("3371") ? 32 + magnitude.length : (stryCov_9fa48("3371"), 32 - magnitude.length));
        return padded;
      }
    }
    const r = integer();
    const s = integer();
    if (stryMutAct_9fa48("3374") ? offset === der.length : stryMutAct_9fa48("3373") ? false : stryMutAct_9fa48("3372") ? true : (stryCov_9fa48("3372", "3373", "3374"), offset !== der.length)) throw new Error(stryMutAct_9fa48("3376") ? "" : (stryCov_9fa48("3376"), "Trailing DER data"));
    return stryMutAct_9fa48("3377") ? bytesToHex(r) - bytesToHex(s) : (stryCov_9fa48("3377"), bytesToHex(r) + bytesToHex(s));
  }
}