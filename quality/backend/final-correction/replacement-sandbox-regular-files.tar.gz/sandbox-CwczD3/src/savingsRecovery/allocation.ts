// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { minor, proportional, RecoveryError, total } from "./amounts";
import { remainingSources } from "./progress";
import type { ContributionAllocation, InstallmentAllocation, Plan } from "./types";
export function allocate(plan: Plan, amount: number, paid: ContributionAllocation[], contributionDate: string): ContributionAllocation {
  if (stryMutAct_9fa48("7587")) {
    {}
  } else {
    stryCov_9fa48("7587");
    if (stryMutAct_9fa48("7590") ? plan.state.kind === "Activated" : stryMutAct_9fa48("7589") ? false : stryMutAct_9fa48("7588") ? true : (stryCov_9fa48("7588", "7589", "7590"), plan.state.kind !== (stryMutAct_9fa48("7591") ? "" : (stryCov_9fa48("7591"), "Activated")))) throw new RecoveryError(stryMutAct_9fa48("7593") ? "" : (stryCov_9fa48("7593"), "recovery_plan_inactive"));
    let remaining = minor(amount, stryMutAct_9fa48("7594") ? false : (stryCov_9fa48("7594"), true));
    const installments: InstallmentAllocation[] = stryMutAct_9fa48("7595") ? ["Stryker was here"] : (stryCov_9fa48("7595"), []);
    for (const [index, installment] of plan.state.commitment.schedule.entries()) {
      if (stryMutAct_9fa48("7596")) {
        {}
      } else {
        stryCov_9fa48("7596");
        const prior = stryMutAct_9fa48("7598") ? paid.flatMap(allocation => allocation.installments).filter(allocation => allocation.installmentIndex === index) : stryMutAct_9fa48("7597") ? paid.filter(allocation => allocation.planId === plan.id).flatMap(allocation => allocation.installments) : (stryCov_9fa48("7597", "7598"), paid.filter(stryMutAct_9fa48("7599") ? () => undefined : (stryCov_9fa48("7599"), allocation => stryMutAct_9fa48("7602") ? allocation.planId !== plan.id : stryMutAct_9fa48("7601") ? false : stryMutAct_9fa48("7600") ? true : (stryCov_9fa48("7600", "7601", "7602"), allocation.planId === plan.id))).flatMap(stryMutAct_9fa48("7603") ? () => undefined : (stryCov_9fa48("7603"), allocation => allocation.installments)).filter(stryMutAct_9fa48("7604") ? () => undefined : (stryCov_9fa48("7604"), allocation => stryMutAct_9fa48("7607") ? allocation.installmentIndex !== index : stryMutAct_9fa48("7606") ? false : stryMutAct_9fa48("7605") ? true : (stryCov_9fa48("7605", "7606", "7607"), allocation.installmentIndex === index))));
        const principalRemaining = stryMutAct_9fa48("7608") ? installment.principalMinor + total(prior.map(allocation => allocation.principalMinor)) : (stryCov_9fa48("7608"), installment.principalMinor - total(prior.map(stryMutAct_9fa48("7609") ? () => undefined : (stryCov_9fa48("7609"), allocation => allocation.principalMinor))));
        const premiumRemaining = stryMutAct_9fa48("7610") ? installment.premiumMinor + total(prior.map(allocation => allocation.premiumMinor)) : (stryCov_9fa48("7610"), installment.premiumMinor - total(prior.map(stryMutAct_9fa48("7611") ? () => undefined : (stryCov_9fa48("7611"), allocation => allocation.premiumMinor))));
        const applied = stryMutAct_9fa48("7612") ? Math.max(remaining, total([principalRemaining, premiumRemaining])) : (stryCov_9fa48("7612"), Math.min(remaining, total(stryMutAct_9fa48("7613") ? [] : (stryCov_9fa48("7613"), [principalRemaining, premiumRemaining]))));
        if (stryMutAct_9fa48("7616") ? applied !== 0 : stryMutAct_9fa48("7615") ? false : stryMutAct_9fa48("7614") ? true : (stryCov_9fa48("7614", "7615", "7616"), applied === 0)) continue;
        const split = proportional(applied, stryMutAct_9fa48("7617") ? [] : (stryCov_9fa48("7617"), [stryMutAct_9fa48("7618") ? {} : (stryCov_9fa48("7618"), {
          component: stryMutAct_9fa48("7619") ? "" : (stryCov_9fa48("7619"), "principal"),
          remaining: principalRemaining
        }), stryMutAct_9fa48("7620") ? {} : (stryCov_9fa48("7620"), {
          component: stryMutAct_9fa48("7621") ? "" : (stryCov_9fa48("7621"), "premium"),
          remaining: premiumRemaining
        })]), stryMutAct_9fa48("7622") ? () => undefined : (stryCov_9fa48("7622"), part => part.remaining));
        const principal = total(stryMutAct_9fa48("7623") ? split.map(share => share.amountMinor) : (stryCov_9fa48("7623"), split.filter(stryMutAct_9fa48("7624") ? () => undefined : (stryCov_9fa48("7624"), share => stryMutAct_9fa48("7627") ? share.part.component !== "principal" : stryMutAct_9fa48("7626") ? false : stryMutAct_9fa48("7625") ? true : (stryCov_9fa48("7625", "7626", "7627"), share.part.component === (stryMutAct_9fa48("7628") ? "" : (stryCov_9fa48("7628"), "principal"))))).map(stryMutAct_9fa48("7629") ? () => undefined : (stryCov_9fa48("7629"), share => share.amountMinor))));
        const premium = total(stryMutAct_9fa48("7630") ? split.map(share => share.amountMinor) : (stryCov_9fa48("7630"), split.filter(stryMutAct_9fa48("7631") ? () => undefined : (stryCov_9fa48("7631"), share => stryMutAct_9fa48("7634") ? share.part.component !== "premium" : stryMutAct_9fa48("7633") ? false : stryMutAct_9fa48("7632") ? true : (stryCov_9fa48("7632", "7633", "7634"), share.part.component === (stryMutAct_9fa48("7635") ? "" : (stryCov_9fa48("7635"), "premium"))))).map(stryMutAct_9fa48("7636") ? () => undefined : (stryCov_9fa48("7636"), share => share.amountMinor))));
        installments.push(stryMutAct_9fa48("7638") ? {} : (stryCov_9fa48("7638"), {
          installmentIndex: index,
          principalMinor: principal,
          premiumMinor: premium,
          prepayment: stryMutAct_9fa48("7642") ? installment.month <= contributionDate.slice(0, 7) : stryMutAct_9fa48("7641") ? installment.month >= contributionDate.slice(0, 7) : stryMutAct_9fa48("7640") ? false : stryMutAct_9fa48("7639") ? true : (stryCov_9fa48("7639", "7640", "7641", "7642"), installment.month > (stryMutAct_9fa48("7643") ? contributionDate : (stryCov_9fa48("7643"), contributionDate.slice(0, 7))))
        }));
        stryMutAct_9fa48("7644") ? remaining += applied : (stryCov_9fa48("7644"), remaining -= applied);
        if (stryMutAct_9fa48("7647") ? remaining !== 0 : stryMutAct_9fa48("7646") ? false : stryMutAct_9fa48("7645") ? true : (stryCov_9fa48("7645", "7646", "7647"), remaining === 0)) break;
      }
    }
    if (stryMutAct_9fa48("7650") ? remaining === 0 : stryMutAct_9fa48("7649") ? false : stryMutAct_9fa48("7648") ? true : (stryCov_9fa48("7648", "7649", "7650"), remaining !== 0)) throw new RecoveryError(stryMutAct_9fa48("7652") ? "" : (stryCov_9fa48("7652"), "recovery_capacity_exceeded"));
    const principalMinor = total(installments.map(stryMutAct_9fa48("7653") ? () => undefined : (stryCov_9fa48("7653"), item => item.principalMinor)));
    const premiumMinor = total(installments.map(stryMutAct_9fa48("7654") ? () => undefined : (stryCov_9fa48("7654"), item => item.premiumMinor)));
    const sources = remainingSources(plan, paid);
    const shares = proportional(principalMinor, sources, stryMutAct_9fa48("7655") ? () => undefined : (stryCov_9fa48("7655"), source => source.principalMinor));
    return stryMutAct_9fa48("7656") ? {} : (stryCov_9fa48("7656"), {
      planId: plan.id,
      amountMinor: amount,
      principalMinor,
      premiumMinor,
      installments,
      sources: shares.map(stryMutAct_9fa48("7657") ? () => undefined : (stryCov_9fa48("7657"), ({
        part,
        amountMinor
      }) => stryMutAct_9fa48("7658") ? {} : (stryCov_9fa48("7658"), {
        entryId: part.entryId,
        principalMinor: amountMinor
      })))
    });
  }
}