// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { requireWorkspace } from "../accounting/membership";
import { periodFromAccountingDate } from "../accounting/period";
import type { Actor } from "../accounting/types";
import { minor, RecoveryError, text, total } from "./amounts";
import { countedAllocations, ownsSourceReservation, paidFor, planStatus, sourcePaid } from "./progress";
import type { AvailableCashInput, RecoveryLedger, RecoveryReadStore } from "./types";
type QueryInput = {
  actor: Actor;
  workspaceId: string;
};
export function createRecoveryQueries(store: RecoveryReadStore, ledger: RecoveryLedger, now: () => number = Date.now) {
  if (stryMutAct_9fa48("8613")) {
    {}
  } else {
    stryCov_9fa48("8613");
    async function state(input: QueryInput, asKnownAt: number | undefined = undefined, throughDate = stryMutAct_9fa48("8614") ? "" : (stryCov_9fa48("8614"), "9999-12-31")) {
      if (stryMutAct_9fa48("8615")) {
        {}
      } else {
        stryCov_9fa48("8615");
        const readAt = now();
        const isCurrent = stryMutAct_9fa48("8618") ? asKnownAt === undefined && asKnownAt === readAt : stryMutAct_9fa48("8617") ? false : stryMutAct_9fa48("8616") ? true : (stryCov_9fa48("8616", "8617", "8618"), (stryMutAct_9fa48("8620") ? asKnownAt !== undefined : stryMutAct_9fa48("8619") ? false : (stryCov_9fa48("8619", "8620"), asKnownAt === undefined)) || (stryMutAct_9fa48("8622") ? asKnownAt !== readAt : stryMutAct_9fa48("8621") ? false : (stryCov_9fa48("8621", "8622"), asKnownAt === readAt)));
        stryMutAct_9fa48("8623") ? asKnownAt &&= readAt : (stryCov_9fa48("8623"), asKnownAt ??= readAt);
        const workspace = await requireWorkspace(ledger, input.workspaceId, input.actor);
        if (stryMutAct_9fa48("8626") ? workspace.kind !== "Personal" || workspace.kind !== "Household" : stryMutAct_9fa48("8625") ? false : stryMutAct_9fa48("8624") ? true : (stryCov_9fa48("8624", "8625", "8626"), (stryMutAct_9fa48("8628") ? workspace.kind === "Personal" : stryMutAct_9fa48("8627") ? true : (stryCov_9fa48("8627", "8628"), workspace.kind !== (stryMutAct_9fa48("8629") ? "" : (stryCov_9fa48("8629"), "Personal")))) && (stryMutAct_9fa48("8631") ? workspace.kind === "Household" : stryMutAct_9fa48("8630") ? true : (stryCov_9fa48("8630", "8631"), workspace.kind !== (stryMutAct_9fa48("8632") ? "" : (stryCov_9fa48("8632"), "Household")))))) throw new RecoveryError(stryMutAct_9fa48("8634") ? "" : (stryCov_9fa48("8634"), "recovery_workspace_ineligible"));
        if (stryMutAct_9fa48("8637") ? (!Number.isFinite(asKnownAt) || asKnownAt < 0) && asKnownAt > readAt : stryMutAct_9fa48("8636") ? false : stryMutAct_9fa48("8635") ? true : (stryCov_9fa48("8635", "8636", "8637"), (stryMutAct_9fa48("8639") ? !Number.isFinite(asKnownAt) && asKnownAt < 0 : stryMutAct_9fa48("8638") ? false : (stryCov_9fa48("8638", "8639"), (stryMutAct_9fa48("8640") ? Number.isFinite(asKnownAt) : (stryCov_9fa48("8640"), !Number.isFinite(asKnownAt))) || (stryMutAct_9fa48("8643") ? asKnownAt >= 0 : stryMutAct_9fa48("8642") ? asKnownAt <= 0 : stryMutAct_9fa48("8641") ? false : (stryCov_9fa48("8641", "8642", "8643"), asKnownAt < 0)))) || (stryMutAct_9fa48("8646") ? asKnownAt <= readAt : stryMutAct_9fa48("8645") ? asKnownAt >= readAt : stryMutAct_9fa48("8644") ? false : (stryCov_9fa48("8644", "8645", "8646"), asKnownAt > readAt)))) throw new RecoveryError(stryMutAct_9fa48("8648") ? "" : (stryCov_9fa48("8648"), "recovery_recording_time_invalid"));
        const stored = await store.snapshot(input.workspaceId);
        const snapshot = stryMutAct_9fa48("8649") ? {} : (stryCov_9fa48("8649"), {
          ...stored,
          plans: isCurrent ? stored.plans : stryMutAct_9fa48("8650") ? stored.plans : (stryCov_9fa48("8650"), stored.plans.filter(stryMutAct_9fa48("8651") ? () => undefined : (stryCov_9fa48("8651"), plan => stryMutAct_9fa48("8654") ? plan.state.kind === "Activated" || plan.state.commitment.activatedAt <= asKnownAt : stryMutAct_9fa48("8653") ? false : stryMutAct_9fa48("8652") ? true : (stryCov_9fa48("8652", "8653", "8654"), (stryMutAct_9fa48("8656") ? plan.state.kind !== "Activated" : stryMutAct_9fa48("8655") ? true : (stryCov_9fa48("8655", "8656"), plan.state.kind === (stryMutAct_9fa48("8657") ? "" : (stryCov_9fa48("8657"), "Activated")))) && (stryMutAct_9fa48("8660") ? plan.state.commitment.activatedAt > asKnownAt : stryMutAct_9fa48("8659") ? plan.state.commitment.activatedAt < asKnownAt : stryMutAct_9fa48("8658") ? true : (stryCov_9fa48("8658", "8659", "8660"), plan.state.commitment.activatedAt <= asKnownAt))))))
        });
        const counted = await countedAllocations(ledger, snapshot, asKnownAt, throughDate);
        const all = stryMutAct_9fa48("8661") ? [] : (stryCov_9fa48("8661"), [...counted.verified, ...counted.declared]);
        const plans = await Promise.all(snapshot.plans.map(stryMutAct_9fa48("8662") ? () => undefined : (stryCov_9fa48("8662"), async plan => stryMutAct_9fa48("8663") ? {} : (stryCov_9fa48("8663"), {
          plan,
          status: await planStatus(ledger, snapshot, plan, all, asKnownAt),
          verified: paidFor(plan.id, counted.verified),
          declaredBaseline: paidFor(plan.id, counted.declared)
        }))));
        return stryMutAct_9fa48("8664") ? {} : (stryCov_9fa48("8664"), {
          workspace,
          snapshot,
          counted,
          all,
          plans,
          asKnownAt,
          isCurrent
        });
      }
    }
    return stryMutAct_9fa48("8665") ? {} : (stryCov_9fa48("8665"), {
      async progress(input: QueryInput & {
        asKnownAt?: number;
      }) {
        if (stryMutAct_9fa48("8666")) {
          {}
        } else {
          stryCov_9fa48("8666");
          const result = await state(input, input.asKnownAt);
          const balances = result.isCurrent ? await ledger.balances(input) : stryMutAct_9fa48("8667") ? ["Stryker was here"] : (stryCov_9fa48("8667"), []);
          return stryMutAct_9fa48("8668") ? {} : (stryCov_9fa48("8668"), {
            currency: result.workspace.functionalCurrency,
            asKnownAt: result.asKnownAt,
            plans: result.plans.map(stryMutAct_9fa48("8669") ? () => undefined : (stryCov_9fa48("8669"), item => stryMutAct_9fa48("8670") ? {} : (stryCov_9fa48("8670"), {
              ...item,
              destinationBalance: stryMutAct_9fa48("8671") ? balances.find(balance => balance.financialAccountProfileId === item.plan.terms.destinationProfileId)?.balance && null : (stryCov_9fa48("8671"), (stryMutAct_9fa48("8672") ? balances.find(balance => balance.financialAccountProfileId === item.plan.terms.destinationProfileId).balance : (stryCov_9fa48("8672"), balances.find(stryMutAct_9fa48("8673") ? () => undefined : (stryCov_9fa48("8673"), balance => stryMutAct_9fa48("8676") ? balance.financialAccountProfileId !== item.plan.terms.destinationProfileId : stryMutAct_9fa48("8675") ? false : stryMutAct_9fa48("8674") ? true : (stryCov_9fa48("8674", "8675", "8676"), balance.financialAccountProfileId === item.plan.terms.destinationProfileId)))?.balance)) ?? null)
            }))),
            contributions: result.counted.contributions.map(stryMutAct_9fa48("8677") ? () => undefined : (stryCov_9fa48("8677"), item => stryMutAct_9fa48("8678") ? {} : (stryCov_9fa48("8678"), {
              ...item.event,
              voided: item.voided,
              corrected: item.corrected
            }))),
            history: stryMutAct_9fa48("8679") ? result.snapshot.events : (stryCov_9fa48("8679"), result.snapshot.events.filter(stryMutAct_9fa48("8680") ? () => undefined : (stryCov_9fa48("8680"), event => stryMutAct_9fa48("8684") ? event.recordedAt > result.asKnownAt : stryMutAct_9fa48("8683") ? event.recordedAt < result.asKnownAt : stryMutAct_9fa48("8682") ? false : stryMutAct_9fa48("8681") ? true : (stryCov_9fa48("8681", "8682", "8683", "8684"), event.recordedAt <= result.asKnownAt))))
          });
        }
      },
      async listCandidates(input: QueryInput & {
        from: string;
        through: string;
      }) {
        if (stryMutAct_9fa48("8685")) {
          {}
        } else {
          stryCov_9fa48("8685");
          const result = await state(input);
          const expenses = await ledger.expenses(input);
          return expenses.map(expense => {
            if (stryMutAct_9fa48("8686")) {
              {}
            } else {
              stryCov_9fa48("8686");
              const decision = stryMutAct_9fa48("8687") ? result.snapshot.events.at(-1) : (stryCov_9fa48("8687"), result.snapshot.events.filter(stryMutAct_9fa48("8688") ? () => undefined : (stryCov_9fa48("8688"), event => stryMutAct_9fa48("8691") ? event.data.kind === "candidateDecision" || event.data.entryId === expense.entryId : stryMutAct_9fa48("8690") ? false : stryMutAct_9fa48("8689") ? true : (stryCov_9fa48("8689", "8690", "8691"), (stryMutAct_9fa48("8693") ? event.data.kind !== "candidateDecision" : stryMutAct_9fa48("8692") ? true : (stryCov_9fa48("8692", "8693"), event.data.kind === (stryMutAct_9fa48("8694") ? "" : (stryCov_9fa48("8694"), "candidateDecision")))) && (stryMutAct_9fa48("8696") ? event.data.entryId !== expense.entryId : stryMutAct_9fa48("8695") ? true : (stryCov_9fa48("8695", "8696"), event.data.entryId === expense.entryId))))).at(stryMutAct_9fa48("8697") ? +1 : (stryCov_9fa48("8697"), -1)));
              const recoveredPrincipalMinor = sourcePaid(expense.entryId, result.all);
              const reservedBy = stryMutAct_9fa48("8698") ? result.plans.find(item => ownsSourceReservation(result.snapshot, item.plan, result.asKnownAt) && item.plan.terms.sources.some(source => source.entryId === expense.entryId))?.plan.id && null : (stryCov_9fa48("8698"), (stryMutAct_9fa48("8699") ? result.plans.find(item => ownsSourceReservation(result.snapshot, item.plan, result.asKnownAt) && item.plan.terms.sources.some(source => source.entryId === expense.entryId)).plan.id : (stryCov_9fa48("8699"), result.plans.find(stryMutAct_9fa48("8700") ? () => undefined : (stryCov_9fa48("8700"), item => stryMutAct_9fa48("8703") ? ownsSourceReservation(result.snapshot, item.plan, result.asKnownAt) || item.plan.terms.sources.some(source => source.entryId === expense.entryId) : stryMutAct_9fa48("8702") ? false : stryMutAct_9fa48("8701") ? true : (stryCov_9fa48("8701", "8702", "8703"), ownsSourceReservation(result.snapshot, item.plan, result.asKnownAt) && (stryMutAct_9fa48("8704") ? item.plan.terms.sources.every(source => source.entryId === expense.entryId) : (stryCov_9fa48("8704"), item.plan.terms.sources.some(stryMutAct_9fa48("8705") ? () => undefined : (stryCov_9fa48("8705"), source => stryMutAct_9fa48("8708") ? source.entryId !== expense.entryId : stryMutAct_9fa48("8707") ? false : stryMutAct_9fa48("8706") ? true : (stryCov_9fa48("8706", "8707", "8708"), source.entryId === expense.entryId))))))))?.plan.id)) ?? null);
              return stryMutAct_9fa48("8709") ? {} : (stryCov_9fa48("8709"), {
                expense,
                decision: (stryMutAct_9fa48("8712") ? decision?.data.kind !== "candidateDecision" : stryMutAct_9fa48("8711") ? false : stryMutAct_9fa48("8710") ? true : (stryCov_9fa48("8710", "8711", "8712"), (stryMutAct_9fa48("8713") ? decision.data.kind : (stryCov_9fa48("8713"), decision?.data.kind)) === (stryMutAct_9fa48("8714") ? "" : (stryCov_9fa48("8714"), "candidateDecision")))) ? decision.data.decision : "eligible" as const,
                recoveredPrincipalMinor,
                remainingEligibleMinor: expense.reversal ? 0 : stryMutAct_9fa48("8715") ? Math.min(0, expense.currentEligibleAmount.minorUnits - recoveredPrincipalMinor) : (stryCov_9fa48("8715"), Math.max(0, stryMutAct_9fa48("8716") ? expense.currentEligibleAmount.minorUnits + recoveredPrincipalMinor : (stryCov_9fa48("8716"), expense.currentEligibleAmount.minorUnits - recoveredPrincipalMinor))),
                reservedBy
              });
            }
          });
        }
      },
      async monthlyWaterfall(input: QueryInput & {
        month: string;
        cash: AvailableCashInput;
        includePrepayment: boolean;
      }) {
        if (stryMutAct_9fa48("8717")) {
          {}
        } else {
          stryCov_9fa48("8717");
          periodFromAccountingDate(stryMutAct_9fa48("8719") ? `` : (stryCov_9fa48("8719"), `${input.month}-01`));
          const monthEnd = new Date(stryMutAct_9fa48("8720") ? `` : (stryCov_9fa48("8720"), `${input.month}-01T00:00:00.000Z`));
          stryMutAct_9fa48("8722") ? monthEnd.setUTCFullYear(monthEnd.getUTCMonth() + 1) : (stryCov_9fa48("8722"), monthEnd.setUTCMonth(stryMutAct_9fa48("8723") ? monthEnd.getUTCMonth() - 1 : (stryCov_9fa48("8723"), monthEnd.getUTCMonth() + 1)));
          stryMutAct_9fa48("8725") ? monthEnd.setTime(0) : (stryCov_9fa48("8725"), monthEnd.setUTCDate(0));
          const throughDate = stryMutAct_9fa48("8726") ? monthEnd.toISOString() : (stryCov_9fa48("8726"), monthEnd.toISOString().slice(0, 10));
          const result = await state(input, undefined, throughDate);
          const protections = input.cash.protections;
          if (stryMutAct_9fa48("8727")) {
            ;
          } else {
            stryCov_9fa48("8727");
            text(protections.provenance);
          }
          const protectedMinor = total(stryMutAct_9fa48("8728") ? [] : (stryCov_9fa48("8728"), [protections.essentialSpendingMinor, protections.taxesMinor, protections.requiredReservesMinor, protections.externalObligationsMinor]));
          let availableMinor: number;
          let ledgerCashMinor: number | null = null;
          const selectedBalances = stryMutAct_9fa48("8729") ? ["Stryker was here"] : (stryCov_9fa48("8729"), []);
          if (stryMutAct_9fa48("8732") ? input.cash.kind !== "entered" : stryMutAct_9fa48("8731") ? false : stryMutAct_9fa48("8730") ? true : (stryCov_9fa48("8730", "8731", "8732"), input.cash.kind === (stryMutAct_9fa48("8733") ? "" : (stryCov_9fa48("8733"), "entered")))) {
            if (stryMutAct_9fa48("8734")) {
              {}
            } else {
              stryCov_9fa48("8734");
              availableMinor = minor(input.cash.availableMinor);
              if (stryMutAct_9fa48("8735")) {
                ;
              } else {
                stryCov_9fa48("8735");
                text(input.cash.attestation);
              }
            }
          } else {
            if (stryMutAct_9fa48("8736")) {
              {}
            } else {
              stryCov_9fa48("8736");
              if (stryMutAct_9fa48("8739") ? !input.cash.liquidProfileIds.length && new Set(input.cash.liquidProfileIds).size !== input.cash.liquidProfileIds.length : stryMutAct_9fa48("8738") ? false : stryMutAct_9fa48("8737") ? true : (stryCov_9fa48("8737", "8738", "8739"), (stryMutAct_9fa48("8740") ? input.cash.liquidProfileIds.length : (stryCov_9fa48("8740"), !input.cash.liquidProfileIds.length)) || (stryMutAct_9fa48("8742") ? new Set(input.cash.liquidProfileIds).size === input.cash.liquidProfileIds.length : stryMutAct_9fa48("8741") ? false : (stryCov_9fa48("8741", "8742"), new Set(input.cash.liquidProfileIds).size !== input.cash.liquidProfileIds.length)))) throw new RecoveryError(stryMutAct_9fa48("8744") ? "" : (stryCov_9fa48("8744"), "recovery_cash_profiles_invalid"));
              const balances = await ledger.balances(input);
              for (const id of input.cash.liquidProfileIds) {
                if (stryMutAct_9fa48("8745")) {
                  {}
                } else {
                  stryCov_9fa48("8745");
                  const balance = balances.find(stryMutAct_9fa48("8746") ? () => undefined : (stryCov_9fa48("8746"), balance => stryMutAct_9fa48("8749") ? balance.financialAccountProfileId !== id : stryMutAct_9fa48("8748") ? false : stryMutAct_9fa48("8747") ? true : (stryCov_9fa48("8747", "8748", "8749"), balance.financialAccountProfileId === id)));
                  if (stryMutAct_9fa48("8752") ? !balance && balance.nature !== "Asset" : stryMutAct_9fa48("8751") ? false : stryMutAct_9fa48("8750") ? true : (stryCov_9fa48("8750", "8751", "8752"), (stryMutAct_9fa48("8753") ? balance : (stryCov_9fa48("8753"), !balance)) || (stryMutAct_9fa48("8755") ? balance.nature === "Asset" : stryMutAct_9fa48("8754") ? false : (stryCov_9fa48("8754", "8755"), balance.nature !== (stryMutAct_9fa48("8756") ? "" : (stryCov_9fa48("8756"), "Asset")))))) throw new RecoveryError(stryMutAct_9fa48("8758") ? "" : (stryCov_9fa48("8758"), "recovery_cash_profile_ineligible"));
                  if (stryMutAct_9fa48("8759")) {
                    ;
                  } else {
                    stryCov_9fa48("8759");
                    selectedBalances.push(balance);
                  }
                }
              }
              const sum = selectedBalances.reduce(stryMutAct_9fa48("8760") ? () => undefined : (stryCov_9fa48("8760"), (sum, balance) => stryMutAct_9fa48("8761") ? sum - BigInt(balance.balance.minorUnits) : (stryCov_9fa48("8761"), sum + BigInt(balance.balance.minorUnits))), 0n);
              const safe = Number(sum);
              if (stryMutAct_9fa48("8764") ? false : stryMutAct_9fa48("8763") ? true : stryMutAct_9fa48("8762") ? Number.isSafeInteger(safe) : (stryCov_9fa48("8762", "8763", "8764"), !Number.isSafeInteger(safe))) throw new RecoveryError(stryMutAct_9fa48("8766") ? "" : (stryCov_9fa48("8766"), "recovery_amount_invalid"));
              ledgerCashMinor = safe;
              availableMinor = stryMutAct_9fa48("8767") ? Math.min(0, safe - protectedMinor) : (stryCov_9fa48("8767"), Math.max(0, stryMutAct_9fa48("8768") ? safe + protectedMinor : (stryCov_9fa48("8768"), safe - protectedMinor)));
            }
          }
          type Due = {
            planId: string;
            installmentIndex: number;
            month: string;
            outstandingMinor: number;
          };
          const shortfalls: Due[] = stryMutAct_9fa48("8769") ? ["Stryker was here"] : (stryCov_9fa48("8769"), []);
          const current: Due[] = stryMutAct_9fa48("8770") ? ["Stryker was here"] : (stryCov_9fa48("8770"), []);
          const prepayment: Due[] = stryMutAct_9fa48("8771") ? ["Stryker was here"] : (stryCov_9fa48("8771"), []);
          for (const item of result.plans) {
            if (stryMutAct_9fa48("8772")) {
              {}
            } else {
              stryCov_9fa48("8772");
              if (stryMutAct_9fa48("8775") ? item.status.kind !== "Active" && item.plan.state.kind !== "Activated" : stryMutAct_9fa48("8774") ? false : stryMutAct_9fa48("8773") ? true : (stryCov_9fa48("8773", "8774", "8775"), (stryMutAct_9fa48("8777") ? item.status.kind === "Active" : stryMutAct_9fa48("8776") ? false : (stryCov_9fa48("8776", "8777"), item.status.kind !== (stryMutAct_9fa48("8778") ? "" : (stryCov_9fa48("8778"), "Active")))) || (stryMutAct_9fa48("8780") ? item.plan.state.kind === "Activated" : stryMutAct_9fa48("8779") ? false : (stryCov_9fa48("8779", "8780"), item.plan.state.kind !== (stryMutAct_9fa48("8781") ? "" : (stryCov_9fa48("8781"), "Activated")))))) continue;
              for (const [index, installment] of item.plan.state.commitment.schedule.entries()) {
                if (stryMutAct_9fa48("8782")) {
                  {}
                } else {
                  stryCov_9fa48("8782");
                  const paid = total(stryMutAct_9fa48("8784") ? result.all.flatMap(allocation => allocation.installments).filter(allocation => allocation.installmentIndex === index).map(allocation => total([allocation.principalMinor, allocation.premiumMinor])) : stryMutAct_9fa48("8783") ? result.all.filter(allocation => allocation.planId === item.plan.id).flatMap(allocation => allocation.installments).map(allocation => total([allocation.principalMinor, allocation.premiumMinor])) : (stryCov_9fa48("8783", "8784"), result.all.filter(stryMutAct_9fa48("8785") ? () => undefined : (stryCov_9fa48("8785"), allocation => stryMutAct_9fa48("8788") ? allocation.planId !== item.plan.id : stryMutAct_9fa48("8787") ? false : stryMutAct_9fa48("8786") ? true : (stryCov_9fa48("8786", "8787", "8788"), allocation.planId === item.plan.id))).flatMap(stryMutAct_9fa48("8789") ? () => undefined : (stryCov_9fa48("8789"), allocation => allocation.installments)).filter(stryMutAct_9fa48("8790") ? () => undefined : (stryCov_9fa48("8790"), allocation => stryMutAct_9fa48("8793") ? allocation.installmentIndex !== index : stryMutAct_9fa48("8792") ? false : stryMutAct_9fa48("8791") ? true : (stryCov_9fa48("8791", "8792", "8793"), allocation.installmentIndex === index))).map(stryMutAct_9fa48("8794") ? () => undefined : (stryCov_9fa48("8794"), allocation => total(stryMutAct_9fa48("8795") ? [] : (stryCov_9fa48("8795"), [allocation.principalMinor, allocation.premiumMinor]))))));
                  const outstandingMinor = minor(stryMutAct_9fa48("8796") ? installment.amountMinor + paid : (stryCov_9fa48("8796"), installment.amountMinor - paid));
                  if (stryMutAct_9fa48("8799") ? outstandingMinor !== 0 : stryMutAct_9fa48("8798") ? false : stryMutAct_9fa48("8797") ? true : (stryCov_9fa48("8797", "8798", "8799"), outstandingMinor === 0)) continue;
                  const row = stryMutAct_9fa48("8800") ? {} : (stryCov_9fa48("8800"), {
                    planId: item.plan.id,
                    installmentIndex: index,
                    month: installment.month,
                    outstandingMinor
                  });
                  if (stryMutAct_9fa48("8804") ? installment.month >= input.month : stryMutAct_9fa48("8803") ? installment.month <= input.month : stryMutAct_9fa48("8802") ? false : stryMutAct_9fa48("8801") ? true : (stryCov_9fa48("8801", "8802", "8803", "8804"), installment.month < input.month)) {
                    if (stryMutAct_9fa48("8805")) {
                      ;
                    } else {
                      stryCov_9fa48("8805");
                      shortfalls.push(row);
                    }
                  } else if (stryMutAct_9fa48("8808") ? installment.month !== input.month : stryMutAct_9fa48("8807") ? false : stryMutAct_9fa48("8806") ? true : (stryCov_9fa48("8806", "8807", "8808"), installment.month === input.month)) {
                    if (stryMutAct_9fa48("8809")) {
                      ;
                    } else {
                      stryCov_9fa48("8809");
                      current.push(row);
                    }
                  } else if (stryMutAct_9fa48("8810")) {
                    ;
                  } else {
                    stryCov_9fa48("8810");
                    prepayment.push(row);
                  }
                }
              }
            }
          }
          const ordered = stryMutAct_9fa48("8811") ? () => undefined : (stryCov_9fa48("8811"), (() => {
            const ordered = (rows: Due[]) => stryMutAct_9fa48("8812") ? rows : (stryCov_9fa48("8812"), rows.sort(stryMutAct_9fa48("8813") ? () => undefined : (stryCov_9fa48("8813"), (a, b) => stryMutAct_9fa48("8816") ? (a.month.localeCompare(b.month) || a.planId.localeCompare(b.planId)) && a.installmentIndex - b.installmentIndex : stryMutAct_9fa48("8815") ? false : stryMutAct_9fa48("8814") ? true : (stryCov_9fa48("8814", "8815", "8816"), (stryMutAct_9fa48("8818") ? a.month.localeCompare(b.month) && a.planId.localeCompare(b.planId) : stryMutAct_9fa48("8817") ? false : (stryCov_9fa48("8817", "8818"), a.month.localeCompare(b.month) || a.planId.localeCompare(b.planId))) || (stryMutAct_9fa48("8819") ? a.installmentIndex + b.installmentIndex : (stryCov_9fa48("8819"), a.installmentIndex - b.installmentIndex))))));
            return ordered;
          })());
          let cash = availableMinor;
          const fund = stryMutAct_9fa48("8820") ? () => undefined : (stryCov_9fa48("8820"), (() => {
            const fund = <Row extends {
              outstandingMinor: number;
            },>(rows: Row[]) => rows.map(row => {
              if (stryMutAct_9fa48("8821")) {
                {}
              } else {
                stryCov_9fa48("8821");
                const allocatedMinor = stryMutAct_9fa48("8822") ? Math.max(cash, row.outstandingMinor) : (stryCov_9fa48("8822"), Math.min(cash, row.outstandingMinor));
                stryMutAct_9fa48("8823") ? cash += allocatedMinor : (stryCov_9fa48("8823"), cash -= allocatedMinor);
                return stryMutAct_9fa48("8824") ? {} : (stryCov_9fa48("8824"), {
                  ...row,
                  allocatedMinor
                });
              }
            });
            return fund;
          })());
          const combinedRecoveryPaymentMinor = total((stryMutAct_9fa48("8825") ? [] : (stryCov_9fa48("8825"), [...shortfalls, ...current])).map(stryMutAct_9fa48("8826") ? () => undefined : (stryCov_9fa48("8826"), row => row.outstandingMinor)));
          const shortfallFunding = fund(ordered(shortfalls));
          const currentFunding = fund(ordered(current));
          const expenses = await ledger.expenses(stryMutAct_9fa48("8827") ? {} : (stryCov_9fa48("8827"), {
            ...input,
            from: stryMutAct_9fa48("8828") ? "" : (stryCov_9fa48("8828"), "0100-01-01"),
            through: throughDate
          }));
          const candidates = stryMutAct_9fa48("8831") ? expenses.filter(expense => {
            const decision = result.snapshot.events.filter(event => event.data.kind === "candidateDecision" && event.data.entryId === expense.entryId).at(-1);
            return (!decision || decision.data.kind === "candidateDecision" && decision.data.decision === "eligible") && !result.plans.some(item => ownsSourceReservation(result.snapshot, item.plan, result.asKnownAt) && item.plan.terms.sources.some(source => source.entryId === expense.entryId));
          }).sort((a, b) => a.accountingDate.localeCompare(b.accountingDate) || a.entryId.localeCompare(b.entryId)).map(expense => ({
            entryId: expense.entryId,
            outstandingMinor: Math.max(0, expense.currentEligibleAmount.minorUnits - sourcePaid(expense.entryId, result.all))
          })) : stryMutAct_9fa48("8830") ? expenses.filter(expense => !expense.reversal).sort((a, b) => a.accountingDate.localeCompare(b.accountingDate) || a.entryId.localeCompare(b.entryId)).map(expense => ({
            entryId: expense.entryId,
            outstandingMinor: Math.max(0, expense.currentEligibleAmount.minorUnits - sourcePaid(expense.entryId, result.all))
          })) : stryMutAct_9fa48("8829") ? expenses.filter(expense => !expense.reversal).filter(expense => {
            const decision = result.snapshot.events.filter(event => event.data.kind === "candidateDecision" && event.data.entryId === expense.entryId).at(-1);
            return (!decision || decision.data.kind === "candidateDecision" && decision.data.decision === "eligible") && !result.plans.some(item => ownsSourceReservation(result.snapshot, item.plan, result.asKnownAt) && item.plan.terms.sources.some(source => source.entryId === expense.entryId));
          }).map(expense => ({
            entryId: expense.entryId,
            outstandingMinor: Math.max(0, expense.currentEligibleAmount.minorUnits - sourcePaid(expense.entryId, result.all))
          })) : (stryCov_9fa48("8829", "8830", "8831"), expenses.filter(stryMutAct_9fa48("8832") ? () => undefined : (stryCov_9fa48("8832"), expense => stryMutAct_9fa48("8833") ? expense.reversal : (stryCov_9fa48("8833"), !expense.reversal))).filter(expense => {
            if (stryMutAct_9fa48("8834")) {
              {}
            } else {
              stryCov_9fa48("8834");
              const decision = stryMutAct_9fa48("8835") ? result.snapshot.events.at(-1) : (stryCov_9fa48("8835"), result.snapshot.events.filter(stryMutAct_9fa48("8836") ? () => undefined : (stryCov_9fa48("8836"), event => stryMutAct_9fa48("8839") ? event.data.kind === "candidateDecision" || event.data.entryId === expense.entryId : stryMutAct_9fa48("8838") ? false : stryMutAct_9fa48("8837") ? true : (stryCov_9fa48("8837", "8838", "8839"), (stryMutAct_9fa48("8841") ? event.data.kind !== "candidateDecision" : stryMutAct_9fa48("8840") ? true : (stryCov_9fa48("8840", "8841"), event.data.kind === (stryMutAct_9fa48("8842") ? "" : (stryCov_9fa48("8842"), "candidateDecision")))) && (stryMutAct_9fa48("8844") ? event.data.entryId !== expense.entryId : stryMutAct_9fa48("8843") ? true : (stryCov_9fa48("8843", "8844"), event.data.entryId === expense.entryId))))).at(stryMutAct_9fa48("8845") ? +1 : (stryCov_9fa48("8845"), -1)));
              return stryMutAct_9fa48("8848") ? !decision || decision.data.kind === "candidateDecision" && decision.data.decision === "eligible" || !result.plans.some(item => ownsSourceReservation(result.snapshot, item.plan, result.asKnownAt) && item.plan.terms.sources.some(source => source.entryId === expense.entryId)) : stryMutAct_9fa48("8847") ? false : stryMutAct_9fa48("8846") ? true : (stryCov_9fa48("8846", "8847", "8848"), (stryMutAct_9fa48("8850") ? !decision && decision.data.kind === "candidateDecision" && decision.data.decision === "eligible" : stryMutAct_9fa48("8849") ? true : (stryCov_9fa48("8849", "8850"), (stryMutAct_9fa48("8851") ? decision : (stryCov_9fa48("8851"), !decision)) || (stryMutAct_9fa48("8853") ? decision.data.kind === "candidateDecision" || decision.data.decision === "eligible" : stryMutAct_9fa48("8852") ? false : (stryCov_9fa48("8852", "8853"), (stryMutAct_9fa48("8855") ? decision.data.kind !== "candidateDecision" : stryMutAct_9fa48("8854") ? true : (stryCov_9fa48("8854", "8855"), decision.data.kind === (stryMutAct_9fa48("8856") ? "" : (stryCov_9fa48("8856"), "candidateDecision")))) && (stryMutAct_9fa48("8858") ? decision.data.decision !== "eligible" : stryMutAct_9fa48("8857") ? true : (stryCov_9fa48("8857", "8858"), decision.data.decision === (stryMutAct_9fa48("8859") ? "" : (stryCov_9fa48("8859"), "eligible")))))))) && (stryMutAct_9fa48("8860") ? result.plans.some(item => ownsSourceReservation(result.snapshot, item.plan, result.asKnownAt) && item.plan.terms.sources.some(source => source.entryId === expense.entryId)) : (stryCov_9fa48("8860"), !(stryMutAct_9fa48("8861") ? result.plans.every(item => ownsSourceReservation(result.snapshot, item.plan, result.asKnownAt) && item.plan.terms.sources.some(source => source.entryId === expense.entryId)) : (stryCov_9fa48("8861"), result.plans.some(stryMutAct_9fa48("8862") ? () => undefined : (stryCov_9fa48("8862"), item => stryMutAct_9fa48("8865") ? ownsSourceReservation(result.snapshot, item.plan, result.asKnownAt) || item.plan.terms.sources.some(source => source.entryId === expense.entryId) : stryMutAct_9fa48("8864") ? false : stryMutAct_9fa48("8863") ? true : (stryCov_9fa48("8863", "8864", "8865"), ownsSourceReservation(result.snapshot, item.plan, result.asKnownAt) && (stryMutAct_9fa48("8866") ? item.plan.terms.sources.every(source => source.entryId === expense.entryId) : (stryCov_9fa48("8866"), item.plan.terms.sources.some(stryMutAct_9fa48("8867") ? () => undefined : (stryCov_9fa48("8867"), source => stryMutAct_9fa48("8870") ? source.entryId !== expense.entryId : stryMutAct_9fa48("8869") ? false : stryMutAct_9fa48("8868") ? true : (stryCov_9fa48("8868", "8869", "8870"), source.entryId === expense.entryId)))))))))))));
            }
          }).sort(stryMutAct_9fa48("8871") ? () => undefined : (stryCov_9fa48("8871"), (a, b) => stryMutAct_9fa48("8874") ? a.accountingDate.localeCompare(b.accountingDate) && a.entryId.localeCompare(b.entryId) : stryMutAct_9fa48("8873") ? false : stryMutAct_9fa48("8872") ? true : (stryCov_9fa48("8872", "8873", "8874"), a.accountingDate.localeCompare(b.accountingDate) || a.entryId.localeCompare(b.entryId)))).map(stryMutAct_9fa48("8875") ? () => undefined : (stryCov_9fa48("8875"), expense => stryMutAct_9fa48("8876") ? {} : (stryCov_9fa48("8876"), {
            entryId: expense.entryId,
            outstandingMinor: stryMutAct_9fa48("8877") ? Math.min(0, expense.currentEligibleAmount.minorUnits - sourcePaid(expense.entryId, result.all)) : (stryCov_9fa48("8877"), Math.max(0, stryMutAct_9fa48("8878") ? expense.currentEligibleAmount.minorUnits + sourcePaid(expense.entryId, result.all) : (stryCov_9fa48("8878"), expense.currentEligibleAmount.minorUnits - sourcePaid(expense.entryId, result.all))))
          }))));
          const candidateFunding = fund(candidates);
          const prepaymentFunding = input.includePrepayment ? fund(ordered(prepayment)) : stryMutAct_9fa48("8879") ? ["Stryker was here"] : (stryCov_9fa48("8879"), []);
          return stryMutAct_9fa48("8880") ? {} : (stryCov_9fa48("8880"), {
            month: input.month,
            currency: result.workspace.functionalCurrency,
            availableCash: stryMutAct_9fa48("8881") ? {} : (stryCov_9fa48("8881"), {
              mode: input.cash.kind,
              availableMinor,
              ledgerCashMinor,
              selectedBalances,
              protectedMinor,
              protectionInputs: protections,
              attestation: (stryMutAct_9fa48("8884") ? input.cash.kind !== "entered" : stryMutAct_9fa48("8883") ? false : stryMutAct_9fa48("8882") ? true : (stryCov_9fa48("8882", "8883", "8884"), input.cash.kind === (stryMutAct_9fa48("8885") ? "" : (stryCov_9fa48("8885"), "entered")))) ? input.cash.attestation : null,
              coverage: "user-declared-protections-only" as const,
              unmodeledObligationsProtected: false as const
            }),
            combinedRecoveryPaymentMinor,
            shortfalls: shortfallFunding,
            currentInstallments: currentFunding,
            expenseRecovery: candidateFunding,
            prepayment: prepaymentFunding,
            ordinarySavingMinor: cash
          });
        }
      }
    });
  }
}