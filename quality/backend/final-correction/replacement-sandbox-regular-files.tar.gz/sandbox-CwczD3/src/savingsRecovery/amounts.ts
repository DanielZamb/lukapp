// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
export class RecoveryError extends Error {
  constructor(readonly code: string) {
    super(code);
  }
}
export function minor(value: number, positive = stryMutAct_9fa48("7659") ? true : (stryCov_9fa48("7659"), false)): number {
  if (stryMutAct_9fa48("7660")) {
    {}
  } else {
    stryCov_9fa48("7660");
    if (stryMutAct_9fa48("7663") ? !Number.isSafeInteger(value) && value < (positive ? 1 : 0) : stryMutAct_9fa48("7662") ? false : stryMutAct_9fa48("7661") ? true : (stryCov_9fa48("7661", "7662", "7663"), (stryMutAct_9fa48("7664") ? Number.isSafeInteger(value) : (stryCov_9fa48("7664"), !Number.isSafeInteger(value))) || (stryMutAct_9fa48("7667") ? value >= (positive ? 1 : 0) : stryMutAct_9fa48("7666") ? value <= (positive ? 1 : 0) : stryMutAct_9fa48("7665") ? false : (stryCov_9fa48("7665", "7666", "7667"), value < (positive ? 1 : 0))))) throw new RecoveryError(stryMutAct_9fa48("7669") ? "" : (stryCov_9fa48("7669"), "recovery_amount_invalid"));
    return value;
  }
}
export function total(values: number[]): number {
  if (stryMutAct_9fa48("7670")) {
    {}
  } else {
    stryCov_9fa48("7670");
    return minor(Number(values.reduce(stryMutAct_9fa48("7671") ? () => undefined : (stryCov_9fa48("7671"), (sum, value) => stryMutAct_9fa48("7672") ? sum - BigInt(minor(value)) : (stryCov_9fa48("7672"), sum + BigInt(minor(value)))), 0n)));
  }
}
export function proportional<T>(amount: number, parts: readonly T[], weight: (part: T) => number) {
  if (stryMutAct_9fa48("7673")) {
    {}
  } else {
    stryCov_9fa48("7673");
    const weighted = parts.map(stryMutAct_9fa48("7674") ? () => undefined : (stryCov_9fa48("7674"), part => stryMutAct_9fa48("7675") ? {} : (stryCov_9fa48("7675"), {
      part,
      weight: weight(part)
    })));
    const weights = weighted.map(stryMutAct_9fa48("7676") ? () => undefined : (stryCov_9fa48("7676"), item => item.weight));
    const sum = total(weights);
    if (stryMutAct_9fa48("7679") ? amount !== 0 : stryMutAct_9fa48("7678") ? false : stryMutAct_9fa48("7677") ? true : (stryCov_9fa48("7677", "7678", "7679"), amount === 0)) return weighted.map(stryMutAct_9fa48("7680") ? () => undefined : (stryCov_9fa48("7680"), ({
      part
    }) => stryMutAct_9fa48("7681") ? {} : (stryCov_9fa48("7681"), {
      part,
      amountMinor: 0
    })));
    if (stryMutAct_9fa48("7684") ? amount > sum && sum === 0 : stryMutAct_9fa48("7683") ? false : stryMutAct_9fa48("7682") ? true : (stryCov_9fa48("7682", "7683", "7684"), (stryMutAct_9fa48("7687") ? amount <= sum : stryMutAct_9fa48("7686") ? amount >= sum : stryMutAct_9fa48("7685") ? false : (stryCov_9fa48("7685", "7686", "7687"), amount > sum)) || (stryMutAct_9fa48("7689") ? sum !== 0 : stryMutAct_9fa48("7688") ? false : (stryCov_9fa48("7688", "7689"), sum === 0)))) throw new RecoveryError(stryMutAct_9fa48("7691") ? "" : (stryCov_9fa48("7691"), "recovery_capacity_exceeded"));
    const shares = weighted.map(stryMutAct_9fa48("7692") ? () => undefined : (stryCov_9fa48("7692"), ({
      part,
      weight
    }, index) => stryMutAct_9fa48("7693") ? {} : (stryCov_9fa48("7693"), {
      part,
      index,
      value: Number(stryMutAct_9fa48("7694") ? BigInt(amount) * BigInt(weight) * BigInt(sum) : (stryCov_9fa48("7694"), (stryMutAct_9fa48("7695") ? BigInt(amount) / BigInt(weight) : (stryCov_9fa48("7695"), BigInt(amount) * BigInt(weight))) / BigInt(sum))),
      residual: stryMutAct_9fa48("7696") ? BigInt(amount) * BigInt(weight) * BigInt(sum) : (stryCov_9fa48("7696"), (stryMutAct_9fa48("7697") ? BigInt(amount) / BigInt(weight) : (stryCov_9fa48("7697"), BigInt(amount) * BigInt(weight))) % BigInt(sum))
    })));
    let rest = stryMutAct_9fa48("7698") ? amount + total(shares.map(share => share.value)) : (stryCov_9fa48("7698"), amount - total(shares.map(stryMutAct_9fa48("7699") ? () => undefined : (stryCov_9fa48("7699"), share => share.value))));
    const order = stryMutAct_9fa48("7700") ? [...shares] : (stryCov_9fa48("7700"), (stryMutAct_9fa48("7701") ? [] : (stryCov_9fa48("7701"), [...shares])).sort(stryMutAct_9fa48("7702") ? () => undefined : (stryCov_9fa48("7702"), (a, b) => (stryMutAct_9fa48("7705") ? a.residual !== b.residual : stryMutAct_9fa48("7704") ? false : stryMutAct_9fa48("7703") ? true : (stryCov_9fa48("7703", "7704", "7705"), a.residual === b.residual)) ? stryMutAct_9fa48("7706") ? a.index + b.index : (stryCov_9fa48("7706"), a.index - b.index) : (stryMutAct_9fa48("7710") ? a.residual <= b.residual : stryMutAct_9fa48("7709") ? a.residual >= b.residual : stryMutAct_9fa48("7708") ? false : stryMutAct_9fa48("7707") ? true : (stryCov_9fa48("7707", "7708", "7709", "7710"), a.residual > b.residual)) ? stryMutAct_9fa48("7711") ? +1 : (stryCov_9fa48("7711"), -1) : 1)));
    for (const share of order) {
      if (stryMutAct_9fa48("7712")) {
        {}
      } else {
        stryCov_9fa48("7712");
        if (stryMutAct_9fa48("7715") ? rest !== 0 : stryMutAct_9fa48("7714") ? false : stryMutAct_9fa48("7713") ? true : (stryCov_9fa48("7713", "7714", "7715"), rest === 0)) break;
        stryMutAct_9fa48("7716") ? share.value-- : (stryCov_9fa48("7716"), share.value++);
        stryMutAct_9fa48("7717") ? rest++ : (stryCov_9fa48("7717"), rest--);
      }
    }
    return shares.map(stryMutAct_9fa48("7718") ? () => undefined : (stryCov_9fa48("7718"), ({
      part,
      value
    }) => stryMutAct_9fa48("7719") ? {} : (stryCov_9fa48("7719"), {
      part,
      amountMinor: value
    })));
  }
}
export function text(value: string): string {
  if (stryMutAct_9fa48("7720")) {
    {}
  } else {
    stryCov_9fa48("7720");
    if (stryMutAct_9fa48("7723") ? false : stryMutAct_9fa48("7722") ? true : stryMutAct_9fa48("7721") ? value.trim() : (stryCov_9fa48("7721", "7722", "7723"), !(stryMutAct_9fa48("7724") ? value : (stryCov_9fa48("7724"), value.trim())))) throw new RecoveryError(stryMutAct_9fa48("7726") ? "" : (stryCov_9fa48("7726"), "recovery_text_required"));
    return value;
  }
}