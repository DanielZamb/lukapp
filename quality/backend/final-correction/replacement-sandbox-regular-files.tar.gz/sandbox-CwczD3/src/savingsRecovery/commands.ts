// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { requireWorkspace } from "../accounting/membership";
import { periodFromAccountingDate } from "../accounting/period";
import { canonicalJson } from "../access/protocol";
import { allocate } from "./allocation";
import { minor, RecoveryError, text, total } from "./amounts";
import { countedAllocations, findPlan, ownsSourceReservation, planStatus, requireExclusiveSources, sourceExpense, sourcePaid, transferEvidence, validDate } from "./progress";
import { freezeSchedule } from "./schedule";
import type { AllocationIntent, CommandContext, ContributionAllocation, PlanTerms, RecoveryEventData, RecoveryLedger, RecoveryStore, Snapshot } from "./types";
export function createRecoveryCommands(store: RecoveryStore, ledger: RecoveryLedger, now: () => number = Date.now) {
  if (stryMutAct_9fa48("7727")) {
    {}
  } else {
    stryCov_9fa48("7727");
    async function command<Input extends CommandContext>(operation: string, input: Input, work: (snapshot: Snapshot, at: number, today: string) => Promise<string>) {
      if (stryMutAct_9fa48("7728")) {
        {}
      } else {
        stryCov_9fa48("7728");
        const workspace = await requireWorkspace(ledger, input.workspaceId, input.actor, stryMutAct_9fa48("7729") ? "" : (stryCov_9fa48("7729"), "manageRecoveryPlans"));
        if (stryMutAct_9fa48("7732") ? workspace.kind !== "Personal" || workspace.kind !== "Household" : stryMutAct_9fa48("7731") ? false : stryMutAct_9fa48("7730") ? true : (stryCov_9fa48("7730", "7731", "7732"), (stryMutAct_9fa48("7734") ? workspace.kind === "Personal" : stryMutAct_9fa48("7733") ? true : (stryCov_9fa48("7733", "7734"), workspace.kind !== (stryMutAct_9fa48("7735") ? "" : (stryCov_9fa48("7735"), "Personal")))) && (stryMutAct_9fa48("7737") ? workspace.kind === "Household" : stryMutAct_9fa48("7736") ? true : (stryCov_9fa48("7736", "7737"), workspace.kind !== (stryMutAct_9fa48("7738") ? "" : (stryCov_9fa48("7738"), "Household")))))) throw new RecoveryError(stryMutAct_9fa48("7740") ? "" : (stryCov_9fa48("7740"), "recovery_workspace_ineligible"));
        if (stryMutAct_9fa48("7741")) {
          ;
        } else {
          stryCov_9fa48("7741");
          text(input.idempotencyKey);
        }
        const fingerprint = canonicalJson(stryMutAct_9fa48("7742") ? {} : (stryCov_9fa48("7742"), {
          operation,
          input
        }));
        const receipt = await store.receipt(input.workspaceId, input.idempotencyKey);
        if (stryMutAct_9fa48("7744") ? false : stryMutAct_9fa48("7743") ? true : (stryCov_9fa48("7743", "7744"), receipt)) {
          if (stryMutAct_9fa48("7745")) {
            {}
          } else {
            stryCov_9fa48("7745");
            if (stryMutAct_9fa48("7748") ? receipt.fingerprint === fingerprint : stryMutAct_9fa48("7747") ? false : stryMutAct_9fa48("7746") ? true : (stryCov_9fa48("7746", "7747", "7748"), receipt.fingerprint !== fingerprint)) throw new RecoveryError(stryMutAct_9fa48("7750") ? "" : (stryCov_9fa48("7750"), "idempotency_key_conflict"));
            return receipt.resultId;
          }
        }
        const at = now();
        const resultId = await work(await store.snapshot(input.workspaceId), at, stryMutAct_9fa48("7751") ? new Date(at).toISOString() : (stryCov_9fa48("7751"), new Date(at).toISOString().slice(0, 10)));
        await store.saveReceipt(input.workspaceId, input.idempotencyKey, stryMutAct_9fa48("7752") ? {} : (stryCov_9fa48("7752"), {
          fingerprint,
          resultId
        }));
        return resultId;
      }
    }
    function append(input: CommandContext, at: number, data: RecoveryEventData) {
      if (stryMutAct_9fa48("7753")) {
        {}
      } else {
        stryCov_9fa48("7753");
        return store.appendEvent(stryMutAct_9fa48("7754") ? {} : (stryCov_9fa48("7754"), {
          workspaceId: input.workspaceId,
          actorId: input.actor.userId,
          recordedAt: at,
          data
        }));
      }
    }
    function validateTerms(terms: PlanTerms) {
      if (stryMutAct_9fa48("7755")) {
        {}
      } else {
        stryCov_9fa48("7755");
        if (stryMutAct_9fa48("7756")) {
          ;
        } else {
          stryCov_9fa48("7756");
          text(terms.name);
        }
        if (stryMutAct_9fa48("7759") ? !terms.sources.length && new Set(terms.sources.map(source => source.entryId)).size !== terms.sources.length : stryMutAct_9fa48("7758") ? false : stryMutAct_9fa48("7757") ? true : (stryCov_9fa48("7757", "7758", "7759"), (stryMutAct_9fa48("7760") ? terms.sources.length : (stryCov_9fa48("7760"), !terms.sources.length)) || (stryMutAct_9fa48("7762") ? new Set(terms.sources.map(source => source.entryId)).size === terms.sources.length : stryMutAct_9fa48("7761") ? false : (stryCov_9fa48("7761", "7762"), new Set(terms.sources.map(stryMutAct_9fa48("7763") ? () => undefined : (stryCov_9fa48("7763"), source => source.entryId))).size !== terms.sources.length)))) throw new RecoveryError(stryMutAct_9fa48("7765") ? "" : (stryCov_9fa48("7765"), "recovery_sources_invalid"));
        terms.sources.forEach(stryMutAct_9fa48("7767") ? () => undefined : (stryCov_9fa48("7767"), source => minor(source.principalMinor, stryMutAct_9fa48("7768") ? false : (stryCov_9fa48("7768"), true))));
        freezeSchedule(terms, stryMutAct_9fa48("7770") ? "" : (stryCov_9fa48("7770"), "2000-01-01"), 0);
      }
    }
    async function contribution(input: CommandContext, snapshot: Snapshot, at: number, today: string, transferEntryId: string, intents: AllocationIntent[], intent: "explicit" | "acceptedProposal", proposalId: string | null) {
      if (stryMutAct_9fa48("7771")) {
        {}
      } else {
        stryCov_9fa48("7771");
        if (stryMutAct_9fa48("7774") ? !intents.length && new Set(intents.map(item => item.planId)).size !== intents.length : stryMutAct_9fa48("7773") ? false : stryMutAct_9fa48("7772") ? true : (stryCov_9fa48("7772", "7773", "7774"), (stryMutAct_9fa48("7775") ? intents.length : (stryCov_9fa48("7775"), !intents.length)) || (stryMutAct_9fa48("7777") ? new Set(intents.map(item => item.planId)).size === intents.length : stryMutAct_9fa48("7776") ? false : (stryCov_9fa48("7776", "7777"), new Set(intents.map(stryMutAct_9fa48("7778") ? () => undefined : (stryCov_9fa48("7778"), item => item.planId))).size !== intents.length)))) throw new RecoveryError(stryMutAct_9fa48("7780") ? "" : (stryCov_9fa48("7780"), "recovery_allocations_invalid"));
        const evidence = await transferEvidence(ledger, input.workspaceId, transferEntryId, today);
        const counted = await countedAllocations(ledger, snapshot, at);
        const consumed = total(stryMutAct_9fa48("7781") ? counted.contributions.flatMap(item => item.data.allocations.map(allocation => allocation.amountMinor)) : (stryCov_9fa48("7781"), counted.contributions.filter(stryMutAct_9fa48("7782") ? () => undefined : (stryCov_9fa48("7782"), item => stryMutAct_9fa48("7785") ? !item.corrected || item.data.transferEntryId === transferEntryId : stryMutAct_9fa48("7784") ? false : stryMutAct_9fa48("7783") ? true : (stryCov_9fa48("7783", "7784", "7785"), (stryMutAct_9fa48("7786") ? item.corrected : (stryCov_9fa48("7786"), !item.corrected)) && (stryMutAct_9fa48("7788") ? item.data.transferEntryId !== transferEntryId : stryMutAct_9fa48("7787") ? true : (stryCov_9fa48("7787", "7788"), item.data.transferEntryId === transferEntryId))))).flatMap(stryMutAct_9fa48("7789") ? () => undefined : (stryCov_9fa48("7789"), item => item.data.allocations.map(stryMutAct_9fa48("7790") ? () => undefined : (stryCov_9fa48("7790"), allocation => allocation.amountMinor))))));
        const amount = total(intents.map(stryMutAct_9fa48("7791") ? () => undefined : (stryCov_9fa48("7791"), item => minor(item.amountMinor, stryMutAct_9fa48("7792") ? false : (stryCov_9fa48("7792"), true)))));
        if (stryMutAct_9fa48("7796") ? total([consumed, amount]) <= evidence.capacityMinor : stryMutAct_9fa48("7795") ? total([consumed, amount]) >= evidence.capacityMinor : stryMutAct_9fa48("7794") ? false : stryMutAct_9fa48("7793") ? true : (stryCov_9fa48("7793", "7794", "7795", "7796"), total(stryMutAct_9fa48("7797") ? [] : (stryCov_9fa48("7797"), [consumed, amount])) > evidence.capacityMinor)) throw new RecoveryError(stryMutAct_9fa48("7799") ? "" : (stryCov_9fa48("7799"), "recovery_transfer_capacity_exceeded"));
        const paid = stryMutAct_9fa48("7800") ? [] : (stryCov_9fa48("7800"), [...counted.verified, ...counted.declared]);
        const allocations: ContributionAllocation[] = stryMutAct_9fa48("7801") ? ["Stryker was here"] : (stryCov_9fa48("7801"), []);
        for (const item of intents) {
          if (stryMutAct_9fa48("7802")) {
            {}
          } else {
            stryCov_9fa48("7802");
            const plan = findPlan(snapshot, item.planId);
            const status = await planStatus(ledger, snapshot, plan, paid, at);
            if (stryMutAct_9fa48("7805") ? status.kind !== "Active" && plan.state.kind !== "Activated" : stryMutAct_9fa48("7804") ? false : stryMutAct_9fa48("7803") ? true : (stryCov_9fa48("7803", "7804", "7805"), (stryMutAct_9fa48("7807") ? status.kind === "Active" : stryMutAct_9fa48("7806") ? false : (stryCov_9fa48("7806", "7807"), status.kind !== (stryMutAct_9fa48("7808") ? "" : (stryCov_9fa48("7808"), "Active")))) || (stryMutAct_9fa48("7810") ? plan.state.kind === "Activated" : stryMutAct_9fa48("7809") ? false : (stryCov_9fa48("7809", "7810"), plan.state.kind !== (stryMutAct_9fa48("7811") ? "" : (stryCov_9fa48("7811"), "Activated")))))) throw new RecoveryError(stryMutAct_9fa48("7813") ? "" : (stryCov_9fa48("7813"), "recovery_plan_inactive"));
            if (stryMutAct_9fa48("7817") ? evidence.entry.accountingDate >= plan.state.commitment.activatedOn : stryMutAct_9fa48("7816") ? evidence.entry.accountingDate <= plan.state.commitment.activatedOn : stryMutAct_9fa48("7815") ? false : stryMutAct_9fa48("7814") ? true : (stryCov_9fa48("7814", "7815", "7816", "7817"), evidence.entry.accountingDate < plan.state.commitment.activatedOn)) throw new RecoveryError(stryMutAct_9fa48("7819") ? "" : (stryCov_9fa48("7819"), "recovery_transfer_before_activation"));
            if (stryMutAct_9fa48("7820")) {
              ;
            } else {
              stryCov_9fa48("7820");
              requireExclusiveSources(snapshot, plan, at);
            }
            const destination = await ledger.getProfile(plan.terms.destinationProfileId);
            if (stryMutAct_9fa48("7823") ? destination?.postingAccountId === evidence.destinationAccountId : stryMutAct_9fa48("7822") ? false : stryMutAct_9fa48("7821") ? true : (stryCov_9fa48("7821", "7822", "7823"), (stryMutAct_9fa48("7824") ? destination.postingAccountId : (stryCov_9fa48("7824"), destination?.postingAccountId)) !== evidence.destinationAccountId)) throw new RecoveryError(stryMutAct_9fa48("7826") ? "" : (stryCov_9fa48("7826"), "recovery_destination_mismatch"));
            if (stryMutAct_9fa48("7827")) {
              ;
            } else {
              stryCov_9fa48("7827");
              allocations.push(allocate(plan, item.amountMinor, paid, evidence.entry.accountingDate));
            }
          }
        }
        return append(input, at, stryMutAct_9fa48("7828") ? {} : (stryCov_9fa48("7828"), {
          kind: stryMutAct_9fa48("7829") ? "" : (stryCov_9fa48("7829"), "contribution"),
          transferEntryId,
          contributionDate: evidence.entry.accountingDate,
          allocations,
          intent,
          proposalId
        }));
      }
    }
    return stryMutAct_9fa48("7830") ? {} : (stryCov_9fa48("7830"), {
      saveDraft(input: CommandContext & {
        planId: string | null;
        expectedRevision: number | null;
        terms: PlanTerms;
      }) {
        if (stryMutAct_9fa48("7831")) {
          {}
        } else {
          stryCov_9fa48("7831");
          return command(stryMutAct_9fa48("7832") ? "" : (stryCov_9fa48("7832"), "saveDraft"), input, async snapshot => {
            if (stryMutAct_9fa48("7833")) {
              {}
            } else {
              stryCov_9fa48("7833");
              if (stryMutAct_9fa48("7834")) {
                ;
              } else {
                stryCov_9fa48("7834");
                validateTerms(input.terms);
              }
              if (stryMutAct_9fa48("7837") ? input.planId !== null : stryMutAct_9fa48("7836") ? false : stryMutAct_9fa48("7835") ? true : (stryCov_9fa48("7835", "7836", "7837"), input.planId === null)) {
                if (stryMutAct_9fa48("7838")) {
                  {}
                } else {
                  stryCov_9fa48("7838");
                  if (stryMutAct_9fa48("7841") ? input.expectedRevision === null : stryMutAct_9fa48("7840") ? false : stryMutAct_9fa48("7839") ? true : (stryCov_9fa48("7839", "7840", "7841"), input.expectedRevision !== null)) throw new RecoveryError(stryMutAct_9fa48("7843") ? "" : (stryCov_9fa48("7843"), "recovery_draft_revision_conflict"));
                  return store.insertPlan(stryMutAct_9fa48("7844") ? {} : (stryCov_9fa48("7844"), {
                    workspaceId: input.workspaceId,
                    revision: 1,
                    terms: input.terms,
                    replacesPlanId: null,
                    state: stryMutAct_9fa48("7845") ? {} : (stryCov_9fa48("7845"), {
                      kind: stryMutAct_9fa48("7846") ? "" : (stryCov_9fa48("7846"), "Draft")
                    })
                  }));
                }
              }
              const plan = findPlan(snapshot, input.planId);
              if (stryMutAct_9fa48("7849") ? snapshot.events.every(event => event.data.kind === "cancelled" && event.data.planId === plan.id) : stryMutAct_9fa48("7848") ? false : stryMutAct_9fa48("7847") ? true : (stryCov_9fa48("7847", "7848", "7849"), snapshot.events.some(stryMutAct_9fa48("7850") ? () => undefined : (stryCov_9fa48("7850"), event => stryMutAct_9fa48("7853") ? event.data.kind === "cancelled" || event.data.planId === plan.id : stryMutAct_9fa48("7852") ? false : stryMutAct_9fa48("7851") ? true : (stryCov_9fa48("7851", "7852", "7853"), (stryMutAct_9fa48("7855") ? event.data.kind !== "cancelled" : stryMutAct_9fa48("7854") ? true : (stryCov_9fa48("7854", "7855"), event.data.kind === (stryMutAct_9fa48("7856") ? "" : (stryCov_9fa48("7856"), "cancelled")))) && (stryMutAct_9fa48("7858") ? event.data.planId !== plan.id : stryMutAct_9fa48("7857") ? true : (stryCov_9fa48("7857", "7858"), event.data.planId === plan.id))))))) throw new RecoveryError(stryMutAct_9fa48("7860") ? "" : (stryCov_9fa48("7860"), "recovery_plan_cancelled"));
              if (stryMutAct_9fa48("7863") ? plan.state.kind === "Draft" : stryMutAct_9fa48("7862") ? false : stryMutAct_9fa48("7861") ? true : (stryCov_9fa48("7861", "7862", "7863"), plan.state.kind !== (stryMutAct_9fa48("7864") ? "" : (stryCov_9fa48("7864"), "Draft")))) throw new RecoveryError(stryMutAct_9fa48("7866") ? "" : (stryCov_9fa48("7866"), "recovery_schedule_frozen"));
              if (stryMutAct_9fa48("7869") ? input.expectedRevision === plan.revision : stryMutAct_9fa48("7868") ? false : stryMutAct_9fa48("7867") ? true : (stryCov_9fa48("7867", "7868", "7869"), input.expectedRevision !== plan.revision)) throw new RecoveryError(stryMutAct_9fa48("7871") ? "" : (stryCov_9fa48("7871"), "recovery_draft_revision_conflict"));
              await store.updatePlan(stryMutAct_9fa48("7872") ? {} : (stryCov_9fa48("7872"), {
                ...plan,
                revision: stryMutAct_9fa48("7873") ? plan.revision - 1 : (stryCov_9fa48("7873"), plan.revision + 1),
                terms: input.terms
              }));
              return plan.id;
            }
          });
        }
      },
      activatePlan(input: CommandContext & {
        planId: string;
        expectedRevision: number;
      }) {
        if (stryMutAct_9fa48("7874")) {
          {}
        } else {
          stryCov_9fa48("7874");
          return command(stryMutAct_9fa48("7875") ? "" : (stryCov_9fa48("7875"), "activatePlan"), input, async (snapshot, at, today) => {
            if (stryMutAct_9fa48("7876")) {
              {}
            } else {
              stryCov_9fa48("7876");
              const plan = findPlan(snapshot, input.planId);
              if (stryMutAct_9fa48("7879") ? snapshot.events.every(event => event.data.kind === "cancelled" && event.data.planId === plan.id) : stryMutAct_9fa48("7878") ? false : stryMutAct_9fa48("7877") ? true : (stryCov_9fa48("7877", "7878", "7879"), snapshot.events.some(stryMutAct_9fa48("7880") ? () => undefined : (stryCov_9fa48("7880"), event => stryMutAct_9fa48("7883") ? event.data.kind === "cancelled" || event.data.planId === plan.id : stryMutAct_9fa48("7882") ? false : stryMutAct_9fa48("7881") ? true : (stryCov_9fa48("7881", "7882", "7883"), (stryMutAct_9fa48("7885") ? event.data.kind !== "cancelled" : stryMutAct_9fa48("7884") ? true : (stryCov_9fa48("7884", "7885"), event.data.kind === (stryMutAct_9fa48("7886") ? "" : (stryCov_9fa48("7886"), "cancelled")))) && (stryMutAct_9fa48("7888") ? event.data.planId !== plan.id : stryMutAct_9fa48("7887") ? true : (stryCov_9fa48("7887", "7888"), event.data.planId === plan.id))))))) throw new RecoveryError(stryMutAct_9fa48("7890") ? "" : (stryCov_9fa48("7890"), "recovery_plan_cancelled"));
              if (stryMutAct_9fa48("7893") ? plan.state.kind === "Draft" : stryMutAct_9fa48("7892") ? false : stryMutAct_9fa48("7891") ? true : (stryCov_9fa48("7891", "7892", "7893"), plan.state.kind !== (stryMutAct_9fa48("7894") ? "" : (stryCov_9fa48("7894"), "Draft")))) throw new RecoveryError(stryMutAct_9fa48("7896") ? "" : (stryCov_9fa48("7896"), "recovery_schedule_frozen"));
              if (stryMutAct_9fa48("7899") ? plan.revision === input.expectedRevision : stryMutAct_9fa48("7898") ? false : stryMutAct_9fa48("7897") ? true : (stryCov_9fa48("7897", "7898", "7899"), plan.revision !== input.expectedRevision)) throw new RecoveryError(stryMutAct_9fa48("7901") ? "" : (stryCov_9fa48("7901"), "recovery_draft_revision_conflict"));
              const period = await ledger.getAccountingPeriod(input.workspaceId, periodFromAccountingDate(today));
              if (stryMutAct_9fa48("7904") ? period?.status === "open" : stryMutAct_9fa48("7903") ? false : stryMutAct_9fa48("7902") ? true : (stryCov_9fa48("7902", "7903", "7904"), (stryMutAct_9fa48("7905") ? period.status : (stryCov_9fa48("7905"), period?.status)) !== (stryMutAct_9fa48("7906") ? "" : (stryCov_9fa48("7906"), "open")))) throw new RecoveryError(stryMutAct_9fa48("7908") ? "" : (stryCov_9fa48("7908"), "recovery_activation_period_not_open"));
              const destination = await ledger.getProfile(plan.terms.destinationProfileId);
              const account = stryMutAct_9fa48("7911") ? destination || (await ledger.getLedgerAccount(destination.postingAccountId)) : stryMutAct_9fa48("7910") ? false : stryMutAct_9fa48("7909") ? true : (stryCov_9fa48("7909", "7910", "7911"), destination && (await ledger.getLedgerAccount(destination.postingAccountId)));
              if (stryMutAct_9fa48("7914") ? (!destination || destination.workspaceId !== input.workspaceId) && account?.nature !== "Asset" : stryMutAct_9fa48("7913") ? false : stryMutAct_9fa48("7912") ? true : (stryCov_9fa48("7912", "7913", "7914"), (stryMutAct_9fa48("7916") ? !destination && destination.workspaceId !== input.workspaceId : stryMutAct_9fa48("7915") ? false : (stryCov_9fa48("7915", "7916"), (stryMutAct_9fa48("7917") ? destination : (stryCov_9fa48("7917"), !destination)) || (stryMutAct_9fa48("7919") ? destination.workspaceId === input.workspaceId : stryMutAct_9fa48("7918") ? false : (stryCov_9fa48("7918", "7919"), destination.workspaceId !== input.workspaceId)))) || (stryMutAct_9fa48("7921") ? account?.nature === "Asset" : stryMutAct_9fa48("7920") ? false : (stryCov_9fa48("7920", "7921"), (stryMutAct_9fa48("7922") ? account.nature : (stryCov_9fa48("7922"), account?.nature)) !== (stryMutAct_9fa48("7923") ? "" : (stryCov_9fa48("7923"), "Asset")))))) throw new RecoveryError(stryMutAct_9fa48("7925") ? "" : (stryCov_9fa48("7925"), "recovery_destination_ineligible"));
              const counted = await countedAllocations(ledger, snapshot, at);
              const paid = stryMutAct_9fa48("7926") ? [] : (stryCov_9fa48("7926"), [...counted.verified, ...counted.declared]);
              const sourceEffectCuts: Record<string, number> = {};
              for (const source of plan.terms.sources) {
                if (stryMutAct_9fa48("7927")) {
                  {}
                } else {
                  stryCov_9fa48("7927");
                  const effects = await ledger.listJournalSourceEffects(input.workspaceId, source.entryId);
                  sourceEffectCuts[source.entryId] = effects.reduce(stryMutAct_9fa48("7928") ? () => undefined : (stryCov_9fa48("7928"), (sequence, effect) => stryMutAct_9fa48("7929") ? Math.min(sequence, effect.sourceSequence) : (stryCov_9fa48("7929"), Math.max(sequence, effect.sourceSequence))), 0);
                  const entry = await ledger.getJournalEntry(source.entryId);
                  const eligible = await sourceExpense(ledger, input.workspaceId, source.entryId, at);
                  const decision = stryMutAct_9fa48("7930") ? snapshot.events.at(-1) : (stryCov_9fa48("7930"), snapshot.events.filter(stryMutAct_9fa48("7931") ? () => undefined : (stryCov_9fa48("7931"), event => stryMutAct_9fa48("7934") ? event.data.kind === "candidateDecision" || event.data.entryId === source.entryId : stryMutAct_9fa48("7933") ? false : stryMutAct_9fa48("7932") ? true : (stryCov_9fa48("7932", "7933", "7934"), (stryMutAct_9fa48("7936") ? event.data.kind !== "candidateDecision" : stryMutAct_9fa48("7935") ? true : (stryCov_9fa48("7935", "7936"), event.data.kind === (stryMutAct_9fa48("7937") ? "" : (stryCov_9fa48("7937"), "candidateDecision")))) && (stryMutAct_9fa48("7939") ? event.data.entryId !== source.entryId : stryMutAct_9fa48("7938") ? true : (stryCov_9fa48("7938", "7939"), event.data.entryId === source.entryId))))).at(stryMutAct_9fa48("7940") ? +1 : (stryCov_9fa48("7940"), -1)));
                  if (stryMutAct_9fa48("7943") ? (!entry || entry.accountingDate > today || decision?.data.kind === "candidateDecision" && decision.data.decision !== "eligible") && source.principalMinor > eligible - sourcePaid(source.entryId, paid) : stryMutAct_9fa48("7942") ? false : stryMutAct_9fa48("7941") ? true : (stryCov_9fa48("7941", "7942", "7943"), (stryMutAct_9fa48("7945") ? (!entry || entry.accountingDate > today) && decision?.data.kind === "candidateDecision" && decision.data.decision !== "eligible" : stryMutAct_9fa48("7944") ? false : (stryCov_9fa48("7944", "7945"), (stryMutAct_9fa48("7947") ? !entry && entry.accountingDate > today : stryMutAct_9fa48("7946") ? false : (stryCov_9fa48("7946", "7947"), (stryMutAct_9fa48("7948") ? entry : (stryCov_9fa48("7948"), !entry)) || (stryMutAct_9fa48("7951") ? entry.accountingDate <= today : stryMutAct_9fa48("7950") ? entry.accountingDate >= today : stryMutAct_9fa48("7949") ? false : (stryCov_9fa48("7949", "7950", "7951"), entry.accountingDate > today)))) || (stryMutAct_9fa48("7953") ? decision?.data.kind === "candidateDecision" || decision.data.decision !== "eligible" : stryMutAct_9fa48("7952") ? false : (stryCov_9fa48("7952", "7953"), (stryMutAct_9fa48("7955") ? decision?.data.kind !== "candidateDecision" : stryMutAct_9fa48("7954") ? true : (stryCov_9fa48("7954", "7955"), (stryMutAct_9fa48("7956") ? decision.data.kind : (stryCov_9fa48("7956"), decision?.data.kind)) === (stryMutAct_9fa48("7957") ? "" : (stryCov_9fa48("7957"), "candidateDecision")))) && (stryMutAct_9fa48("7959") ? decision.data.decision === "eligible" : stryMutAct_9fa48("7958") ? true : (stryCov_9fa48("7958", "7959"), decision.data.decision !== (stryMutAct_9fa48("7960") ? "" : (stryCov_9fa48("7960"), "eligible")))))))) || (stryMutAct_9fa48("7963") ? source.principalMinor <= eligible - sourcePaid(source.entryId, paid) : stryMutAct_9fa48("7962") ? source.principalMinor >= eligible - sourcePaid(source.entryId, paid) : stryMutAct_9fa48("7961") ? false : (stryCov_9fa48("7961", "7962", "7963"), source.principalMinor > (stryMutAct_9fa48("7964") ? eligible + sourcePaid(source.entryId, paid) : (stryCov_9fa48("7964"), eligible - sourcePaid(source.entryId, paid))))))) throw new RecoveryError(stryMutAct_9fa48("7966") ? "" : (stryCov_9fa48("7966"), "recovery_source_ineligible"));
                  for (const other of snapshot.plans) {
                    if (stryMutAct_9fa48("7967")) {
                      {}
                    } else {
                      stryCov_9fa48("7967");
                      if (stryMutAct_9fa48("7970") ? other.id === plan.id && !other.terms.sources.some(item => item.entryId === source.entryId) : stryMutAct_9fa48("7969") ? false : stryMutAct_9fa48("7968") ? true : (stryCov_9fa48("7968", "7969", "7970"), (stryMutAct_9fa48("7972") ? other.id !== plan.id : stryMutAct_9fa48("7971") ? false : (stryCov_9fa48("7971", "7972"), other.id === plan.id)) || (stryMutAct_9fa48("7973") ? other.terms.sources.some(item => item.entryId === source.entryId) : (stryCov_9fa48("7973"), !(stryMutAct_9fa48("7974") ? other.terms.sources.every(item => item.entryId === source.entryId) : (stryCov_9fa48("7974"), other.terms.sources.some(stryMutAct_9fa48("7975") ? () => undefined : (stryCov_9fa48("7975"), item => stryMutAct_9fa48("7978") ? item.entryId !== source.entryId : stryMutAct_9fa48("7977") ? false : stryMutAct_9fa48("7976") ? true : (stryCov_9fa48("7976", "7977", "7978"), item.entryId === source.entryId))))))))) continue;
                      if (stryMutAct_9fa48("7980") ? false : stryMutAct_9fa48("7979") ? true : (stryCov_9fa48("7979", "7980"), ownsSourceReservation(snapshot, other, at))) throw new RecoveryError(stryMutAct_9fa48("7982") ? "" : (stryCov_9fa48("7982"), "recovery_source_reserved"));
                    }
                  }
                }
              }
              const commitment = stryMutAct_9fa48("7983") ? {} : (stryCov_9fa48("7983"), {
                ...freezeSchedule(plan.terms, today, at),
                sourceEffectCuts
              });
              await store.updatePlan(stryMutAct_9fa48("7984") ? {} : (stryCov_9fa48("7984"), {
                ...plan,
                revision: stryMutAct_9fa48("7985") ? plan.revision - 1 : (stryCov_9fa48("7985"), plan.revision + 1),
                state: stryMutAct_9fa48("7986") ? {} : (stryCov_9fa48("7986"), {
                  kind: stryMutAct_9fa48("7987") ? "" : (stryCov_9fa48("7987"), "Activated"),
                  commitment
                })
              }));
              return plan.id;
            }
          });
        }
      },
      cancelPlan(input: CommandContext & {
        planId: string;
        reason: string;
      }) {
        if (stryMutAct_9fa48("7988")) {
          {}
        } else {
          stryCov_9fa48("7988");
          return command(stryMutAct_9fa48("7989") ? "" : (stryCov_9fa48("7989"), "cancelPlan"), input, async (snapshot, at) => {
            if (stryMutAct_9fa48("7990")) {
              {}
            } else {
              stryCov_9fa48("7990");
              const plan = findPlan(snapshot, input.planId);
              if (stryMutAct_9fa48("7993") ? snapshot.events.every(event => event.data.kind === "cancelled" && event.data.planId === plan.id) : stryMutAct_9fa48("7992") ? false : stryMutAct_9fa48("7991") ? true : (stryCov_9fa48("7991", "7992", "7993"), snapshot.events.some(stryMutAct_9fa48("7994") ? () => undefined : (stryCov_9fa48("7994"), event => stryMutAct_9fa48("7997") ? event.data.kind === "cancelled" || event.data.planId === plan.id : stryMutAct_9fa48("7996") ? false : stryMutAct_9fa48("7995") ? true : (stryCov_9fa48("7995", "7996", "7997"), (stryMutAct_9fa48("7999") ? event.data.kind !== "cancelled" : stryMutAct_9fa48("7998") ? true : (stryCov_9fa48("7998", "7999"), event.data.kind === (stryMutAct_9fa48("8000") ? "" : (stryCov_9fa48("8000"), "cancelled")))) && (stryMutAct_9fa48("8002") ? event.data.planId !== plan.id : stryMutAct_9fa48("8001") ? true : (stryCov_9fa48("8001", "8002"), event.data.planId === plan.id))))))) throw new RecoveryError(stryMutAct_9fa48("8004") ? "" : (stryCov_9fa48("8004"), "recovery_plan_cancelled"));
              return append(input, at, stryMutAct_9fa48("8005") ? {} : (stryCov_9fa48("8005"), {
                kind: stryMutAct_9fa48("8006") ? "" : (stryCov_9fa48("8006"), "cancelled"),
                planId: plan.id,
                reason: text(input.reason)
              }));
            }
          });
        }
      },
      replacePlan(input: CommandContext & {
        planId: string;
        terms: PlanTerms;
        reason: string;
      }) {
        if (stryMutAct_9fa48("8007")) {
          {}
        } else {
          stryCov_9fa48("8007");
          return command(stryMutAct_9fa48("8008") ? "" : (stryCov_9fa48("8008"), "replacePlan"), input, async (snapshot, at) => {
            if (stryMutAct_9fa48("8009")) {
              {}
            } else {
              stryCov_9fa48("8009");
              const plan = findPlan(snapshot, input.planId);
              if (stryMutAct_9fa48("8012") ? plan.state.kind === "Activated" : stryMutAct_9fa48("8011") ? false : stryMutAct_9fa48("8010") ? true : (stryCov_9fa48("8010", "8011", "8012"), plan.state.kind !== (stryMutAct_9fa48("8013") ? "" : (stryCov_9fa48("8013"), "Activated")))) throw new RecoveryError(stryMutAct_9fa48("8015") ? "" : (stryCov_9fa48("8015"), "recovery_plan_inactive"));
              if (stryMutAct_9fa48("8016")) {
                ;
              } else {
                stryCov_9fa48("8016");
                validateTerms(input.terms);
              }
              if (stryMutAct_9fa48("8017")) {
                ;
              } else {
                stryCov_9fa48("8017");
                text(input.reason);
              }
              if (stryMutAct_9fa48("8020") ? false : stryMutAct_9fa48("8019") ? true : stryMutAct_9fa48("8018") ? snapshot.events.some(event => event.data.kind === "cancelled" && event.data.planId === plan.id) : (stryCov_9fa48("8018", "8019", "8020"), !(stryMutAct_9fa48("8021") ? snapshot.events.every(event => event.data.kind === "cancelled" && event.data.planId === plan.id) : (stryCov_9fa48("8021"), snapshot.events.some(stryMutAct_9fa48("8022") ? () => undefined : (stryCov_9fa48("8022"), event => stryMutAct_9fa48("8025") ? event.data.kind === "cancelled" || event.data.planId === plan.id : stryMutAct_9fa48("8024") ? false : stryMutAct_9fa48("8023") ? true : (stryCov_9fa48("8023", "8024", "8025"), (stryMutAct_9fa48("8027") ? event.data.kind !== "cancelled" : stryMutAct_9fa48("8026") ? true : (stryCov_9fa48("8026", "8027"), event.data.kind === (stryMutAct_9fa48("8028") ? "" : (stryCov_9fa48("8028"), "cancelled")))) && (stryMutAct_9fa48("8030") ? event.data.planId !== plan.id : stryMutAct_9fa48("8029") ? true : (stryCov_9fa48("8029", "8030"), event.data.planId === plan.id))))))))) await append(input, at, stryMutAct_9fa48("8031") ? {} : (stryCov_9fa48("8031"), {
                kind: stryMutAct_9fa48("8032") ? "" : (stryCov_9fa48("8032"), "cancelled"),
                planId: plan.id,
                reason: input.reason
              }));
              return store.insertPlan(stryMutAct_9fa48("8033") ? {} : (stryCov_9fa48("8033"), {
                workspaceId: input.workspaceId,
                revision: 1,
                terms: input.terms,
                replacesPlanId: plan.id,
                state: stryMutAct_9fa48("8034") ? {} : (stryCov_9fa48("8034"), {
                  kind: stryMutAct_9fa48("8035") ? "" : (stryCov_9fa48("8035"), "Draft")
                })
              }));
            }
          });
        }
      },
      reconcilePlans(input: CommandContext) {
        if (stryMutAct_9fa48("8036")) {
          {}
        } else {
          stryCov_9fa48("8036");
          return command(stryMutAct_9fa48("8037") ? "" : (stryCov_9fa48("8037"), "reconcilePlans"), input, async (snapshot, at) => {
            if (stryMutAct_9fa48("8038")) {
              {}
            } else {
              stryCov_9fa48("8038");
              const counted = await countedAllocations(ledger, snapshot, at);
              for (const plan of snapshot.plans) {
                if (stryMutAct_9fa48("8039")) {
                  {}
                } else {
                  stryCov_9fa48("8039");
                  const status = await planStatus(ledger, snapshot, plan, stryMutAct_9fa48("8040") ? [] : (stryCov_9fa48("8040"), [...counted.verified, ...counted.declared]), at);
                  if (stryMutAct_9fa48("8043") ? status.kind === "Suspended" || !snapshot.events.some(event => event.data.kind === "suspended" && event.data.planId === plan.id) : stryMutAct_9fa48("8042") ? false : stryMutAct_9fa48("8041") ? true : (stryCov_9fa48("8041", "8042", "8043"), (stryMutAct_9fa48("8045") ? status.kind !== "Suspended" : stryMutAct_9fa48("8044") ? true : (stryCov_9fa48("8044", "8045"), status.kind === (stryMutAct_9fa48("8046") ? "" : (stryCov_9fa48("8046"), "Suspended")))) && (stryMutAct_9fa48("8047") ? snapshot.events.some(event => event.data.kind === "suspended" && event.data.planId === plan.id) : (stryCov_9fa48("8047"), !(stryMutAct_9fa48("8048") ? snapshot.events.every(event => event.data.kind === "suspended" && event.data.planId === plan.id) : (stryCov_9fa48("8048"), snapshot.events.some(stryMutAct_9fa48("8049") ? () => undefined : (stryCov_9fa48("8049"), event => stryMutAct_9fa48("8052") ? event.data.kind === "suspended" || event.data.planId === plan.id : stryMutAct_9fa48("8051") ? false : stryMutAct_9fa48("8050") ? true : (stryCov_9fa48("8050", "8051", "8052"), (stryMutAct_9fa48("8054") ? event.data.kind !== "suspended" : stryMutAct_9fa48("8053") ? true : (stryCov_9fa48("8053", "8054"), event.data.kind === (stryMutAct_9fa48("8055") ? "" : (stryCov_9fa48("8055"), "suspended")))) && (stryMutAct_9fa48("8057") ? event.data.planId !== plan.id : stryMutAct_9fa48("8056") ? true : (stryCov_9fa48("8056", "8057"), event.data.planId === plan.id))))))))))) await append(input, at, stryMutAct_9fa48("8058") ? {} : (stryCov_9fa48("8058"), {
                    kind: stryMutAct_9fa48("8059") ? "" : (stryCov_9fa48("8059"), "suspended"),
                    planId: plan.id,
                    entryIds: status.unsupportedEntryIds
                  }));
                }
              }
              return input.workspaceId;
            }
          });
        }
      },
      decideCandidate(input: CommandContext & {
        entryId: string;
        decision: "eligible" | "deferred" | "excluded";
      }) {
        if (stryMutAct_9fa48("8060")) {
          {}
        } else {
          stryCov_9fa48("8060");
          return command(stryMutAct_9fa48("8061") ? "" : (stryCov_9fa48("8061"), "decideCandidate"), input, async (snapshot, at) => {
            if (stryMutAct_9fa48("8062")) {
              {}
            } else {
              stryCov_9fa48("8062");
              if (stryMutAct_9fa48("8065") ? false : stryMutAct_9fa48("8064") ? true : stryMutAct_9fa48("8063") ? await sourceExpense(ledger, input.workspaceId, input.entryId, at) : (stryCov_9fa48("8063", "8064", "8065"), !(await sourceExpense(ledger, input.workspaceId, input.entryId, at)))) throw new RecoveryError(stryMutAct_9fa48("8067") ? "" : (stryCov_9fa48("8067"), "recovery_source_ineligible"));
              if (stryMutAct_9fa48("8070") ? snapshot.plans.every(plan => ownsSourceReservation(snapshot, plan, at) && plan.terms.sources.some(source => source.entryId === input.entryId)) : stryMutAct_9fa48("8069") ? false : stryMutAct_9fa48("8068") ? true : (stryCov_9fa48("8068", "8069", "8070"), snapshot.plans.some(stryMutAct_9fa48("8071") ? () => undefined : (stryCov_9fa48("8071"), plan => stryMutAct_9fa48("8074") ? ownsSourceReservation(snapshot, plan, at) || plan.terms.sources.some(source => source.entryId === input.entryId) : stryMutAct_9fa48("8073") ? false : stryMutAct_9fa48("8072") ? true : (stryCov_9fa48("8072", "8073", "8074"), ownsSourceReservation(snapshot, plan, at) && (stryMutAct_9fa48("8075") ? plan.terms.sources.every(source => source.entryId === input.entryId) : (stryCov_9fa48("8075"), plan.terms.sources.some(stryMutAct_9fa48("8076") ? () => undefined : (stryCov_9fa48("8076"), source => stryMutAct_9fa48("8079") ? source.entryId !== input.entryId : stryMutAct_9fa48("8078") ? false : stryMutAct_9fa48("8077") ? true : (stryCov_9fa48("8077", "8078", "8079"), source.entryId === input.entryId)))))))))) throw new RecoveryError(stryMutAct_9fa48("8081") ? "" : (stryCov_9fa48("8081"), "recovery_source_reserved"));
              return append(input, at, stryMutAct_9fa48("8082") ? {} : (stryCov_9fa48("8082"), {
                kind: stryMutAct_9fa48("8083") ? "" : (stryCov_9fa48("8083"), "candidateDecision"),
                entryId: input.entryId,
                decision: input.decision
              }));
            }
          });
        }
      },
      recordContribution(input: CommandContext & {
        transferEntryId: string;
        allocations: AllocationIntent[];
      }) {
        if (stryMutAct_9fa48("8084")) {
          {}
        } else {
          stryCov_9fa48("8084");
          return command(stryMutAct_9fa48("8085") ? "" : (stryCov_9fa48("8085"), "recordContribution"), input, stryMutAct_9fa48("8086") ? () => undefined : (stryCov_9fa48("8086"), (snapshot, at, today) => contribution(input, snapshot, at, today, input.transferEntryId, input.allocations, stryMutAct_9fa48("8087") ? "" : (stryCov_9fa48("8087"), "explicit"), null)));
        }
      },
      reverseContribution(input: CommandContext & {
        contributionId: string;
        reason: string;
      }) {
        if (stryMutAct_9fa48("8088")) {
          {}
        } else {
          stryCov_9fa48("8088");
          return command(stryMutAct_9fa48("8089") ? "" : (stryCov_9fa48("8089"), "reverseContribution"), input, async (snapshot, at) => {
            if (stryMutAct_9fa48("8090")) {
              {}
            } else {
              stryCov_9fa48("8090");
              const original = snapshot.events.find(stryMutAct_9fa48("8091") ? () => undefined : (stryCov_9fa48("8091"), event => stryMutAct_9fa48("8094") ? event.id === input.contributionId || event.data.kind === "contribution" : stryMutAct_9fa48("8093") ? false : stryMutAct_9fa48("8092") ? true : (stryCov_9fa48("8092", "8093", "8094"), (stryMutAct_9fa48("8096") ? event.id !== input.contributionId : stryMutAct_9fa48("8095") ? true : (stryCov_9fa48("8095", "8096"), event.id === input.contributionId)) && (stryMutAct_9fa48("8098") ? event.data.kind !== "contribution" : stryMutAct_9fa48("8097") ? true : (stryCov_9fa48("8097", "8098"), event.data.kind === (stryMutAct_9fa48("8099") ? "" : (stryCov_9fa48("8099"), "contribution")))))));
              if (stryMutAct_9fa48("8102") ? false : stryMutAct_9fa48("8101") ? true : stryMutAct_9fa48("8100") ? original : (stryCov_9fa48("8100", "8101", "8102"), !original)) throw new RecoveryError(stryMutAct_9fa48("8104") ? "" : (stryCov_9fa48("8104"), "recovery_contribution_not_found"));
              if (stryMutAct_9fa48("8107") ? snapshot.events.every(event => event.data.kind === "contributionReversal" && event.data.contributionId === input.contributionId) : stryMutAct_9fa48("8106") ? false : stryMutAct_9fa48("8105") ? true : (stryCov_9fa48("8105", "8106", "8107"), snapshot.events.some(stryMutAct_9fa48("8108") ? () => undefined : (stryCov_9fa48("8108"), event => stryMutAct_9fa48("8111") ? event.data.kind === "contributionReversal" || event.data.contributionId === input.contributionId : stryMutAct_9fa48("8110") ? false : stryMutAct_9fa48("8109") ? true : (stryCov_9fa48("8109", "8110", "8111"), (stryMutAct_9fa48("8113") ? event.data.kind !== "contributionReversal" : stryMutAct_9fa48("8112") ? true : (stryCov_9fa48("8112", "8113"), event.data.kind === (stryMutAct_9fa48("8114") ? "" : (stryCov_9fa48("8114"), "contributionReversal")))) && (stryMutAct_9fa48("8116") ? event.data.contributionId !== input.contributionId : stryMutAct_9fa48("8115") ? true : (stryCov_9fa48("8115", "8116"), event.data.contributionId === input.contributionId))))))) throw new RecoveryError(stryMutAct_9fa48("8118") ? "" : (stryCov_9fa48("8118"), "recovery_contribution_already_reversed"));
              return append(input, at, stryMutAct_9fa48("8119") ? {} : (stryCov_9fa48("8119"), {
                kind: stryMutAct_9fa48("8120") ? "" : (stryCov_9fa48("8120"), "contributionReversal"),
                contributionId: input.contributionId,
                reason: text(input.reason)
              }));
            }
          });
        }
      },
      proposeAllocation(input: CommandContext & {
        transferEntryId: string;
        allocations: AllocationIntent[];
        importReference: string;
      }) {
        if (stryMutAct_9fa48("8121")) {
          {}
        } else {
          stryCov_9fa48("8121");
          return command(stryMutAct_9fa48("8122") ? "" : (stryCov_9fa48("8122"), "proposeAllocation"), input, async (snapshot, at, today) => {
            if (stryMutAct_9fa48("8123")) {
              {}
            } else {
              stryCov_9fa48("8123");
              await transferEvidence(ledger, input.workspaceId, input.transferEntryId, today);
              if (stryMutAct_9fa48("8126") ? !input.allocations.length && new Set(input.allocations.map(item => item.planId)).size !== input.allocations.length : stryMutAct_9fa48("8125") ? false : stryMutAct_9fa48("8124") ? true : (stryCov_9fa48("8124", "8125", "8126"), (stryMutAct_9fa48("8127") ? input.allocations.length : (stryCov_9fa48("8127"), !input.allocations.length)) || (stryMutAct_9fa48("8129") ? new Set(input.allocations.map(item => item.planId)).size === input.allocations.length : stryMutAct_9fa48("8128") ? false : (stryCov_9fa48("8128", "8129"), new Set(input.allocations.map(stryMutAct_9fa48("8130") ? () => undefined : (stryCov_9fa48("8130"), item => item.planId))).size !== input.allocations.length)))) throw new RecoveryError(stryMutAct_9fa48("8132") ? "" : (stryCov_9fa48("8132"), "recovery_allocations_invalid"));
              input.allocations.forEach(item => {
                if (stryMutAct_9fa48("8134")) {
                  {}
                } else {
                  stryCov_9fa48("8134");
                  if (stryMutAct_9fa48("8135")) {
                    ;
                  } else {
                    stryCov_9fa48("8135");
                    findPlan(snapshot, item.planId);
                  }
                  minor(item.amountMinor, stryMutAct_9fa48("8137") ? false : (stryCov_9fa48("8137"), true));
                }
              });
              return append(input, at, stryMutAct_9fa48("8138") ? {} : (stryCov_9fa48("8138"), {
                kind: stryMutAct_9fa48("8139") ? "" : (stryCov_9fa48("8139"), "proposal"),
                transferEntryId: input.transferEntryId,
                allocations: input.allocations,
                importReference: text(input.importReference)
              }));
            }
          });
        }
      },
      decideProposal(input: CommandContext & {
        proposalId: string;
        decision: "accepted" | "rejected";
      }) {
        if (stryMutAct_9fa48("8140")) {
          {}
        } else {
          stryCov_9fa48("8140");
          return command(stryMutAct_9fa48("8141") ? "" : (stryCov_9fa48("8141"), "decideProposal"), input, async (snapshot, at, today) => {
            if (stryMutAct_9fa48("8142")) {
              {}
            } else {
              stryCov_9fa48("8142");
              const proposal = snapshot.events.find(stryMutAct_9fa48("8143") ? () => undefined : (stryCov_9fa48("8143"), event => stryMutAct_9fa48("8146") ? event.id !== input.proposalId : stryMutAct_9fa48("8145") ? false : stryMutAct_9fa48("8144") ? true : (stryCov_9fa48("8144", "8145", "8146"), event.id === input.proposalId)));
              if (stryMutAct_9fa48("8149") ? proposal?.data.kind === "proposal" : stryMutAct_9fa48("8148") ? false : stryMutAct_9fa48("8147") ? true : (stryCov_9fa48("8147", "8148", "8149"), (stryMutAct_9fa48("8150") ? proposal.data.kind : (stryCov_9fa48("8150"), proposal?.data.kind)) !== (stryMutAct_9fa48("8151") ? "" : (stryCov_9fa48("8151"), "proposal")))) throw new RecoveryError(stryMutAct_9fa48("8153") ? "" : (stryCov_9fa48("8153"), "recovery_proposal_not_found"));
              if (stryMutAct_9fa48("8156") ? snapshot.events.every(event => event.data.kind === "proposalDecision" && event.data.proposalId === input.proposalId) : stryMutAct_9fa48("8155") ? false : stryMutAct_9fa48("8154") ? true : (stryCov_9fa48("8154", "8155", "8156"), snapshot.events.some(stryMutAct_9fa48("8157") ? () => undefined : (stryCov_9fa48("8157"), event => stryMutAct_9fa48("8160") ? event.data.kind === "proposalDecision" || event.data.proposalId === input.proposalId : stryMutAct_9fa48("8159") ? false : stryMutAct_9fa48("8158") ? true : (stryCov_9fa48("8158", "8159", "8160"), (stryMutAct_9fa48("8162") ? event.data.kind !== "proposalDecision" : stryMutAct_9fa48("8161") ? true : (stryCov_9fa48("8161", "8162"), event.data.kind === (stryMutAct_9fa48("8163") ? "" : (stryCov_9fa48("8163"), "proposalDecision")))) && (stryMutAct_9fa48("8165") ? event.data.proposalId !== input.proposalId : stryMutAct_9fa48("8164") ? true : (stryCov_9fa48("8164", "8165"), event.data.proposalId === input.proposalId))))))) throw new RecoveryError(stryMutAct_9fa48("8167") ? "" : (stryCov_9fa48("8167"), "recovery_proposal_already_decided"));
              const contributionId = (stryMutAct_9fa48("8170") ? input.decision !== "accepted" : stryMutAct_9fa48("8169") ? false : stryMutAct_9fa48("8168") ? true : (stryCov_9fa48("8168", "8169", "8170"), input.decision === (stryMutAct_9fa48("8171") ? "" : (stryCov_9fa48("8171"), "accepted")))) ? await contribution(input, snapshot, at, today, proposal.data.transferEntryId, proposal.data.allocations, stryMutAct_9fa48("8172") ? "" : (stryCov_9fa48("8172"), "acceptedProposal"), proposal.id) : null;
              return append(input, at, stryMutAct_9fa48("8173") ? {} : (stryCov_9fa48("8173"), {
                kind: stryMutAct_9fa48("8174") ? "" : (stryCov_9fa48("8174"), "proposalDecision"),
                proposalId: proposal.id,
                decision: input.decision,
                contributionId
              }));
            }
          });
        }
      },
      declareOpeningProgress(input: CommandContext & {
        planId: string;
        amountMinor: number;
        throughDate: string;
        provenance: string;
        evidenceUnavailable: true;
      }) {
        if (stryMutAct_9fa48("8175")) {
          {}
        } else {
          stryCov_9fa48("8175");
          return command(stryMutAct_9fa48("8176") ? "" : (stryCov_9fa48("8176"), "declareOpeningProgress"), input, async (snapshot, at, today) => {
            if (stryMutAct_9fa48("8177")) {
              {}
            } else {
              stryCov_9fa48("8177");
              const plan = findPlan(snapshot, input.planId);
              if (stryMutAct_9fa48("8180") ? plan.state.kind === "Activated" : stryMutAct_9fa48("8179") ? false : stryMutAct_9fa48("8178") ? true : (stryCov_9fa48("8178", "8179", "8180"), plan.state.kind !== (stryMutAct_9fa48("8181") ? "" : (stryCov_9fa48("8181"), "Activated")))) throw new RecoveryError(stryMutAct_9fa48("8183") ? "" : (stryCov_9fa48("8183"), "recovery_plan_inactive"));
              if (stryMutAct_9fa48("8184")) {
                ;
              } else {
                stryCov_9fa48("8184");
                validDate(input.throughDate);
              }
              if (stryMutAct_9fa48("8188") ? input.throughDate < plan.state.commitment.activatedOn : stryMutAct_9fa48("8187") ? input.throughDate > plan.state.commitment.activatedOn : stryMutAct_9fa48("8186") ? false : stryMutAct_9fa48("8185") ? true : (stryCov_9fa48("8185", "8186", "8187", "8188"), input.throughDate >= plan.state.commitment.activatedOn)) throw new RecoveryError(stryMutAct_9fa48("8190") ? "" : (stryCov_9fa48("8190"), "recovery_opening_date_invalid"));
              if (stryMutAct_9fa48("8193") ? snapshot.events.every(event => event.data.kind === "openingProgress" && event.data.planId === plan.id || event.data.kind === "contribution" && event.data.allocations.some(item => item.planId === plan.id)) : stryMutAct_9fa48("8192") ? false : stryMutAct_9fa48("8191") ? true : (stryCov_9fa48("8191", "8192", "8193"), snapshot.events.some(stryMutAct_9fa48("8194") ? () => undefined : (stryCov_9fa48("8194"), event => stryMutAct_9fa48("8197") ? event.data.kind === "openingProgress" && event.data.planId === plan.id && event.data.kind === "contribution" && event.data.allocations.some(item => item.planId === plan.id) : stryMutAct_9fa48("8196") ? false : stryMutAct_9fa48("8195") ? true : (stryCov_9fa48("8195", "8196", "8197"), (stryMutAct_9fa48("8199") ? event.data.kind === "openingProgress" || event.data.planId === plan.id : stryMutAct_9fa48("8198") ? false : (stryCov_9fa48("8198", "8199"), (stryMutAct_9fa48("8201") ? event.data.kind !== "openingProgress" : stryMutAct_9fa48("8200") ? true : (stryCov_9fa48("8200", "8201"), event.data.kind === (stryMutAct_9fa48("8202") ? "" : (stryCov_9fa48("8202"), "openingProgress")))) && (stryMutAct_9fa48("8204") ? event.data.planId !== plan.id : stryMutAct_9fa48("8203") ? true : (stryCov_9fa48("8203", "8204"), event.data.planId === plan.id)))) || (stryMutAct_9fa48("8206") ? event.data.kind === "contribution" || event.data.allocations.some(item => item.planId === plan.id) : stryMutAct_9fa48("8205") ? false : (stryCov_9fa48("8205", "8206"), (stryMutAct_9fa48("8208") ? event.data.kind !== "contribution" : stryMutAct_9fa48("8207") ? true : (stryCov_9fa48("8207", "8208"), event.data.kind === (stryMutAct_9fa48("8209") ? "" : (stryCov_9fa48("8209"), "contribution")))) && (stryMutAct_9fa48("8210") ? event.data.allocations.every(item => item.planId === plan.id) : (stryCov_9fa48("8210"), event.data.allocations.some(stryMutAct_9fa48("8211") ? () => undefined : (stryCov_9fa48("8211"), item => stryMutAct_9fa48("8214") ? item.planId !== plan.id : stryMutAct_9fa48("8213") ? false : stryMutAct_9fa48("8212") ? true : (stryCov_9fa48("8212", "8213", "8214"), item.planId === plan.id)))))))))))) throw new RecoveryError(stryMutAct_9fa48("8216") ? "" : (stryCov_9fa48("8216"), "recovery_opening_already_established"));
              const counted = await countedAllocations(ledger, snapshot, at);
              if (stryMutAct_9fa48("8219") ? (await planStatus(ledger, snapshot, plan, [...counted.verified, ...counted.declared], at)).kind === "Active" : stryMutAct_9fa48("8218") ? false : stryMutAct_9fa48("8217") ? true : (stryCov_9fa48("8217", "8218", "8219"), (await planStatus(ledger, snapshot, plan, stryMutAct_9fa48("8220") ? [] : (stryCov_9fa48("8220"), [...counted.verified, ...counted.declared]), at)).kind !== (stryMutAct_9fa48("8221") ? "" : (stryCov_9fa48("8221"), "Active")))) throw new RecoveryError(stryMutAct_9fa48("8223") ? "" : (stryCov_9fa48("8223"), "recovery_plan_inactive"));
              const destination = await ledger.getProfile(plan.terms.destinationProfileId);
              const transfers = await ledger.listAccountTransferEntriesInRange(input.workspaceId, plan.state.commitment.activatedOn, today);
              for (const transfer of transfers) {
                if (stryMutAct_9fa48("8224")) {
                  {}
                } else {
                  stryCov_9fa48("8224");
                  if (stryMutAct_9fa48("8226") ? false : stryMutAct_9fa48("8225") ? true : (stryCov_9fa48("8225", "8226"), await ledger.findReversalOf(transfer.id))) continue;
                  const outgoing = transfer.lines.find(stryMutAct_9fa48("8227") ? () => undefined : (stryCov_9fa48("8227"), line => stryMutAct_9fa48("8231") ? line.creditMinorUnits <= 0 : stryMutAct_9fa48("8230") ? line.creditMinorUnits >= 0 : stryMutAct_9fa48("8229") ? false : stryMutAct_9fa48("8228") ? true : (stryCov_9fa48("8228", "8229", "8230", "8231"), line.creditMinorUnits > 0)));
                  const incoming = transfer.lines.find(stryMutAct_9fa48("8232") ? () => undefined : (stryCov_9fa48("8232"), line => stryMutAct_9fa48("8236") ? line.debitMinorUnits <= 0 : stryMutAct_9fa48("8235") ? line.debitMinorUnits >= 0 : stryMutAct_9fa48("8234") ? false : stryMutAct_9fa48("8233") ? true : (stryCov_9fa48("8233", "8234", "8235", "8236"), line.debitMinorUnits > 0)));
                  if (stryMutAct_9fa48("8239") ? (!outgoing || !incoming) && incoming.ledgerAccountId !== destination?.postingAccountId : stryMutAct_9fa48("8238") ? false : stryMutAct_9fa48("8237") ? true : (stryCov_9fa48("8237", "8238", "8239"), (stryMutAct_9fa48("8241") ? !outgoing && !incoming : stryMutAct_9fa48("8240") ? false : (stryCov_9fa48("8240", "8241"), (stryMutAct_9fa48("8242") ? outgoing : (stryCov_9fa48("8242"), !outgoing)) || (stryMutAct_9fa48("8243") ? incoming : (stryCov_9fa48("8243"), !incoming)))) || (stryMutAct_9fa48("8245") ? incoming.ledgerAccountId === destination?.postingAccountId : stryMutAct_9fa48("8244") ? false : (stryCov_9fa48("8244", "8245"), incoming.ledgerAccountId !== (stryMutAct_9fa48("8246") ? destination.postingAccountId : (stryCov_9fa48("8246"), destination?.postingAccountId)))))) continue;
                  const sourceAccount = await ledger.getLedgerAccount(outgoing.ledgerAccountId);
                  const destinationAccount = await ledger.getLedgerAccount(incoming.ledgerAccountId);
                  if (stryMutAct_9fa48("8249") ? sourceAccount?.nature === "Asset" || destinationAccount?.nature === "Asset" : stryMutAct_9fa48("8248") ? false : stryMutAct_9fa48("8247") ? true : (stryCov_9fa48("8247", "8248", "8249"), (stryMutAct_9fa48("8251") ? sourceAccount?.nature !== "Asset" : stryMutAct_9fa48("8250") ? true : (stryCov_9fa48("8250", "8251"), (stryMutAct_9fa48("8252") ? sourceAccount.nature : (stryCov_9fa48("8252"), sourceAccount?.nature)) === (stryMutAct_9fa48("8253") ? "" : (stryCov_9fa48("8253"), "Asset")))) && (stryMutAct_9fa48("8255") ? destinationAccount?.nature !== "Asset" : stryMutAct_9fa48("8254") ? true : (stryCov_9fa48("8254", "8255"), (stryMutAct_9fa48("8256") ? destinationAccount.nature : (stryCov_9fa48("8256"), destinationAccount?.nature)) === (stryMutAct_9fa48("8257") ? "" : (stryCov_9fa48("8257"), "Asset")))))) throw new RecoveryError(stryMutAct_9fa48("8259") ? "" : (stryCov_9fa48("8259"), "recovery_opening_evidence_available"));
                }
              }
              const allocation = allocate(plan, input.amountMinor, stryMutAct_9fa48("8260") ? ["Stryker was here"] : (stryCov_9fa48("8260"), []), input.throughDate);
              return append(input, at, stryMutAct_9fa48("8261") ? {} : (stryCov_9fa48("8261"), {
                kind: stryMutAct_9fa48("8262") ? "" : (stryCov_9fa48("8262"), "openingProgress"),
                planId: plan.id,
                throughDate: input.throughDate,
                provenance: text(input.provenance),
                evidenceUnavailable: input.evidenceUnavailable,
                allocation
              }));
            }
          });
        }
      }
    });
  }
}