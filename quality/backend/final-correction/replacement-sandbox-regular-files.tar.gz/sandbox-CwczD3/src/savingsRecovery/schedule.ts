// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { nextPeriod, periodFromAccountingDate, firstDayOf } from "../accounting/period";
import { minor, RecoveryError, total } from "./amounts";
import type { FrozenCommitment, PlanTerms } from "./types";
export function freezeSchedule(terms: PlanTerms, activatedOn: string, activatedAt: number): Omit<FrozenCommitment, "sourceEffectCuts"> {
  if (stryMutAct_9fa48("8886")) {
    {}
  } else {
    stryCov_9fa48("8886");
    const principalMinor = total(terms.sources.map(stryMutAct_9fa48("8887") ? () => undefined : (stryCov_9fa48("8887"), source => source.principalMinor)));
    minor(principalMinor, stryMutAct_9fa48("8889") ? false : (stryCov_9fa48("8889"), true));
    const amount = minor(terms.installmentAmountMinor, stryMutAct_9fa48("8890") ? false : (stryCov_9fa48("8890"), true));
    const count = terms.installmentCount;
    if (stryMutAct_9fa48("8893") ? (!Number.isInteger(count) || count < 1) && count > 600 : stryMutAct_9fa48("8892") ? false : stryMutAct_9fa48("8891") ? true : (stryCov_9fa48("8891", "8892", "8893"), (stryMutAct_9fa48("8895") ? !Number.isInteger(count) && count < 1 : stryMutAct_9fa48("8894") ? false : (stryCov_9fa48("8894", "8895"), (stryMutAct_9fa48("8896") ? Number.isInteger(count) : (stryCov_9fa48("8896"), !Number.isInteger(count))) || (stryMutAct_9fa48("8899") ? count >= 1 : stryMutAct_9fa48("8898") ? count <= 1 : stryMutAct_9fa48("8897") ? false : (stryCov_9fa48("8897", "8898", "8899"), count < 1)))) || (stryMutAct_9fa48("8902") ? count <= 600 : stryMutAct_9fa48("8901") ? count >= 600 : stryMutAct_9fa48("8900") ? false : (stryCov_9fa48("8900", "8901", "8902"), count > 600)))) throw new RecoveryError(stryMutAct_9fa48("8904") ? "" : (stryCov_9fa48("8904"), "recovery_installment_count_invalid"));
    const goal = minor(Number(stryMutAct_9fa48("8905") ? BigInt(count) / BigInt(amount) : (stryCov_9fa48("8905"), BigInt(count) * BigInt(amount))));
    if (stryMutAct_9fa48("8909") ? goal >= principalMinor : stryMutAct_9fa48("8908") ? goal <= principalMinor : stryMutAct_9fa48("8907") ? false : stryMutAct_9fa48("8906") ? true : (stryCov_9fa48("8906", "8907", "8908", "8909"), goal < principalMinor)) throw new RecoveryError(stryMutAct_9fa48("8911") ? "" : (stryCov_9fa48("8911"), "recovery_installment_below_principal"));
    const presentValue = stryMutAct_9fa48("8912") ? () => undefined : (stryCov_9fa48("8912"), (() => {
      const presentValue = (rate: number) => (stryMutAct_9fa48("8915") ? rate !== 0 : stryMutAct_9fa48("8914") ? false : stryMutAct_9fa48("8913") ? true : (stryCov_9fa48("8913", "8914", "8915"), rate === 0)) ? goal : stryMutAct_9fa48("8916") ? amount * -Math.expm1(-count * Math.log1p(rate)) * rate : (stryCov_9fa48("8916"), (stryMutAct_9fa48("8917") ? amount / -Math.expm1(-count * Math.log1p(rate)) : (stryCov_9fa48("8917"), amount * (stryMutAct_9fa48("8918") ? +Math.expm1(-count * Math.log1p(rate)) : (stryCov_9fa48("8918"), -Math.expm1(stryMutAct_9fa48("8919") ? -count / Math.log1p(rate) : (stryCov_9fa48("8919"), (stryMutAct_9fa48("8920") ? +count : (stryCov_9fa48("8920"), -count)) * Math.log1p(rate))))))) / rate);
      return presentValue;
    })());
    let low = 0;
    let high = stryMutAct_9fa48("8921") ? amount * principalMinor : (stryCov_9fa48("8921"), amount / principalMinor);
    for (let step = 0; stryMutAct_9fa48("8924") ? step >= 100 : stryMutAct_9fa48("8923") ? step <= 100 : stryMutAct_9fa48("8922") ? false : (stryCov_9fa48("8922", "8923", "8924"), step < 100); stryMutAct_9fa48("8925") ? step-- : (stryCov_9fa48("8925"), step++)) {
      if (stryMutAct_9fa48("8926")) {
        {}
      } else {
        stryCov_9fa48("8926");
        const middle = stryMutAct_9fa48("8927") ? (low + high) * 2 : (stryCov_9fa48("8927"), (stryMutAct_9fa48("8928") ? low - high : (stryCov_9fa48("8928"), low + high)) / 2);
        if (stryMutAct_9fa48("8932") ? presentValue(middle) <= principalMinor : stryMutAct_9fa48("8931") ? presentValue(middle) >= principalMinor : stryMutAct_9fa48("8930") ? false : stryMutAct_9fa48("8929") ? true : (stryCov_9fa48("8929", "8930", "8931", "8932"), presentValue(middle) > principalMinor)) low = middle;else high = middle;
      }
    }
    const impliedMonthlyRate = (stryMutAct_9fa48("8935") ? goal !== principalMinor : stryMutAct_9fa48("8934") ? false : stryMutAct_9fa48("8933") ? true : (stryCov_9fa48("8933", "8934", "8935"), goal === principalMinor)) ? 0 : stryMutAct_9fa48("8936") ? (low + high) * 2 : (stryCov_9fa48("8936"), (stryMutAct_9fa48("8937") ? low - high : (stryCov_9fa48("8937"), low + high)) / 2);
    let period = periodFromAccountingDate(activatedOn);
    let recovered = 0;
    const schedule = stryMutAct_9fa48("8938") ? ["Stryker was here"] : (stryCov_9fa48("8938"), []);
    for (let index = 0; stryMutAct_9fa48("8941") ? index >= count : stryMutAct_9fa48("8940") ? index <= count : stryMutAct_9fa48("8939") ? false : (stryCov_9fa48("8939", "8940", "8941"), index < count); stryMutAct_9fa48("8942") ? index-- : (stryCov_9fa48("8942"), index++)) {
      if (stryMutAct_9fa48("8943")) {
        {}
      } else {
        stryCov_9fa48("8943");
        const remainingCount = stryMutAct_9fa48("8944") ? count - index + 1 : (stryCov_9fa48("8944"), (stryMutAct_9fa48("8945") ? count + index : (stryCov_9fa48("8945"), count - index)) - 1);
        const balance = (stryMutAct_9fa48("8948") ? impliedMonthlyRate !== 0 : stryMutAct_9fa48("8947") ? false : stryMutAct_9fa48("8946") ? true : (stryCov_9fa48("8946", "8947", "8948"), impliedMonthlyRate === 0)) ? stryMutAct_9fa48("8949") ? remainingCount / amount : (stryCov_9fa48("8949"), remainingCount * amount) : stryMutAct_9fa48("8950") ? amount * -Math.expm1(-remainingCount * Math.log1p(impliedMonthlyRate)) * impliedMonthlyRate : (stryCov_9fa48("8950"), (stryMutAct_9fa48("8951") ? amount / -Math.expm1(-remainingCount * Math.log1p(impliedMonthlyRate)) : (stryCov_9fa48("8951"), amount * (stryMutAct_9fa48("8952") ? +Math.expm1(-remainingCount * Math.log1p(impliedMonthlyRate)) : (stryCov_9fa48("8952"), -Math.expm1(stryMutAct_9fa48("8953") ? -remainingCount / Math.log1p(impliedMonthlyRate) : (stryCov_9fa48("8953"), (stryMutAct_9fa48("8954") ? +remainingCount : (stryCov_9fa48("8954"), -remainingCount)) * Math.log1p(impliedMonthlyRate))))))) / impliedMonthlyRate);
        const cumulative = (stryMutAct_9fa48("8957") ? index !== count - 1 : stryMutAct_9fa48("8956") ? false : stryMutAct_9fa48("8955") ? true : (stryCov_9fa48("8955", "8956", "8957"), index === (stryMutAct_9fa48("8958") ? count + 1 : (stryCov_9fa48("8958"), count - 1)))) ? principalMinor : Math.round(stryMutAct_9fa48("8959") ? principalMinor + balance : (stryCov_9fa48("8959"), principalMinor - balance));
        const principal = stryMutAct_9fa48("8960") ? cumulative + recovered : (stryCov_9fa48("8960"), cumulative - recovered);
        if (stryMutAct_9fa48("8961")) {
          ;
        } else {
          stryCov_9fa48("8961");
          minor(principal);
        }
        if (stryMutAct_9fa48("8964") ? principal > amount && period.year > 9999 : stryMutAct_9fa48("8963") ? false : stryMutAct_9fa48("8962") ? true : (stryCov_9fa48("8962", "8963", "8964"), (stryMutAct_9fa48("8967") ? principal <= amount : stryMutAct_9fa48("8966") ? principal >= amount : stryMutAct_9fa48("8965") ? false : (stryCov_9fa48("8965", "8966", "8967"), principal > amount)) || (stryMutAct_9fa48("8970") ? period.year <= 9999 : stryMutAct_9fa48("8969") ? period.year >= 9999 : stryMutAct_9fa48("8968") ? false : (stryCov_9fa48("8968", "8969", "8970"), period.year > 9999)))) throw new RecoveryError(stryMutAct_9fa48("8972") ? "" : (stryCov_9fa48("8972"), "recovery_schedule_invalid"));
        schedule.push(stryMutAct_9fa48("8974") ? {} : (stryCov_9fa48("8974"), {
          month: stryMutAct_9fa48("8975") ? firstDayOf(period) : (stryCov_9fa48("8975"), firstDayOf(period).slice(0, 7)),
          amountMinor: amount,
          principalMinor: principal,
          premiumMinor: stryMutAct_9fa48("8976") ? amount + principal : (stryCov_9fa48("8976"), amount - principal)
        }));
        recovered = cumulative;
        period = nextPeriod(period);
      }
    }
    return stryMutAct_9fa48("8977") ? {} : (stryCov_9fa48("8977"), {
      activatedOn,
      activatedAt,
      principalMinor,
      impliedMonthlyRate,
      schedule
    });
  }
}