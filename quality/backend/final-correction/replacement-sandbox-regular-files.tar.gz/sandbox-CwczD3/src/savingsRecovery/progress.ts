// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { expenseEligibility } from "../accounting/queries/expenseEligibility";
import { periodFromAccountingDate } from "../accounting/period";
import { minor, RecoveryError, total } from "./amounts";
import type { ContributionAllocation, Plan, RecoveryLedger, Snapshot, SourceAllocation } from "./types";
export async function countedAllocations(ledger: RecoveryLedger, snapshot: Snapshot, asKnownAt: number, throughDate = stryMutAct_9fa48("8263") ? "" : (stryCov_9fa48("8263"), "9999-12-31")) {
  if (stryMutAct_9fa48("8264")) {
    {}
  } else {
    stryCov_9fa48("8264");
    const events = stryMutAct_9fa48("8265") ? snapshot.events : (stryCov_9fa48("8265"), snapshot.events.filter(stryMutAct_9fa48("8266") ? () => undefined : (stryCov_9fa48("8266"), event => stryMutAct_9fa48("8270") ? event.recordedAt > asKnownAt : stryMutAct_9fa48("8269") ? event.recordedAt < asKnownAt : stryMutAct_9fa48("8268") ? false : stryMutAct_9fa48("8267") ? true : (stryCov_9fa48("8267", "8268", "8269", "8270"), event.recordedAt <= asKnownAt))));
    const reversed = new Set(events.flatMap(stryMutAct_9fa48("8271") ? () => undefined : (stryCov_9fa48("8271"), event => (stryMutAct_9fa48("8274") ? event.data.kind !== "contributionReversal" : stryMutAct_9fa48("8273") ? false : stryMutAct_9fa48("8272") ? true : (stryCov_9fa48("8272", "8273", "8274"), event.data.kind === (stryMutAct_9fa48("8275") ? "" : (stryCov_9fa48("8275"), "contributionReversal")))) ? stryMutAct_9fa48("8276") ? [] : (stryCov_9fa48("8276"), [event.data.contributionId]) : stryMutAct_9fa48("8277") ? ["Stryker was here"] : (stryCov_9fa48("8277"), []))));
    const contributions = stryMutAct_9fa48("8278") ? ["Stryker was here"] : (stryCov_9fa48("8278"), []);
    for (const event of events) {
      if (stryMutAct_9fa48("8279")) {
        {}
      } else {
        stryCov_9fa48("8279");
        if (stryMutAct_9fa48("8282") ? event.data.kind === "contribution" : stryMutAct_9fa48("8281") ? false : stryMutAct_9fa48("8280") ? true : (stryCov_9fa48("8280", "8281", "8282"), event.data.kind !== (stryMutAct_9fa48("8283") ? "" : (stryCov_9fa48("8283"), "contribution")))) continue;
        const transfer = await ledger.getJournalEntry(event.data.transferEntryId);
        const reversal = stryMutAct_9fa48("8286") ? transfer || (await ledger.findReversalOf(transfer.id)) : stryMutAct_9fa48("8285") ? false : stryMutAct_9fa48("8284") ? true : (stryCov_9fa48("8284", "8285", "8286"), transfer && (await ledger.findReversalOf(transfer.id)));
        const voided = stryMutAct_9fa48("8289") ? !transfer && reversal !== undefined && reversal.postedAt <= asKnownAt : stryMutAct_9fa48("8288") ? false : stryMutAct_9fa48("8287") ? true : (stryCov_9fa48("8287", "8288", "8289"), (stryMutAct_9fa48("8290") ? transfer : (stryCov_9fa48("8290"), !transfer)) || (stryMutAct_9fa48("8292") ? reversal !== undefined || reversal.postedAt <= asKnownAt : stryMutAct_9fa48("8291") ? false : (stryCov_9fa48("8291", "8292"), (stryMutAct_9fa48("8294") ? reversal === undefined : stryMutAct_9fa48("8293") ? true : (stryCov_9fa48("8293", "8294"), reversal !== undefined)) && (stryMutAct_9fa48("8297") ? reversal.postedAt > asKnownAt : stryMutAct_9fa48("8296") ? reversal.postedAt < asKnownAt : stryMutAct_9fa48("8295") ? true : (stryCov_9fa48("8295", "8296", "8297"), reversal.postedAt <= asKnownAt)))));
        contributions.push(stryMutAct_9fa48("8299") ? {} : (stryCov_9fa48("8299"), {
          event,
          data: event.data,
          voided,
          corrected: reversed.has(event.id)
        }));
      }
    }
    const verified = stryMutAct_9fa48("8300") ? contributions.flatMap(item => item.data.allocations) : (stryCov_9fa48("8300"), contributions.filter(stryMutAct_9fa48("8301") ? () => undefined : (stryCov_9fa48("8301"), item => stryMutAct_9fa48("8304") ? !item.voided && !item.corrected || item.data.contributionDate <= throughDate : stryMutAct_9fa48("8303") ? false : stryMutAct_9fa48("8302") ? true : (stryCov_9fa48("8302", "8303", "8304"), (stryMutAct_9fa48("8306") ? !item.voided || !item.corrected : stryMutAct_9fa48("8305") ? true : (stryCov_9fa48("8305", "8306"), (stryMutAct_9fa48("8307") ? item.voided : (stryCov_9fa48("8307"), !item.voided)) && (stryMutAct_9fa48("8308") ? item.corrected : (stryCov_9fa48("8308"), !item.corrected)))) && (stryMutAct_9fa48("8311") ? item.data.contributionDate > throughDate : stryMutAct_9fa48("8310") ? item.data.contributionDate < throughDate : stryMutAct_9fa48("8309") ? true : (stryCov_9fa48("8309", "8310", "8311"), item.data.contributionDate <= throughDate))))).flatMap(stryMutAct_9fa48("8312") ? () => undefined : (stryCov_9fa48("8312"), item => item.data.allocations)));
    const declared = events.flatMap(stryMutAct_9fa48("8313") ? () => undefined : (stryCov_9fa48("8313"), event => (stryMutAct_9fa48("8316") ? event.data.kind === "openingProgress" || event.data.throughDate <= throughDate : stryMutAct_9fa48("8315") ? false : stryMutAct_9fa48("8314") ? true : (stryCov_9fa48("8314", "8315", "8316"), (stryMutAct_9fa48("8318") ? event.data.kind !== "openingProgress" : stryMutAct_9fa48("8317") ? true : (stryCov_9fa48("8317", "8318"), event.data.kind === (stryMutAct_9fa48("8319") ? "" : (stryCov_9fa48("8319"), "openingProgress")))) && (stryMutAct_9fa48("8322") ? event.data.throughDate > throughDate : stryMutAct_9fa48("8321") ? event.data.throughDate < throughDate : stryMutAct_9fa48("8320") ? true : (stryCov_9fa48("8320", "8321", "8322"), event.data.throughDate <= throughDate)))) ? stryMutAct_9fa48("8323") ? [] : (stryCov_9fa48("8323"), [event.data.allocation]) : stryMutAct_9fa48("8324") ? ["Stryker was here"] : (stryCov_9fa48("8324"), [])));
    return stryMutAct_9fa48("8325") ? {} : (stryCov_9fa48("8325"), {
      verified,
      declared,
      contributions
    });
  }
}
export function paidFor(planId: string, allocations: ContributionAllocation[]) {
  if (stryMutAct_9fa48("8326")) {
    {}
  } else {
    stryCov_9fa48("8326");
    const matching = stryMutAct_9fa48("8327") ? allocations : (stryCov_9fa48("8327"), allocations.filter(stryMutAct_9fa48("8328") ? () => undefined : (stryCov_9fa48("8328"), allocation => stryMutAct_9fa48("8331") ? allocation.planId !== planId : stryMutAct_9fa48("8330") ? false : stryMutAct_9fa48("8329") ? true : (stryCov_9fa48("8329", "8330", "8331"), allocation.planId === planId))));
    return stryMutAct_9fa48("8332") ? {} : (stryCov_9fa48("8332"), {
      amountMinor: total(matching.map(stryMutAct_9fa48("8333") ? () => undefined : (stryCov_9fa48("8333"), allocation => allocation.amountMinor))),
      principalMinor: total(matching.map(stryMutAct_9fa48("8334") ? () => undefined : (stryCov_9fa48("8334"), allocation => allocation.principalMinor))),
      premiumMinor: total(matching.map(stryMutAct_9fa48("8335") ? () => undefined : (stryCov_9fa48("8335"), allocation => allocation.premiumMinor)))
    });
  }
}
export function sourcePaid(entryId: string, allocations: ContributionAllocation[]) {
  if (stryMutAct_9fa48("8336")) {
    {}
  } else {
    stryCov_9fa48("8336");
    return total(allocations.flatMap(stryMutAct_9fa48("8337") ? () => undefined : (stryCov_9fa48("8337"), allocation => stryMutAct_9fa48("8338") ? allocation.sources.map(source => source.principalMinor) : (stryCov_9fa48("8338"), allocation.sources.filter(stryMutAct_9fa48("8339") ? () => undefined : (stryCov_9fa48("8339"), source => stryMutAct_9fa48("8342") ? source.entryId !== entryId : stryMutAct_9fa48("8341") ? false : stryMutAct_9fa48("8340") ? true : (stryCov_9fa48("8340", "8341", "8342"), source.entryId === entryId))).map(stryMutAct_9fa48("8343") ? () => undefined : (stryCov_9fa48("8343"), source => source.principalMinor))))));
  }
}
export async function sourceExpenseFacts(ledger: RecoveryLedger, workspaceId: string, entryId: string, asKnownAt: number) {
  if (stryMutAct_9fa48("8344")) {
    {}
  } else {
    stryCov_9fa48("8344");
    const entry = await ledger.getJournalEntry(entryId);
    if (stryMutAct_9fa48("8347") ? (!entry || entry.workspaceId !== workspaceId || entry.policy !== "cash-expense@1") && entry.postedAt > asKnownAt : stryMutAct_9fa48("8346") ? false : stryMutAct_9fa48("8345") ? true : (stryCov_9fa48("8345", "8346", "8347"), (stryMutAct_9fa48("8349") ? (!entry || entry.workspaceId !== workspaceId) && entry.policy !== "cash-expense@1" : stryMutAct_9fa48("8348") ? false : (stryCov_9fa48("8348", "8349"), (stryMutAct_9fa48("8351") ? !entry && entry.workspaceId !== workspaceId : stryMutAct_9fa48("8350") ? false : (stryCov_9fa48("8350", "8351"), (stryMutAct_9fa48("8352") ? entry : (stryCov_9fa48("8352"), !entry)) || (stryMutAct_9fa48("8354") ? entry.workspaceId === workspaceId : stryMutAct_9fa48("8353") ? false : (stryCov_9fa48("8353", "8354"), entry.workspaceId !== workspaceId)))) || (stryMutAct_9fa48("8356") ? entry.policy === "cash-expense@1" : stryMutAct_9fa48("8355") ? false : (stryCov_9fa48("8355", "8356"), entry.policy !== (stryMutAct_9fa48("8357") ? "" : (stryCov_9fa48("8357"), "cash-expense@1")))))) || (stryMutAct_9fa48("8360") ? entry.postedAt <= asKnownAt : stryMutAct_9fa48("8359") ? entry.postedAt >= asKnownAt : stryMutAct_9fa48("8358") ? false : (stryCov_9fa48("8358", "8359", "8360"), entry.postedAt > asKnownAt)))) return stryMutAct_9fa48("8361") ? {} : (stryCov_9fa48("8361"), {
      minorUnits: 0,
      prefixes: stryMutAct_9fa48("8362") ? ["Stryker was here"] : (stryCov_9fa48("8362"), [])
    });
    const reversal = await ledger.findReversalOf(entryId);
    if (stryMutAct_9fa48("8365") ? reversal || reversal.postedAt <= asKnownAt : stryMutAct_9fa48("8364") ? false : stryMutAct_9fa48("8363") ? true : (stryCov_9fa48("8363", "8364", "8365"), reversal && (stryMutAct_9fa48("8368") ? reversal.postedAt > asKnownAt : stryMutAct_9fa48("8367") ? reversal.postedAt < asKnownAt : stryMutAct_9fa48("8366") ? true : (stryCov_9fa48("8366", "8367", "8368"), reversal.postedAt <= asKnownAt)))) return stryMutAct_9fa48("8369") ? {} : (stryCov_9fa48("8369"), {
      minorUnits: 0,
      prefixes: stryMutAct_9fa48("8370") ? ["Stryker was here"] : (stryCov_9fa48("8370"), [])
    });
    const amounts = stryMutAct_9fa48("8371") ? ["Stryker was here"] : (stryCov_9fa48("8371"), []);
    for (const line of entry.lines) {
      if (stryMutAct_9fa48("8372")) {
        {}
      } else {
        stryCov_9fa48("8372");
        const account = await ledger.getLedgerAccount(line.ledgerAccountId);
        if (stryMutAct_9fa48("8375") ? account?.nature !== "Expense" : stryMutAct_9fa48("8374") ? false : stryMutAct_9fa48("8373") ? true : (stryCov_9fa48("8373", "8374", "8375"), (stryMutAct_9fa48("8376") ? account.nature : (stryCov_9fa48("8376"), account?.nature)) === (stryMutAct_9fa48("8377") ? "" : (stryCov_9fa48("8377"), "Expense")))) if (stryMutAct_9fa48("8378")) {
          ;
        } else {
          stryCov_9fa48("8378");
          amounts.push(line.debitMinorUnits);
        }
      }
    }
    return await expenseEligibility(ledger, stryMutAct_9fa48("8379") ? {} : (stryCov_9fa48("8379"), {
      workspaceId,
      sourceEntryId: entryId,
      originalMinorUnits: total(amounts),
      asKnownAt
    }));
  }
}
export async function planStatus(ledger: RecoveryLedger, snapshot: Snapshot, plan: Plan, allocations: ContributionAllocation[], asKnownAt: number) {
  if (stryMutAct_9fa48("8380")) {
    {}
  } else {
    stryCov_9fa48("8380");
    const events = stryMutAct_9fa48("8381") ? snapshot.events : (stryCov_9fa48("8381"), snapshot.events.filter(stryMutAct_9fa48("8382") ? () => undefined : (stryCov_9fa48("8382"), event => stryMutAct_9fa48("8386") ? event.recordedAt > asKnownAt : stryMutAct_9fa48("8385") ? event.recordedAt < asKnownAt : stryMutAct_9fa48("8384") ? false : stryMutAct_9fa48("8383") ? true : (stryCov_9fa48("8383", "8384", "8385", "8386"), event.recordedAt <= asKnownAt))));
    if (stryMutAct_9fa48("8389") ? events.every(event => event.data.kind === "cancelled" && event.data.planId === plan.id) : stryMutAct_9fa48("8388") ? false : stryMutAct_9fa48("8387") ? true : (stryCov_9fa48("8387", "8388", "8389"), events.some(stryMutAct_9fa48("8390") ? () => undefined : (stryCov_9fa48("8390"), event => stryMutAct_9fa48("8393") ? event.data.kind === "cancelled" || event.data.planId === plan.id : stryMutAct_9fa48("8392") ? false : stryMutAct_9fa48("8391") ? true : (stryCov_9fa48("8391", "8392", "8393"), (stryMutAct_9fa48("8395") ? event.data.kind !== "cancelled" : stryMutAct_9fa48("8394") ? true : (stryCov_9fa48("8394", "8395"), event.data.kind === (stryMutAct_9fa48("8396") ? "" : (stryCov_9fa48("8396"), "cancelled")))) && (stryMutAct_9fa48("8398") ? event.data.planId !== plan.id : stryMutAct_9fa48("8397") ? true : (stryCov_9fa48("8397", "8398"), event.data.planId === plan.id))))))) return stryMutAct_9fa48("8399") ? {} : (stryCov_9fa48("8399"), {
      kind: "Cancelled" as const,
      unsupportedEntryIds: stryMutAct_9fa48("8400") ? ["Stryker was here"] : (stryCov_9fa48("8400"), [])
    });
    if (stryMutAct_9fa48("8403") ? plan.state.kind === "Draft" && plan.state.commitment.activatedAt > asKnownAt : stryMutAct_9fa48("8402") ? false : stryMutAct_9fa48("8401") ? true : (stryCov_9fa48("8401", "8402", "8403"), (stryMutAct_9fa48("8405") ? plan.state.kind !== "Draft" : stryMutAct_9fa48("8404") ? false : (stryCov_9fa48("8404", "8405"), plan.state.kind === (stryMutAct_9fa48("8406") ? "" : (stryCov_9fa48("8406"), "Draft")))) || (stryMutAct_9fa48("8409") ? plan.state.commitment.activatedAt <= asKnownAt : stryMutAct_9fa48("8408") ? plan.state.commitment.activatedAt >= asKnownAt : stryMutAct_9fa48("8407") ? false : (stryCov_9fa48("8407", "8408", "8409"), plan.state.commitment.activatedAt > asKnownAt)))) return stryMutAct_9fa48("8410") ? {} : (stryCov_9fa48("8410"), {
      kind: "Draft" as const,
      unsupportedEntryIds: stryMutAct_9fa48("8411") ? ["Stryker was here"] : (stryCov_9fa48("8411"), [])
    });
    const paid = paidFor(plan.id, allocations);
    if (stryMutAct_9fa48("8414") ? paid.amountMinor !== total(plan.state.commitment.schedule.map(item => item.amountMinor)) : stryMutAct_9fa48("8413") ? false : stryMutAct_9fa48("8412") ? true : (stryCov_9fa48("8412", "8413", "8414"), paid.amountMinor === total(plan.state.commitment.schedule.map(stryMutAct_9fa48("8415") ? () => undefined : (stryCov_9fa48("8415"), item => item.amountMinor))))) return stryMutAct_9fa48("8416") ? {} : (stryCov_9fa48("8416"), {
      kind: "Completed" as const,
      unsupportedEntryIds: stryMutAct_9fa48("8417") ? ["Stryker was here"] : (stryCov_9fa48("8417"), [])
    });
    const unsupportedEntryIds = stryMutAct_9fa48("8418") ? ["Stryker was here"] : (stryCov_9fa48("8418"), []);
    for (const source of plan.terms.sources) {
      if (stryMutAct_9fa48("8419")) {
        {}
      } else {
        stryCov_9fa48("8419");
        const sourceFacts = await sourceExpenseFacts(ledger, plan.workspaceId, source.entryId, asKnownAt);
        const recoveredElsewhere = sourcePaid(source.entryId, stryMutAct_9fa48("8420") ? allocations : (stryCov_9fa48("8420"), allocations.filter(stryMutAct_9fa48("8421") ? () => undefined : (stryCov_9fa48("8421"), allocation => stryMutAct_9fa48("8424") ? allocation.planId === plan.id : stryMutAct_9fa48("8423") ? false : stryMutAct_9fa48("8422") ? true : (stryCov_9fa48("8422", "8423", "8424"), allocation.planId !== plan.id)))));
        let unsupported = stryMutAct_9fa48("8428") ? source.principalMinor + recoveredElsewhere <= sourceFacts.minorUnits : stryMutAct_9fa48("8427") ? source.principalMinor + recoveredElsewhere >= sourceFacts.minorUnits : stryMutAct_9fa48("8426") ? false : stryMutAct_9fa48("8425") ? true : (stryCov_9fa48("8425", "8426", "8427", "8428"), (stryMutAct_9fa48("8429") ? source.principalMinor - recoveredElsewhere : (stryCov_9fa48("8429"), source.principalMinor + recoveredElsewhere)) > sourceFacts.minorUnits);
        for (const change of sourceFacts.prefixes) {
          if (stryMutAct_9fa48("8430")) {
            {}
          } else {
            stryCov_9fa48("8430");
            if (stryMutAct_9fa48("8432") ? false : stryMutAct_9fa48("8431") ? true : (stryCov_9fa48("8431", "8432"), unsupported)) continue;
            const cut = plan.state.commitment.sourceEffectCuts[source.entryId];
            if (stryMutAct_9fa48("8435") ? cut !== undefined || change.sourceSequence <= cut : stryMutAct_9fa48("8434") ? false : stryMutAct_9fa48("8433") ? true : (stryCov_9fa48("8433", "8434", "8435"), (stryMutAct_9fa48("8437") ? cut === undefined : stryMutAct_9fa48("8436") ? true : (stryCov_9fa48("8436", "8437"), cut !== undefined)) && (stryMutAct_9fa48("8440") ? change.sourceSequence > cut : stryMutAct_9fa48("8439") ? change.sourceSequence < cut : stryMutAct_9fa48("8438") ? true : (stryCov_9fa48("8438", "8439", "8440"), change.sourceSequence <= cut)))) continue;
            const historical = await countedAllocations(ledger, snapshot, change.recordedAt);
            const paidAtChange = stryMutAct_9fa48("8441") ? [] : (stryCov_9fa48("8441"), [...historical.verified, ...historical.declared]);
            if (stryMutAct_9fa48("8444") ? paidFor(plan.id, paidAtChange).amountMinor !== total(plan.state.commitment.schedule.map(item => item.amountMinor)) : stryMutAct_9fa48("8443") ? false : stryMutAct_9fa48("8442") ? true : (stryCov_9fa48("8442", "8443", "8444"), paidFor(plan.id, paidAtChange).amountMinor === total(plan.state.commitment.schedule.map(stryMutAct_9fa48("8445") ? () => undefined : (stryCov_9fa48("8445"), item => item.amountMinor))))) continue;
            const recoveredOutsideAtChange = sourcePaid(source.entryId, stryMutAct_9fa48("8446") ? paidAtChange : (stryCov_9fa48("8446"), paidAtChange.filter(stryMutAct_9fa48("8447") ? () => undefined : (stryCov_9fa48("8447"), allocation => stryMutAct_9fa48("8450") ? allocation.planId === plan.id : stryMutAct_9fa48("8449") ? false : stryMutAct_9fa48("8448") ? true : (stryCov_9fa48("8448", "8449", "8450"), allocation.planId !== plan.id)))));
            unsupported = stryMutAct_9fa48("8454") ? source.principalMinor + recoveredOutsideAtChange <= change.eligibleMinorUnits : stryMutAct_9fa48("8453") ? source.principalMinor + recoveredOutsideAtChange >= change.eligibleMinorUnits : stryMutAct_9fa48("8452") ? false : stryMutAct_9fa48("8451") ? true : (stryCov_9fa48("8451", "8452", "8453", "8454"), (stryMutAct_9fa48("8455") ? source.principalMinor - recoveredOutsideAtChange : (stryCov_9fa48("8455"), source.principalMinor + recoveredOutsideAtChange)) > change.eligibleMinorUnits);
          }
        }
        if (stryMutAct_9fa48("8457") ? false : stryMutAct_9fa48("8456") ? true : (stryCov_9fa48("8456", "8457"), unsupported)) if (stryMutAct_9fa48("8458")) {
          ;
        } else {
          stryCov_9fa48("8458");
          unsupportedEntryIds.push(source.entryId);
        }
      }
    }
    if (stryMutAct_9fa48("8461") ? unsupportedEntryIds.length && events.some(event => event.data.kind === "suspended" && event.data.planId === plan.id) : stryMutAct_9fa48("8460") ? false : stryMutAct_9fa48("8459") ? true : (stryCov_9fa48("8459", "8460", "8461"), unsupportedEntryIds.length || (stryMutAct_9fa48("8462") ? events.every(event => event.data.kind === "suspended" && event.data.planId === plan.id) : (stryCov_9fa48("8462"), events.some(stryMutAct_9fa48("8463") ? () => undefined : (stryCov_9fa48("8463"), event => stryMutAct_9fa48("8466") ? event.data.kind === "suspended" || event.data.planId === plan.id : stryMutAct_9fa48("8465") ? false : stryMutAct_9fa48("8464") ? true : (stryCov_9fa48("8464", "8465", "8466"), (stryMutAct_9fa48("8468") ? event.data.kind !== "suspended" : stryMutAct_9fa48("8467") ? true : (stryCov_9fa48("8467", "8468"), event.data.kind === (stryMutAct_9fa48("8469") ? "" : (stryCov_9fa48("8469"), "suspended")))) && (stryMutAct_9fa48("8471") ? event.data.planId !== plan.id : stryMutAct_9fa48("8470") ? true : (stryCov_9fa48("8470", "8471"), event.data.planId === plan.id))))))))) return stryMutAct_9fa48("8472") ? {} : (stryCov_9fa48("8472"), {
      kind: "Suspended" as const,
      unsupportedEntryIds
    });
    return stryMutAct_9fa48("8473") ? {} : (stryCov_9fa48("8473"), {
      kind: "Active" as const,
      unsupportedEntryIds
    });
  }
}
export async function transferEvidence(ledger: RecoveryLedger, workspaceId: string, entryId: string, today: string) {
  if (stryMutAct_9fa48("8474")) {
    {}
  } else {
    stryCov_9fa48("8474");
    const entry = await ledger.getJournalEntry(entryId);
    if (stryMutAct_9fa48("8477") ? (!entry || entry.workspaceId !== workspaceId || entry.policy !== "account-transfer@1" || entry.lines.length !== 2) && entry.accountingDate > today : stryMutAct_9fa48("8476") ? false : stryMutAct_9fa48("8475") ? true : (stryCov_9fa48("8475", "8476", "8477"), (stryMutAct_9fa48("8479") ? (!entry || entry.workspaceId !== workspaceId || entry.policy !== "account-transfer@1") && entry.lines.length !== 2 : stryMutAct_9fa48("8478") ? false : (stryCov_9fa48("8478", "8479"), (stryMutAct_9fa48("8481") ? (!entry || entry.workspaceId !== workspaceId) && entry.policy !== "account-transfer@1" : stryMutAct_9fa48("8480") ? false : (stryCov_9fa48("8480", "8481"), (stryMutAct_9fa48("8483") ? !entry && entry.workspaceId !== workspaceId : stryMutAct_9fa48("8482") ? false : (stryCov_9fa48("8482", "8483"), (stryMutAct_9fa48("8484") ? entry : (stryCov_9fa48("8484"), !entry)) || (stryMutAct_9fa48("8486") ? entry.workspaceId === workspaceId : stryMutAct_9fa48("8485") ? false : (stryCov_9fa48("8485", "8486"), entry.workspaceId !== workspaceId)))) || (stryMutAct_9fa48("8488") ? entry.policy === "account-transfer@1" : stryMutAct_9fa48("8487") ? false : (stryCov_9fa48("8487", "8488"), entry.policy !== (stryMutAct_9fa48("8489") ? "" : (stryCov_9fa48("8489"), "account-transfer@1")))))) || (stryMutAct_9fa48("8491") ? entry.lines.length === 2 : stryMutAct_9fa48("8490") ? false : (stryCov_9fa48("8490", "8491"), entry.lines.length !== 2)))) || (stryMutAct_9fa48("8494") ? entry.accountingDate <= today : stryMutAct_9fa48("8493") ? entry.accountingDate >= today : stryMutAct_9fa48("8492") ? false : (stryCov_9fa48("8492", "8493", "8494"), entry.accountingDate > today)))) throw new RecoveryError(stryMutAct_9fa48("8496") ? "" : (stryCov_9fa48("8496"), "recovery_transfer_ineligible"));
    if (stryMutAct_9fa48("8498") ? false : stryMutAct_9fa48("8497") ? true : (stryCov_9fa48("8497", "8498"), await ledger.findReversalOf(entry.id))) throw new RecoveryError(stryMutAct_9fa48("8500") ? "" : (stryCov_9fa48("8500"), "recovery_transfer_reversed"));
    const source = entry.lines.find(stryMutAct_9fa48("8501") ? () => undefined : (stryCov_9fa48("8501"), line => stryMutAct_9fa48("8505") ? line.creditMinorUnits <= 0 : stryMutAct_9fa48("8504") ? line.creditMinorUnits >= 0 : stryMutAct_9fa48("8503") ? false : stryMutAct_9fa48("8502") ? true : (stryCov_9fa48("8502", "8503", "8504", "8505"), line.creditMinorUnits > 0)));
    const destination = entry.lines.find(stryMutAct_9fa48("8506") ? () => undefined : (stryCov_9fa48("8506"), line => stryMutAct_9fa48("8510") ? line.debitMinorUnits <= 0 : stryMutAct_9fa48("8509") ? line.debitMinorUnits >= 0 : stryMutAct_9fa48("8508") ? false : stryMutAct_9fa48("8507") ? true : (stryCov_9fa48("8507", "8508", "8509", "8510"), line.debitMinorUnits > 0)));
    if (stryMutAct_9fa48("8513") ? (!source || !destination) && source.creditMinorUnits !== destination.debitMinorUnits : stryMutAct_9fa48("8512") ? false : stryMutAct_9fa48("8511") ? true : (stryCov_9fa48("8511", "8512", "8513"), (stryMutAct_9fa48("8515") ? !source && !destination : stryMutAct_9fa48("8514") ? false : (stryCov_9fa48("8514", "8515"), (stryMutAct_9fa48("8516") ? source : (stryCov_9fa48("8516"), !source)) || (stryMutAct_9fa48("8517") ? destination : (stryCov_9fa48("8517"), !destination)))) || (stryMutAct_9fa48("8519") ? source.creditMinorUnits === destination.debitMinorUnits : stryMutAct_9fa48("8518") ? false : (stryCov_9fa48("8518", "8519"), source.creditMinorUnits !== destination.debitMinorUnits)))) throw new RecoveryError(stryMutAct_9fa48("8521") ? "" : (stryCov_9fa48("8521"), "recovery_transfer_ineligible"));
    const [sourceAccount, destinationAccount] = await Promise.all(stryMutAct_9fa48("8522") ? [] : (stryCov_9fa48("8522"), [ledger.getLedgerAccount(source.ledgerAccountId), ledger.getLedgerAccount(destination.ledgerAccountId)]));
    if (stryMutAct_9fa48("8525") ? sourceAccount?.nature !== "Asset" && destinationAccount?.nature !== "Asset" : stryMutAct_9fa48("8524") ? false : stryMutAct_9fa48("8523") ? true : (stryCov_9fa48("8523", "8524", "8525"), (stryMutAct_9fa48("8527") ? sourceAccount?.nature === "Asset" : stryMutAct_9fa48("8526") ? false : (stryCov_9fa48("8526", "8527"), (stryMutAct_9fa48("8528") ? sourceAccount.nature : (stryCov_9fa48("8528"), sourceAccount?.nature)) !== (stryMutAct_9fa48("8529") ? "" : (stryCov_9fa48("8529"), "Asset")))) || (stryMutAct_9fa48("8531") ? destinationAccount?.nature === "Asset" : stryMutAct_9fa48("8530") ? false : (stryCov_9fa48("8530", "8531"), (stryMutAct_9fa48("8532") ? destinationAccount.nature : (stryCov_9fa48("8532"), destinationAccount?.nature)) !== (stryMutAct_9fa48("8533") ? "" : (stryCov_9fa48("8533"), "Asset")))))) throw new RecoveryError(stryMutAct_9fa48("8535") ? "" : (stryCov_9fa48("8535"), "recovery_transfer_ineligible"));
    return stryMutAct_9fa48("8536") ? {} : (stryCov_9fa48("8536"), {
      entry,
      destinationAccountId: destination.ledgerAccountId,
      capacityMinor: minor(destination.debitMinorUnits, stryMutAct_9fa48("8537") ? false : (stryCov_9fa48("8537"), true))
    });
  }
}
export function findPlan(snapshot: Snapshot, id: string): Plan {
  if (stryMutAct_9fa48("8538")) {
    {}
  } else {
    stryCov_9fa48("8538");
    const plan = snapshot.plans.find(stryMutAct_9fa48("8539") ? () => undefined : (stryCov_9fa48("8539"), plan => stryMutAct_9fa48("8542") ? plan.id !== id : stryMutAct_9fa48("8541") ? false : stryMutAct_9fa48("8540") ? true : (stryCov_9fa48("8540", "8541", "8542"), plan.id === id)));
    if (stryMutAct_9fa48("8545") ? false : stryMutAct_9fa48("8544") ? true : stryMutAct_9fa48("8543") ? plan : (stryCov_9fa48("8543", "8544", "8545"), !plan)) throw new RecoveryError(stryMutAct_9fa48("8547") ? "" : (stryCov_9fa48("8547"), "recovery_plan_not_found"));
    return plan;
  }
}
export function validDate(date: string): string {
  if (stryMutAct_9fa48("8548")) {
    {}
  } else {
    stryCov_9fa48("8548");
    if (stryMutAct_9fa48("8549")) {
      ;
    } else {
      stryCov_9fa48("8549");
      periodFromAccountingDate(date);
    }
    return date;
  }
}
export function remainingSources(plan: Plan, allocations: ContributionAllocation[]): SourceAllocation[] {
  if (stryMutAct_9fa48("8550")) {
    {}
  } else {
    stryCov_9fa48("8550");
    return plan.terms.sources.map(stryMutAct_9fa48("8551") ? () => undefined : (stryCov_9fa48("8551"), source => stryMutAct_9fa48("8552") ? {} : (stryCov_9fa48("8552"), {
      ...source,
      principalMinor: minor(stryMutAct_9fa48("8553") ? source.principalMinor + sourcePaid(source.entryId, allocations.filter(allocation => allocation.planId === plan.id)) : (stryCov_9fa48("8553"), source.principalMinor - sourcePaid(source.entryId, stryMutAct_9fa48("8554") ? allocations : (stryCov_9fa48("8554"), allocations.filter(stryMutAct_9fa48("8555") ? () => undefined : (stryCov_9fa48("8555"), allocation => stryMutAct_9fa48("8558") ? allocation.planId !== plan.id : stryMutAct_9fa48("8557") ? false : stryMutAct_9fa48("8556") ? true : (stryCov_9fa48("8556", "8557", "8558"), allocation.planId === plan.id)))))))
    })));
  }
}
export async function sourceExpense(ledger: RecoveryLedger, workspaceId: string, entryId: string, asKnownAt: number) {
  if (stryMutAct_9fa48("8559")) {
    {}
  } else {
    stryCov_9fa48("8559");
    return (await sourceExpenseFacts(ledger, workspaceId, entryId, asKnownAt)).minorUnits;
  }
}
export function ownsSourceReservation(snapshot: Snapshot, plan: Plan, asKnownAt: number): boolean {
  if (stryMutAct_9fa48("8560")) {
    {}
  } else {
    stryCov_9fa48("8560");
    return stryMutAct_9fa48("8563") ? plan.state.kind === "Activated" && plan.state.commitment.activatedAt <= asKnownAt || !snapshot.events.some(event => event.recordedAt <= asKnownAt && event.data.kind === "cancelled" && event.data.planId === plan.id) : stryMutAct_9fa48("8562") ? false : stryMutAct_9fa48("8561") ? true : (stryCov_9fa48("8561", "8562", "8563"), (stryMutAct_9fa48("8565") ? plan.state.kind === "Activated" || plan.state.commitment.activatedAt <= asKnownAt : stryMutAct_9fa48("8564") ? true : (stryCov_9fa48("8564", "8565"), (stryMutAct_9fa48("8567") ? plan.state.kind !== "Activated" : stryMutAct_9fa48("8566") ? true : (stryCov_9fa48("8566", "8567"), plan.state.kind === (stryMutAct_9fa48("8568") ? "" : (stryCov_9fa48("8568"), "Activated")))) && (stryMutAct_9fa48("8571") ? plan.state.commitment.activatedAt > asKnownAt : stryMutAct_9fa48("8570") ? plan.state.commitment.activatedAt < asKnownAt : stryMutAct_9fa48("8569") ? true : (stryCov_9fa48("8569", "8570", "8571"), plan.state.commitment.activatedAt <= asKnownAt)))) && (stryMutAct_9fa48("8572") ? snapshot.events.some(event => event.recordedAt <= asKnownAt && event.data.kind === "cancelled" && event.data.planId === plan.id) : (stryCov_9fa48("8572"), !(stryMutAct_9fa48("8573") ? snapshot.events.every(event => event.recordedAt <= asKnownAt && event.data.kind === "cancelled" && event.data.planId === plan.id) : (stryCov_9fa48("8573"), snapshot.events.some(stryMutAct_9fa48("8574") ? () => undefined : (stryCov_9fa48("8574"), event => stryMutAct_9fa48("8577") ? event.recordedAt <= asKnownAt && event.data.kind === "cancelled" || event.data.planId === plan.id : stryMutAct_9fa48("8576") ? false : stryMutAct_9fa48("8575") ? true : (stryCov_9fa48("8575", "8576", "8577"), (stryMutAct_9fa48("8579") ? event.recordedAt <= asKnownAt || event.data.kind === "cancelled" : stryMutAct_9fa48("8578") ? true : (stryCov_9fa48("8578", "8579"), (stryMutAct_9fa48("8582") ? event.recordedAt > asKnownAt : stryMutAct_9fa48("8581") ? event.recordedAt < asKnownAt : stryMutAct_9fa48("8580") ? true : (stryCov_9fa48("8580", "8581", "8582"), event.recordedAt <= asKnownAt)) && (stryMutAct_9fa48("8584") ? event.data.kind !== "cancelled" : stryMutAct_9fa48("8583") ? true : (stryCov_9fa48("8583", "8584"), event.data.kind === (stryMutAct_9fa48("8585") ? "" : (stryCov_9fa48("8585"), "cancelled")))))) && (stryMutAct_9fa48("8587") ? event.data.planId !== plan.id : stryMutAct_9fa48("8586") ? true : (stryCov_9fa48("8586", "8587"), event.data.planId === plan.id))))))))));
  }
}
export function requireExclusiveSources(snapshot: Snapshot, plan: Plan, asKnownAt: number) {
  if (stryMutAct_9fa48("8588")) {
    {}
  } else {
    stryCov_9fa48("8588");
    if (stryMutAct_9fa48("8591") ? false : stryMutAct_9fa48("8590") ? true : stryMutAct_9fa48("8589") ? ownsSourceReservation(snapshot, plan, asKnownAt) : (stryCov_9fa48("8589", "8590", "8591"), !ownsSourceReservation(snapshot, plan, asKnownAt))) throw new RecoveryError(stryMutAct_9fa48("8593") ? "" : (stryCov_9fa48("8593"), "recovery_plan_inactive"));
    for (const source of plan.terms.sources) {
      if (stryMutAct_9fa48("8594")) {
        {}
      } else {
        stryCov_9fa48("8594");
        if (stryMutAct_9fa48("8597") ? snapshot.plans.every(other => other.id !== plan.id && ownsSourceReservation(snapshot, other, asKnownAt) && other.terms.sources.some(item => item.entryId === source.entryId)) : stryMutAct_9fa48("8596") ? false : stryMutAct_9fa48("8595") ? true : (stryCov_9fa48("8595", "8596", "8597"), snapshot.plans.some(stryMutAct_9fa48("8598") ? () => undefined : (stryCov_9fa48("8598"), other => stryMutAct_9fa48("8601") ? other.id !== plan.id && ownsSourceReservation(snapshot, other, asKnownAt) || other.terms.sources.some(item => item.entryId === source.entryId) : stryMutAct_9fa48("8600") ? false : stryMutAct_9fa48("8599") ? true : (stryCov_9fa48("8599", "8600", "8601"), (stryMutAct_9fa48("8603") ? other.id !== plan.id || ownsSourceReservation(snapshot, other, asKnownAt) : stryMutAct_9fa48("8602") ? true : (stryCov_9fa48("8602", "8603"), (stryMutAct_9fa48("8605") ? other.id === plan.id : stryMutAct_9fa48("8604") ? true : (stryCov_9fa48("8604", "8605"), other.id !== plan.id)) && ownsSourceReservation(snapshot, other, asKnownAt))) && (stryMutAct_9fa48("8606") ? other.terms.sources.every(item => item.entryId === source.entryId) : (stryCov_9fa48("8606"), other.terms.sources.some(stryMutAct_9fa48("8607") ? () => undefined : (stryCov_9fa48("8607"), item => stryMutAct_9fa48("8610") ? item.entryId !== source.entryId : stryMutAct_9fa48("8609") ? false : stryMutAct_9fa48("8608") ? true : (stryCov_9fa48("8608", "8609", "8610"), item.entryId === source.entryId)))))))))) throw new RecoveryError(stryMutAct_9fa48("8612") ? "" : (stryCov_9fa48("8612"), "recovery_source_reserved"));
      }
    }
  }
}