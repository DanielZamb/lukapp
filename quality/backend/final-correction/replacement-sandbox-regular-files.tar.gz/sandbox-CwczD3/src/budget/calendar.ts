// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import type { PeriodKey } from "../accounting/types";
export function monthIndex(month: PeriodKey) {
  if (stryMutAct_9fa48("7045")) {
    {}
  } else {
    stryCov_9fa48("7045");
    return stryMutAct_9fa48("7046") ? (month.year - 1) * 12 + month.month + 1 : (stryCov_9fa48("7046"), (stryMutAct_9fa48("7047") ? (month.year - 1) * 12 - month.month : (stryCov_9fa48("7047"), (stryMutAct_9fa48("7048") ? (month.year - 1) / 12 : (stryCov_9fa48("7048"), (stryMutAct_9fa48("7049") ? month.year + 1 : (stryCov_9fa48("7049"), month.year - 1)) * 12)) + month.month)) - 1);
  }
}
export function compareMonths(a: PeriodKey, b: PeriodKey) {
  if (stryMutAct_9fa48("7050")) {
    {}
  } else {
    stryCov_9fa48("7050");
    return stryMutAct_9fa48("7051") ? monthIndex(a) + monthIndex(b) : (stryCov_9fa48("7051"), monthIndex(a) - monthIndex(b));
  }
}