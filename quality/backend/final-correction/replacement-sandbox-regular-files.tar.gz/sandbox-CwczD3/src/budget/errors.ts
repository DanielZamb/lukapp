// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
export const budgetErrorMessages = {
  budget_not_found: "Budget not found",
  budget_revision_stale: "Budget changed; refresh the plan",
  budget_retired: "Budget is retired",
  budget_revision_invalid: "Budget revision must be a positive whole number",
  budget_effective_month_invalid: "Choose a future month or confirm a retrospective planning change",
  budget_target_invalid: "Choose an active Expense category or a Workspace Expense account",
  budget_cardinality_conflict: "A single standing Budget already applies in these months",
  budget_name_conflict: "Choose a distinct Budget name",
  budget_limit_invalid: "Budget limit and carry cap must be nonnegative whole minor units",
  budget_money_overflow: "Budget amount exceeds the supported whole minor units",
  budget_history_limit: "Budget has reached its supported limit-change history",
  budget_workspace_limit: "Workspace has reached its supported number of Budgets",
  budget_reason_required: "Explain the retrospective planning change"
} as const;
export class BudgetError extends Error {
  constructor(readonly code: keyof typeof budgetErrorMessages) {
    super(budgetErrorMessages[code]);
    this.name = stryMutAct_9fa48("7308") ? "" : (stryCov_9fa48("7308"), "BudgetError");
  }
}