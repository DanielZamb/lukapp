// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { requireWorkspace } from "../accounting/membership";
import { resolveExpenseProposal } from "../accounting/planningReads";
import type { AccountingPlanningReads, CashExpenseProposal, PostedExpenseLine, ProposedExpense } from "../accounting/planningReads";
import type { Money, PeriodKey } from "../accounting/types";
import { compareMonths } from "./calendar";
import { requireBudget } from "./commands";
import { BudgetError } from "./errors";
import { budgetPolicy } from "./types";
import type { Budget, BudgetReads, BudgetTarget, LimitDecision, PlanningSelection, Scope } from "./types";
export type PlanningAmounts = {
  kind: "notStarted" | "retired" | "noLimit";
} | {
  kind: "limited";
  limit: Money;
  carry: Money;
  available: Money;
  remaining: Money;
  overage: Money;
  carryOut: Money;
};
export type MonthEvaluation = {
  month: PeriodKey;
  actual: Money;
  sources: PostedExpenseLine[];
  selectedLimit: LimitDecision | null;
  planning: PlanningAmounts;
};
export type BudgetEvaluation = MonthEvaluation & {
  budgetId: Budget["id"];
  name: string;
  target: BudgetTarget;
  functionalCurrency: string;
  selectedRevision: number;
  currentRevision: number;
  policy: typeof budgetPolicy.version;
  rollover: Budget["rollover"];
  evaluationContract: typeof budgetPolicy.evaluationContract;
  ledgerBasis: "currentPostedLines";
  carryEvidence: MonthEvaluation[];
};
function money(currency: string, value: bigint): Money {
  if (stryMutAct_9fa48("7309")) {
    {}
  } else {
    stryCov_9fa48("7309");
    const minorUnits = Number(value);
    if (stryMutAct_9fa48("7312") ? false : stryMutAct_9fa48("7311") ? true : stryMutAct_9fa48("7310") ? Number.isSafeInteger(minorUnits) : (stryCov_9fa48("7310", "7311", "7312"), !Number.isSafeInteger(minorUnits))) throw new BudgetError(stryMutAct_9fa48("7314") ? "" : (stryCov_9fa48("7314"), "budget_money_overflow"));
    return stryMutAct_9fa48("7315") ? {} : (stryCov_9fa48("7315"), {
      currency,
      minorUnits
    });
  }
}
function positive(value: bigint) {
  if (stryMutAct_9fa48("7316")) {
    {}
  } else {
    stryCov_9fa48("7316");
    return (stryMutAct_9fa48("7320") ? value <= 0n : stryMutAct_9fa48("7319") ? value >= 0n : stryMutAct_9fa48("7318") ? false : stryMutAct_9fa48("7317") ? true : (stryCov_9fa48("7317", "7318", "7319", "7320"), value > 0n)) ? value : 0n;
  }
}
function min(a: bigint, b: bigint) {
  if (stryMutAct_9fa48("7321")) {
    {}
  } else {
    stryCov_9fa48("7321");
    return (stryMutAct_9fa48("7325") ? a >= b : stryMutAct_9fa48("7324") ? a <= b : stryMutAct_9fa48("7323") ? false : stryMutAct_9fa48("7322") ? true : (stryCov_9fa48("7322", "7323", "7324", "7325"), a < b)) ? a : b;
  }
}
function matches(target: BudgetTarget, line: {
  accountId?: string;
  categoryId?: string;
}) {
  if (stryMutAct_9fa48("7326")) {
    {}
  } else {
    stryCov_9fa48("7326");
    switch (target.kind) {
      case stryMutAct_9fa48("7328") ? "" : (stryCov_9fa48("7328"), "totalExpense"):
        if (stryMutAct_9fa48("7327")) {} else {
          stryCov_9fa48("7327");
          return stryMutAct_9fa48("7329") ? false : (stryCov_9fa48("7329"), true);
        }
      case stryMutAct_9fa48("7331") ? "" : (stryCov_9fa48("7331"), "expenseAccount"):
        if (stryMutAct_9fa48("7330")) {} else {
          stryCov_9fa48("7330");
          return stryMutAct_9fa48("7334") ? target.ledgerAccountId !== line.accountId : stryMutAct_9fa48("7333") ? false : stryMutAct_9fa48("7332") ? true : (stryCov_9fa48("7332", "7333", "7334"), target.ledgerAccountId === line.accountId);
        }
      case stryMutAct_9fa48("7336") ? "" : (stryCov_9fa48("7336"), "category"):
        if (stryMutAct_9fa48("7335")) {} else {
          stryCov_9fa48("7335");
          return stryMutAct_9fa48("7339") ? target.categoryId !== line.categoryId : stryMutAct_9fa48("7338") ? false : stryMutAct_9fa48("7337") ? true : (stryCov_9fa48("7337", "7338", "7339"), target.categoryId === line.categoryId);
        }
      default:
        if (stryMutAct_9fa48("7340")) {} else {
          stryCov_9fa48("7340");
          {
            if (stryMutAct_9fa48("7341")) {
              {}
            } else {
              stryCov_9fa48("7341");
              const exhaustive: never = target;
              return exhaustive;
            }
          }
        }
    }
  }
}
function applicableLimit(budget: Budget, month: PeriodKey): LimitDecision | null {
  if (stryMutAct_9fa48("7342")) {
    {}
  } else {
    stryCov_9fa48("7342");
    let selected: LimitDecision | null = null;
    for (const limit of budget.limits) {
      if (stryMutAct_9fa48("7343")) {
        {}
      } else {
        stryCov_9fa48("7343");
        if (stryMutAct_9fa48("7347") ? compareMonths(limit.effective.month, month) <= 0 : stryMutAct_9fa48("7346") ? compareMonths(limit.effective.month, month) >= 0 : stryMutAct_9fa48("7345") ? false : stryMutAct_9fa48("7344") ? true : (stryCov_9fa48("7344", "7345", "7346", "7347"), compareMonths(limit.effective.month, month) > 0)) continue;
        if (stryMutAct_9fa48("7350") ? (!selected || compareMonths(limit.effective.month, selected.effective.month) > 0) && compareMonths(limit.effective.month, selected.effective.month) === 0 && limit.revision > selected.revision : stryMutAct_9fa48("7349") ? false : stryMutAct_9fa48("7348") ? true : (stryCov_9fa48("7348", "7349", "7350"), (stryMutAct_9fa48("7352") ? !selected && compareMonths(limit.effective.month, selected.effective.month) > 0 : stryMutAct_9fa48("7351") ? false : (stryCov_9fa48("7351", "7352"), (stryMutAct_9fa48("7353") ? selected : (stryCov_9fa48("7353"), !selected)) || (stryMutAct_9fa48("7356") ? compareMonths(limit.effective.month, selected.effective.month) <= 0 : stryMutAct_9fa48("7355") ? compareMonths(limit.effective.month, selected.effective.month) >= 0 : stryMutAct_9fa48("7354") ? false : (stryCov_9fa48("7354", "7355", "7356"), compareMonths(limit.effective.month, selected.effective.month) > 0)))) || (stryMutAct_9fa48("7358") ? compareMonths(limit.effective.month, selected.effective.month) === 0 || limit.revision > selected.revision : stryMutAct_9fa48("7357") ? false : (stryCov_9fa48("7357", "7358"), (stryMutAct_9fa48("7360") ? compareMonths(limit.effective.month, selected.effective.month) !== 0 : stryMutAct_9fa48("7359") ? true : (stryCov_9fa48("7359", "7360"), compareMonths(limit.effective.month, selected.effective.month) === 0)) && (stryMutAct_9fa48("7363") ? limit.revision <= selected.revision : stryMutAct_9fa48("7362") ? limit.revision >= selected.revision : stryMutAct_9fa48("7361") ? true : (stryCov_9fa48("7361", "7362", "7363"), limit.revision > selected.revision)))))) selected = limit;
      }
    }
    return selected;
  }
}
function planning(budget: Budget, month: PeriodKey, limit: LimitDecision | null, currency: string, actual: bigint, carry: bigint): PlanningAmounts {
  if (stryMutAct_9fa48("7364")) {
    {}
  } else {
    stryCov_9fa48("7364");
    if (stryMutAct_9fa48("7368") ? compareMonths(month, budget.startMonth) >= 0 : stryMutAct_9fa48("7367") ? compareMonths(month, budget.startMonth) <= 0 : stryMutAct_9fa48("7366") ? false : stryMutAct_9fa48("7365") ? true : (stryCov_9fa48("7365", "7366", "7367", "7368"), compareMonths(month, budget.startMonth) < 0)) return stryMutAct_9fa48("7369") ? {} : (stryCov_9fa48("7369"), {
      kind: stryMutAct_9fa48("7370") ? "" : (stryCov_9fa48("7370"), "notStarted")
    });
    if (stryMutAct_9fa48("7373") ? budget.lifecycle.kind === "retired" || compareMonths(month, budget.lifecycle.effective.month) >= 0 : stryMutAct_9fa48("7372") ? false : stryMutAct_9fa48("7371") ? true : (stryCov_9fa48("7371", "7372", "7373"), (stryMutAct_9fa48("7375") ? budget.lifecycle.kind !== "retired" : stryMutAct_9fa48("7374") ? true : (stryCov_9fa48("7374", "7375"), budget.lifecycle.kind === (stryMutAct_9fa48("7376") ? "" : (stryCov_9fa48("7376"), "retired")))) && (stryMutAct_9fa48("7379") ? compareMonths(month, budget.lifecycle.effective.month) < 0 : stryMutAct_9fa48("7378") ? compareMonths(month, budget.lifecycle.effective.month) > 0 : stryMutAct_9fa48("7377") ? true : (stryCov_9fa48("7377", "7378", "7379"), compareMonths(month, budget.lifecycle.effective.month) >= 0)))) return stryMutAct_9fa48("7380") ? {} : (stryCov_9fa48("7380"), {
      kind: stryMutAct_9fa48("7381") ? "" : (stryCov_9fa48("7381"), "retired")
    });
    if (stryMutAct_9fa48("7384") ? !limit && limit.limit === null : stryMutAct_9fa48("7383") ? false : stryMutAct_9fa48("7382") ? true : (stryCov_9fa48("7382", "7383", "7384"), (stryMutAct_9fa48("7385") ? limit : (stryCov_9fa48("7385"), !limit)) || (stryMutAct_9fa48("7387") ? limit.limit !== null : stryMutAct_9fa48("7386") ? false : (stryCov_9fa48("7386", "7387"), limit.limit === null)))) return stryMutAct_9fa48("7388") ? {} : (stryCov_9fa48("7388"), {
      kind: stryMutAct_9fa48("7389") ? "" : (stryCov_9fa48("7389"), "noLimit")
    });
    return limitedAmounts(budget.rollover, limit.limit, currency, actual, carry);
  }
}
function limitedAmounts(rollover: Budget["rollover"], limit: Money, currency: string, actual: bigint, carry: bigint): PlanningAmounts {
  if (stryMutAct_9fa48("7390")) {
    {}
  } else {
    stryCov_9fa48("7390");
    const incoming = (stryMutAct_9fa48("7393") ? rollover.kind !== "none" : stryMutAct_9fa48("7392") ? false : stryMutAct_9fa48("7391") ? true : (stryCov_9fa48("7391", "7392", "7393"), rollover.kind === (stryMutAct_9fa48("7394") ? "" : (stryCov_9fa48("7394"), "none")))) ? 0n : carry;
    const available = stryMutAct_9fa48("7395") ? BigInt(limit.minorUnits) - incoming : (stryCov_9fa48("7395"), BigInt(limit.minorUnits) + incoming);
    const remaining = stryMutAct_9fa48("7396") ? available + actual : (stryCov_9fa48("7396"), available - actual);
    const carryOut = (stryMutAct_9fa48("7399") ? rollover.kind !== "none" : stryMutAct_9fa48("7398") ? false : stryMutAct_9fa48("7397") ? true : (stryCov_9fa48("7397", "7398", "7399"), rollover.kind === (stryMutAct_9fa48("7400") ? "" : (stryCov_9fa48("7400"), "none")))) ? 0n : min(BigInt(rollover.cap.minorUnits), positive(stryMutAct_9fa48("7401") ? available + positive(actual) : (stryCov_9fa48("7401"), available - positive(actual))));
    return stryMutAct_9fa48("7402") ? {} : (stryCov_9fa48("7402"), {
      kind: stryMutAct_9fa48("7403") ? "" : (stryCov_9fa48("7403"), "limited"),
      limit,
      carry: money(currency, incoming),
      available: money(currency, available),
      remaining: money(currency, remaining),
      overage: money(currency, positive(stryMutAct_9fa48("7404") ? +remaining : (stryCov_9fa48("7404"), -remaining))),
      carryOut: money(currency, carryOut)
    });
  }
}
async function selectedBudgets(store: BudgetReads, input: Scope & {
  selection: PlanningSelection;
}) {
  if (stryMutAct_9fa48("7405")) {
    {}
  } else {
    stryCov_9fa48("7405");
    if (stryMutAct_9fa48("7408") ? input.selection.kind !== "current" : stryMutAct_9fa48("7407") ? false : stryMutAct_9fa48("7406") ? true : (stryCov_9fa48("7406", "7407", "7408"), input.selection.kind === (stryMutAct_9fa48("7409") ? "" : (stryCov_9fa48("7409"), "current")))) return (await store.listBudgets(input.workspaceId)).map(stryMutAct_9fa48("7410") ? () => undefined : (stryCov_9fa48("7410"), budget => stryMutAct_9fa48("7411") ? {} : (stryCov_9fa48("7411"), {
      budget,
      currentRevision: budget.revision
    })));
    const head = await requireBudget(store, input.workspaceId, input.selection.budgetId);
    const budget = await store.getVersion(head.id, input.selection.revision);
    if (stryMutAct_9fa48("7414") ? !budget && budget.workspaceId !== input.workspaceId : stryMutAct_9fa48("7413") ? false : stryMutAct_9fa48("7412") ? true : (stryCov_9fa48("7412", "7413", "7414"), (stryMutAct_9fa48("7415") ? budget : (stryCov_9fa48("7415"), !budget)) || (stryMutAct_9fa48("7417") ? budget.workspaceId === input.workspaceId : stryMutAct_9fa48("7416") ? false : (stryCov_9fa48("7416", "7417"), budget.workspaceId !== input.workspaceId)))) throw new BudgetError(stryMutAct_9fa48("7419") ? "" : (stryCov_9fa48("7419"), "budget_revision_invalid"));
    return stryMutAct_9fa48("7420") ? [] : (stryCov_9fa48("7420"), [stryMutAct_9fa48("7421") ? {} : (stryCov_9fa48("7421"), {
      budget,
      currentRevision: head.revision
    })]);
  }
}
async function evaluateSelected(accounting: AccountingPlanningReads, workspaceId: Budget["workspaceId"], currency: string, month: PeriodKey, selected: Awaited<ReturnType<typeof selectedBudgets>>): Promise<BudgetEvaluation[]> {
  if (stryMutAct_9fa48("7422")) {
    {}
  } else {
    stryCov_9fa48("7422");
    const cache = new Map<string, PostedExpenseLine[]>();
    async function lines(period: PeriodKey) {
      if (stryMutAct_9fa48("7423")) {
        {}
      } else {
        stryCov_9fa48("7423");
        const key = stryMutAct_9fa48("7424") ? `` : (stryCov_9fa48("7424"), `${period.year}:${period.month}`);
        let result = cache.get(key);
        if (stryMutAct_9fa48("7427") ? false : stryMutAct_9fa48("7426") ? true : stryMutAct_9fa48("7425") ? result : (stryCov_9fa48("7425", "7426", "7427"), !result)) {
          if (stryMutAct_9fa48("7428")) {
            {}
          } else {
            stryCov_9fa48("7428");
            result = await accounting.postedExpenseLines(workspaceId, period);
            if (stryMutAct_9fa48("7429")) {
              ;
            } else {
              stryCov_9fa48("7429");
              cache.set(key, result);
            }
          }
        }
        return result;
      }
    }
    const rows: BudgetEvaluation[] = stryMutAct_9fa48("7430") ? ["Stryker was here"] : (stryCov_9fa48("7430"), []);
    for (const {
      budget,
      currentRevision
    } of selected) {
      if (stryMutAct_9fa48("7431")) {
        {}
      } else {
        stryCov_9fa48("7431");
        let first = month.month;
        if (stryMutAct_9fa48("7434") ? budget.rollover.kind === "carryUnspent" || compareMonths(budget.startMonth, month) <= 0 : stryMutAct_9fa48("7433") ? false : stryMutAct_9fa48("7432") ? true : (stryCov_9fa48("7432", "7433", "7434"), (stryMutAct_9fa48("7436") ? budget.rollover.kind !== "carryUnspent" : stryMutAct_9fa48("7435") ? true : (stryCov_9fa48("7435", "7436"), budget.rollover.kind === (stryMutAct_9fa48("7437") ? "" : (stryCov_9fa48("7437"), "carryUnspent")))) && (stryMutAct_9fa48("7440") ? compareMonths(budget.startMonth, month) > 0 : stryMutAct_9fa48("7439") ? compareMonths(budget.startMonth, month) < 0 : stryMutAct_9fa48("7438") ? true : (stryCov_9fa48("7438", "7439", "7440"), compareMonths(budget.startMonth, month) <= 0)))) first = (stryMutAct_9fa48("7443") ? budget.startMonth.year !== month.year : stryMutAct_9fa48("7442") ? false : stryMutAct_9fa48("7441") ? true : (stryCov_9fa48("7441", "7442", "7443"), budget.startMonth.year === month.year)) ? budget.startMonth.month : 1;
        let carry = 0n;
        const history: MonthEvaluation[] = stryMutAct_9fa48("7444") ? ["Stryker was here"] : (stryCov_9fa48("7444"), []);
        for (let number = first; stryMutAct_9fa48("7447") ? number > month.month : stryMutAct_9fa48("7446") ? number < month.month : stryMutAct_9fa48("7445") ? false : (stryCov_9fa48("7445", "7446", "7447"), number <= month.month); stryMutAct_9fa48("7448") ? number-- : (stryCov_9fa48("7448"), number++)) {
          if (stryMutAct_9fa48("7449")) {
            {}
          } else {
            stryCov_9fa48("7449");
            const period = stryMutAct_9fa48("7450") ? {} : (stryCov_9fa48("7450"), {
              year: month.year,
              month: number
            });
            const sources = stryMutAct_9fa48("7451") ? await lines(period) : (stryCov_9fa48("7451"), (await lines(period)).filter(stryMutAct_9fa48("7452") ? () => undefined : (stryCov_9fa48("7452"), line => matches(budget.target, stryMutAct_9fa48("7453") ? {} : (stryCov_9fa48("7453"), {
              accountId: line.account.id,
              categoryId: stryMutAct_9fa48("7454") ? line.category.categoryId : (stryCov_9fa48("7454"), line.category?.categoryId)
            })))));
            const actual = sources.reduce(stryMutAct_9fa48("7455") ? () => undefined : (stryCov_9fa48("7455"), (sum, line) => stryMutAct_9fa48("7456") ? sum + BigInt(line.debitMinorUnits) + BigInt(line.creditMinorUnits) : (stryCov_9fa48("7456"), (stryMutAct_9fa48("7457") ? sum - BigInt(line.debitMinorUnits) : (stryCov_9fa48("7457"), sum + BigInt(line.debitMinorUnits))) - BigInt(line.creditMinorUnits))), 0n);
            const selectedLimit = applicableLimit(budget, period);
            const amounts = planning(budget, period, selectedLimit, currency, actual, carry);
            const evaluated: MonthEvaluation = stryMutAct_9fa48("7458") ? {} : (stryCov_9fa48("7458"), {
              month: period,
              actual: money(currency, actual),
              sources,
              selectedLimit,
              planning: amounts
            });
            carry = (stryMutAct_9fa48("7461") ? amounts.kind !== "limited" : stryMutAct_9fa48("7460") ? false : stryMutAct_9fa48("7459") ? true : (stryCov_9fa48("7459", "7460", "7461"), amounts.kind === (stryMutAct_9fa48("7462") ? "" : (stryCov_9fa48("7462"), "limited")))) ? BigInt(amounts.carryOut.minorUnits) : 0n;
            if (stryMutAct_9fa48("7466") ? number >= month.month : stryMutAct_9fa48("7465") ? number <= month.month : stryMutAct_9fa48("7464") ? false : stryMutAct_9fa48("7463") ? true : (stryCov_9fa48("7463", "7464", "7465", "7466"), number < month.month)) {
              if (stryMutAct_9fa48("7467")) {
                ;
              } else {
                stryCov_9fa48("7467");
                history.push(evaluated);
              }
            } else rows.push(stryMutAct_9fa48("7469") ? {} : (stryCov_9fa48("7469"), {
              ...evaluated,
              budgetId: budget.id,
              name: budget.name,
              target: budget.target,
              functionalCurrency: currency,
              selectedRevision: budget.revision,
              currentRevision,
              policy: budgetPolicy.version,
              rollover: budget.rollover,
              evaluationContract: budgetPolicy.evaluationContract,
              ledgerBasis: stryMutAct_9fa48("7470") ? "" : (stryCov_9fa48("7470"), "currentPostedLines"),
              carryEvidence: history
            }));
          }
        }
      }
    }
    return rows;
  }
}
export async function listBudgets(store: BudgetReads, accounting: AccountingPlanningReads, input: Scope) {
  if (stryMutAct_9fa48("7471")) {
    {}
  } else {
    stryCov_9fa48("7471");
    await requireWorkspace(accounting, input.workspaceId, input.actor);
    return store.listBudgets(input.workspaceId);
  }
}
export async function evaluateBudgets(store: BudgetReads, accounting: AccountingPlanningReads, input: Scope & {
  month: PeriodKey;
  selection: PlanningSelection;
}) {
  if (stryMutAct_9fa48("7472")) {
    {}
  } else {
    stryCov_9fa48("7472");
    const workspace = await requireWorkspace(accounting, input.workspaceId, input.actor);
    const rows = await evaluateSelected(accounting, workspace.id, workspace.functionalCurrency, input.month, await selectedBudgets(store, input));
    return stryMutAct_9fa48("7473") ? {} : (stryCov_9fa48("7473"), {
      workspaceId: workspace.id,
      month: input.month,
      functionalCurrency: workspace.functionalCurrency,
      evaluationContract: budgetPolicy.evaluationContract,
      ledgerBasis: "currentPostedLines" as const,
      rows
    });
  }
}
export type BudgetImpact = {
  kind: "advisory";
  hasPostingAuthority: false;
  blocksPosting: false;
  evaluationContract: typeof budgetPolicy.evaluationContract;
  proposal: ProposedExpense;
  impacts: Array<{
    evaluation: BudgetEvaluation;
    proposedDelta: Money;
    projected: {
      actual: Money;
      planning: PlanningAmounts;
    };
  }>;
};
export async function budgetImpactWarning(store: BudgetReads, accounting: AccountingPlanningReads, input: Scope & {
  proposal: CashExpenseProposal;
}): Promise<BudgetImpact> {
  if (stryMutAct_9fa48("7474")) {
    {}
  } else {
    stryCov_9fa48("7474");
    const workspace = await requireWorkspace(accounting, input.workspaceId, input.actor);
    const proposal = await resolveExpenseProposal(accounting, workspace, input.proposal);
    const evaluations = await evaluateSelected(accounting, workspace.id, workspace.functionalCurrency, proposal.month, await selectedBudgets(store, stryMutAct_9fa48("7475") ? {} : (stryCov_9fa48("7475"), {
      ...input,
      selection: stryMutAct_9fa48("7476") ? {} : (stryCov_9fa48("7476"), {
        kind: stryMutAct_9fa48("7477") ? "" : (stryCov_9fa48("7477"), "current")
      })
    })));
    return stryMutAct_9fa48("7478") ? {} : (stryCov_9fa48("7478"), {
      kind: stryMutAct_9fa48("7479") ? "" : (stryCov_9fa48("7479"), "advisory"),
      hasPostingAuthority: stryMutAct_9fa48("7480") ? true : (stryCov_9fa48("7480"), false),
      blocksPosting: stryMutAct_9fa48("7481") ? true : (stryCov_9fa48("7481"), false),
      evaluationContract: budgetPolicy.evaluationContract,
      proposal,
      impacts: evaluations.map(evaluation => {
        if (stryMutAct_9fa48("7482")) {
          {}
        } else {
          stryCov_9fa48("7482");
          const delta = matches(evaluation.target, stryMutAct_9fa48("7483") ? {} : (stryCov_9fa48("7483"), {
            accountId: proposal.account.ledgerAccountId,
            categoryId: stryMutAct_9fa48("7484") ? proposal.category.categoryId : (stryCov_9fa48("7484"), proposal.category?.categoryId)
          })) ? BigInt(proposal.amount.minorUnits) : 0n;
          const actual = stryMutAct_9fa48("7485") ? BigInt(evaluation.actual.minorUnits) - delta : (stryCov_9fa48("7485"), BigInt(evaluation.actual.minorUnits) + delta);
          const amounts = evaluation.planning;
          const projected = (stryMutAct_9fa48("7488") ? amounts.kind === "limited" : stryMutAct_9fa48("7487") ? false : stryMutAct_9fa48("7486") ? true : (stryCov_9fa48("7486", "7487", "7488"), amounts.kind !== (stryMutAct_9fa48("7489") ? "" : (stryCov_9fa48("7489"), "limited")))) ? amounts : limitedAmounts(evaluation.rollover, amounts.limit, workspace.functionalCurrency, actual, BigInt(amounts.carry.minorUnits));
          return stryMutAct_9fa48("7490") ? {} : (stryCov_9fa48("7490"), {
            evaluation,
            proposedDelta: money(workspace.functionalCurrency, delta),
            projected: stryMutAct_9fa48("7491") ? {} : (stryCov_9fa48("7491"), {
              actual: money(workspace.functionalCurrency, actual),
              planning: projected
            })
          });
        }
      })
    });
  }
}