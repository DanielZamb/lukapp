// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { categorySnapshot, requireCategory } from "../accounting/categories";
import { commandIdentity } from "../accounting/commandIdentity";
import { AccountingError } from "../accounting/errors";
import { requireWorkspace } from "../accounting/membership";
import { clockMonth } from "../accounting/period";
import type { Money, PeriodKey, StoredWorkspace } from "../accounting/types";
import { compareMonths } from "./calendar";
import { BudgetError } from "./errors";
import { budgetPolicy } from "./types";
import type { Budget, BudgetReads, BudgetResult, CreateBudgetInput, Decision, Dependencies, EffectiveChange, RetireBudgetInput, UpdateBudgetInput } from "./types";
function currency(workspace: StoredWorkspace, amount: Money | null) {
  if (stryMutAct_9fa48("7052")) {
    {}
  } else {
    stryCov_9fa48("7052");
    if (stryMutAct_9fa48("7055") ? amount !== null || amount.currency !== workspace.functionalCurrency : stryMutAct_9fa48("7054") ? false : stryMutAct_9fa48("7053") ? true : (stryCov_9fa48("7053", "7054", "7055"), (stryMutAct_9fa48("7057") ? amount === null : stryMutAct_9fa48("7056") ? true : (stryCov_9fa48("7056", "7057"), amount !== null)) && (stryMutAct_9fa48("7059") ? amount.currency === workspace.functionalCurrency : stryMutAct_9fa48("7058") ? true : (stryCov_9fa48("7058", "7059"), amount.currency !== workspace.functionalCurrency)))) throw new AccountingError(stryMutAct_9fa48("7061") ? "" : (stryCov_9fa48("7061"), "currency_mismatch"));
  }
}
function decision(deps: Dependencies, actor: Decision["decidedBy"], revision: number): Decision {
  if (stryMutAct_9fa48("7062")) {
    {}
  } else {
    stryCov_9fa48("7062");
    return stryMutAct_9fa48("7063") ? {} : (stryCov_9fa48("7063"), {
      revision,
      decidedBy: actor,
      decidedAt: deps.clock.now().getTime(),
      policy: budgetPolicy.version
    });
  }
}
function nextRevision(budget: Budget) {
  if (stryMutAct_9fa48("7064")) {
    {}
  } else {
    stryCov_9fa48("7064");
    const revision = stryMutAct_9fa48("7065") ? budget.revision - 1 : (stryCov_9fa48("7065"), budget.revision + 1);
    if (stryMutAct_9fa48("7068") ? false : stryMutAct_9fa48("7067") ? true : stryMutAct_9fa48("7066") ? Number.isSafeInteger(revision) : (stryCov_9fa48("7066", "7067", "7068"), !Number.isSafeInteger(revision))) throw new BudgetError(stryMutAct_9fa48("7070") ? "" : (stryCov_9fa48("7070"), "budget_revision_invalid"));
    return revision;
  }
}
function assertEffective(deps: Dependencies, effective: EffectiveChange, start: PeriodKey) {
  if (stryMutAct_9fa48("7071")) {
    {}
  } else {
    stryCov_9fa48("7071");
    const relative = compareMonths(effective.month, clockMonth(deps.clock.now()));
    if (stryMutAct_9fa48("7074") ? compareMonths(effective.month, start) < 0 && (effective.kind === "prospective" ? relative <= 0 : relative > 0) : stryMutAct_9fa48("7073") ? false : stryMutAct_9fa48("7072") ? true : (stryCov_9fa48("7072", "7073", "7074"), (stryMutAct_9fa48("7077") ? compareMonths(effective.month, start) >= 0 : stryMutAct_9fa48("7076") ? compareMonths(effective.month, start) <= 0 : stryMutAct_9fa48("7075") ? false : (stryCov_9fa48("7075", "7076", "7077"), compareMonths(effective.month, start) < 0)) || ((stryMutAct_9fa48("7080") ? effective.kind !== "prospective" : stryMutAct_9fa48("7079") ? false : stryMutAct_9fa48("7078") ? true : (stryCov_9fa48("7078", "7079", "7080"), effective.kind === (stryMutAct_9fa48("7081") ? "" : (stryCov_9fa48("7081"), "prospective")))) ? stryMutAct_9fa48("7085") ? relative > 0 : stryMutAct_9fa48("7084") ? relative < 0 : stryMutAct_9fa48("7083") ? false : stryMutAct_9fa48("7082") ? true : (stryCov_9fa48("7082", "7083", "7084", "7085"), relative <= 0) : stryMutAct_9fa48("7089") ? relative <= 0 : stryMutAct_9fa48("7088") ? relative >= 0 : stryMutAct_9fa48("7087") ? false : stryMutAct_9fa48("7086") ? true : (stryCov_9fa48("7086", "7087", "7088", "7089"), relative > 0)))) throw new BudgetError(stryMutAct_9fa48("7091") ? "" : (stryCov_9fa48("7091"), "budget_effective_month_invalid"));
  }
}
export async function requireBudget(store: BudgetReads, workspaceId: Budget["workspaceId"], id: Budget["id"]) {
  if (stryMutAct_9fa48("7092")) {
    {}
  } else {
    stryCov_9fa48("7092");
    const budget = await store.getBudget(id);
    if (stryMutAct_9fa48("7095") ? !budget && budget.workspaceId !== workspaceId : stryMutAct_9fa48("7094") ? false : stryMutAct_9fa48("7093") ? true : (stryCov_9fa48("7093", "7094", "7095"), (stryMutAct_9fa48("7096") ? budget : (stryCov_9fa48("7096"), !budget)) || (stryMutAct_9fa48("7098") ? budget.workspaceId === workspaceId : stryMutAct_9fa48("7097") ? false : (stryCov_9fa48("7097", "7098"), budget.workspaceId !== workspaceId)))) throw new BudgetError(stryMutAct_9fa48("7100") ? "" : (stryCov_9fa48("7100"), "budget_not_found"));
    return budget;
  }
}
function overlaps(a: Pick<Budget, "startMonth" | "lifecycle">, b: Pick<Budget, "startMonth" | "lifecycle">) {
  if (stryMutAct_9fa48("7101")) {
    {}
  } else {
    stryCov_9fa48("7101");
    const endA = (stryMutAct_9fa48("7104") ? a.lifecycle.kind !== "retired" : stryMutAct_9fa48("7103") ? false : stryMutAct_9fa48("7102") ? true : (stryCov_9fa48("7102", "7103", "7104"), a.lifecycle.kind === (stryMutAct_9fa48("7105") ? "" : (stryCov_9fa48("7105"), "retired")))) ? a.lifecycle.effective.month : undefined;
    const endB = (stryMutAct_9fa48("7108") ? b.lifecycle.kind !== "retired" : stryMutAct_9fa48("7107") ? false : stryMutAct_9fa48("7106") ? true : (stryCov_9fa48("7106", "7107", "7108"), b.lifecycle.kind === (stryMutAct_9fa48("7109") ? "" : (stryCov_9fa48("7109"), "retired")))) ? b.lifecycle.effective.month : undefined;
    if (stryMutAct_9fa48("7112") ? endA || compareMonths(endA, a.startMonth) <= 0 : stryMutAct_9fa48("7111") ? false : stryMutAct_9fa48("7110") ? true : (stryCov_9fa48("7110", "7111", "7112"), endA && (stryMutAct_9fa48("7115") ? compareMonths(endA, a.startMonth) > 0 : stryMutAct_9fa48("7114") ? compareMonths(endA, a.startMonth) < 0 : stryMutAct_9fa48("7113") ? true : (stryCov_9fa48("7113", "7114", "7115"), compareMonths(endA, a.startMonth) <= 0)))) return stryMutAct_9fa48("7116") ? true : (stryCov_9fa48("7116"), false);
    if (stryMutAct_9fa48("7119") ? endB || compareMonths(endB, b.startMonth) <= 0 : stryMutAct_9fa48("7118") ? false : stryMutAct_9fa48("7117") ? true : (stryCov_9fa48("7117", "7118", "7119"), endB && (stryMutAct_9fa48("7122") ? compareMonths(endB, b.startMonth) > 0 : stryMutAct_9fa48("7121") ? compareMonths(endB, b.startMonth) < 0 : stryMutAct_9fa48("7120") ? true : (stryCov_9fa48("7120", "7121", "7122"), compareMonths(endB, b.startMonth) <= 0)))) return stryMutAct_9fa48("7123") ? true : (stryCov_9fa48("7123"), false);
    return stryMutAct_9fa48("7126") ? !endA || compareMonths(b.startMonth, endA) < 0 || !endB || compareMonths(a.startMonth, endB) < 0 : stryMutAct_9fa48("7125") ? false : stryMutAct_9fa48("7124") ? true : (stryCov_9fa48("7124", "7125", "7126"), (stryMutAct_9fa48("7128") ? !endA && compareMonths(b.startMonth, endA) < 0 : stryMutAct_9fa48("7127") ? true : (stryCov_9fa48("7127", "7128"), (stryMutAct_9fa48("7129") ? endA : (stryCov_9fa48("7129"), !endA)) || (stryMutAct_9fa48("7132") ? compareMonths(b.startMonth, endA) >= 0 : stryMutAct_9fa48("7131") ? compareMonths(b.startMonth, endA) <= 0 : stryMutAct_9fa48("7130") ? false : (stryCov_9fa48("7130", "7131", "7132"), compareMonths(b.startMonth, endA) < 0)))) && (stryMutAct_9fa48("7134") ? !endB && compareMonths(a.startMonth, endB) < 0 : stryMutAct_9fa48("7133") ? true : (stryCov_9fa48("7133", "7134"), (stryMutAct_9fa48("7135") ? endB : (stryCov_9fa48("7135"), !endB)) || (stryMutAct_9fa48("7138") ? compareMonths(a.startMonth, endB) >= 0 : stryMutAct_9fa48("7137") ? compareMonths(a.startMonth, endB) <= 0 : stryMutAct_9fa48("7136") ? false : (stryCov_9fa48("7136", "7137", "7138"), compareMonths(a.startMonth, endB) < 0)))));
  }
}
function assertNames(peers: Budget[], budget: Omit<Budget, "id"> & {
  id?: Budget["id"];
}) {
  if (stryMutAct_9fa48("7139")) {
    {}
  } else {
    stryCov_9fa48("7139");
    for (const peer of peers) {
      if (stryMutAct_9fa48("7140")) {
        {}
      } else {
        stryCov_9fa48("7140");
        if (stryMutAct_9fa48("7143") ? peer.id === budget.id && !overlaps(peer, budget) : stryMutAct_9fa48("7142") ? false : stryMutAct_9fa48("7141") ? true : (stryCov_9fa48("7141", "7142", "7143"), (stryMutAct_9fa48("7145") ? peer.id !== budget.id : stryMutAct_9fa48("7144") ? false : (stryCov_9fa48("7144", "7145"), peer.id === budget.id)) || (stryMutAct_9fa48("7146") ? overlaps(peer, budget) : (stryCov_9fa48("7146"), !overlaps(peer, budget))))) continue;
        if (stryMutAct_9fa48("7149") ? peer.cardinality === "singleStanding" && budget.cardinality === "singleStanding" : stryMutAct_9fa48("7148") ? false : stryMutAct_9fa48("7147") ? true : (stryCov_9fa48("7147", "7148", "7149"), (stryMutAct_9fa48("7151") ? peer.cardinality !== "singleStanding" : stryMutAct_9fa48("7150") ? false : (stryCov_9fa48("7150", "7151"), peer.cardinality === (stryMutAct_9fa48("7152") ? "" : (stryCov_9fa48("7152"), "singleStanding")))) || (stryMutAct_9fa48("7154") ? budget.cardinality !== "singleStanding" : stryMutAct_9fa48("7153") ? false : (stryCov_9fa48("7153", "7154"), budget.cardinality === (stryMutAct_9fa48("7155") ? "" : (stryCov_9fa48("7155"), "singleStanding")))))) throw new BudgetError(stryMutAct_9fa48("7157") ? "" : (stryCov_9fa48("7157"), "budget_cardinality_conflict"));
        if (stryMutAct_9fa48("7160") ? peer.name.toLocaleLowerCase("en-US") !== budget.name.toLocaleLowerCase("en-US") : stryMutAct_9fa48("7159") ? false : stryMutAct_9fa48("7158") ? true : (stryCov_9fa48("7158", "7159", "7160"), (stryMutAct_9fa48("7161") ? peer.name.toLocaleUpperCase("en-US") : (stryCov_9fa48("7161"), peer.name.toLocaleLowerCase(stryMutAct_9fa48("7162") ? "" : (stryCov_9fa48("7162"), "en-US")))) === (stryMutAct_9fa48("7163") ? budget.name.toLocaleUpperCase("en-US") : (stryCov_9fa48("7163"), budget.name.toLocaleLowerCase(stryMutAct_9fa48("7164") ? "" : (stryCov_9fa48("7164"), "en-US")))))) throw new BudgetError(stryMutAct_9fa48("7166") ? "" : (stryCov_9fa48("7166"), "budget_name_conflict"));
      }
    }
  }
}
async function replay(deps: Dependencies, workspaceId: Budget["workspaceId"], key: string, request: string): Promise<BudgetResult | undefined> {
  if (stryMutAct_9fa48("7167")) {
    {}
  } else {
    stryCov_9fa48("7167");
    const receipt = await deps.store.getReceipt(workspaceId, key);
    if (stryMutAct_9fa48("7170") ? false : stryMutAct_9fa48("7169") ? true : stryMutAct_9fa48("7168") ? receipt : (stryCov_9fa48("7168", "7169", "7170"), !receipt)) return undefined;
    if (stryMutAct_9fa48("7173") ? receipt.request === request : stryMutAct_9fa48("7172") ? false : stryMutAct_9fa48("7171") ? true : (stryCov_9fa48("7171", "7172", "7173"), receipt.request !== request)) throw new AccountingError(stryMutAct_9fa48("7175") ? "" : (stryCov_9fa48("7175"), "idempotency_key_conflict"));
    return stryMutAct_9fa48("7176") ? {} : (stryCov_9fa48("7176"), {
      budget: receipt.budget,
      replay: stryMutAct_9fa48("7177") ? false : (stryCov_9fa48("7177"), true)
    });
  }
}
async function finish(deps: Dependencies, budget: Budget, key: string, request: string): Promise<BudgetResult> {
  if (stryMutAct_9fa48("7178")) {
    {}
  } else {
    stryCov_9fa48("7178");
    await deps.store.appendVersion(budget);
    await deps.store.saveReceipt(stryMutAct_9fa48("7179") ? {} : (stryCov_9fa48("7179"), {
      workspaceId: budget.workspaceId,
      idempotencyKey: key,
      request,
      budget
    }));
    return stryMutAct_9fa48("7180") ? {} : (stryCov_9fa48("7180"), {
      budget,
      replay: stryMutAct_9fa48("7181") ? true : (stryCov_9fa48("7181"), false)
    });
  }
}
export async function createBudget(deps: Dependencies, input: CreateBudgetInput): Promise<BudgetResult> {
  if (stryMutAct_9fa48("7182")) {
    {}
  } else {
    stryCov_9fa48("7182");
    const workspace = await requireWorkspace(deps.accounting, input.workspaceId, input.actor, stryMutAct_9fa48("7183") ? "" : (stryCov_9fa48("7183"), "manageBudgets"));
    const request = commandIdentity(stryMutAct_9fa48("7184") ? {} : (stryCov_9fa48("7184"), {
      command: stryMutAct_9fa48("7185") ? "" : (stryCov_9fa48("7185"), "createBudget"),
      ...input
    }));
    const prior = await replay(deps, input.workspaceId, input.idempotencyKey, request);
    if (stryMutAct_9fa48("7187") ? false : stryMutAct_9fa48("7186") ? true : (stryCov_9fa48("7186", "7187"), prior)) return prior;
    if (stryMutAct_9fa48("7188")) {
      ;
    } else {
      stryCov_9fa48("7188");
      currency(workspace, input.limit);
    }
    if (stryMutAct_9fa48("7191") ? input.rollover.kind !== "carryUnspent" : stryMutAct_9fa48("7190") ? false : stryMutAct_9fa48("7189") ? true : (stryCov_9fa48("7189", "7190", "7191"), input.rollover.kind === (stryMutAct_9fa48("7192") ? "" : (stryCov_9fa48("7192"), "carryUnspent")))) if (stryMutAct_9fa48("7193")) {
      ;
    } else {
      stryCov_9fa48("7193");
      currency(workspace, input.rollover.cap);
    }
    let target: Budget["target"];
    switch (input.target.kind) {
      case stryMutAct_9fa48("7195") ? "" : (stryCov_9fa48("7195"), "totalExpense"):
        if (stryMutAct_9fa48("7194")) {} else {
          stryCov_9fa48("7194");
          target = input.target;
          break;
        }
      case stryMutAct_9fa48("7197") ? "" : (stryCov_9fa48("7197"), "expenseAccount"):
        if (stryMutAct_9fa48("7196")) {} else {
          stryCov_9fa48("7196");
          {
            if (stryMutAct_9fa48("7198")) {
              {}
            } else {
              stryCov_9fa48("7198");
              const account = await deps.accounting.getLedgerAccount(input.target.ledgerAccountId);
              if (stryMutAct_9fa48("7201") ? (!account || account.workspaceId !== workspace.id) && account.nature !== "Expense" : stryMutAct_9fa48("7200") ? false : stryMutAct_9fa48("7199") ? true : (stryCov_9fa48("7199", "7200", "7201"), (stryMutAct_9fa48("7203") ? !account && account.workspaceId !== workspace.id : stryMutAct_9fa48("7202") ? false : (stryCov_9fa48("7202", "7203"), (stryMutAct_9fa48("7204") ? account : (stryCov_9fa48("7204"), !account)) || (stryMutAct_9fa48("7206") ? account.workspaceId === workspace.id : stryMutAct_9fa48("7205") ? false : (stryCov_9fa48("7205", "7206"), account.workspaceId !== workspace.id)))) || (stryMutAct_9fa48("7208") ? account.nature === "Expense" : stryMutAct_9fa48("7207") ? false : (stryCov_9fa48("7207", "7208"), account.nature !== (stryMutAct_9fa48("7209") ? "" : (stryCov_9fa48("7209"), "Expense")))))) throw new BudgetError(stryMutAct_9fa48("7211") ? "" : (stryCov_9fa48("7211"), "budget_target_invalid"));
              target = stryMutAct_9fa48("7212") ? {} : (stryCov_9fa48("7212"), {
                ...input.target,
                code: account.code,
                name: account.name
              });
              break;
            }
          }
        }
      case stryMutAct_9fa48("7214") ? "" : (stryCov_9fa48("7214"), "category"):
        if (stryMutAct_9fa48("7213")) {} else {
          stryCov_9fa48("7213");
          {
            if (stryMutAct_9fa48("7215")) {
              {}
            } else {
              stryCov_9fa48("7215");
              const category = await requireCategory(deps.accounting, workspace.id, input.target.categoryId);
              if (stryMutAct_9fa48("7218") ? (category.status !== "active" || category.classification.kind !== "resolved") && category.classification.nature !== "Expense" : stryMutAct_9fa48("7217") ? false : stryMutAct_9fa48("7216") ? true : (stryCov_9fa48("7216", "7217", "7218"), (stryMutAct_9fa48("7220") ? category.status !== "active" && category.classification.kind !== "resolved" : stryMutAct_9fa48("7219") ? false : (stryCov_9fa48("7219", "7220"), (stryMutAct_9fa48("7222") ? category.status === "active" : stryMutAct_9fa48("7221") ? false : (stryCov_9fa48("7221", "7222"), category.status !== (stryMutAct_9fa48("7223") ? "" : (stryCov_9fa48("7223"), "active")))) || (stryMutAct_9fa48("7225") ? category.classification.kind === "resolved" : stryMutAct_9fa48("7224") ? false : (stryCov_9fa48("7224", "7225"), category.classification.kind !== (stryMutAct_9fa48("7226") ? "" : (stryCov_9fa48("7226"), "resolved")))))) || (stryMutAct_9fa48("7228") ? category.classification.nature === "Expense" : stryMutAct_9fa48("7227") ? false : (stryCov_9fa48("7227", "7228"), category.classification.nature !== (stryMutAct_9fa48("7229") ? "" : (stryCov_9fa48("7229"), "Expense")))))) throw new BudgetError(stryMutAct_9fa48("7231") ? "" : (stryCov_9fa48("7231"), "budget_target_invalid"));
              target = stryMutAct_9fa48("7232") ? {} : (stryCov_9fa48("7232"), {
                ...input.target,
                selectedSnapshot: categorySnapshot(category)
              });
              break;
            }
          }
        }
      default:
        if (stryMutAct_9fa48("7233")) {} else {
          stryCov_9fa48("7233");
          {
            if (stryMutAct_9fa48("7234")) {
              {}
            } else {
              stryCov_9fa48("7234");
              const exhaustive: never = input.target;
              return exhaustive;
            }
          }
        }
    }
    const made = decision(deps, input.actor.userId, 1);
    const fields: Omit<Budget, "id"> = stryMutAct_9fa48("7235") ? {} : (stryCov_9fa48("7235"), {
      workspaceId: workspace.id,
      name: stryMutAct_9fa48("7236") ? input.name : (stryCov_9fa48("7236"), input.name.trim()),
      nameDecision: made,
      revision: 1,
      startMonth: input.startMonth,
      target,
      cardinality: input.cardinality,
      rollover: input.rollover,
      created: made,
      lifecycle: stryMutAct_9fa48("7237") ? {} : (stryCov_9fa48("7237"), {
        kind: stryMutAct_9fa48("7238") ? "" : (stryCov_9fa48("7238"), "standing")
      }),
      limits: stryMutAct_9fa48("7239") ? [] : (stryCov_9fa48("7239"), [stryMutAct_9fa48("7240") ? {} : (stryCov_9fa48("7240"), {
        ...made,
        effective: stryMutAct_9fa48("7241") ? {} : (stryCov_9fa48("7241"), {
          kind: stryMutAct_9fa48("7242") ? "" : (stryCov_9fa48("7242"), "initial"),
          month: input.startMonth
        }),
        limit: input.limit
      })])
    });
    const peers = await deps.store.listBudgets(workspace.id);
    if (stryMutAct_9fa48("7246") ? peers.length < budgetPolicy.maxWorkspaceBudgets : stryMutAct_9fa48("7245") ? peers.length > budgetPolicy.maxWorkspaceBudgets : stryMutAct_9fa48("7244") ? false : stryMutAct_9fa48("7243") ? true : (stryCov_9fa48("7243", "7244", "7245", "7246"), peers.length >= budgetPolicy.maxWorkspaceBudgets)) throw new BudgetError(stryMutAct_9fa48("7248") ? "" : (stryCov_9fa48("7248"), "budget_workspace_limit"));
    if (stryMutAct_9fa48("7249")) {
      ;
    } else {
      stryCov_9fa48("7249");
      assertNames(peers, fields);
    }
    const budget = await deps.store.insertBudget(fields);
    return finish(deps, budget, input.idempotencyKey, request);
  }
}
export async function updateBudget(deps: Dependencies, input: UpdateBudgetInput): Promise<BudgetResult> {
  if (stryMutAct_9fa48("7250")) {
    {}
  } else {
    stryCov_9fa48("7250");
    const workspace = await requireWorkspace(deps.accounting, input.workspaceId, input.actor, stryMutAct_9fa48("7251") ? "" : (stryCov_9fa48("7251"), "manageBudgets"));
    const request = commandIdentity(stryMutAct_9fa48("7252") ? {} : (stryCov_9fa48("7252"), {
      command: stryMutAct_9fa48("7253") ? "" : (stryCov_9fa48("7253"), "updateBudget"),
      ...input
    }));
    const prior = await replay(deps, input.workspaceId, input.idempotencyKey, request);
    if (stryMutAct_9fa48("7255") ? false : stryMutAct_9fa48("7254") ? true : (stryCov_9fa48("7254", "7255"), prior)) return prior;
    const current = await requireBudget(deps.store, workspace.id, input.budgetId);
    if (stryMutAct_9fa48("7258") ? current.revision === input.revision : stryMutAct_9fa48("7257") ? false : stryMutAct_9fa48("7256") ? true : (stryCov_9fa48("7256", "7257", "7258"), current.revision !== input.revision)) throw new BudgetError(stryMutAct_9fa48("7260") ? "" : (stryCov_9fa48("7260"), "budget_revision_stale"));
    if (stryMutAct_9fa48("7263") ? current.lifecycle.kind !== "retired" : stryMutAct_9fa48("7262") ? false : stryMutAct_9fa48("7261") ? true : (stryCov_9fa48("7261", "7262", "7263"), current.lifecycle.kind === (stryMutAct_9fa48("7264") ? "" : (stryCov_9fa48("7264"), "retired")))) throw new BudgetError(stryMutAct_9fa48("7266") ? "" : (stryCov_9fa48("7266"), "budget_retired"));
    const changed = decision(deps, input.actor.userId, nextRevision(current));
    let budget: Budget;
    switch (input.change.kind) {
      case stryMutAct_9fa48("7268") ? "" : (stryCov_9fa48("7268"), "rename"):
        if (stryMutAct_9fa48("7267")) {} else {
          stryCov_9fa48("7267");
          budget = stryMutAct_9fa48("7269") ? {} : (stryCov_9fa48("7269"), {
            ...current,
            name: stryMutAct_9fa48("7270") ? input.change.name : (stryCov_9fa48("7270"), input.change.name.trim()),
            nameDecision: changed,
            revision: changed.revision
          });
          if (stryMutAct_9fa48("7271")) {
            ;
          } else {
            stryCov_9fa48("7271");
            assertNames(await deps.store.listBudgets(budget.workspaceId), budget);
          }
          break;
        }
      case stryMutAct_9fa48("7273") ? "" : (stryCov_9fa48("7273"), "limit"):
        if (stryMutAct_9fa48("7272")) {} else {
          stryCov_9fa48("7272");
          if (stryMutAct_9fa48("7274")) {
            ;
          } else {
            stryCov_9fa48("7274");
            assertEffective(deps, input.change.effective, current.startMonth);
          }
          if (stryMutAct_9fa48("7275")) {
            ;
          } else {
            stryCov_9fa48("7275");
            currency(workspace, input.change.limit);
          }
          if (stryMutAct_9fa48("7279") ? current.limits.length < budgetPolicy.maxLimitDecisions : stryMutAct_9fa48("7278") ? current.limits.length > budgetPolicy.maxLimitDecisions : stryMutAct_9fa48("7277") ? false : stryMutAct_9fa48("7276") ? true : (stryCov_9fa48("7276", "7277", "7278", "7279"), current.limits.length >= budgetPolicy.maxLimitDecisions)) throw new BudgetError(stryMutAct_9fa48("7281") ? "" : (stryCov_9fa48("7281"), "budget_history_limit"));
          budget = stryMutAct_9fa48("7282") ? {} : (stryCov_9fa48("7282"), {
            ...current,
            revision: changed.revision,
            limits: stryMutAct_9fa48("7283") ? [] : (stryCov_9fa48("7283"), [...current.limits, stryMutAct_9fa48("7284") ? {} : (stryCov_9fa48("7284"), {
              ...changed,
              effective: input.change.effective,
              limit: input.change.limit
            })])
          });
          break;
        }
      default:
        if (stryMutAct_9fa48("7285")) {} else {
          stryCov_9fa48("7285");
          {
            if (stryMutAct_9fa48("7286")) {
              {}
            } else {
              stryCov_9fa48("7286");
              const exhaustive: never = input.change;
              return exhaustive;
            }
          }
        }
    }
    await deps.store.saveBudget(budget);
    return finish(deps, budget, input.idempotencyKey, request);
  }
}
export async function retireBudget(deps: Dependencies, input: RetireBudgetInput): Promise<BudgetResult> {
  if (stryMutAct_9fa48("7287")) {
    {}
  } else {
    stryCov_9fa48("7287");
    await requireWorkspace(deps.accounting, input.workspaceId, input.actor, stryMutAct_9fa48("7288") ? "" : (stryCov_9fa48("7288"), "manageBudgets"));
    const request = commandIdentity(stryMutAct_9fa48("7289") ? {} : (stryCov_9fa48("7289"), {
      command: stryMutAct_9fa48("7290") ? "" : (stryCov_9fa48("7290"), "retireBudget"),
      ...input
    }));
    const prior = await replay(deps, input.workspaceId, input.idempotencyKey, request);
    if (stryMutAct_9fa48("7292") ? false : stryMutAct_9fa48("7291") ? true : (stryCov_9fa48("7291", "7292"), prior)) return prior;
    const current = await requireBudget(deps.store, input.workspaceId, input.budgetId);
    if (stryMutAct_9fa48("7295") ? current.revision === input.revision : stryMutAct_9fa48("7294") ? false : stryMutAct_9fa48("7293") ? true : (stryCov_9fa48("7293", "7294", "7295"), current.revision !== input.revision)) throw new BudgetError(stryMutAct_9fa48("7297") ? "" : (stryCov_9fa48("7297"), "budget_revision_stale"));
    if (stryMutAct_9fa48("7300") ? current.lifecycle.kind !== "retired" : stryMutAct_9fa48("7299") ? false : stryMutAct_9fa48("7298") ? true : (stryCov_9fa48("7298", "7299", "7300"), current.lifecycle.kind === (stryMutAct_9fa48("7301") ? "" : (stryCov_9fa48("7301"), "retired")))) throw new BudgetError(stryMutAct_9fa48("7303") ? "" : (stryCov_9fa48("7303"), "budget_retired"));
    if (stryMutAct_9fa48("7304")) {
      ;
    } else {
      stryCov_9fa48("7304");
      assertEffective(deps, input.effective, current.startMonth);
    }
    const changed = decision(deps, input.actor.userId, nextRevision(current));
    const budget: Budget = stryMutAct_9fa48("7305") ? {} : (stryCov_9fa48("7305"), {
      ...current,
      revision: changed.revision,
      lifecycle: stryMutAct_9fa48("7306") ? {} : (stryCov_9fa48("7306"), {
        kind: stryMutAct_9fa48("7307") ? "" : (stryCov_9fa48("7307"), "retired"),
        effective: input.effective,
        decision: changed
      })
    });
    await deps.store.saveBudget(budget);
    return finish(deps, budget, input.idempotencyKey, request);
  }
}