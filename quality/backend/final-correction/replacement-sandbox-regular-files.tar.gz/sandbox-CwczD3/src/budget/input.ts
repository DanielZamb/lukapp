// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { AccountingError } from "../accounting/errors";
import { requirePeriodKey } from "../accounting/period";
import type { CashExpenseProposal } from "../accounting/planningReads";
import type { Money } from "../accounting/types";
import { BudgetError } from "./errors";
import type { CreateBudgetInput, EffectiveChange, PlanningSelection, RetireBudgetInput, UpdateBudgetInput } from "./types";
function name(value: string) {
  if (stryMutAct_9fa48("7492")) {
    {}
  } else {
    stryCov_9fa48("7492");
    if (stryMutAct_9fa48("7495") ? false : stryMutAct_9fa48("7494") ? true : stryMutAct_9fa48("7493") ? value.trim() : (stryCov_9fa48("7493", "7494", "7495"), !(stryMutAct_9fa48("7496") ? value : (stryCov_9fa48("7496"), value.trim())))) throw new AccountingError(stryMutAct_9fa48("7498") ? "" : (stryCov_9fa48("7498"), "name_required"));
  }
}
function key(value: string) {
  if (stryMutAct_9fa48("7499")) {
    {}
  } else {
    stryCov_9fa48("7499");
    if (stryMutAct_9fa48("7502") ? false : stryMutAct_9fa48("7501") ? true : stryMutAct_9fa48("7500") ? value.trim() : (stryCov_9fa48("7500", "7501", "7502"), !(stryMutAct_9fa48("7503") ? value : (stryCov_9fa48("7503"), value.trim())))) throw new AccountingError(stryMutAct_9fa48("7505") ? "" : (stryCov_9fa48("7505"), "idempotency_key_required"));
  }
}
export function validateRevision(revision: number) {
  if (stryMutAct_9fa48("7506")) {
    {}
  } else {
    stryCov_9fa48("7506");
    if (stryMutAct_9fa48("7509") ? !Number.isSafeInteger(revision) && revision < 1 : stryMutAct_9fa48("7508") ? false : stryMutAct_9fa48("7507") ? true : (stryCov_9fa48("7507", "7508", "7509"), (stryMutAct_9fa48("7510") ? Number.isSafeInteger(revision) : (stryCov_9fa48("7510"), !Number.isSafeInteger(revision))) || (stryMutAct_9fa48("7513") ? revision >= 1 : stryMutAct_9fa48("7512") ? revision <= 1 : stryMutAct_9fa48("7511") ? false : (stryCov_9fa48("7511", "7512", "7513"), revision < 1)))) throw new BudgetError(stryMutAct_9fa48("7515") ? "" : (stryCov_9fa48("7515"), "budget_revision_invalid"));
  }
}
function nonnegative(amount: Money | null) {
  if (stryMutAct_9fa48("7516")) {
    {}
  } else {
    stryCov_9fa48("7516");
    if (stryMutAct_9fa48("7519") ? amount !== null || !Number.isSafeInteger(amount.minorUnits) || amount.minorUnits < 0 : stryMutAct_9fa48("7518") ? false : stryMutAct_9fa48("7517") ? true : (stryCov_9fa48("7517", "7518", "7519"), (stryMutAct_9fa48("7521") ? amount === null : stryMutAct_9fa48("7520") ? true : (stryCov_9fa48("7520", "7521"), amount !== null)) && (stryMutAct_9fa48("7523") ? !Number.isSafeInteger(amount.minorUnits) && amount.minorUnits < 0 : stryMutAct_9fa48("7522") ? true : (stryCov_9fa48("7522", "7523"), (stryMutAct_9fa48("7524") ? Number.isSafeInteger(amount.minorUnits) : (stryCov_9fa48("7524"), !Number.isSafeInteger(amount.minorUnits))) || (stryMutAct_9fa48("7527") ? amount.minorUnits >= 0 : stryMutAct_9fa48("7526") ? amount.minorUnits <= 0 : stryMutAct_9fa48("7525") ? false : (stryCov_9fa48("7525", "7526", "7527"), amount.minorUnits < 0)))))) throw new BudgetError(stryMutAct_9fa48("7529") ? "" : (stryCov_9fa48("7529"), "budget_limit_invalid"));
  }
}
function effective(value: EffectiveChange) {
  if (stryMutAct_9fa48("7530")) {
    {}
  } else {
    stryCov_9fa48("7530");
    if (stryMutAct_9fa48("7531")) {
      ;
    } else {
      stryCov_9fa48("7531");
      requirePeriodKey(value.month);
    }
    if (stryMutAct_9fa48("7534") ? value.kind === "retrospective" || !value.reason.trim() : stryMutAct_9fa48("7533") ? false : stryMutAct_9fa48("7532") ? true : (stryCov_9fa48("7532", "7533", "7534"), (stryMutAct_9fa48("7536") ? value.kind !== "retrospective" : stryMutAct_9fa48("7535") ? true : (stryCov_9fa48("7535", "7536"), value.kind === (stryMutAct_9fa48("7537") ? "" : (stryCov_9fa48("7537"), "retrospective")))) && (stryMutAct_9fa48("7538") ? value.reason.trim() : (stryCov_9fa48("7538"), !(stryMutAct_9fa48("7539") ? value.reason : (stryCov_9fa48("7539"), value.reason.trim())))))) throw new BudgetError(stryMutAct_9fa48("7541") ? "" : (stryCov_9fa48("7541"), "budget_reason_required"));
  }
}
export function validateCreate(input: Omit<CreateBudgetInput, "actor">) {
  if (stryMutAct_9fa48("7542")) {
    {}
  } else {
    stryCov_9fa48("7542");
    if (stryMutAct_9fa48("7543")) {
      ;
    } else {
      stryCov_9fa48("7543");
      name(input.name);
    }
    if (stryMutAct_9fa48("7544")) {
      ;
    } else {
      stryCov_9fa48("7544");
      key(input.idempotencyKey);
    }
    if (stryMutAct_9fa48("7545")) {
      ;
    } else {
      stryCov_9fa48("7545");
      requirePeriodKey(input.startMonth);
    }
    if (stryMutAct_9fa48("7546")) {
      ;
    } else {
      stryCov_9fa48("7546");
      nonnegative(input.limit);
    }
    if (stryMutAct_9fa48("7549") ? input.rollover.kind !== "carryUnspent" : stryMutAct_9fa48("7548") ? false : stryMutAct_9fa48("7547") ? true : (stryCov_9fa48("7547", "7548", "7549"), input.rollover.kind === (stryMutAct_9fa48("7550") ? "" : (stryCov_9fa48("7550"), "carryUnspent")))) if (stryMutAct_9fa48("7551")) {
      ;
    } else {
      stryCov_9fa48("7551");
      nonnegative(input.rollover.cap);
    }
  }
}
export function validateUpdate(input: Omit<UpdateBudgetInput, "actor">) {
  if (stryMutAct_9fa48("7552")) {
    {}
  } else {
    stryCov_9fa48("7552");
    if (stryMutAct_9fa48("7553")) {
      ;
    } else {
      stryCov_9fa48("7553");
      key(input.idempotencyKey);
    }
    if (stryMutAct_9fa48("7554")) {
      ;
    } else {
      stryCov_9fa48("7554");
      validateRevision(input.revision);
    }
    if (stryMutAct_9fa48("7557") ? input.change.kind !== "rename" : stryMutAct_9fa48("7556") ? false : stryMutAct_9fa48("7555") ? true : (stryCov_9fa48("7555", "7556", "7557"), input.change.kind === (stryMutAct_9fa48("7558") ? "" : (stryCov_9fa48("7558"), "rename")))) {
      if (stryMutAct_9fa48("7559")) {
        ;
      } else {
        stryCov_9fa48("7559");
        name(input.change.name);
      }
    } else {
      if (stryMutAct_9fa48("7560")) {
        {}
      } else {
        stryCov_9fa48("7560");
        if (stryMutAct_9fa48("7561")) {
          ;
        } else {
          stryCov_9fa48("7561");
          effective(input.change.effective);
        }
        if (stryMutAct_9fa48("7562")) {
          ;
        } else {
          stryCov_9fa48("7562");
          nonnegative(input.change.limit);
        }
      }
    }
  }
}
export function validateRetire(input: Omit<RetireBudgetInput, "actor">) {
  if (stryMutAct_9fa48("7563")) {
    {}
  } else {
    stryCov_9fa48("7563");
    if (stryMutAct_9fa48("7564")) {
      ;
    } else {
      stryCov_9fa48("7564");
      key(input.idempotencyKey);
    }
    if (stryMutAct_9fa48("7565")) {
      ;
    } else {
      stryCov_9fa48("7565");
      validateRevision(input.revision);
    }
    if (stryMutAct_9fa48("7566")) {
      ;
    } else {
      stryCov_9fa48("7566");
      effective(input.effective);
    }
  }
}
export function validateSelection(selection: PlanningSelection) {
  if (stryMutAct_9fa48("7567")) {
    {}
  } else {
    stryCov_9fa48("7567");
    if (stryMutAct_9fa48("7570") ? selection.kind !== "revision" : stryMutAct_9fa48("7569") ? false : stryMutAct_9fa48("7568") ? true : (stryCov_9fa48("7568", "7569", "7570"), selection.kind === (stryMutAct_9fa48("7571") ? "" : (stryCov_9fa48("7571"), "revision")))) if (stryMutAct_9fa48("7572")) {
      ;
    } else {
      stryCov_9fa48("7572");
      validateRevision(selection.revision);
    }
  }
}
export function validateProposal(proposal: CashExpenseProposal) {
  if (stryMutAct_9fa48("7573")) {
    {}
  } else {
    stryCov_9fa48("7573");
    if (stryMutAct_9fa48("7576") ? !Number.isSafeInteger(proposal.amount.minorUnits) && proposal.amount.minorUnits <= 0 : stryMutAct_9fa48("7575") ? false : stryMutAct_9fa48("7574") ? true : (stryCov_9fa48("7574", "7575", "7576"), (stryMutAct_9fa48("7577") ? Number.isSafeInteger(proposal.amount.minorUnits) : (stryCov_9fa48("7577"), !Number.isSafeInteger(proposal.amount.minorUnits))) || (stryMutAct_9fa48("7580") ? proposal.amount.minorUnits > 0 : stryMutAct_9fa48("7579") ? proposal.amount.minorUnits < 0 : stryMutAct_9fa48("7578") ? false : (stryCov_9fa48("7578", "7579", "7580"), proposal.amount.minorUnits <= 0)))) throw new AccountingError(stryMutAct_9fa48("7582") ? "" : (stryCov_9fa48("7582"), "amount_must_be_positive"));
    if (stryMutAct_9fa48("7585") ? proposal.categoryRevision === undefined : stryMutAct_9fa48("7584") ? false : stryMutAct_9fa48("7583") ? true : (stryCov_9fa48("7583", "7584", "7585"), proposal.categoryRevision !== undefined)) if (stryMutAct_9fa48("7586")) {
      ;
    } else {
      stryCov_9fa48("7586");
      validateRevision(proposal.categoryRevision);
    }
  }
}